<?php

namespace Drupal\savingscard\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Provides Custom Block.
 *
 * @Block(
 *   id = "signupform_block",
 *   admin_label = @Translation("Signup form"),
 *   category = @Translation("Signup Form Details"),
 * )
 */
class SignupBlock extends BlockBase {

	public function build() {
		$form = \Drupal::formBuilder()->getForm('Drupal\savingscard\Form\SignupForm');
		return $form;
	}

	protected function blockAccess(AccountInterface $account) {
		return AccessResult::allowedIfHasPermission($account, 'access content');
	}

	public function blockForm($form, FormStateInterface $form_state) {
		$config = $this->getConfiguration();
		return $form;
	}

	public function blockSubmit($form, FormStateInterface $form_state) {
		$this->configuration['signup_block_settings'] = $form_state->getValue('signup_block_settings');
	}

}
