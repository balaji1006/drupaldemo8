<?php

namespace Drupal\savingscard\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class DownloadForm.
 *
 * @package Drupal\savingscard\Form
 */
class DownloadForm extends FormBase {


  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'download_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

  $form['download_info'] = array (
		'#type' => 'checkbox',
		'#title' => ('I agree that I have a prescription for ABILIFY (aripiprazole) and commercial insurance. <a href="javascript:;" title="Conditions apply">Conditions apply</a>.'),
		'#attributes' => array('class' => array('download_info')),
		'#required' => false,
		'#prefix' => '<div class="popup__cehckbox"><div class="round">',
		'#suffix' => '</div></div>'
	);
	
	$form['submit'] = [
		'#type' => 'submit',
		'#value' => 'Download Now',
		'#attributes' => array('class' => array('btn payretail__btn')),
	];

    return $form;
  }

  /**
    * {@inheritdoc}
    */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
	public function submitForm(array &$form, FormStateInterface $form_state) {
		global $base_root, $base_url;
		$mem_num = '568609055';
		$grpid = 'ABY56';
		$CEID = '9871';
		$dest_url = '/savings-card-program?&mem_num='.$mem_num.'&grpid='.$grpid.'&CEID='.$CEID;
		$url = Url::fromUri('internal:' . $dest_url);
		$form_state->setRedirectUrl( $url );
	}

}
