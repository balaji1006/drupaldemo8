<?php

namespace Drupal\savingscard\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class MydataController.
 *
 * @package Drupal\savingscard\Controller
 */
class SavingscardController extends ControllerBase {

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function display() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('This page contain all inforamtion about Savings Card Program. ')
    ];
  }

}
