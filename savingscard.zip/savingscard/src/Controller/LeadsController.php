<?php

namespace Drupal\savingscard\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;

/**
 * Class DisplayTableController.
 *
 * @package Drupal\savingscard\Controller
 */
class LeadsController extends ControllerBase {


  public function getContent() {
    // First we'll tell the user what's going on. This content can be found
    // in the twig template file: templates/description.html.twig.
    // @todo: Set up links to create nodes and point to devel module.
    $build = [
      'description' => [
        '#theme' => 'savingscard_description',
        '#description' => 'foo',
        '#attributes' => [],
      ],
    ];
    return $build;
  }

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function display() {
    $header_table = array(
      'id'=>    t('SrNo'),
      'firstname' => t('Name'),
      'email'=>t('Email'),
      'address1' => t('Address'),
      'zip' => t('Zip'),
      'city' => t('City'),
      'state' => t('State'),
      'opt' => t('operations'),
      'opt1' => t('operations'),
    );
    $query = \Drupal::database()->select('savingscard', 'm');
    $query->fields('m', ['id','firstname','lastname','email','address1','address2','zip','city','state']);
    $results = $query->execute()->fetchAll();
        
    $rows=array();
    foreach($results as $data){
        $delete = Url::fromUserInput('/admin/structure/savings-card/delete/'.$data->id);
        $edit   = Url::fromUserInput('/admin/structure/savings-card/mydata?num='.$data->id);
        $rows[] = array(
        'id' =>$data->id,
        'name' => $data->firstname.' '.$data->lastname,
        'email' => $data->email,
        'address1' => $data->address1.', '.$data->address2,
        'zip' => $data->zip,
        'city' => $data->city,
        'state' => $data->state,
        \Drupal::l('Delete', $delete),
        \Drupal::l('Edit', $edit),
        );
    }    
      $form['table'] = [
            '#type' => 'table',
            '#header' => $header_table,
            '#rows' => $rows,
            '#empty' => t('No users found'),
        ];
        //echo '<pre>';print_r($form['table']);exit;
        return $form;
  }

}
