
## Admin App New code

This code contains the functionalities that are moved from payor-portal's admin portal.

This code made in php 7.2 and laravel 5.5

