<?php

/*return [
    'upload_dir' => env('CSV_UPLOAD_DIR'),
];*/

return [
    'upload_dir'=>'/var/tmp/uploads/csv'

];
