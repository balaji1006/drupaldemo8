<?php
return [
    'credentials' => [
        'environment'    => env('DOCUSIGN_ENVIRONMENT'),
        'integrator_key' => env('DOCUSIGN_INTEGRATOR_KEY'),
        'email'          => env('DOCUSIGN_EMAIL'),
        'password'       => env('DOCUSIGN_PASSWORD'),
        'version'        => 'v2',
    ],
    'email' => 'aortiz@revopay.com'
];
