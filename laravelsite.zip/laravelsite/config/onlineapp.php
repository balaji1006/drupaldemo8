<?php

return [
    'upload_onlineapp_dir' => env('ONLINEAPP_UPLOAD_DIR'),
];

