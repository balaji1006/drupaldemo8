<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class TaReports extends Model
{
    public function getUsersPaidByMonth() {
        $properties = array();
        $groupIds = [12,16,18,24,29,49,105,337,366,384,389,576,671,723,736,739,747,751,758,870,894,1022,1028,1048,1076,1096,1144,1156,1226,1232];
		$properties = DB::table('properties')
                ->join('companies', 'companies.id', '=', 'properties.id_companies')
                ->join('partners', 'partners.id', '=', 'companies.id_partners')
                ->join('accounting_transactions', 'accounting_transactions.property_id', '=', 'properties.id')
                ->leftjoin('web_users', 'web_users.web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->select('partners.partner_title', 'accounting_transactions.trans_first_post_date as fromdate','companies.company_name', 'accounting_transactions.trans_first_post_date as todate','properties.name_clients', 'properties.id', 'properties.units')
				->where('properties.status_pp', 1)
                ->where('properties.name_clients', 'NOT LIKE', '%misc%')
                //->where('properties.status_clients', 1)
                //->whereIn('companies.id', $groupIds) //change for each search;
				->where('accounting_transactions.trans_status', 1)
				->where('accounting_transactions.is_convenience_fee_trans', 0)
                ->where('accounting_transactions.source', '!=', 'NACHA')
                ->where('web_users.account_number', '!=', '')
                ->where('accounting_transactions.trans_type', '<', 2);
				
		return $properties;		
           
	}
}
