<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UsersAccessPartners extends Model
{

    protected $table = 'users_access_partners';
    protected $primaryKey = null;
    public $timestamps = false;
    public $incrementing = false;

    public function user()
    {
        return $this->belongsTo('App\Model\UsersAdmin', 'users_admin_id');
    }

    public function partner()
    {
        return $this->belongsTo('App\Model\Partners', 'partners_id');
    }
}
