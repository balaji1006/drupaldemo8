<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Bill extends Model
{

    protected $table = 'bill';
    public $timestamps = false;
    
    function getByFilter($idlevel){
        $query= DB::table($this->table)->join('vendor','bill.vendor_id','=','vendor.id')->where('bill.property_id',$idlevel)->select('bill.id','bill.name','bill.amount','bill.invoice','bill.status','bill.cycle','bill.recurring','bill.due_from','bill.due_to','vendor.vname as vendor','vendor.eid');
        return $query;
    }
    
    function cancelBill($id){
        DB::table($this->table)->where('id',$id)->delete();
    }
    
    function getBillById($bid){
        $result=DB::table($this->table)->where('id','=',$bid)->first();
        return $result;
    }
    
    function updateBill($id,$newbill){
        DB::table($this->table)->where('id','=',$id)->update($newbill);
    }
    
    function setStatus($id,$status){
        DB::table($this->table)->where('id','=',$id)->update(['status'=>$status]);
    }
}