<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Collection;

class WebUsers extends Model
{

    protected $table = 'web_users';
    public $timestamps = false;
    protected $primaryKey = 'web_user_id';

    function getUsrFirstName_Photo($web_user_id)
    {
        $result = $this->select('first_name', 'photo')->where('web_user_id', $web_user_id)->first();
        if (empty($result['photo'])) {
            $result['photo'] = '/img/calendar.png';
        }
        return $result;
    }

    function getMinimalDataFind($idproperty, $acc)
    {
        if ($acc == "") {
            return null;
        }
        $result = $this->where('property_id', '=', $idproperty)->where('web_status', '<', 1000)->where('account_number', '=', $acc)->select('companyname', 'property_id', 'account_number', 'first_name', 'last_name', 'email_address', 'web_user_id', 'web_status', 'phone_number')->first();
        return $result;
    }

    function getMinimalDataFindId($idproperty, $web_user_id)
    {
        $result = $this->where('property_id', '=', $idproperty)->where('web_status', '<', 1000)->where('web_user_id', '=', $web_user_id)->select('companyname', 'account_number', 'first_name', 'last_name', 'email_address', 'web_user_id', 'web_status', 'phone_number')->first();
        return $result;
    }

    function getOClickInfo($idproperty, $web_user_id, $trans_id, $profile_id)
    {
        $result = DB::table('oneclick_reminder')->where('id_properties', $idproperty)
                ->where('web_user_id', $web_user_id)
                ->where('trans_id', $trans_id)
                ->where('profile_id', $profile_id)
                ->first();
        return $result;
    }

    function getOneClickInfoBy_ID($id)
    {
        $result = DB::table('oneclick_reminder')->where('id', $id)->first();
        return $result;
    }

    function insertOClickReminder($partner_id, $company_id, $property_id, $web_user_id, $trans_id, $profile_id, $day, $frequency, $next_reminder)
    {
        DB::table('oneclick_reminder')->insert(
            ['id_partners' => $partner_id, 'id_companies' => $company_id, 'id_properties' => $property_id, 'web_user_id' => $web_user_id,
                    'trans_id' => $trans_id, 'profile_id' => $profile_id, 'day' => $day, 'frequency' => $frequency, 'next_reminder' => $next_reminder, 'created_at' => date("Y-m-d H:i:s")]
        );
    }

    function cancelOClickReminderBy_ID($id)
    {
        DB::table('oneclick_reminder')->where('id', $id)->update(['status' => '0'
        ]);
    }

    function reactiveOClickReminderBy_ID($id, $day, $frequency, $next_reminder)
    {
        DB::table('oneclick_reminder')->where('id', $id)->update(['status' => '1', 'day' => $day, 'frequency' => $frequency, 'next_reminder' => $next_reminder]);
    }

    function getOneClickReminderBy_WebUsrId($web_user_id)
    {
        $result = DB::table('oneclick_reminder')->where('web_user_id', $web_user_id)->where('status', 1)->get();
        return $result;
    }

    function updateNextReminder($id, $next_reminder)
    {
        DB::table('oneclick_reminder')->where('id', $id)->update([
            'next_reminder' => $next_reminder
        ]);
    }

    function updateOCToken($id, $token)
    {
        DB::table('oneclick_reminder')->where('id', $id)->update([
            'token' => $token
        ]);
    }

    function existTokenOCReminder($web_user_id, $property_id, $trans_id)
    {
        $result = DB::table('oneclick_reminder')
                ->where('web_user_id', $web_user_id)
                ->where('id_properties', $property_id)
                ->where('trans_id', $trans_id)
                ->where('status', 1)
                ->select('token')
                ->first();

        if (empty($result['token'])) {
            return false;
        }
        return true;
    }

    function cancelOneClick($trans_id, $web_user_id, $property_id)
    {
        $oneclick = DB::table('oneclick_reminder')
                ->where('web_user_id', $web_user_id)
                ->where('id_properties', $property_id)
                ->where('trans_id', $trans_id)
                ->where('status', 1)
                ->select('token')
                ->first();
        if (empty($oneclick)) {
            return "An active 1-Click Reminder was not found for this transaction";
        }
        DB::table('oneclick_reminder')
                ->where('web_user_id', $web_user_id)
                ->where('id_properties', $property_id)
                ->where('trans_id', $trans_id)
                ->where('status', 1)->update([
            'status' => 0
                ]);
        return "1-Click Reminder successfully canceled";
    }

    function isAutoLimit($uid, $limit = 0)
    {
        $result = DB::table('accounting_recurring_transactions')->where('trans_web_user_id', '=', $uid)->where('trans_status', '=', 1)->count();
        if (!empty($limit)) {
            if ($result >= $limit) {
                return true;
            }
        }
        return false;
    }

    function existTokenAutoPayExtend($token, $trans_id, $property_id, $web_user_id)
    {
        $result = DB::table('autopay_extend')
                ->where('web_user_id', $web_user_id)
                ->where('id_properties', $property_id)
                ->where('trans_id', $trans_id)
                ->where('token', $token)
                ->where('status', 1)
                ->select('id')
                ->first();

        if (empty($result['id'])) {
            return false;
        }
        return true;
    }

    function expiredDayOneClick($idproperty, $web_user_id, $trans_id)
    {
        $result = DB::table('oneclick_reminder')
                ->where('web_user_id', $web_user_id)
                ->where('id_properties', $idproperty)
                ->where('trans_id', $trans_id)
                ->where('status', 1)
                ->select('next_reminder')
                ->first();

        if (empty($result['next_reminder'])) {
            return true;
        }
        $activetime = strtotime("-5 day");
        $strtime = strtotime($result['next_reminder']);
        if ($activetime > $strtime) {
            return true;
        }
        return false;
    }

    public function getWebUserListByFields($idlevel, $level, $fieldstoincluded)
    {

        $webuserlist = array();
        if ($level == 'P') {
            //echo '<pre>';
            //print_r($whereCondition);
            $query = DB::table($this->table)
                    ->join('properties', 'properties.id', '=', 'web_users.property_id')
                    ->join('companies', 'companies.id', '=', 'properties.id_companies')
                    ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                    ->select($fieldstoincluded);
            if ($idlevel != '-954581') {
                $query->where('web_status', '<', 1000);
                $query->where('properties.id_partners', '=', $idlevel);
            }

            $webuserlist = $query->get();
        } elseif ($level == 'M') {
            //echo '<pre>';
            //print_r($whereCondition);
            $query = DB::table($this->table)
                    ->join('properties', 'properties.id', '=', 'web_users.property_id')
                    ->join('companies', 'companies.id', '=', 'properties.id_companies')
                    ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                    ->select($fieldstoincluded);
            if ($idlevel != '-954581') {
                $query->where('web_status', '<', 1000);
                $query->where('web_users.property_id', '=', $idlevel);
            }

            $webuserlist = $query->get();
        } elseif ($level == 'G') {
            //echo '<pre>';
            //print_r($whereCondition);
            $query = DB::table($this->table)
                    ->join('properties', 'properties.id', '=', 'web_users.property_id')
                    ->join('companies', 'companies.id', '=', 'properties.id_companies')
                    ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                    ->select($fieldstoincluded);
            if ($idlevel != '-954581') {
                $query->where('web_status', '<', 1000);
                $query->where('properties.id_companies', '=', $idlevel);
            }

            $webuserlist = $query->get();
        }

        return $webuserlist;
    }

    public function getWebUserList($idlevel, $level, $whereCondition = array())
    {

        //echo $idlevel.' == '.$level; die;
        $webuserlist = array();
        $daterangecondition = array();

        switch (strtoupper($level)) {
            case "B":
                $partnersA=DB::table('branch_partner')->whereIn('branch_id',[$idlevel])->select('id_partners')->get();
                $partners=array();
                foreach($partnersA as $pa){
                    $partners[]=$pa->id_partners;
                }
                $query = DB::table($this->table)
                        ->join('properties', 'properties.id', '=', 'web_users.property_id')
                        ->join('companies', 'companies.id', '=', 'properties.id_companies')
                        ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                        ->whereIn('properties.id_partners',$partners)
                        ->select('web_user_id as id', 'partners.partner_title as partner', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.companyname', 'account_number as webuser', 'first_name', 'last_name', 'username', 'email_address as email', 'web_users.phone_number as phone', 'web_users.address', 'address_unit as unit', 'web_users.city', DB::raw('UPPER(web_users.state) as state'), 'web_users.zip', 'balance', 'web_status as status', 'web_users.last_updated', 'web_users.last_updated_by', 'web_users.suppression', 'web_users.companyname');
                //building search parameter if any only for export
                if (!empty($whereCondition)) {
                    foreach ($whereCondition as $key => $value) {
                        if (stristr($value, 'date')) {
                            $valueArray = explode('=', $value);
                            if ($valueArray[1] != '') {
                                $date = explode('/', $valueArray[1]);
                                $daterangecondition[] = $date[2] . '-' . $date[0] . '-' . $date[1];
                            }
                        } else {
                            $valueArray = explode('=', $value);
                            if ($valueArray[0] != 'search') {
                                if ($valueArray[0] == 'address') {
                                    $query->where('web_users.' . $valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                } elseif ($valueArray[0] == 'state') {
                                    $query->where('web_users.' . $valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                } else {
                                    $query->where($valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                }
                            }
                        }
                    }
                }
                $webuserlist = $query;
                break;
            case "P":
                $query = DB::table($this->table)
                        ->join('properties', 'properties.id', '=', 'web_users.property_id')
                        ->join('companies', 'companies.id', '=', 'properties.id_companies')
                        ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                        ->select('web_user_id as id', 'partners.partner_title as partner', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.companyname', 'account_number as webuser', 'first_name', 'last_name', 'username', 'email_address as email', 'web_users.phone_number as phone', 'web_users.address', 'address_unit as unit', 'web_users.city', DB::raw('UPPER(web_users.state) as state'), 'web_users.zip', 'balance', 'web_status as status', 'web_users.last_updated', 'web_users.last_updated_by', 'web_users.suppression', 'web_users.companyname');
                $query->where('web_status', '<', 1000);
                $query->where('properties.id_partners', $idlevel);
                //building search parameter if any only for export
                if (!empty($whereCondition)) {
                    foreach ($whereCondition as $key => $value) {
                        if (stristr($value, 'date')) {
                            $valueArray = explode('=', $value);
                            if ($valueArray[1] != '') {
                                $date = explode('/', $valueArray[1]);
                                $daterangecondition[] = $date[2] . '-' . $date[0] . '-' . $date[1];
                            }
                        } else {
                            $valueArray = explode('=', $value);
                            if ($valueArray[0] != 'search') {
                                if ($valueArray[0] == 'address') {
                                    $query->where('web_users.' . $valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                } elseif ($valueArray[0] == 'state') {
                                    $query->where('web_users.' . $valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                } else {
                                    $query->where($valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                }
                            }
                        }
                    }
                }
                $webuserlist = $query;
                break;
            case "G":
                $query = DB::table($this->table)
                        ->join('properties', 'properties.id', '=', 'web_users.property_id')
                        ->join('companies', 'companies.id', '=', 'properties.id_companies')
                        ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                        ->select('web_user_id as id', 'partners.partner_title as partner', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.companyname', 'account_number as webuser', 'first_name', 'last_name', 'username', 'email_address as email', 'web_users.phone_number as phone', 'web_users.address', 'address_unit as unit', 'web_users.city', DB::raw('UPPER(web_users.state) as state'), 'web_users.zip', 'balance', 'web_status as status', 'web_users.last_updated', 'web_users.last_updated_by', 'web_users.suppression');
                $query->where('web_status', '<', 1000);
                $query->whereIn('properties.id_companies', explode('!', $idlevel));
                $webuserlist = $query;
                break;
            case "M":
                //echo '<pre>';
                //print_r($whereCondition);
                $query = DB::table($this->table)
                        ->join('properties', 'properties.id', '=', 'web_users.property_id')
                        ->join('companies', 'companies.id', '=', 'properties.id_companies')
                        ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                        ->select('web_user_id as id', 'partners.partner_title as partner', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.companyname', 'account_number as webuser', 'first_name', 'last_name', 'username', 'email_address as email', 'web_users.phone_number as phone', 'web_users.address', 'address_unit as unit', 'web_users.city', DB::raw('UPPER(web_users.state) as state'), 'web_users.zip', 'balance', 'web_status as status', 'web_users.last_updated', 'web_users.last_updated_by', 'web_users.suppression');
                $query->where('web_status', '<', 1000);
                $query->whereIn('web_users.property_id', explode('!', $idlevel));
                $webuserlist = $query;
                break;
            case "A":
            default:    
                $query = DB::table($this->table)
                        ->join('properties', 'properties.id', '=', 'web_users.property_id')
                        ->join('companies', 'companies.id', '=', 'properties.id_companies')
                        ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                        ->select('web_user_id as id', 'partners.partner_title as partner', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.companyname', 'account_number as webuser', 'first_name', 'last_name', 'username', 'email_address as email', 'web_users.phone_number as phone', 'web_users.address', 'address_unit as unit', 'web_users.city', DB::raw('UPPER(web_users.state) as state'), 'web_users.zip', 'balance', 'web_status as status', 'web_users.last_updated', 'web_users.last_updated_by', 'web_users.suppression', 'web_users.companyname');
                //building search parameter if any only for export
                if (!empty($whereCondition)) {
                    foreach ($whereCondition as $key => $value) {
                        if (stristr($value, 'date')) {
                            $valueArray = explode('=', $value);
                            if ($valueArray[1] != '') {
                                $date = explode('/', $valueArray[1]);
                                $daterangecondition[] = $date[2] . '-' . $date[0] . '-' . $date[1];
                            }
                        } else {
                            $valueArray = explode('=', $value);
                            if ($valueArray[0] != 'search') {
                                if ($valueArray[0] == 'address') {
                                    $query->where('web_users.' . $valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                } elseif ($valueArray[0] == 'state') {
                                    $query->where('web_users.' . $valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                } else {
                                    $query->where($valueArray[0], 'like', '%' . $valueArray[1] . '%');
                                }
                            }
                        }
                    }
                }
                $webuserlist = $query;
                break;
        }
        return $webuserlist;
    }

    public function getWebUserdetail($web_user_id)
    {
        $webuserdetail = DB::table($this->table)
                ->join('properties', 'properties.id', '=', 'web_users.property_id')
                ->join('companies', 'companies.id', '=', 'properties.id_companies')
                ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                ->select('compositeID_clients', 'web_user_id as id', 'partners.partner_title as partner', 'partners.id as partner_id', 'companies.company_name as group', 'companies.id as company_id', 'properties.name_clients as merchant', 'properties.id as merchant_id', 'companyname', 'account_number as webuser', 'first_name', 'last_name', 'username', 'email_address as email', 'web_users.phone_number as phone', 'web_users.address', 'address_unit as unit', 'web_users.city', DB::raw('UPPER(web_users.state) as state'), 'web_users.zip', 'balance', 'web_status as status', 'web_users.last_updated', 'web_users.last_updated_by', 'web_users.suppression')
                ->where('web_users.web_user_id', '=', $web_user_id)
                ->first();

        return $webuserdetail;
    }

    public function getPartnerList()
    {

        $partnerlist = DB::table('partners')
                ->pluck('partners.partner_title', 'id');

        return $partnerlist;
    }

    public function getCompanyList()
    {

        $companylist = DB::table('companies')
                ->pluck('companies.company_name', 'id');

        return $companylist;
    }

    public function getCompanyListByPartner($idp)
    {

        $companylist = DB::table('companies')
                ->where('id_partners', $idp)
                ->pluck('companies.company_name', 'id');

        return $companylist;
    }

    public function getMerchantList()
    {

        $merchantlist = DB::table('properties')
                ->pluck('properties.name_clients', 'id');

        return $merchantlist;
    }

    public function getMerchantListByGroup($idg)
    {

        $merchantlist = DB::table('properties')
                ->where('id_companies', $idg)
                ->pluck('properties.name_clients', 'id');

        return $merchantlist;
    }

    public function saveWebUser($webuserdata = array())
    {
        if (isset($webuserdata['_token'])) {
            unset($webuserdata['_token']);
        }
        if (isset($webuserdata['isError'])) {
            unset($webuserdata['isError']);
        }
        if (isset($webuserdata['name_clients'])) {
            $webuserdata['property_id'] = $webuserdata['name_clients'];
            unset($webuserdata['name_clients']);
        }

        if (isset($webuserdata['partner_title'])) {
            //$webuserdata['property_id']=$webuserdata['name_clients'];
            unset($webuserdata['partner_title']);
        }

        if (isset($webuserdata['company_name'])) {
            //$webuserdata['property_id']=$webuserdata['name_clients'];
            unset($webuserdata['company_name']);
        }


        $webuserdata['last_updated_by'] = 'admin';

        if (isset($webuserdata['id']) && $webuserdata['id'] > 0) {
            $web_user_id = $webuserdata['id'];
            unset($webuserdata['id']);
            //verify account number
            $property_id = $this->get1UserInfo($web_user_id, 'property_id');
            if (isset($webuserdata['account_number']) && trim($webuserdata['account_number']) != '') {
                $ct = DB::table($this->table)->where('web_user_id', '!=', $web_user_id)->where('web_status', '<', 1000)->where('account_number', '=', trim($webuserdata['account_number']))->where('property_id', '=', $property_id)->count();
                if ($ct > 0) {
                    return -3;
                }
            }
            //verify username
            if (isset($webuserdata['username']) && trim($webuserdata['username']) != '') {
                $ct = DB::table($this->table)->where('web_user_id', '!=', $web_user_id)->where('web_status', '<', 1000)->where('username', '=', trim($webuserdata['username']))->where('property_id', '=', $property_id)->count();
                if ($ct > 0) {
                    return -6;
                }
            }
            DB::table($this->table)
                    ->where('web_user_id', $web_user_id)
                    ->update($webuserdata);
            return $web_user_id;
        } else {
            //verify account number
            $property_id = $webuserdata['property_id'];
            if (isset($webuserdata['account_number']) && trim($webuserdata['account_number']) != '') {
                $ct = DB::table($this->table)->where('web_status', '<', 1000)->where('account_number', '=', trim($webuserdata['account_number']))->where('property_id', '=', $property_id)->count();
                if ($ct > 0) {
                    return -3;
                }
            }
            //verify username
            if (isset($webuserdata['username']) && trim($webuserdata['username']) != '') {
                $ct = DB::table($this->table)->where('web_status', '<', 1000)->where('username', '=', trim($webuserdata['username']))->where('property_id', '=', $property_id)->count();
                if ($ct > 0) {
                    return -6;
                }
            }
            unset($webuserdata['id']);
            $web_user_id = DB::table($this->table)
                    ->insertGetId($webuserdata);

            return $web_user_id;
        }
    }

    public function getPropertyIdByUserId($web_user_id)
    {

        $property_id = DB::table($this->table)
                ->select('property_id')
                ->where('web_users.web_user_id', '=', $web_user_id)
                ->first();
        return $property_id;
    }

    function get1UserInfo($web_user_id, $key)
    {
        $info = DB::table('web_users')->select($key)->where('web_user_id', $web_user_id)->first();
        $info = (array) $info;
        return $info[$key];
    }

    function getFullNameById($idusr)
    {
        $result = $this->where('web_user_id', '=', $idusr)->select('first_name', 'last_name')->first();
        return $result['first_name'] . ' ' . $result['last_name'];
    }

    public function getFutureMappingName($tablename, $level, $idlevel)
    {

        if ($level == 'group') {
            $mapping_name = DB::table($tablename)
                    ->where('companyid', $idlevel)
                    ->where('importw_num', 'import')
                    ->select('mapping_name', 'web_users_mapping_id', 'boolmappingsavedforfuture')
                    ->orderBy('web_users_mapping_id', 'DESC')
                    ->first();
        } elseif ($level == 'partner') {
            $mapping_name = DB::table($tablename)
                    ->where('partnerid', $idlevel)
                    ->where('importw_num', 'import')
                    ->select('mapping_name', 'web_users_mapping_id', 'boolmappingsavedforfuture')
                    ->orderBy('web_users_mapping_id', 'DESC')
                    ->first();
        } else {
            $mapping_name = DB::table($tablename)
                    ->where('propertyid', $idlevel)
                    ->where('importw_num', 'import')
                    ->select('mapping_name', 'web_users_mapping_id', 'boolmappingsavedforfuture')
                    ->orderBy('web_users_mapping_id', 'DESC')
                    ->first();
        }


        return $mapping_name;
    }

    public function updateFutureMappingName($mapping_name, $id, $tablename)
    {

        DB::table($tablename)
                ->where('web_users_mapping_id', $id)
                ->update(['mapping_name' => $mapping_name]);

        return true;
    }

    public function addFutureMappingName($mapping_name, $tablename, $level, $idlevel)
    {
        if ($level == 'group') {
            DB::table($tablename)->insert(['mapping_name' => $mapping_name, 'mapped_file_data' => '', 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1, 'companyid' => $idlevel, 'adminid' => 0, 'token' => '']);
        } elseif ($level == 'partner') {
            DB::table($tablename)->insert(['mapping_name' => $mapping_name, 'mapped_file_data' => '', 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1, 'partnerid' => $idlevel, 'adminid' => 0, 'token' => '']);
        } else {
            DB::table($tablename)->insert(['mapping_name' => $mapping_name, 'mapped_file_data' => '', 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1, 'propertyid' => $idlevel, 'adminid' => 0, 'token' => '']);
        }


        return true;
    }

    public function isCatChecked($payment_type_id, $web_user_id)
    {

        $web_user_permissions = DB::table('web_users_permissions')
                ->where('web_users_permissions.web_user_id', '=', $web_user_id)
                ->where('web_users_permissions.payment_type_id', '=', $payment_type_id)
                ->first();

        if (!empty($web_user_permissions)) {
            return 'checked';
        } else {
            return 0;
        }
    }

    public function getTableStructure()
    {

        $tablestructure = DB::select(DB::raw("DESC web_users"));
        return $tablestructure;
    }

    public function GetUsrExportFormat($level, $idlevel)
    {
        if ($level == 'group') {
            $export = DB::table('web_users_mapping')->where('companyid', $idlevel)->where('importw_num', 'export')->orderBy('web_users_mapping_id', 'desc')->first();
        } elseif ($level == 'partner') {
            $export = DB::table('web_users_mapping')->where('partnerid', $idlevel)->where('importw_num', 'export')->orderBy('web_users_mapping_id', 'desc')->first();
        } else {
            $export = DB::table('web_users_mapping')->where('propertyid', $idlevel)->where('importw_num', 'export')->orderBy('web_users_mapping_id', 'desc')->first();
        }
        return $export;
    }

    public function StoreExportFormat($jsonEncodeEF, $level, $idlevel, $mappingName)
    {
        if ($level == 'group') {
            $export = DB::table('web_users_mapping')->where('mapping_name', $mappingName)->where('companyid', $idlevel)->where('importw_num', 'export')->orderBy('web_users_mapping_id', 'desc')->first();
            if (empty($export)) {
                DB::table('web_users_mapping')->insert(['importw_num' => 'export', 'mapping_name' => $mappingName, 'mapped_file_data' => $jsonEncodeEF, 'companyid' => $idlevel]);
            } else {
                DB::table('web_users_mapping')->where('web_users_mapping_id', $export['web_users_mapping_id'])->update(['mapped_file_data' => $jsonEncodeEF]);
            }
        } elseif ($level == 'partner') {
            $export = DB::table('web_users_mapping')->where('mapping_name', $mappingName)->where('partnerid', $idlevel)->where('importw_num', 'export')->orderBy('web_users_mapping_id', 'desc')->first();
            if (empty($export)) {
                DB::table('web_users_mapping')->insert(['importw_num' => 'export', 'mapping_name' => $mappingName, 'mapped_file_data' => $jsonEncodeEF, 'partnerid' => $idlevel]);
            } else {
                DB::table('web_users_mapping')->where('web_users_mapping_id', $export['web_users_mapping_id'])->update(['mapped_file_data' => $jsonEncodeEF]);
            }
        } else {
            $export = DB::table('web_users_mapping')->where('mapping_name', $mappingName)->where('propertyid', $idlevel)->where('importw_num', 'export')->orderBy('web_users_mapping_id', 'desc')->first();
            if (empty($export)) {
                DB::table('web_users_mapping')->insert(['importw_num' => 'export', 'mapping_name' => $mappingName, 'mapped_file_data' => $jsonEncodeEF, 'propertyid' => $idlevel]);
            } else {
                DB::table('web_users_mapping')->where('web_users_mapping_id', $export['web_users_mapping_id'])->update(['mapped_file_data' => $jsonEncodeEF]);
            }
        }

        return true;
    }

    public function getWebUserFutureMapping($tablename, $level, $idlevel)
    {
        if ($level == 'group') {
            $webusersmappingdata = DB::table($tablename)
                    ->where('companyid', $idlevel)
                    ->where('importw_num', 'import')
                    ->orderBy('web_users_mapping_id', 'DESC')
                    ->first();
        } elseif ($level == 'partner') {
            $webusersmappingdata = DB::table($tablename)
                    ->where('partnerid', $idlevel)
                    ->where('importw_num', 'import')
                    ->orderBy('web_users_mapping_id', 'DESC')
                    ->first();
        } else {
            $webusersmappingdata = DB::table($tablename)
                    ->where('propertyid', $idlevel)
                    ->where('importw_num', 'import')
                    ->orderBy('web_users_mapping_id', 'DESC')
                    ->first();
        }


        return $webusersmappingdata;
    }

    public function updateWebUserMapping($json_data, $tablename, $level, $idlevel)
    {
        if ($level == 'group') {
            DB::table($tablename)->where('companyid', $idlevel)->where('importw_num', 'import')->update(['mapped_file_data' => $json_data, 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1]);
        } elseif ($level == 'partner') {
            DB::table($tablename)->where('partnerid', $idlevel)->where('importw_num', 'import')->update(['mapped_file_data' => $json_data, 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1]);
        } else {
            DB::table($tablename)->where('propertyid', $idlevel)->where('importw_num', 'import')->update(['mapped_file_data' => $json_data, 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1]);
        }

        return true;
    }

    public function addToWebUserMapping($json_data, $tablename, $level, $idlevel)
    {
        if ($level == 'group') {
            DB::table($tablename)->insert(['importw_num' => 'import', 'mapped_file_data' => $json_data, 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1, 'companyid' => $idlevel]);
        } elseif ($level == 'partner') {
            DB::table($tablename)->insert(['importw_num' => 'import', 'mapped_file_data' => $json_data, 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1, 'partnerid' => $idlevel]);
        } else {
            DB::table($tablename)->insert(['importw_num' => 'import', 'mapped_file_data' => $json_data, 'readytoimportRecords' => 0, 'unmappedfields' => 0, 'unmappedfieldsResult' => '', 'skipped_records' => 0, 'uploaded_file_name' => '', 'import_table_name' => '', 'skippedfields' => 0, 'skippedfieldResult' => '', 'boolmappingsavedforfuture' => 1, 'propertyid' => $idlevel]);
        }

        return true;
    }

    public function deleteWebUserMapping($tablename)
    {

        //DB::table($tablename)->delete();
        //return true;
    }

    public function deleteWebUser($id)
    {

        DB::table($this->table)
                ->where('web_user_id', $id)
                ->update(['web_status' => '9999']);
        return true;
    }

    public function addDataToTable($file_data, $table_name, $with3, $pl_id, $do_update2, $fields_to_not_to_import)
    {

        $user_data = array();
        $acc_no = 0;
        //echo $with3; die;
        if (!empty($file_data)) {
            foreach ($file_data as $key => $data) {
                //echo '<pre>';

                if ($data) {
                    $dataObj2Array = (array) $data;

                    $existquery = '';
                    //if($this->tablename == 'web_users'){
                    //checking for account number if already exists


                    if (isset($dataObj2Array['property_id']) && ($with3 == 'groups')) {
                        $property_id_array = explode('||', $dataObj2Array['property_id']);
                        $company_id = $pl_id;
                        //echo $company_id.' === '.$property_id_array[0]; die;

                        $properties_detail = $this->getPropertyIdFromProperty($property_id_array[0], $company_id, 'id_companies', 'properties');
                        //echo '<pre>';
                        //print_r($properties_detail); die;
                        if (!empty($properties_detail)) {
                            $acc_no = explode('||', $dataObj2Array['account_number']);
                            $user_data = $this->getWebUserByPropertyId($properties_detail['id'], $acc_no[0]);
                            //echo '<pre>';
                            //print_r($user_data); die;
                            if (!empty($user_data)) {
                                //
                                //$dataObj2Array['company_name'] = '||bigint_20';
                                $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                            }
                        } else {
                            $dataInsert = array();

                            foreach ($dataObj2Array as $key => $datavalue) {
                                $cleanvalue = explode('||', $datavalue)[0];
                                $dataInsert[$key] = $cleanvalue;
                            }

                            DB::table('web_users')->insert(
                                $dataInsert
                            );
                        }
                    } elseif (isset($dataObj2Array['property_id']) && ($with3 == 'partners')) {
                        $property_id_array = explode('||', $dataObj2Array['property_id']);
                        //$group_id_array = explode('||', $dataObj2Array['group_id']);
                        $partner_id = $pl_id;
                        //echo $partner_id.''.$property_id_array[0]; die;
                        //$company_details = $this->getCompanyIdFromCompany($partner_id_array[0], $group_id_array[0], 'id_partners');
                        //if(!empty($company_details)){
                        $properties_detail = $this->getPropertyIdFromProperty($property_id_array[0], $partner_id, 'id_partners', 'properties');
                        //echo '<pre>';
                        //print_r($properties_detail); die;
                        if (!empty($properties_detail)) {
                            $acc_no = explode('||', $dataObj2Array['account_number']);
                            $user_data = $this->getWebUserByPropertyId($properties_detail['id'], $acc_no[0]);
                            if (!empty($user_data)) {
                                //$dataObj2Array['group_id'] = '||varchar_100';
                                //$dataObj2Array['company_name'] = '||bigint_20';
                                $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                            }
                        }
                        //}
                    } elseif (isset($dataObj2Array['account_number']) && ($with3 == 'web_users')) {
                        $acc_no = explode('||', $dataObj2Array['account_number']);
                        $user_data = DB::table($table_name)
                                ->select('web_user_id', 'web_status')
                                ->where('account_number', $acc_no[0])
                                ->first();
                    } else {
                        //echo 'pp'; die;
                        $partner_detail = array();
                        $group_detail = array();
                        $merchant = array();
                        //uploading under admin
                        if (isset($dataObj2Array['partner'])) {
                            $partner = explode('||', $dataObj2Array['partner']);
                            $partner_detail = $this->getPartnerIdByName($partner[0]);
                        } elseif (isset($dataObj2Array['Partner'])) {
                            $partner = explode('||', $dataObj2Array['partner']);
                            $partner_detail = $this->getPartnerIdByName($partner[0]);
                        }
                        if (isset($dataObj2Array['group'])) {
                            $group = explode('||', $dataObj2Array['group']);
                            $group_detail = $this->getCompanyIdByName($group[0]);
                        } elseif (isset($dataObj2Array['Group'])) {
                            $group = explode('||', $dataObj2Array['Group']);
                            $group_detail = $this->getCompanyIdByName($group[0]);
                        }
                        if (isset($dataObj2Array['merchant'])) {
                            $merchant = explode('||', $dataObj2Array['merchant']);
                        } elseif (isset($dataObj2Array['Merchant'])) {
                            $merchant = explode('||', $dataObj2Array['Merchant']);
                        }

                        //$group_id_array = explode('||', $dataObj2Array['group_id']);
                        //echo $partner_id.''.$property_id_array[0]; die;
                        //$company_details = $this->getCompanyIdFromCompany($partner_id_array[0], $group_id_array[0], 'id_partners');
                        //if(!empty($company_details)){
                        if (isset($merchant[0])) {
                            $properties_detail = $this->getPropertyIdFromGPM($merchant[0], $group_detail['id'], $partner_detail['id'], 'properties');
                        }
                        //echo '<pre>';
                        //print_r($properties_detail); die;
                        if (!empty($properties_detail)) {
                            $acc_no = explode('||', $dataObj2Array['account_number']);
                            $user_data = $this->getWebUserByPropertyId($properties_detail['id'], $acc_no[0]);
                            if (!empty($user_data)) {
                                //$dataObj2Array['group_id'] = '||varchar_100';
                                //$dataObj2Array['company_name'] = '||bigint_20';
                                $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                            }
                        }
                        //}
                    }

                    //}
                    //echo '<pre>';
                    //print_r($user_data); die;
                    if (!empty($user_data)) {
                        $updatecommand = '';

                        if ($do_update2) {
                            $updatecommand = $this->setDataToUpdateDatabase($acc_no[0], $dataObj2Array, $table_name, $do_update2, $user_data->web_status);
                            //echo $updatecommand.'=======';
                            DB::statement($updatecommand);
                        } else {
                            $updatecommand = $this->setDataToUpdateDatabase($acc_no[0], $dataObj2Array, $table_name, 0, $user_data->web_status);
                            //echo $updatecommand.'=======';
                            DB::statement($updatecommand);
                        }
                    } else {
                        //echo 'IN ELSE';
                        $boolAddUser = true;
                        if (isset($dataObj2Array['property_id']) && ($with3 == 'groups')) {
                            //echo 'IN IF';
                            $property_id_array = explode('||', $dataObj2Array['property_id']);
                            $company_id = $pl_id;
                            $properties_detail = $this->getPropertyIdFromProperty($property_id_array[0], $company_id, 'id_companies', 'properties');
                            //echo '<pre>';
                            //print_r($properties_detail); die;
                            if (empty($properties_detail)) {
                                //echo 'IN IF'; die;
                                $boolAddUser = false;
                                //$dataCount = count($dataObj2Array) - 1;
                            } else {
                                //echo 'IN ELSE'; die;
                                if (isset($dataObj2Array['account_number'])) {
                                    //echo 'IN IF';
                                    //$usr_email_regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
                                    $fname = explode('||', $dataObj2Array['first_name']);
                                    if ($fname[0] == '') {
                                        $boolAddUser = false;
                                    } else {
                                        //$dataObj2Array['company_name'] = '||bigint_20';
                                        $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                                        //$dataCount = count($dataObj2Array) - 1;
                                    }

                                    //echo var_dump($boolAddUser); die;
                                } else {
                                    //echo 'IN ELSE'; die;
                                    //$dataObj2Array['company_name'] = '||bigint_20';
                                    $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                                    //$dataCount = count($dataObj2Array) - 1;
                                }
                            }
                        } elseif (isset($dataObj2Array['property_id']) && ($with3 == 'partners')) {
                            $property_id_array = explode('||', $dataObj2Array['property_id']);
                            //$group_id_array = explode('||', $dataObj2Array['group_id']);
                            $partner_id = $pl_id;
                            //$company_details = $this->getCompanyIdFromCompany($partner_id_array[0], $group_id_array[0], 'id_partners');
                            //if(!empty($company_details)){
                            $properties_detail = $this->getPropertyIdFromProperty($property_id_array[0], $partner_id, 'id_partners', 'properties');
                            if (empty($properties_detail)) {
                                $boolAddUser = false;
                                //$dataCount = count($dataObj2Array) - 1;
                            } else {
                                //$dataObj2Array['partner_name'] = '||bigint_20';
                                //$dataObj2Array['group_id'] = '||varchar_100';
                                if (isset($dataObj2Array['account_number'])) {
                                    //echo 'IN ELSE IF';
                                    //$usr_email_regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
                                    $fname = explode('||', $dataObj2Array['first_name']);
                                    if ($fname[0] == '') {
                                        $boolAddUser = false;
                                    } else {
                                        $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                                        //$dataCount = count($dataObj2Array) - 1;
                                    }
                                } else {
                                    $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                                    //$dataCount = count($dataObj2Array) - 1;
                                }
                            }

                            //}
                        } elseif (isset($dataObj2Array['account_number']) && ($with3 == 'web_users')) {
                            //echo 'IN ELSE IF';
                            //$usr_email_regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
                            $fname = explode('||', $dataObj2Array['first_name']);
                            if ($fname[0] == '') {
                                $boolAddUser = false;
                            }
                        } else {
                            $partner_detail = array();
                            $group_detail = array();
                            $merchant = array();
                            //uploading under admin
                            if (isset($dataObj2Array['partner'])) {
                                $partner = explode('||', $dataObj2Array['partner']);
                                $partner_detail = $this->getPartnerIdByName($partner[0]);
                            } elseif (isset($dataObj2Array['Partner'])) {
                                $partner = explode('||', $dataObj2Array['partner']);
                                $partner_detail = $this->getPartnerIdByName($partner[0]);
                            }
                            if (isset($dataObj2Array['group'])) {
                                $group = explode('||', $dataObj2Array['group']);
                                $group_detail = $this->getCompanyIdByName($group[0]);
                            } elseif (isset($dataObj2Array['Group'])) {
                                $group = explode('||', $dataObj2Array['Group']);
                                $group_detail = $this->getCompanyIdByName($group[0]);
                            }
                            if (isset($dataObj2Array['merchant'])) {
                                $merchant = explode('||', $dataObj2Array['merchant']);
                            } elseif (isset($dataObj2Array['Merchant'])) {
                                $merchant = explode('||', $dataObj2Array['Merchant']);
                            }

                            //$group_id_array = explode('||', $dataObj2Array['group_id']);
                            //echo $partner_id.''.$property_id_array[0]; die;
                            //$company_details = $this->getCompanyIdFromCompany($partner_id_array[0], $group_id_array[0], 'id_partners');
                            //if(!empty($company_details)){
                            if (isset($merchant[0])) {
                                $properties_detail = $this->getPropertyIdFromGPM($merchant[0], $group_detail['id'], $partner_detail['id'], 'properties');
                            }
                            //echo '<pre>';
                            //print_r($properties_detail); die;
                            if (empty($properties_detail)) {
                                $boolAddUser = false;
                            } else {
                                if (isset($dataObj2Array['account_number'])) {
                                    //echo 'IN ELSE IF';
                                    //$usr_email_regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
                                    $fname = explode('||', $dataObj2Array['first_name']);
                                    if ($fname[0] == '') {
                                        $boolAddUser = false;
                                    } else {
                                        //$dataObj2Array['company_name'] = '||bigint_20';
                                        $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                                        //$dataCount = count($dataObj2Array) - 1;
                                    }
                                } else {
                                    //$dataObj2Array['company_name'] = '||bigint_20';
                                    $dataObj2Array['property_id'] = $properties_detail['id'] . '||bigint_20';
                                    //$dataCount = count($dataObj2Array) - 1;
                                }
                            }
                            //}
                        }
                        if ($boolAddUser) {
                            //echo 'IN IF one'; die;
                            $insert_command = 'INSERT INTO `' . $table_name . '` (';
                            $insert_values_string = '';
                            //$table_field_array = array();
                            //$insert_field = '';
                            $mysqlTableData = array();
                            $mysqlTableData = $this->getTableStructure();
                            $mysqlTableDataList = array();
                            //echo '<pre>';
                            //print_r($mysqlTableData); die;
                            $insert_field = '';
                            if (!empty($mysqlTableData)) {
                                foreach ($mysqlTableData as $table_fields_key => $table_fields_value) {
                                    if (($table_fields_value['Key'] != 'PRI') && !in_array($table_fields_value['Field'], $fields_to_not_to_import)) {
                                        //$insert_field .= '`'.trim($table_fields_value['Field']).'`,';
                                        $mysqlTableDataList[trim($table_fields_value['Field'])] = '`' . trim($table_fields_value['Field']) . '`,';
                                    }
                                }
                            }

                            //removing key not being used from array
                            //echo $dataCount.' === ';
                            $tempDataObj2Array = array_intersect_key($dataObj2Array, $mysqlTableDataList);
                            $dataCount = count($tempDataObj2Array);
                            if (!empty($tempDataObj2Array)) {
                                foreach ($tempDataObj2Array as $table_key => $table_value) {
                                    $insert_field .= '`' . trim($table_key) . '`,';
                                }
                            }
                            //echo '<pre>';
                            //print_r($tempDataObj2Array); die;
                            $pre_insert_command = $insert_command . rtrim($insert_field, ',') . ' ) VALUES ';
                            $i = 0;
                            foreach ($tempDataObj2Array as $dataKey => $dataValue) {
                                //if($dataKey != 'sort_order'){
                                //echo $dataValue; echo '<br/>';
                                $dataValueArray = explode('||', $dataValue);
                                $dataInfoArray = explode('_', $dataValueArray[1]);
                                //echo '<pre>';
                                //print_r($dataValueArray);
                                if (($dataInfoArray[0] == 'int' || $dataInfoArray[0] == 'bigint' || $dataInfoArray[0] == 'decimal') && ($dataKey != 'company_name' && $dataKey != 'partner_name' && $dataKey != 'group_id')) {
                                    if ($i + 1 == $dataCount) {
                                        //checking length of the string value entered
                                        if ($dataValueArray[0] != '' && is_numeric($dataValueArray[0])) {
                                            $insert_values_string .= $dataValueArray[0] . ' ) , ';
                                        } else {
                                            $insert_values_string .= '0 ) , ';
                                        }
                                        $i++;
                                    } elseif ($i + 1 == 1) {
                                        if ($dataValueArray[0] != '' && is_numeric($dataValueArray[0])) {
                                            $insert_values_string .= ' ( ' . $dataValueArray[0] . ' , ';
                                        } else {
                                            $insert_values_string .= ' ( 0 , ';
                                        }
                                        $i++;
                                    } else {
                                        if ($dataValueArray[0] != '' && is_numeric($dataValueArray[0])) {
                                            $insert_values_string .= $dataValueArray[0] . ' , ';
                                        } else {
                                            $insert_values_string .= ' 0 , ';
                                        }
                                        $i++;
                                    }
                                } elseif (($dataInfoArray[0] == 'varchar' || $dataInfoArray[0] == 'text' || $dataInfoArray[0] == 'datetime' || $dataInfoArray[0] == 'timestamp' || $dataInfoArray[0] == 'date') && ($dataKey != 'company_name' && $dataKey != 'partner_name' && $dataKey != 'group_id')) {
                                    if ($i + 1 == $dataCount) {
                                        //echo 'IN IF';
                                        $insert_values_string .= '\'' . addslashes($dataValueArray[0]) . '\' ) , ';
                                        $i++;
                                    } elseif ($i + 1 == 1) {
                                        //echo 'IN ELSE IF';
                                        $insert_values_string .= ' (\' ' . addslashes($dataValueArray[0]) . ' \', ';
                                        $i++;
                                    } else {
                                        //echo 'IN ELSE ';
                                        $insert_values_string .= '\'' . addslashes($dataValueArray[0]) . '\', ';
                                        $i++;
                                    }
                                }
                            }
                            //echo $insert_values_string; echo '<br/>'; die;
                            $insert_query = $pre_insert_command . substr($insert_values_string, 0, strlen($insert_values_string) - 2);
                            //echo rtrim($insert_query, ',').'====='; die;
                            DB::statement(rtrim($insert_query, ','));
                        }
                    }//end else
                }
            }
        }
        //echo $insert_values_string; die;
        //die;
        return array('error' => '0', 'message' => 'Data has been imported successfully');
    }

    //function is to set record for update
    public function setDataToUpdateDatabase($account_number, $data = array(), $tablename = 'web_users', $update_active_users = 0, $user_active)
    {

        $updatecommand = 'UPDATE `' . $tablename . '` SET ';
        $property_id = 0;
        //echo $user_active; echo '---1---';
        //echo '<pre>';
        //print_r($data); die;

        if (!empty($data)) {
            foreach ($data as $tablecolumn => $value) {
                $usr_email_regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
                $dataValueArray = explode('||', $value);
                $dataInfoArray = explode('_', $dataValueArray[1]);
                // code to skip from update , if account is empty or email address is empty or invalid
                if (($tablecolumn == 'property_id') && (!empty($dataValueArray[0]))) {
                    $property_id = $dataValueArray[0];
                }
                if (($tablecolumn == 'account_number') && ($dataValueArray[0] == '')) {
                    continue;
                } elseif (($tablecolumn == 'email_address') && ($dataValueArray[0] == '')) {
                    continue;
                } elseif (($tablecolumn == 'email_address') && ($dataValueArray[0] != '')) {
                    if (!preg_match($usr_email_regex, $dataValueArray[0])) {
                        continue;
                    }
                }
                if (($dataInfoArray[0] == 'int' || $dataInfoArray[0] == 'bigint' || $dataInfoArray[0] == 'decimal') && ($tablecolumn != 'company_name' && $tablecolumn != 'partner_name' && $tablecolumn != 'group_id')) {
                    if ($dataValueArray[0] != '' && is_numeric($dataValueArray[0])) {
                        if ($user_active == 1) {
                            if ($tablecolumn != 'web_status') {
                                $updatecommand .= '`' . $tablecolumn . '` = ' . $dataValueArray[0] . ', ';
                            }
                        } else {
                            $updatecommand .= '`' . $tablecolumn . '` = ' . $dataValueArray[0] . ', ';
                        }
                    }
                } elseif (($dataInfoArray[0] == 'varchar' || $dataInfoArray[0] == 'text' || $dataInfoArray[0] == 'datetime' || $dataInfoArray[0] == 'timestamp') && ($tablecolumn != 'company_name' && $tablecolumn != 'partner_name' && $tablecolumn != 'group_id')) {
                    //echo 'IN ELSE ';
                    if ($user_active == 1) {
                        if ($tablecolumn != 'web_status') {
                            if ($dataValueArray[0] != '') {
                                $updatecommand .= '`' . $tablecolumn . '` = \'' . addslashes($dataValueArray[0]) . '\', ';
                            }
                        }
                    } else {
                        if ($dataValueArray[0] != '') {
                            $updatecommand .= '`' . $tablecolumn . '` = \'' . addslashes($dataValueArray[0]) . '\', ';
                        }
                    }
                }
            }
        }
        if (!$update_active_users) {
            $updatecommand = rtrim($updatecommand, ', ') . ' WHERE `account_number` = \'' . $account_number . '\' AND `web_status` != 1 AND `property_id` =' . $property_id;
        } else {
            //$updatecommand = rtrim($updatecommand, ', ').' WHERE `account_number` = \''.$account_number.'\' AND `web_status` = 1 ';
            $updatecommand = rtrim($updatecommand, ', ') . ' WHERE `account_number` = \'' . $account_number . '\' AND `property_id` =' . $property_id;
        }
        //echo $updatecommand; echo '===================';
        return $updatecommand;
    }

    public function getWUOldPassword($wuid, $wupassword)
    {

        $wudetailByPassword = DB::table($this->table)
                ->where('web_user_id', $wuid)
                ->where('password', DB::raw('Password(\'' . $wupassword . '\')'))
                ->first();

        return $wudetailByPassword;
    }

    public function setWUOldPassword($wuid, $wunewpassword)
    {

        DB::table($this->table)
                ->where('web_user_id', $wuid)
                ->update(['password' => $wunewpassword, 'web_status' => 1]);

        return true;
    }

    public function getWebUserTicketHistory($idlevel, $level, $wuid)
    {

        $wu_ticket_history = DB::table('tickets')
                ->Where('ticket_user_id', $wuid)
                ->Select('ticket_id', 'ticket_property', 'ticket_partner', 'ticket_email', 'ticket_type', 'ticket_name', 'ticket_lastname', 'ticket_phone', 'ticket_company', 'ticket_address', 'ticket_notes', 'ticket_date_submitted', 'ticket_status')
                ->orderBy('ticket_id', 'DESC')
                ->take(10);

        return $wu_ticket_history;
    }

    public function getPropertyIdFromProperty($id_property, $id_value, $fieldname, $tablename = 'properties')
    {

        $propertyIdByProperty = DB::table($tablename)
                ->where($fieldname, $id_value)
                ->where('compositeID_clients', $id_property)
                ->first();

        return $propertyIdByProperty;
    }

    public function getPropertyIdFromGPM($merchant, $company_id, $partner_id, $tablename = 'properties')
    {

        $property_detail = DB::table($tablename)
                ->where('id_companies', $company_id)
                ->where('id_partners', $partner_id)
                ->where('name_clients', addslashes($merchant))
                ->first();

        return $property_detail;
    }

    public function getCompanyIdFromCompany($id_partner, $id_group, $fieldname = 'id_partners', $tablename = 'companies')
    {

        $companyIdByCompany = DB::table($tablename)
                ->where($fieldname, $id_partner)
                ->where('compositeID_companies', $id_group)
                ->first();

        return $companyIdByCompany;
    }

    public function getWebUserByPropertyId($id_property, $account_number)
    {


        $webuserDetails = DB::table($this->table)
                ->where('property_id', $id_property)
                ->where('account_number', $account_number)
                ->where('web_status', '<', '1000')
                ->first();
        return $webuserDetails;
    }

    public function getWebUserByPropertyIdWithEmail($id_property)
    {
        $data = DB::table($this->table)
            ->where('property_id', $id_property)
            ->where('email_address','!=','')
            ->where('web_status', '<', '1000')
            ->get();
        return $data;
    }

    public function getPartnerIdByName($partner_name)
    {

        $partner_detail = DB::table('partners')
                ->where('partner_name', addslashes($partner_name))
                ->first();
        return $partner_detail;
    }

    public function getCompanyIdByName($company_name)
    {

        $company_detail = DB::table('companies')
                ->where('company_name', addslashes($company_name))
                ->first();
        return $company_detail;
    }

    public function getPaymentTypeDetail($property_id)
    {
        $paymenttypedetail = DB::table('payment_type')
                ->where('payment_type.property_id', '=', $property_id)
                ->first();
        return $paymenttypedetail;
    }

    function sqlPassword($input)
    {
        $pass = strtoupper(sha1(sha1($input, true)));
        $pass = '*' . $pass;
        return $pass;
    }

    function validateLogin($idproperty, $acc, $user, $passw)
    {
        $query = DB::table('web_users')->select('web_user_id')->where('property_id', '=', $idproperty);
        if ($acc != '') {
            $query->where('account_number', '=', $acc);
        }
        if ($user != '') {
            $query->where('username', '=', $user);
        }
        if ($passw != '') {
            $query->where('password', '=', $this->sqlPassword($passw));
        }
        if ($user != '' && $passw != '') {
            $query->whereIn('web_status', array(1));
        } else {
            $query->whereIn('web_status', array(1, 46, 998));
        }
        $result = $query->first();
        return $result;
    }

    function FindLogin($level, $idproperty, $user, $passw)
    {
        $query = DB::table('web_users')->join('properties', 'properties.id', '=', 'web_users.property_id')->select('web_user_id', 'property_id')->where('username', '=', $user)->where('password', '=', $this->sqlPassword($passw))->whereIn('web_status', array(1));
        if ($level == 'P') {
            $query->where('properties.id_partners', $idproperty);
        } elseif ($level == 'G') {
            $query->where('properties.id_companies', $idproperty);
        } else {
            $query->where('properties.id', $idproperty);
        }
        $result = $query->first();
        return $result;
    }

    function set1UserInfo($web_user_id, $key, $value)
    {
        DB::table('web_users')->where('web_user_id', $web_user_id)->update(array($key => $value));
    }

    function FindOpenbyID($web_user_id)
    {
        $query = DB::table('web_users')->join('properties', 'properties.id', '=', 'web_users.property_id')
                        ->join('companies', 'companies.id', '=', 'properties.id_companies')
                        ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')->where('web_user_id', '=', $web_user_id)->select('account_number', 'first_name', 'last_name', 'email_address', 'web_users.address', 'address_unit', 'web_users.city', 'web_users.state', 'web_users.zip', 'web_status', 'balance', 'balance_due', 'web_users.phone_number', 'suppression', 'properties.compositeID_clients as paypointID', 'companies.compositeID_companies as companyID');
        $result = $query->get();
        return $result;
    }

    function FindOpen2($params, $idproperty, $status, $match, $idcompany = 0, $idpartner = 0)
    {
        $query = DB::table('web_users')->join('properties', 'properties.id', '=', 'web_users.property_id')
                ->join('companies', 'companies.id', '=', 'properties.id_companies')
                ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')->where('web_status', '<', 1000)
                ->where('properties.status_clients', 1)
                ->where('companies.status', 1)
                ->where('partners.status', 1);
        if (isset($params['includeUsr']) && $params['includeUsr'] == true) {
            $query->select('account_number', 'first_name', 'last_name', 'email_address', 'web_users.address', 'address_unit', 'web_users.city', 'web_users.state', 'web_users.zip', 'web_status', 'balance', 'balance_due', 'web_users.phone_number', 'web_users.username', 'suppression', 'properties.compositeID_clients as paypointID', 'companies.compositeID_companies as companyID');
        } else {
            $query->select('account_number', 'first_name', 'last_name', 'email_address', 'web_users.address', 'address_unit', 'web_users.city', 'web_users.state', 'web_users.zip', 'web_status', 'balance', 'balance_due', 'web_users.phone_number', 'suppression', 'properties.compositeID_clients as paypointID', 'companies.compositeID_companies as companyID');
        }
        if (isset($params['account_number'])) {
            if ($match) {
                $query->where('account_number', '=', $params['account_number']);
            } else {
                $query->where('account_number', 'like', '%' . $params['account_number'] . '%');
            }
        }
        if ($idproperty > 0) {
            $query->where('properties.id', '=', $idproperty);
        } elseif ($idcompany > 0) {
            $query->where('properties.id_companies', '=', $idcompany);
        } elseif ($idpartner > 0) {
            $query->where('properties.id_partners', '=', $idpartner);
        }
        if ($idproperty <= 0 && isset($params['name_clients'])) {
            if ($match) {
                $query->where('properties.name_clients', 'like', $params['name_clients']);
            } else {
                $query->where('properties.name_clients', 'like', '%' . str_replace(' ', '%', $params['name_clients']) . '%');
            }
        }
        if (isset($params['first_name'])) {
            if ($match) {
                $query->where('web_users.first_name', 'like', $params['first_name']);
            } else {
                $query->where('web_users.first_name', 'like', '%' . $params['first_name'] . '%');
            }
        }
        if (isset($params['last_name'])) {
            if ($match) {
                $query->where('web_users.last_name', 'like', $params['last_name']);
            } else {
                $query->where('web_users.last_name', 'like', '%' . $params['last_name'] . '%');
            }
        }
        if (isset($params['address'])) {
            $query->where("web_users.address", 'like', '%' . $params['address'] . '%');
        }
        if (isset($params['city'])) {
            if ($match) {
                $query->where('web_users.city', '=', $params['city']);
            } else {
                $query->where('web_users.city', 'like', '%' . $params['city'] . '%');
            }
        }
        if (isset($params['state'])) {
            if ($match) {
                $query->where('web_users.state', '=', $params['state']);
            } else {
                $query->where('web_users.state', 'like', '%' . $params['state'] . '%');
            }
        }
        if (isset($params['zip'])) {
            if ($match) {
                $query->where('web_users.zip', '=', $params['zip']);
            } else {
                $query->where('web_users.zip', 'like', '%' . $params['zip'] . '%');
            }
        }
        if (isset($params['email'])) {
            if ($match) {
                $query->where('email_address', '=', $params['email']);
            } else {
                $query->where('email_address', 'like', '%' . $params['email'] . '%');
            }
        }
        if (isset($params['username'])) {
            if ($match) {
                $query->where('username', '=', $params['username']);
            } else {
                $query->where('username', 'like', '%' . $params['username'] . '%');
            }
        }
        if (!empty($status)) {
            if (!is_array($status)) {
                $query->where('web_status', '=', $status);
            } else {
                $query->whereIn('web_status', $status);
            }
        }
        $result = $query->get();
        return $result;
    }

    function FindOpen($idproperty, $acc, $name, $address, $email, $status, $match, $idcompany = 0, $idpartner = 0)
    {
        $query = DB::table('web_users')->join('properties', 'properties.id', '=', 'web_users.property_id')
                ->join('companies', 'companies.id', '=', 'properties.id_companies')
                ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                ->where('web_status', '<', 1000)
                ->where('properties.status_clients', 1)
                ->where('companies.status', 1)
                ->where('partners.status', 1)
                ->select('account_number', 'first_name', 'last_name', 'email_address', 'web_users.address', 'address_unit', 'web_users.city', 'web_users.state', 'web_users.zip', 'web_status', 'balance', 'balance_due', 'web_users.phone_number', 'suppression', 'properties.compositeID_clients as paypointID', 'companies.compositeID_companies as companyID');
        if (!empty($acc)) {
            if ($match) {
                $query->where('account_number', '=', $acc);
            } else {
                $query->where('account_number', 'like', '%' . $acc . '%');
            }
        }
        if ($idproperty > 0) {
            $query->where('properties.id', '=', $idproperty);
        } elseif ($idcompany > 0) {
            $query->where('properties.id_companies', '=', $idcompany);
        } elseif ($idpartner > 0) {
            $query->where('properties.id_partners', '=', $idpartner);
        }
        if (!empty($name)) {
            if ($match) {
                $query->whereRaw("CONCAT(first_name,' ',last_name) ='" . $name . "'");
            } else {
                $pieces = explode(' ', $name);
                $dfq = '';
                foreach ($pieces as $pic) {
                    if (!empty($pic)) {
                        if ($dfq != '') {
                            $dfq .= " OR ";
                        }
                        $dfq .= "CONCAT(first_name,' ',last_name) LIKE '%" . $pic . "%'";
                    }
                }
                if ($dfq != '') {
                    $dfq = '(' . $dfq . ')';
                    $query->whereRaw($dfq);
                }
            }
        }
        if (!empty($address)) {
            if ($match) {
                $query->whereRaw("CONCAT(address,' ',city,' ',state,' ',zip) ='" . $address . "'");
            } else {
                $pieces = explode(' ', $address);
                $dfq = '';
                foreach ($pieces as $pic) {
                    if (!empty($pic)) {
                        if ($dfq != '') {
                            $dfq .= " OR ";
                        }
                        $dfq .= "CONCAT(address,' ',city,' ',state,' ',zip) like '%" . $pic . "%'";
                    }
                }
                if ($dfq != '') {
                    $dfq = '(' . $dfq . ')';
                    $query->whereRaw($dfq);
                }
            }
        }
        if (!empty($email)) {
            if ($match) {
                $query->where('email_address', '=', $email);
            } else {
                $query->where('email_address', 'like', '%' . $email . '%');
            }
        }
        if (!empty($status)) {
            if (!is_array($status)) {
                $query->where('web_status', '=', $status);
            } else {
                $query->whereIn('web_status', $status);
            }
        }
        $result = $query->get();
        return $result;
    }

    function CreateOrUpdateUsr($usrInfo)
    {
        $result = array();

        $result['type'] = 'error';
        $result['id'] = 0;

        $statusWebUsr = array(0, 1, 46, 998, 999, 9999, '0', '1', '46', '998', '999', '9999');

        if (isset($usrInfo['account_number']) && !empty($usrInfo['account_number'])) {
            if (!isset($usrInfo['last_updated_by'])) {
                $usrInfo['last_updated_by'] = 'api2';
            }
            if (isset($usrInfo['web_status'])) {
                if (!in_array($usrInfo['web_status'], $statusWebUsr)) {
                    if ($usrInfo['web_status'] > 1000) {
                        $usrInfo['web_status'] == 9999;
                    } else {
                        $usrInfo['web_status'] = 0;
                    }
                }
            }

            if (isset($usrInfo['suppression'])) {
                if ($usrInfo['suppression'] != 1 && $usrInfo['suppression'] != 0) {
                    unset($usrInfo['suppression']);
                }
            }

            if (isset($usrInfo['web_user_id'])) {
                unset($usrInfo['web_user_id']);
            }


            $usr = DB::table('web_users')
                    ->where('account_number', $usrInfo['account_number'])
                    ->where('property_id', $usrInfo['property_id'])
                    ->select('web_user_id')
                    ->first();
            if (!empty($usr['web_user_id'])) {
                DB::table('web_users')
                        ->where('web_user_id', $usr['web_user_id'])
                        ->update($usrInfo);
                if (isset($usrInfo['balance'])) {
                    $balance = $usrInfo['balance'] * 1;
                    if ($balance <= 0) {
                        $balance = 0;
                    }

                    //update autopayments
                    $fld = array();
                    $fld['trans_recurring_net_amount'] = $balance;
                    $fld['trans_descr'] = 'Payment:      ' . number_format($balance, 2);
                    $objtx = new Transations();
                    $web_user_id = $usr['web_user_id'];
                    $objtx->updateRTxByUser($web_user_id, $fld, true);
                }
                $result['type'] = 'updated';
                $result['id'] = $usr['web_user_id'];
                if (isset($usrInfo['web_status'])) {
                    if ($usrInfo['web_status'] == 9999 || $usrInfo['web_status'] == '9999') {
                        $result['type'] = 'deleted';
                        $result['id'] = $usr['web_user_id'];
                    }
                }
            } else {
                if (!isset($usrInfo['web_status'])) {
                    $usrInfo['web_status'] = 998;
                }
                $usr['web_user_id'] = DB::table('web_users')
                        ->insertGetId($usrInfo);
                $result['type'] = 'add';
                $result['id'] = $usr['web_user_id'];
            }
        } else {
            if (!isset($usrInfo['first_name']) || empty($usrInfo['first_name'])) {
                if (!isset($usrInfo['last_name']) || empty($usrInfo['last_name'])) {
                    $result['type'] = 'error';
                    $result['id'] = 0;
                    return $result;
                }
            }
            if (!isset($usrInfo['web_status'])) {
                $usrInfo['web_status'] = 998;
            }
            $usr = DB::table('web_users')
                    ->insertGetId($usrInfo);
            $result['type'] = 'add';
            $result['id'] = $usr;
        }
        return $result;
    }

    public function searchWebUser($criteria)
    {
        $usr = DB::table('web_users')
                ->where('account_number', 'like', "%$criteria%")
                ->orWhere('first_name', 'like', "%$criteria%")
                ->orWhere('last_name', 'like', "%$criteria%")
                ->select('web_user_id', 'account_number', 'first_name', 'last_name', 'username', 'address', 'city', 'state', 'zip', 'country', 'email_address', 'phone_number')
                ->get();
        return $usr;
    }

    public function searchWebUserAcc($acc,$idproperty)
    {
        $usr = DB::table('web_users')
                ->where('account_number', 'like', $acc)
                ->where('property_id',$idproperty)
                ->where('web_status','<',1000)
                ->select('web_user_id', 'account_number', 'first_name', 'last_name', 'username', 'address', 'city', 'state', 'zip', 'country', 'email_address', 'phone_number','web_status')
                ->first();
        return $usr;
    }
    
    function getBillAmmount($web_user_id)
    {
        $query = DB::table('web_users_category')
                ->select('description', 'bill_amount')
                ->where('web_user_id', $web_user_id)
                ->where('bill_amount', '>', 0)
                ->get();
        return $query;
    }

    function getCategByUser($web_user_id, $all = 0, $object=1)
    {

        if ($all) {
            if($object){
                $query = DB::table('web_users_category')
                    ->where('web_user_id', $web_user_id)
                    ->where('description', '!=', 'Payment')
                    ->get();
            }
            else{
                $query = DB::table('web_users_category')
                    ->where('web_user_id', $web_user_id)
                    ->where('description', '!=', 'Payment');
            }

        } else {
            if($object) {
                $query = DB::table('web_users_category')
                    ->where('web_user_id', $web_user_id)
                    ->where('description', '!=', 'Payment')
                    ->where('added', 0)
                    ->get();
            }
            else{
                $query = DB::table('web_users_category')
                    ->where('web_user_id', $web_user_id)
                    ->where('description', '!=', 'Payment')
                    ->where('added', 0);
            }
        }

        return $query;
    }

    function getCategCreatedByUser($web_user_id)
    {
        $query = DB::table('web_users_category')
                ->where('web_user_id', $web_user_id)
                ->where('description', '!=', 'Payment')
                ->where('added', 1)
                ->get();
        return $query;
    }

    function getCategByProperty($idproperty)
    {
        $query = DB::table('payment_type')
                ->where('property_id', $idproperty)
                ->where('payment_type_name', '!=', 'Payment')
                ->get();
        return $query;
    }

    function getPaymentTypeById($id)
    {
        $query = DB::table('payment_type')
                ->where('payment_type_id', $id)
                ->where('payment_type_name', '!=', 'Payment')
                ->first();
        return $query;
    }

    function getPaymentTypeByPropDesc($idprop, $desc)
    {

        $query = DB::table('payment_type')
                ->where('property_id', $idprop)
                ->where('payment_type_name', $desc)
                ->where('payment_type_name', '!=', 'Payment')
                ->first();

        return $query;
    }

    function getCategByUPD($web_user_id, $property_id, $description)
    {
        $query = DB::table('web_users_category')
                ->where('web_user_id', $web_user_id)
                ->where('property_id', $property_id)
                ->where('description', $description)
                ->where('description', '!=', 'Payment')
                ->first();
        return $query;
    }

    function updateCategById($id, $data, $property_id)
    {

        if (isset($data['catname'])) {
            DB::table('payment_type')
                    ->where('payment_type_name', $data['catname'])
                    ->where('property_id', $property_id)
                    ->update(array(
                        'payment_type_name' => $data['editCatDesc'],
                        'amount' => $data['editCatAm'],
                        'payment_type_code' => '',
                    ));
        }
        DB::table('web_users_category')
                ->where('id', $id)
                ->update(array(
                    'code' => $data['editCatCode'],
                    'description' => $data['editCatDesc'],
                    'amount' => $data['editCatAm'],
                ));
    }

    /**
     * Gets web_users by property_id and status
     *
     * @param string $property_id the id of the web user
     * @param array $status the status to search
     * @return array
     */
    function getActAutWebUsersByPropertyId($property_id, $status)
    {
        $resul = DB::table('web_users')
                ->select('web_user_id', 'web_status')
                ->where('property_id', $property_id)
                ->whereIn('web_status', $status)
                ->get();
        return $resul;
    }

    /**
     * Gets the one click reminders by property_id and status
     * @param int $property_id
     * @param int $status
     * @return array
     */
    public function getOClickReminderByIdProperty($property_id, $status)
    {
        $result = DB::table('oneclick_reminder')
                ->select('id', 'status')
                ->where('id_properties', $property_id)
                ->where('status', $status)
                ->get();
        return $result;
    }

    /**
     * Updates one field from the one click reminder table
     * @param int $id
     * @param string $key
     * @param type $value
     */
    public function set1ClickReminderInfo($id, $key, $value)
    {
        DB::table('oneclick_reminder')
                ->where('id', $id)
                ->update(array($key => $value));
    }

    function setPasswordRaw($pass, $id)
    {
        DB::update("update web_users set password = PASSWORD('" . $pass . "') where web_user_id = ?", [$id]);
    }
    
    function getUserData($id){
        $query= \Illuminate\Support\Facades\DB::table('web_users')->where('web_user_id',$id)->first();
        return $query;
    }
    
    static function getAuditData($id){
        return \Illuminate\Support\Facades\DB::table('web_users')->where('web_user_id',$id)->select('web_user_id as id', \Illuminate\Support\Facades\DB::raw("CONCAT(account_number,' | ',first_name,' ',last_name) as name"))->first();
    } 
    
    static function getStatementByUser($iduser){
        $result= \Illuminate\Support\Facades\DB::table('statements')->where('id_users','=',$iduser)->select('ids','billcycle','amount','sfile')->orderBy('billcycle','desc');
        return $result;
    }
    
    static function getCountStatementByUser($iduser){
        $result=\Illuminate\Support\Facades\DB::table('statements')->where('id_users','=',$iduser)->count();
        return $result;
    }
}
