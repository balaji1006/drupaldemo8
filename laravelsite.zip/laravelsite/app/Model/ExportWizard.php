<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class ExportWizard extends Model {

    protected $table = 'export_wizard';
    protected $table_templates = 'export_wizard_templates';

    public function getTables() {
        $result = DB::table($this->table)->get();
        return $result;
    }

    public function getTableByName($name) {
        $result = DB::table($this->table)
                ->where('table_name', $name)
                ->first();
        return $result;
    }

    public function createTemplate($id_user, $data) {
        $id = DB::table($this->table_templates)->insertGetId([
            'id_user' => $id_user,
            'fields' => json_encode($data),
        ]);
        return $id;
    }

    public function saveTemplate($id_user, $data, $id_template) {
        DB::table($this->table_templates)
                ->where('id', $id_template)
                ->update(['fields' => json_encode($data)]);
    }

    public function deleteTemplate($id) {
        DB::table($this->table_templates)
                ->where('id', $id)
                ->delete();
    }

    public function getTemplates($id_user) {
        $result = DB::table($this->table_templates)
                ->where('id_user', $id_user)
                ->orderBy('id', 'DESC')
                ->get();
        return $result;
    }

    public function getTemplate($id_template) {
        $result = DB::table($this->table_templates)
                ->where('id', $id_template)
                ->first();
        return $result;
    }

}
