<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Bin extends Model
{

    protected $table = 'bin';
    protected $softDelete = false;
    public $timestamps = false;

    function findPanID($pancode, $network)
    {
        $result = DB::table($this->table)->where('bin_number', '=', $pancode)->where('table_id', 'LIKE', $network)->select('id')->first();
        if (empty($result)) {
            return 0;
        }
        return $result['id'];
    }

    function isCheckCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('CheckCard', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isGiftCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('GiftCard', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isCreditCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('CreditCard', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isCommercialCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('CommercialCard', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isPrepaidCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('PrepaidCard', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isHSACard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('HSAFSA', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isEBTCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('EBT', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isInternationalCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('International', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isFleetCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('FleetCard', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function isDebitCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->where('DebitCard', '=', 1)->select('id')->first();
        if (empty($result)) {
            return false;
        }
        return true;
    }

    function getAllBINbyCard($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")->get();
        return $result;
    }

    function getBinCardInfo($card)
    {
        $result = DB::table($this->table)->whereRaw("bin_number=SUBSTR('" . $card . "',1,bin_length)")
                ->orderBy('bin_length', 'desc')
                ->select('table_id as type', 'DebitCard', 'CheckCard', 'CreditCard', 'GiftCard', 'CommercialCard', 'FleetCard', 'PrepaidCard', 'HSAFSA', 'PinLess', 'EBT', 'WICBIN', 'International', 'DurbinBIN', 'PinLessPOS')
                ->first();
        return $result;
    }

    function ValidCCard($card, $pin)
    {
        $ccvalids = explode("|", $pin);
        if ($this->isCheckCard($card) && in_array("CheckCard", $ccvalids)) {
            return true;
        } elseif ($this->isGiftCard($card) && in_array("GiftCard", $ccvalids)) {
            return true;
        } elseif ($this->isCreditCard($card) && in_array("CreditCard", $ccvalids)) {
            return true;
        } elseif ($this->isCommercialCard($card) && in_array("CommercialCard", $ccvalids)) {
            return true;
        } elseif ($this->isPrepaidCard($card) && in_array("PrepaidCard", $ccvalids)) {
            return true;
        } elseif ($this->isHSACard($card) && in_array("HSACard", $ccvalids)) {
            return true;
        } elseif ($this->isEBTCard($card) && in_array("EBTCard", $ccvalids)) {
            return true;
        } elseif ($this->isInternationalCard($card) && in_array("InternationalCard", $ccvalids)) {
            return true;
        } elseif ($this->isFleetCard($card) && in_array("FleetCard", $ccvalids)) {
            return true;
        } elseif ($this->isDebitCard($card) && in_array("DebitCard", $ccvalids)) {
            return true;
        }
        return false;
    }
}
