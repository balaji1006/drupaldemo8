<?php

namespace App\Model;
use Illuminate\Database\Eloquent\Model;
use DB;

class Pricing extends Model {
    public function getAllPricing(){
        $pricing_db = DB::table('pricing')
            ->join('price_table', 'price_table.idpt', '=', 'pricing.id_table')
            ->groupBy('price_table.tlabel')

        ;
        return $pricing_db;
    }

    public function getServices($id_table){
        $pricing_db = DB::table('pricing')
            ->join('bill_item', 'bill_item.id_bill', '=', 'pricing.service')
            ->join('bill_cycle', 'bill_cycle.id', '=', 'pricing.freq')
            ->where('pricing.id_table','=',$id_table);
        return $pricing_db;
    }

    public function getPGM($id_table){
        $pricing_db = DB::table('pricing')
            ->join('price_applied_to', 'price_applied_to.id_pricing', '=', 'pricing.id_table')
            ->join('partners', 'price_applied_to.id_partners', '=', 'partners.id')
            ->leftjoin('companies', 'price_applied_to.id_companies', '=', 'companies.id')
            ->leftjoin('properties', 'price_applied_to.id_property', '=', 'properties.id')
            ->groupby('partners.id')
            ->where('pricing.id_table','=',$id_table);
        return $pricing_db;
    }

    public function getPAT($id_table){
        $pricing_db = DB::table('price_applied_to')
            ->join('partners', 'price_applied_to.id_partners', '=', 'partners.id')
            ->leftjoin('companies', 'price_applied_to.id_companies', '=', 'companies.id')
            ->leftjoin('properties', 'price_applied_to.id_property', '=', 'properties.id')
            ->where('price_applied_to.id_pricing','=',$id_table)
            ->select('partners.partner_title','companies.company_name','properties.name_clients');
        return $pricing_db;
    }


    public function getPricingTable($id_table){
        $pricing_db = DB::table('price_table')
            ->where('price_table.idpt','=',$id_table)
            ->first()
        ;
        return $pricing_db;
    }

    public function getPricingByPT($id_table){
        $pricing = DB::table('pricing')
            ->where('pricing.id_table','=',$id_table)
            ->get()
        ;
        return $pricing;
    }
    
    function getPricingByFilter(){
        $pricing_db = DB::table('price_table');
        return $pricing_db;
    }
}