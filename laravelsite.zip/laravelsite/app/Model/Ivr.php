<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Ivr extends Model {

    protected $table;

    function __construct() {
        $this->table = 'ivr';
    }

    function getIvrInfo($ivr_id) {
        $ivr = $this->where('execute', 1)->where('ivr_id', $ivr_id)->select('id_property', 'give_balance', 'type_validation', 'id', 'rules')->first();
        return $ivr;
    }

    function isValidToken($api_usr, $api_passw) {
        $isvalid = DB::table('api_user')->where('apiusername', $api_usr)
                ->whereRaw("sha1('" . $api_passw . "')= apipasswd")
                ->where('ustatus', 1)
                ->select('id_property', 'id_company', 'id_partner')
                ->first();
        return $isvalid;
    }

    function getUsrAccNum($usr_id, $level, $idlevel) {
        $usr1 = DB::table('web_users')->join('properties', 'properties.id', '=', 'web_users.property_id')->whereIn('web_status', [1, 46, 998])->where('account_number', '=', $usr_id);
        if ($level == 'P') {
            $usr1->where('properties.id_partners', '=', $idlevel);
        } elseif ($level == 'G') {
            $usr1->where('properties.id_companies', '=', $idlevel);
        } else {
            $usr1->where('property_id', '=', $idlevel);
        }
        $usr = $usr1->select('last_name', 'balance', 'web_user_id', 'first_name', 'last_name', 'property_id')->get();
        return $usr;
    }

    function ValidIVR($ivr_id, $level, $idlevel) {
        if ($level == 'G') {
            $cd = DB::table('properties')->where('id_companies', '=', $idlevel)->where('id', '=', $ivr_id)->count();
            if (empty($cd))
                return false;
        }
        elseif ($level == 'P') {
            $cd = DB::table('properties')->where('id_partners', '=', $idlevel)->where('id', '=', $ivr_id)->count();
            if (empty($cd))
                return false;
        }
        return true;
    }

    function getUsrWebId($usr_id, $id_property, $rule = null) {
        $usr = DB::table('web_users')->where('web_user_id', $usr_id)->where('property_id', $id_property)->whereIn('web_status', [1, 998])->select('last_name', 'balance', 'web_user_id', 'first_name', 'last_name')->first();
        return $usr;
    }

    function isValidCardNumber($ccNum) {
        $type = "";
        if (preg_match("/^5[1-5][0-9]{14}$/", $ccNum))
            $type = "MasterCard";

        if (preg_match("/^4[0-9]{12}([0-9]{3})?$/", $ccNum))
            $type = "Visa";

        if (preg_match("/^3[47][0-9]{13}$/", $ccNum))
            $type = "AmericanExpress";

        if (preg_match("/^3(0[0-5]|[68][0-9])[0-9]{11}$/", $ccNum))
            $type = "DinersClub";

        if (preg_match("/^6011[0-9]{12}$/", $ccNum))
            $type = "Discover";

        if (preg_match("/^(3[0-9]{4}|2131|1800)[0-9]{11}$/", $ccNum))
            $type = "JCB";

        if (empty($type)) {
            return false;
        }

        $revcode = strrev($ccNum);
        $checksum = 0;

        for ($i = 0; $i < strlen($revcode); $i++) {
            $current_num = intval($revcode[$i]);
            if ($i & 1) {  // Odd  position
                $current_num *= 2;
            }
            // Split digits and add.
            $checksum += $current_num % 10;
            if
            ($current_num > 9) {
                $checksum += 1;
            }
        }

        if ($checksum % 10 == 0) {
            return true;
        } else {
            return false;
        }
    }

    function isValidCardvsCredentials($ccNum, $idp) {
        $type = "";
        if (preg_match("/^3[47][0-9]{13}$/", $ccNum))
            $type = "AmericanExpress";

        $amex = DB::table('merchant_account')->where('property_id', $idp)->where('is_recurring', 0)->whereIn('payment_method', ['amex', 'am'])->count();
        if (empty($amex) && $type == "AmericanExpress") {
            return false;
        }


        $cc = DB::table('merchant_account')->where('property_id', $idp)->where('is_recurring', 0)->where('payment_method', 'cc')->count();
        if (empty($cc) || $type == "AmericanExpress")
            return false;
        return true;
    }

    function isValidRouting($RoutingNumber) {
        if (!is_numeric($RoutingNumber) || strlen($RoutingNumber) != 9)
            return false;

        $len = strlen($RoutingNumber);
        $first_two = substr($RoutingNumber, 0, 2);

        if (!(($first_two >= 01 && $first_two <= 15) ||
                ($first_two >= 21 && $first_two <= 32) ||
                ($first_two >= 61 && $first_two <= 72))
        ) {
            return false;
        }

        for ($j = 0; $j < $len; $j++) {
            $temp = "" + substr($RoutingNumber, $j, 1);
            if ($temp < 0 || $temp > 9)
                return false;
        }

        $iTotal = 0;
        for ($i = 0; $i < $len; $i += 3) {
            $iTotal += substr($RoutingNumber, $i, 1) * 3 + substr($RoutingNumber, $i + 1, 1) * 7 + substr($RoutingNumber, $i + 2, 1);
        }

        if ($iTotal != 0 && $iTotal % 10 == 0) {
            return true;
        } else {
            return false;
        }
    }

    function isValidProperty($id_property, $id_companies, $id_partners) {
        if ($id_property != 0) {
            $id = DB::table('properties')->where('id', $id_property)->select('id')->first();
        } else if ($id_companies != 0) {
            $id = DB::table('properties')->where('id_companies', $id_companies)->select('id')->first();
        } else if ($id_partners != 0) {
            $id = DB::table('properties')->where('id_partners', $id_partners)->select('id')->first();
        } else {
            return false;
        }
        if (empty($id)) {
            return false;
        }
        if ($id['id'] > 0) {
            return true;
        }
        return false;
    }

    function isValidPropertyByToken($ivr_id, $id_property, $id_companies, $id_partners) {
        if ($id_property != 0) {
            if ($id_property == $ivr_id) {
                return true;
            }
        } else if ($id_companies != 0) {
            $id = DB::table('properties')->where('id_companies', $id_companies)->where('id', $ivr_id)->select('id')->first();
        } else if ($id_partners != 0) {
            $id = DB::table('properties')->where('id_partners', $id_partners)->where('id', $ivr_id)->select('id')->first();
        } else {
            return false;
        }
        if (empty($id)) {
            return false;
        }
        if ($id['id'] > 0) {
            return true;
        }
        return false;
    }

    function getIvrByProperty($id_property) {
        $result = DB::table('ivr')->where('id_property', $id_property)->first();
        return $result;
    }

    function getIVRToken($phone_number) {
        if ($phone_number != 0) {
            $ivr_token = DB::table('ivr_token')->where('ivr_phone', $phone_number)->select('token')->first();
        } else {
            return false;
        }

        return $ivr_token;
    }

}
