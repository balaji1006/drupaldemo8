<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Categories extends Model
{

    protected $table = 'payment_type';
    protected $softDelete = false;
    public $timestamps = false;

    public function getCategoriesByFilter($idlevel, $filter = null) {
        $query = DB::table($this->table)
            ->orderBy('payment_type_id','DESC')
            ->where('property_id',$idlevel);

        return $query;
    }

    function getCategoriesPGM($id, $type)
    {
        switch (strtolower($type)) {
            case 'b':
                $partnersA=DB::table('branch_partner')->where('branch_id',$id)->select('id_partners')->get();
                $partners=array();
                foreach($partnersA as $pa){
                    $partners[]=$pa->id_partners;
                }
                $result = DB::table('trans_categories')
                        ->join('accounting_transactions', 'trans_categories.trans_id', '=', 'accounting_transactions.trans_id')
                        ->join('partners', 'trans_categories.id_partners', '=', 'partners.id')
                        ->join('companies', 'trans_categories.id_companies', '=', 'companies.id')
                        ->join('properties', 'trans_categories.id_properties', '=', 'properties.id')
                        ->whereIn('properties.id_partners',$partners)
                        ->select('accounting_transactions.trans_first_post_date', 'partners.partner_title', 'companies.company_name', 'properties.name_clients', 'accounting_transactions.trans_account_number', 'trans_user_name', 'qty', 'amount', 'category_name','trans_categories.trans_id');
                return $result;
                break;
            case 'a':
                $result = DB::table('trans_categories')
                        ->join('accounting_transactions', 'trans_categories.trans_id', '=', 'accounting_transactions.trans_id')
                        ->join('partners', 'trans_categories.id_partners', '=', 'partners.id')
                        ->join('companies', 'trans_categories.id_companies', '=', 'companies.id')
                        ->join('properties', 'trans_categories.id_properties', '=', 'properties.id')
                        ->select('accounting_transactions.trans_first_post_date', 'partners.partner_title', 'companies.company_name', 'properties.name_clients', 'accounting_transactions.trans_account_number', 'trans_user_name', 'qty', 'amount', 'category_name','trans_categories.trans_id');
                return $result;
                break;
            case 'p':
                $result = DB::table('trans_categories')
                        ->join('accounting_transactions', 'trans_categories.trans_id', '=', 'accounting_transactions.trans_id')
                        ->join('companies', 'trans_categories.id_companies', '=', 'companies.id')
                        ->join('properties', 'trans_categories.id_properties', '=', 'properties.id')
                        ->where('companies.id_partners', $id)
                        ->select('accounting_transactions.trans_first_post_date', 'companies.company_name', 'properties.name_clients', 'accounting_transactions.trans_account_number', 'trans_user_name', 'qty', 'amount', 'category_name','trans_categories.trans_id');
                return $result;
                break;
            case 'g':
                $result = DB::table('trans_categories')
                        ->join('accounting_transactions', 'trans_categories.trans_id', '=', 'accounting_transactions.trans_id')
                        ->join('properties', 'trans_categories.id_properties', '=', 'properties.id')
                        ->where('properties.id_companies', $id)
                        ->select('accounting_transactions.trans_first_post_date', 'properties.name_clients', 'accounting_transactions.trans_account_number', 'trans_user_name', 'qty', 'amount', 'category_name','trans_categories.trans_id');
                return $result;
                break;
            case 'm':
                $result = DB::table('trans_categories')
                        ->join('accounting_transactions', 'trans_categories.trans_id', '=', 'accounting_transactions.trans_id')
                        ->where('trans_categories.id_properties', $id)
                        ->select('accounting_transactions.trans_first_post_date', 'accounting_transactions.trans_account_number', 'trans_user_name', 'qty', 'amount', 'category_name','trans_categories.trans_id');
                return $result;
                break;

            default:
                return null;
        }
    }

    function insertCategoryforMerchant($data)
    {
        if (isset($data['payment_type_code']) && $data['payment_type_code'] != '') {
            $result = $this->where('property_id', '=', $data['property_id'])->where('payment_type_code', '=', $data['payment_type_code'])->select('payment_type_id')->first();
            if (!empty($result)) {
                return;
            }
        }
        DB::table($this->table)->insert($data);
    }


    /**
     * Get the category
     * @param string $payment_type_code the code to search
     * @param string $property_id the property id to search
     * @return array the category data found
     */
    function getCatByCodeAndPropId($payment_type_code, $property_id)
    {
        return DB::table('payment_type')
                        ->where('payment_type_code', '=', $payment_type_code)
                        ->where('property_id', '=', $property_id)
                        ->select('payment_type_id')
                        ->first();
    }

    /**
     *  Insert a new category
     * @param array $data the info to set
     * @return array the result
     */
    function createCategory($data)
    {
        $result = [];
        if (isset($data['payment_type_id'])) {
            unset($data['payment_type_id']);
        }
        $id = DB::table('payment_type')->insertGetid($data);
        $data['payment_type_id'] = $id;
        $result['type'] = 'add';
        $result['category'] = $data;
        return $result;
    }

    /**
     * Update the category
     * @param int $payment_type_id the id of the category to update
     * @param array $data the info to set
     * @return array the result
     */
    function updateCategory($payment_type_id, $data)
    {
        $result = [];
        DB::table('payment_type')
                ->where('payment_type_id', '=', $payment_type_id)
                ->update($data);
        $data['payment_type_id'] = $payment_type_id;
        $result['type'] = 'updated';
        $result['category'] = $data;

        return $result;
    }

    function DeleteCategory($category)
    {
        $pid = "";
        $pcode = "";
        $result = array();

        //Empty Category
        if (empty($category)) {
            $result['type'] = 'error';
            $result['category'] = "Empty Category";
            return $result;
        }

        if (isset($category['payment_type_id']) && !empty($category['payment_type_id'])) {
            $pid = $category['payment_type_id'];
            $info = DB::table('payment_type')
                            ->where('payment_type_id', '=', $category['payment_type_id'])
                            ->where('property_id', '=', $category['property_id'])
                            ->select('payment_type_code', 'property_id')->first();
            if (!empty($info['property_id'])) {
                DB::table('payment_type')
                        ->where('payment_type_id', '=', $category['payment_type_id'])
                        ->where('property_id', '=', $category['property_id'])
                        ->delete();
                $result['type'] = 'deleted';
                $result['category'] = array('payment_type_id' => $category['payment_type_id'], 'code' => $info['payment_type_code']);
                return $result;
            }
        }
        if (isset($category['payment_type_code']) && !empty($category['payment_type_code'])) {
            $pcode = $category['payment_type_code'];
            $info = DB::table('payment_type')
                            ->where('payment_type_code', '=', $category['payment_type_code'])
                            ->where('property_id', '=', $category['property_id'])
                            ->select('payment_type_id')->first();
            if (!empty($info['payment_type_id'])) {
                DB::table('payment_type')
                        ->where('payment_type_id', '=', $info['payment_type_id'])
                        ->where('property_id', '=', $category['property_id'])
                        ->delete();
                $result['type'] = 'deleted';
                $result['category'] = array('payment_type_id' => $info['payment_type_id'], 'code' => $category['payment_type_code']);
                return $result;
            }
        }

        $result['type'] = 'error';
        $result['category'] = array('payment_type_id' => $pid, 'code' => $pcode);

        return $result;
    }

    function getCatByCode($idproperty, $code)
    {
        $dbCat = $this->where('property_id', $idproperty)->where('payment_type_code', $code)->first();
        return $dbCat;
    }

    function UpdateCat($idcat, $data)
    {
        $this->updateCategory($idcat, $data);
    }

    function InsertCat($data)
    {
        $this->createCategory($data);
    }

    function Get1Data($id, $key)
    {
        $dbCat = $this->where('payment_type_id', $id)->select($key)->first();
        return $dbCat[$key];
    }

    function UpdateBalance($paymentInfo)
    {
        $obj_user = new WebUsers();
        if (isset($paymentInfo['categories']) && isset($paymentInfo['web_user_id'])) {
            $cat = $paymentInfo['categories'];
            for ($i = 0; $i < count($cat); $i++) {
                if (isset($cat[$i]['id']) && !empty($cat[$i]['id'])) {
                    $is_balance = $this->Get1Data($cat[$i]['id'], 'is_balance');
                    if (!empty($is_balance) && $is_balance == 1 && !empty($paymentInfo['web_user_id'])) { //update user balance
                        $balance = $obj_user->get1UserInfo($paymentInfo['web_user_id'], 'balance');
                        $balance = $balance - $cat[$i]['amount'];
                        $obj_user->set1UserInfo($paymentInfo['web_user_id'], "balance", $balance);
                    }
                }
            }
        }
    }

    function getCatByID($id, $property_id)
    {
        $cat = DB::table('payment_type')
                ->where('property_id', $property_id)
                ->where('payment_type_id', $id)
                ->first();
        return $cat;
    }
    
    function removeCategory($id){
        DB::table('payment_type')->where('payment_type_id',$id)->delete();
    }
}
