<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Layout extends Model {

    protected $table = 'layout';
    protected $softDelete = false;
    public $timestamps = false;

    function getLayouts() {
        $result = DB::table($this->table);
        return $result;
    }

    function getLayoutsObj() {
        $result = DB::table($this->table)->where('layout.id_layout', '>', 0)->orderBy('idl', 'DESC');
        return $result;
    }

    function getDefaultLayout($id = 0) {
        $result = DB::table('layout_labels')->where('id_layout', $id)->get();
        return $result;
    }

    function getLayoutValues($idlevel, $level) {
        $layout_id = 0;
        if ($level == 'P') {

            $playout = \Illuminate\Support\Facades\DB::table('partners')->where('id', $idlevel)->select('layout_id')->first();
            if (!empty($playout)) {
                $layout_id = $playout->layout_id;
            }
        } elseif ($level == 'G') {
            $glayout = \Illuminate\Support\Facades\DB::table('companies')->where('id', $idlevel)->select('clayout_id', 'id_partners')->first();
            if (!empty($glayout)) {
                $layout_id = $glayout->clayout_id;
            }
            if ($layout_id == 0) {
                $playout = \Illuminate\Support\Facades\DB::table('partners')->where('id', $glayout->id_partners)->select('layout_id')->first();
                if (!empty($playout)) {
                    $layout_id = $playout->layout_id;
                }
            }
        } elseif ($level == 'M') {
            $mlayout = \Illuminate\Support\Facades\DB::table('properties')->where('id', $idlevel)->select('playout_id', 'id_companies')->first();
            if (!empty($mlayout)) {
                $layout_id = $mlayout->playout_id;
            }
            if ($layout_id == 0) {
                $glayout = \Illuminate\Support\Facades\DB::table('companies')->where('id', $mlayout->id_companies)->select('clayout_id', 'id_partners')->first();
                if (!empty($glayout)) {
                    $layout_id = $glayout->clayout_id;
                }
                if ($layout_id == 0) {
                    $playout = \Illuminate\Support\Facades\DB::table('partners')->where('id', $glayout->id_partners)->select('layout_id')->first();
                    if (!empty($playout)) {
                        $layout_id = $playout->layout_id;
                    }
                }
            }
        }

        return $this->getDefaultLayout($layout_id);
    }

    function saveNewLayout($data) {

        $max = DB::table('layout')->max('id_layout');
        DB::table('layout')->insert(array('lay_name' => $data['name'], 'id_layout' => $max + 1));
        unset($data['_token']);
        unset($data['name']);
        foreach ($data as $key => $d) {
            DB::table('layout_labels')->insert(array('id_layout' => $max + 1, 'label' => $key, 'text' => $d));
        }
    }

    function updateLayout($data, $id) {

        DB::table('layout')->where('idl', $id)->update(array('lay_name' => $data['name']));
        $layout = DB::table('layout')->where('idl', $id)->first();
        if ($layout) {

            unset($data['_token']);
            unset($data['name']);
            foreach ($data as $key => $d) {
                DB::table('layout_labels')
                        ->where('id_layout', $layout->id_layout)
                        ->where('label', $key)
                        ->update(array('text' => $d));
            }
        }
    }

    function getLayoutValuesMaster($id) {
        $result = DB::table('layout')
                ->where('layout.idl', $id)
                ->join('layout_labels', 'layout_labels.id_layout', '=', 'layout.id_layout')
                ->get();

        return $result;
    }

    static function extractLayoutValue($key, $layout) {
        $label = '';
        foreach ($layout as $record) {
            if ($record->label == $key) {
                $label = $record->text;
                return $label;
            }
        }
        return $label;
    }

}
