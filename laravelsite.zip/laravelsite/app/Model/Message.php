<?php

namespace App\Model;

class Message
{

    private $message = array(
        'eterm1' => 'Customer Information is Empty',
        'etermninv' => 'Invoice Information is Empty',
        'eterm2' => 'User not found',
        'eterm0' => 'Unfortunately, we are not allowed to accept payments for this account by phone. Please contact [:DBA_NAME:] for further information.',
        'eterm999' => 'Unfortunately, we are not allowed to accept payments for this account by phone. Please contact [:DBA_NAME:] for further information.',
        'eterm0999' => 'Unfortunately, we are not allowed to accept payments for this account by phone. Please contact [:DBA_NAME:] for further information.',
        //'eterm0'=>'Sorry - you cannot make a payment for an Inactive user.',
        //'eterm999'=>'Sorry - you cannot make a payment for an UnAuthorized user.',
        //'eterm0999'=>'Sorry - you cannot make a payment for an UnAuthorized or Inactive user.',
        'exptoken' => 'Invalid Token',
        'invApiKey' => 'Invalid API Key',
        'emptyacc' => 'Account # Field is required',
        'emptyfirstnameacc' => 'At least one of the First Name or Account # fields is required',
        'existacc' => 'A user with this account number already exists in the system',
        'exptime' => 'Session Expired. Please refresh your browser',
        'invApiKey' => 'Invalid Token',
        'invtoken' => 'Invalid Token',
        'noinv' => 'Invoice # not found',
        'inv_noact' => 'This Invoice is already in use',
        'inv_status' => 'This Invoice is already ',
        'sectoken1' => 'sectoken is already in use',
        'sectoken2' => 'sectoken received has too many declines',
        'payonline1' => "Sorry! You've entered an incorrect username or password. Please try again",
        'payonline2' => "Sorry! We couldn't find a match with the email address entered. Please try again",
        'payonline3' => "Your username has been sent to your email address. You should receive the email within 15 minutes. If you do not receive the email, please check your spam folder or contact us.",
        'payonline4' => "Your password reset request has been received! Please check your email for instructions on how to set your new password. You should receive the email within 15 minutes. If you do not receive the email, please check your spam folder or contact us.",
        'payonline5' => "Data not found. Please refine your search.",
        'payonline6' => "Sorry, your session has expired due to inactivity. Please refresh your browser to continue.",
        'payonline7' => "Sorry! We couldn't find a match with the email address, username and password entered. Please try again.",
        'payonline8' => "Sorry! We couldn't find a match with the username and email address entered. Please try again.",
        'oneclick1' => "Invalid property ID.",
        'oneclick2' => "Invalid web user ID.",
        'oneclick3' => "Invalid API key.",
        'oneclick4' => "Invalid transaction ID.",
        'oneclick5' => "Sorry! The One-Click payment option is no longer active for this merchant.",
        'oneclick6' => "Sorry! You have already made a payment using this link.",
        'oneclick7' => "Sorry! You are not able to make a One-Click Payment",
        'oneclick8' => "Sorry! You are only allowed to make 1 One-Click Payment per Day",
        'oneclick9' => "Sorry! This link has expired. To make a payment, please login to your account.",
        'oneclick10' => "Oops! You do not have an active payment method saved! Please login and add a payment method to continue with your payment",
        'nocredential' => "Sorry! You haven't credentials",
        'norefund' => "Function not allowed in this gateway",
        'transactionRefunded' => "The full amount of this transaction has already been refunded. Please contact Customer Service for further assistance.",
        'invalidRefundAmount' => "Invalid amount to Refund",
        'invalidPartialRefundEC' => "Invalid amount to Refund, you cannot make a partial refund to echeck transactions"
    );

    function __construct()
    {
    }

    public function getMessageByKey($key)
    {
        return $this->message[$key];
    }

    function getMessage()
    {
        return $this->message;
    }
}
