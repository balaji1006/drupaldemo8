<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class TopsData extends Model {

    protected $table = 'tops_data';
    protected $softDelete = false;
    public $timestamps = false;

    public function createTOPS($data) {
        $result = DB::table($this->table)->insertGetId($data);
        return $result;
    }

    public function getIDfromMerchant($idProperty) {
        $result = DB::table($this->table)->where('id_property', '=', $idProperty)->select('id')->first();
        return !empty($result) ? $result->id : 0;
    }

    public function getIDbyCompany($idCompany) {
        $result = DB::table($this->table)->where('id_company', '=', $idCompany)->select('id')->get();
        return !empty($result) ? $result : 0;
    }

    public function getIDPropbyCompany($idCompany) {
        $result = DB::table($this->table)->where('id_company', '=', $idCompany)->get();
        return !empty($result) ? $result : 0;
    }

    public function updateTOPS($idTops, $data) {
        DB::table($this->table)->where('id', '=', $idTops)->update($data);
    }

    public function get1Info($id, $key) {
        $result = DB::table($this->table)->where('id', '=', $id)->select($key)->first();
        return $result->$key;
    }

    public function getByMerchant($idLevel) {
        $result = DB::table($this->table)->where('id_property', '=', $idLevel)->first();
        return $result;
    }

    public function set1Info($id, $key, $value) {
        DB::table($this->table)->where('id', '=', $id)->update(array($key => $value));
    }

    public function getListPayment() {
        $result = DB::table($this->table)->where('pay_account_id', '>', 0)->get();
        return $result;
    }

    public function getAllData() {
        $result = DB::table($this->table)->get();
        return $result;
    }

    public function getTopsKey($id, $level) {
        $query = DB::table($this->table);
        switch ($level) {
            case 'M':
                $query->where('id_property', $id);
                break;
            case 'G':
                $query->where('id_company', $id);
                break;
            case 'P':
                $query->where('id_partner', $id);
                break;
            default:
                $query = NULL;
        }

        return $query != NULL ? $query->get() : '';
    }

}
