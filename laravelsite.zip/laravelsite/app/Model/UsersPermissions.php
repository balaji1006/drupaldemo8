<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UsersPermissions extends Model
{

    protected $table = 'users_permissions';
    protected $primaryKey = 'users_admin_id';
    public $incrementing = false;
    public $timestamps = false;

    function Permissions()
    {
        return $this->belongsTo('App\Model\Permissions', 'permissions_id');
    }

    function getUserAdminPermissions($id){
        $data = $this->where('users_admin_id',$id)->get();
        return $data;
    }
}
