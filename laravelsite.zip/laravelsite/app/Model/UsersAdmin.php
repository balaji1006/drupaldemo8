<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class UsersAdmin extends Model
{

    protected $table = 'users_admin';
    public $timestamps = false;

    function getUsersAdmins($level, $idlevel){
        switch (strtoupper($level)){
            case "A":
                $data= DB::table('users_access_master')
                    ->join('users_admin','users_access_master.users_admin_id','=','users_admin.id')
                    ->orderBy('users_admin.id','DESC');
                return $data;
                break;
            case "B":
                $data= DB::table('users_access_branch')
                    ->join('users_admin','users_access_branch.users_admin_id','=','users_admin.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('users_access_branch.branch_id',$idlevel);
                return $data;
                break;
            case "P":
                $data= DB::table('users_access_partners')
                    ->join('users_admin','users_access_partners.users_admin_id','=','users_admin.id')
                    ->join('partners','users_access_partners.partners_id','=','partners.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('users_access_partners.partners_id',$idlevel);
                return $data;
                break;
            case "G":
                $data= DB::table('users_access_company')
                    ->join('users_admin','users_access_company.users_admin_id','=','users_admin.id')
                    ->join('companies','users_access_company.companies_id','=','companies.id')
                    ->join('partners','companies.id_partners','=','partners.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('users_access_company.companies_id',$idlevel);
                return $data;
                break;
            case "M":
                $data= DB::table('users_access_merchant')
                    ->join('users_admin','users_access_merchant.users_admin_id','=','users_admin.id')
                    ->join('properties','users_access_merchant.property_id','=','properties.id')
                    ->join('companies','properties.id_companies','=','companies.id')
                    ->join('partners','properties.id_partners','=','partners.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('users_access_merchant.property_id',$idlevel);
                return $data;
                break;

        }

    }

    function getUsersAdminsCompanies($level,$idlevel){
        switch (strtoupper($level)) {
            case "B":
                $bdata= DB::table('branch_partner')->where('branch_partner.branch_id',$idlevel)->get();
                $partners = array();
                foreach($bdata as $pa){
                    $partners[]=$pa->id_partners;
                }

                $data= DB::table('companies')
                    ->join('users_access_company','users_access_company.companies_id','=','companies.id')
                    ->join('users_admin','users_access_company.users_admin_id','=','users_admin.id')
                    ->join('partners','companies.id_partners','=','partners.id')
                    ->orderBy('users_admin.id','DESC')
                    ->whereIn('companies.id_partners',$partners);
                return $data;
                break;
            case "P":
                $data= DB::table('companies')
                    ->join('users_access_company','users_access_company.companies_id','=','companies.id')
                    ->join('users_admin','users_access_company.users_admin_id','=','users_admin.id')
                    ->join('partners','companies.id_partners','=','partners.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('companies.id_partners',$idlevel);
                return $data;
                break;
            case "G":
                $data= DB::table('companies')
                    ->join('users_access_company','users_access_company.companies_id','=','companies.id')
                    ->join('users_admin','users_access_company.users_admin_id','=','users_admin.id')
                    ->join('partners','companies.id_partners','=','partners.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('companies.id',$idlevel);
                return $data;
                break;
        }

    }

    function getUsersAdminsMerchants($level,$idlevel){
        switch (strtoupper($level)) {
            case "B":
                $bdata= DB::table('branch_partner')->where('branch_partner.branch_id',$idlevel)->get();
                $partners = array();
                foreach($bdata as $pa){
                    $partners[]=$pa->id_partners;
                }

                $data= DB::table('properties')
                    ->join('users_access_merchant','users_access_merchant.property_id','=','properties.id')
                    ->join('users_admin','users_access_merchant.users_admin_id','=','users_admin.id')
                    ->join('partners','properties.id_partners','=','partners.id')
                    ->join('companies','properties.id_companies','=','companies.id')
                    ->orderBy('users_admin.id','DESC')
                    ->whereIn('properties.id_partners',$partners);
                return $data;
                break;
            case "P":
                $data= DB::table('properties')
                    ->join('users_access_merchant','users_access_merchant.property_id','=','properties.id')
                    ->join('users_admin','users_access_merchant.users_admin_id','=','users_admin.id')
                    ->join('partners','properties.id_partners','=','partners.id')
                    ->join('companies','properties.id_companies','=','companies.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('properties.id_partners',$idlevel);
                return $data;
                break;
            case "G":
                $data= DB::table('properties')
                    ->join('users_access_merchant','users_access_merchant.property_id','=','properties.id')
                    ->join('users_admin','users_access_merchant.users_admin_id','=','users_admin.id')
                    ->join('partners','properties.id_partners','=','partners.id')
                    ->join('companies','properties.id_companies','=','companies.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('properties.id_companies',$idlevel);
                return $data;
                break;
            case "M":
                $data= DB::table('properties')
                    ->join('users_access_merchant','users_access_merchant.property_id','=','properties.id')
                    ->join('users_admin','users_access_merchant.users_admin_id','=','users_admin.id')
                    ->join('companies','properties.id_companies','=','companies.id')
                    ->join('partners','properties.id_partners','=','partners.id')
                    ->orderBy('users_admin.id','DESC')
                    ->where('properties.id',$idlevel);
                return $data;
                break;
        }



    }

    function getUsersAdminsPartners($level,$idlevel){



        switch (strtoupper($level)) {
            case "B":
                $bdata= DB::table('branch_partner')->where('branch_partner.branch_id',$idlevel)->get();
                $partners = array();
                foreach($bdata as $pa){
                    $partners[]=$pa->id_partners;
                }

                $data= DB::table('partners')
                    ->join('users_access_partners','users_access_partners.partners_id','=','partners.id')
                    ->join('users_admin','users_access_partners.users_admin_id','=','users_admin.id')
                    ->orderBy('users_admin.id','DESC')
                    ->whereIn('partners.id',$partners);
                return $data;
                break;
        }



    }

    function getUserAdminByUsername($username){
        $data = DB::table($this->table)->where('username',$username)->first();
        return $data;
    }

    function getUserAdminById($id){
        $data = DB::table($this->table)->where('id',$id)->first();
        return $data;
    }
}
