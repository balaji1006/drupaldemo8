<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Invoices extends Model
{

    protected $table = 'invoice';
    protected $softDelete = false;
    public $timestamps = false;
    
    function getInvoiceByFilter($idlevel){
        $query=DB::table($this->table)->where('invoice.property_id',$idlevel)
                ->join('web_users','web_users.web_user_id','=','invoice.web_user_id')
                ->where('recurring',0)
                ->select('id', 'invoice_number', 'status', 'invoice_date', 'invoice_due_date', 'amount', 'paid', 'invoice.web_user_id','description',DB::raw("CONCAT(web_users.first_name,' ',web_users.last_name) as name"),'invoice_reference','sentby','invoice.property_id','status');
        return $query;
    }

    function getInvoiceByInvoice_number($invoice_number, $property_id, $web_user_id)
    {
        $invoice_info = $this->select('id', 'status', 'invoice_number', 'invoice_date', 'invoice_due_date', 'amount', 'paid', 'notes', 'terms')->where('web_user_id', $web_user_id)->where('property_id', $property_id)->where('invoice_number', $invoice_number)->first();
        return $invoice_info;
    }
    
    function getInvoiceByInvoiceID($id, $property_id)
    {
        $invoice_info = $this->select('id', 'status', 'invoice_number', 'invoice_date', 'invoice_due_date', 'amount', 'paid', 'notes', 'terms','web_user_id', 'description', 'property_id')->where('id', $id)->where('property_id', $property_id)->first();
        return $invoice_info;
    }
    
    function deleteInvoiceTotal($id){
        DB::table('invoice_discount')->where('discount_idinvoice',$id)->delete();
        DB::table('invoice_data')->where('id_invoice',$id)->delete();
        DB::table('invoice')->where('id',$id)->delete();
    }

    function getUserByInv_num($inv_num, $idp)
    {
        $result = $this->where('invoice_number', $inv_num)->where('property_id', $idp)->select('web_user_id')->first();
        if (empty($result['web_user_id'])) {
            return 0;
        }
        $result = DB::table('web_users')->where('web_user_id', $result['web_user_id'])->where('property_id', $idp)->whereIn('web_status', [1, 46, 998])->first();
        return $result;
    }
    
    function getUserByInvID($invid, $idp)
    {
        $result = $this->where('id', $invid)->where('property_id', $idp)->select('web_user_id')->first();
        if (empty($result['web_user_id'])) {
            return 0;
        }
        $result = DB::table('web_users')->where('web_user_id', $result['web_user_id'])->where('property_id', $idp)->whereIn('web_status', [1, 46, 998])->first();
        return $result;
    }

    function getInvoiceHistoryByUserId($idlevel, $level, $web_user_id)
    {
        $invoicelist = DB::table('invoice')
                ->Where('web_user_id', $web_user_id)
                ->whereIn('status', array('open', 'sent', 'paid', 'closed'))
                ->Select('id', 'invoice_number', 'status', 'invoice_date', 'invoice_due_date', 'amount', 'paid', 'property_id', 'web_user_id');
        return $invoicelist;
    }

    function getDiscountByInvoice($invoice_id, $id_property, $invoiceamount, $invoice_date)
    {
        $discount = DB::table('invoice_discount')->select('discount_id', 'discount_idinvoice', 'discount_days', 'discount_percent', 'discount_amount', 'discount_date', 'discount_dynamic')->where('discount_idinvoice', $invoice_id)->where('discount_idproperty', $id_property)->first();
        $dic = array();

        if ($discount == null) {
            $dic['discountamount'] = 0;
            $dic['discount'] = 0;
            return $dic;
        }


        $amountpercent = ($invoiceamount * $discount->discount_percent / 100);
        $amountdaydiscount = $amountpercent / $discount->discount_days;
        $tmptime = strtotime($invoice_date);
        $tmptoday = strtotime(date("Y-m-d"));

        $tmpdif = $tmptoday - $tmptime;
        $i = $tmpdif / 86400;
        if ($i <= $discount->discount_days) {
            if ($discount->discount_dynamic == 1) {
                $dic['discountamount'] = $invoiceamount - $amountdaydiscount * ($discount->discount_days - $i);
                $dic['discount'] = $amountdaydiscount * ($discount->discount_days - $i);
            } else {
                $dic['discount'] = ($invoiceamount * $discount->discount_percent / 100);
                $dic['discountamount'] = $invoiceamount - $dic['discount'];
            }
        } else {
            $dic['discountamount'] = 0;
            $dic['discount'] = 0;
        }
        return $dic;
    }

    function getInvoiceItems($invoice_id, $id_property)
    {
        $invoice_info = DB::table('invoice_data')->join('item_data', 'item_data.id_item', '=', 'invoice_data.item')->select('item_data.code', 'invoice_data.id', 'invoice_data.item', 'invoice_data.qty', 'invoice_data.price', 'item_data.description', 'item_data.um as unit', 'invoice_data.tax', 'invoice_data.discount', 'invoice_data.total', 'item_data.id_item')->where('invoice_data.id_invoice', $invoice_id)->where('invoice_data.property_id', $id_property)->get();
        return $invoice_info;
    }

    function get1InvData($inv_id, $key)
    {
        $info = DB::table('invoice')->select($key)->where('id', $inv_id)->first();
        $info = (array) $info;
        return $info[$key];
    }

    function set1InvInfo($inv_id, $key, $value)
    {
        DB::table('invoice')->where('id', $inv_id)->update(array($key => $value));
    }

    function getInvoiceDiscount($invoice_id, $id_property, $invoiceamount, $invoice_date)
    {
        $discount = DB::table('invoice_discount')->select('discount_id', 'discount_idinvoice', 'discount_days', 'discount_percent', 'discount_amount', 'discount_date', 'discount_dynamic')->where('discount_idinvoice', $invoice_id)->where('discount_idproperty', $id_property)->first();

        $message2 = "";
        //if ($discount !== null && $discount->discount_date >= date("Y-m-d")) {
        if ($discount !== null) {
            $message2 .= "<div style=\"color: #000000; margin-top: 5px; margin-bottom: 5px; font-size:11pt; font-family: Calibri, sans-serif; \">";
            $message2 .= "<br><label><b>Discount Offered for this Invoice:</b></label><br>";
            if ($discount->discount_dynamic == 1) {
                // some math to calculate the values
                $amountpercent = ($invoiceamount * $discount->discount_percent / 100);
                $amountdaydiscount = $amountpercent / $discount->discount_days;
                $tmptime = strtotime($invoice_date);
                // start with the message
                $message2 .= "<label style='color:#4cae4c'><b>Pay today and save money. The faster you pay, the more you save.</b></label><br>";
                $message2 .= "<table style=\"font-size: 11pt; font-family: Calibri, sans-serif;\" width=\"70%\"><tbody>";
                $message2.= "<tr><td style='padding:8px 4px'></td>";
                $bgcolor = "#ffffff";
                for ($i = 0, $j = 1; $i < 30; $i++, $j++, $tmptime+=86400) {
                    if ($j == 7) {
                        $message2 .= "</tr><tr>";
                        $j = 0;
                    }
                    if ($i >= $discount->discount_days) {
                        $bgcolor = "#f5f5f5";
                        $discountamount = $invoiceamount;
                    } else {
                        $discountamount = $invoiceamount - $amountdaydiscount * ($discount->discount_days - $i);
                    }
                    $message2 .= "<td style=\"background-color: " . $bgcolor . "; padding:8px 4px;text-align: center;  border: 1px #ddd solid;\">$" . number_format($discountamount, 2) . "<br>" . date("m/d", $tmptime) . "</td>\n";
                }
                // finish the row with empty cells
                for (; $j < 7; $j++) {
                    $message2 .= "<td style='padding:8px 4px'></td>";
                }
                // close the table
                $message2 .= "</tr></tbody></table>";
            } else {
                $message2.="<div style=\"color: #000000; margin-top: 5px; color:#333; margin-bottom: 15px; font-size:11pt; font-family: Calibri, sans-serif;\">";
                $message2 .= "If paid within " . $discount->discount_days . " days, ";
                $message2 .= "you will receive a " . $discount->discount_percent . "% discount, ";
                $message2 .= "the net amount during the discount period $" . $discount->discount_amount . ". Otherwise, payment in full is due by invoice due date. <br>";
                $message2.="</div>";
            }
            $message2 .= "</div>\n";
        }
        return $message2;
    }
    
    /**
     * Create a new Invoice record
     * @param array $fields (All fields to save)
     * @return id The id of the new record
     */
    function createInvoice($fields) {
        $id = DB::table($this->table)->insertGetId($fields);
        return $id;
    }
    
    /**
     * Updates the invoice fields
     * @param array $fields
     */
    function updateInvoice($fields) {
        if (!empty($fields['id'])) {
            DB::table($this->table)
                    ->where('id', $fields['id'])
                    ->update($fields);
        }
    }

    /**
     * Creates a new Invoice data record
     * @param array $fields (All fields to save)
     * @return id The id of the new record
     */
    function createInvoiceData($fields){
        $id = DB::table('invoice_data')->insertGetId($fields);
        return $id;
    }
    
    /**
     * Updates the invoice data
     * @param type $fields
     */
    function updateInvoiceData($fields) {
        if (!empty($fields['id'])) {
            DB::table('invoice_data')
                    ->where('id', $fields['id'])
                    ->update($fields);
        }
    }

    /**
     * Deletes a Invoice data record by id
     * @param int $id
     */
    function deleteInvoiceData($id) {
        if (!empty($id)) {
            DB::table('invoice_data')->where('id', $id)->delete();
        }
    }

    /**
     * Creates a item_data record
     * @param array $fields
     * @return int
     */
    function createItemData($fields) {
        $id = DB::table('item_data')->insertGetId($fields);
        return $id;
    }

    /**
     * Updates the item_data fields
     * @param array $fields
     */
    function updateItemData($fields) {
        if (!empty($fields['id_item'])) {
            DB::table('item_data')
                    ->where('id_item', $fields['id_item'])
                    ->update($fields);
        }
    }
    
    /**
     * Delete a item_data record by id
     * @param int $id_item
     */
    function deleteItemData($id_item) {
        if(!empty($id_item)){
            DB::table('item_data')->where('id_item', $id_item)->delete();
        }
    }

    /**
     * creates a new discount record 
     * @param type $fields
     * @return type
     */
    function createInvoiceDiscount($fields){
        $id = DB::table('invoice_discount')->insertGetId($fields);
        return $id;
    }
    
    /**
     * Updates a discount record
     * @param array $fields
     */
    function updateInvoiceDiscount($fields) {
        if (!empty($fields['discount_id'])) {
            DB::table('invoice_discount')
                    ->where('discount_id', $fields['discount_id'])
                    ->update($fields);
        }
    }
    
    /**
     * Delete the discount associated to an invoice
     * @param int $invoiceId
     */
    function deleteInvoiceDiscount($invoiceId){
        DB::table('invoice_discount')->where('discount_idinvoice', $invoiceId)->delete();
    }

    /**
     * Validate if the invoice number is already taken by the property
     * @param string $token
     * @param string $invoice
     * @param id $id
     * @return int 1: if exists, 0: if doesn't exit
     */
    function validateInvoice($token, $invoice, $id) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $invoice2 = $invoice;
        if (strlen($invoice) < 6) {
            $invoice2 = str_pad($invoice, 6, 0, STR_PAD_LEFT);
        }
        if (!empty($id)) {
            $exist = Invoices::where('id', '!=', $id)
                    ->where('property_id', $idlevel)
                    ->where(function($query) use ($invoice, $invoice2) {
                        $query->where('invoice_number', $invoice)
                        ->orWhere('invoice_number', $invoice2);
                    })->value('id');
        } else {
            $exist = Invoices::where('property_id', $idlevel)
                    ->where(function($query) use ($invoice, $invoice2) {
                        $query->where('invoice_number', $invoice)
                        ->orWhere('invoice_number', $invoice2);
                    })->value('id');
        }

        if (!empty($exist)) {
            return 1;
        }

        return 0;
    }
    
    function deleteItemsData($invoiceId){
        $id = DB::table('item_data')->insertGetId($fields);
        return $id;
    }
    
    /**
     * Gets the discount by invoice
     * @param int $invoiceId
     * @return type
     */
    function getDiscountByInvoiceId($invoiceId) {
        $info = DB::table('invoice_discount')->where('discount_idinvoice', $invoiceId)->first();
        return $info;
    }

    /**
     * Calculate the next invoice number
     * @param int $idlevel the Id of the property
     * @return string The next invoice number
     */
    function getNextInvoiceNumber($idlevel) {
        //Gets the last invoice number by property
        $invoice = DB::table($this->table)
                ->select('invoice_number')
                ->where('property_id', $idlevel)
                ->orderBy('invoice_number', 'desc')
                ->first();

        //if extis, increments the invoice number by 1, otherwise stablish the first invoice number
        if (!empty($invoice->invoice_number)) {
            $max = $invoice->invoice_number;
            $max++;
        } else {
            $max = "000001";
        }

        // fills the left side with Zeros 
        if (strlen($max) < 6) {
            $max = str_pad($max, 6, '0', STR_PAD_LEFT);
        }

        //Search if the new invoice number exists
        $invoiceExits = true;
        while ($invoiceExits) {
            $invoiceNumber = DB::table($this->table)
                    ->where('property_id', $idlevel)
                    ->where('invoice_number', $max)
                    ->select('invoice_number')
                    ->first();

            //if the invoice number exits, it's incremented by 1
            if (!empty($invoiceNumber->invoice_number)) {
                $max++;
            } else {
                $invoiceExits = false;
            }
        }

        // fills the left side with Zeros 
        if (strlen($max) < 6) {
            $max = str_pad($max, 6, '0', STR_PAD_LEFT);
        }

        return $max;
    }

}
