<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Vendors extends Model {

    protected $table = 'vendor';
    public $timestamps = false;
    
    public function getVendorByFilter($idlevel, $filter = null) {
        $query = DB::table($this->table)
                ->where('status', '!=',200)
                ->where('property_id',$idlevel)
                ->orderBy('id', 'DESC');
        $query->select('id', 'eid', 'vname', 'mail', 'contact', 'work_phone', 'work_fax', 'type','status');
        return $query;
    }
    
    public function saveVendor($data) {
        DB::table($this->table)->insert($data);
    }
    
    public function stopBillsVendor($id){
        \Illuminate\Support\Facades\DB::table('bill')->where('vendor_id',$id)->where('status',1)->delete();
    }
    
    public function deleteVendor($id) {
        $this->stopBillsVendor($id);
        DB::table($this->table)
                ->where('id', $id)
                ->update(['status' => 200]);
    }
    
    public function getVendordetail($id) {
        $vendordetails = DB::table($this->table)
                ->where('id', '=', $id)
                ->first();

        return $vendordetails;
    }
    
    public function updateVendor($data, $id) {
        DB::table($this->table)
                ->where('id', $id)
                ->update($data);
    }
    
    function InsertIfNotExists($idproperty,$data){
        $result=$this->where('property_id','=',$idproperty)->where('status','<',999)->where('eid','like',trim($data['eid']))->count();
        if($result>0) return;
        $this->insert($data);
    }

    function InsertUpdate($idproperty,$data){
        $result=$this->where('property_id','=',$idproperty)->where('status','<',999)->where('eid','like',trim($data['eid']))->select('id')->first();
        if(!empty($result)) {
            $vid=$result['id'];
            $this->where('id','=',$vid)->update($data);
            return $vid;
        }
        if(!isset($data['property_id']))$data['property_id']=$idproperty;
        $vid=$this->insertGetId($data);
        return $vid;
    }
    
    function getVendorById($idproperty,$vid){
        $result=$this->where('property_id','=',$idproperty)->where('status','<',999)->where('eid','like',trim($vid))->first();
        return $result;
    }
    
    function getVendorByIdx($idproperty,$vid){
        $result=$this->where('property_id','=',$idproperty)->where('id','=',$vid)->first();
        return $result;
    }
    
    function existsBill($idproperty,$bill){
        $result=DB::table('evendorpay_transactions')->where('property_id','=',$idproperty)->where('trans_status','=',1)->where('trans_last_post_date','>=',date('Y-m-d 00:00:00',strtotime('-1 day')))->where('invoice_num','=',$bill)->count();
        if($result>0)return true;
        return false;
    }
    
    function insertBill($data){
        $result=DB::table('bill')->insertGetId($data);
        return $result;
    }
    
    function update1Bill($bid,$key,$value){
        DB::table('bill')->where('id','=',$bid)->update(array($key=>$value));
    }
    
    function getLastInquire($idproperty){
        $result=DB::table('last_inquiries')->where('property_id','=',$idproperty)->first();
        return $result;
    }
    
    function updateInquire($idproperty,$id,$txid){
        if($id>0){
            DB::table('last_inquiries')->where('id','=',$id)->update(array('last_id'=>$txid));
        }
        else {
            DB::table('last_inquiries')->insert(array('last_id'=>$txid,'property_id'=>$idproperty));
        }
    }
    
    function set1Info($id,$key,$value){
        DB::table($this->table)->where('id','=',$id)->update(array($key=>$value));
    }
    
    function getVendorstoBill($idlevel){
        $query = DB::table($this->table)
                ->where('status', '=',1)
                ->where('property_id',$idlevel)
                ->where('routing','!=','')
                ->where('account','!=','');
        $query->select('id', 'eid', 'vname', 'mail', 'contact', 'work_phone', 'work_fax', 'type','status');
        return $query->get();
    }

    function getVendorByProperty($idvendor, $idproperty){

        $query = DB::table($this->table)
            ->where('property_id',$idproperty)
            ->where('eid',$idvendor)
            ->first();
        return $query;
    }
}
