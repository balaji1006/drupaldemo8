<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class PromotionsModel extends Model
{

    protected $table = 'promotions';

    function getPromoContent($id_p)
    {
        $result = $this->where('id_p', $id_p)->select('promo_content')->first();
        return $result['promo_content'];
    }

    function getPromoLink($id_p)
    {
        $result = $this->where('id_p', $id_p)->select('promo_link')->first();
        return $result['promo_link'];
    }

    function getPromotionsDone()
    {
        $data = DB::table('promo_done')
                ->select('promo_name', 'partner_title', 'company_name', 'name_clients', 'first_name', 'last_name', 'email_address', 'done_date', 'trans_id')
                ->join('promotions', 'promo_done.id_promo', '=', 'promotions.id_p')
                ->join('properties', 'promo_done.property_id', '=', 'properties.id')
                ->join('partners', 'properties.id_partners', '=', 'partners.id')
                ->join('companies', 'properties.id_companies', '=', 'companies.id')
                ->join('web_users', 'promo_done.id_user', '=', 'web_users.web_user_id');
        return $data;
    }

    function getPromotions()
    {
        $data = DB::table('promotions')
                ->select('id_p', 'promo_content', 'promo_name', 'promo_link')
        ;
        return $data;
    }

    public function getPromotion($id)
    {
        $data = DB::table('promotions')
                ->where('id_p', '=', $id)
                ->first();
        ;
        return $data;
    }

    public function getPromotionByName($name)
    {
        $data = DB::table('promotions')
                ->where('promo_name', '=', $name)
                ->first();
        ;
        return $data;
    }

    public function search($table, $field, $criteria)
    {
        $data = DB::table($table)
                ->where($field, 'like', "%$criteria%")
                ->get();
        ;
        return $data;
    }

    public function getAppliedToPartners($id)
    {
        $data = DB::table('promo_applied')
                ->join('partners', 'promo_applied.id_partners', '=', 'partners.id')
                ->where('id_promo', '=', $id)
                ->where('id_partners', '>', 0)
                ->get();
        ;
        return $data;
    }

    public function getAppliedToGroups($id)
    {
        $data = DB::table('promo_applied')
                ->select('companies.company_name', 'promo_applied.id_property', 'promo_applied.id_companies', 'promo_applied.id_partners')
                ->join('companies', 'promo_applied.id_companies', '=', 'companies.id')
                ->where('id_promo', '=', $id)
                ->where('promo_applied.id_companies', '>', 0)
                ->get();
        ;
        return $data;
    }

    public function getAppliedToMerchants($id)
    {
        $data = DB::table('promo_applied')
                ->select('properties.name_clients', 'promo_applied.id_property', 'promo_applied.id_companies', 'promo_applied.id_partners')
                ->join('properties', 'promo_applied.id_property', '=', 'properties.id')
                ->where('id_promo', '=', $id)
                ->where('id_property', '>', 0)
                ->get();
        ;
        return $data;
    }
}
