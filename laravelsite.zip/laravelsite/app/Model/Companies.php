<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Companies extends Model {

    protected $table = 'companies';
    public $timestamps = false;

    function getPartnerID($id_company) {
        $result = DB::table('companies')->where('id', '=', $id_company)->select('id_partners')->first();
        return $result->id_partners;
    }

    public function getCompaniesByPartnerId($id_partner) {

        return DB::table($this->table)->where('id_partners', $id_partner)->get();
    }

    public function getCompanyById($id) {

        return DB::table($this->table)->where('id', $id)->get();
    }

    function getCompanyLogo($id_companies, $id_partners) {
        if (empty($id_companies)) {
            return '/img/revo.png';
        }
        $logo_group = $this->select('logo_group')->where('id', $id_companies)->first();
        if (!empty($logo_group['logo_group'])) {
            if (file_exists('logos/companies/' . $logo_group['logo_group'])) {
                return '/logos/companies/' . $logo_group['logo_group'];
            } else {
                $obj_partners = new Partners();
                return $obj_partners->getPartnerLogo($id_partners);
            }
        } else {
            $obj_partners = new Partners();
            return $obj_partners->getPartnerLogo($id_partners);
        }
    }

    function set1CompanyInfo($id, $key, $value) {
        DB::table($this->table)->where('id', '=', $id)->update(array($key => $value));
    }

    function get1CompanyInfo($id, $key) {
        $result = $this->where('id', '=', $id)->select($key)->first();
        return $result[$key];
    }

    function getLayoutID($id_company) {
        $result = DB::table('companies')->select('clayout_id')->where('id', '=', $id_company)->first();
        $result = (array) $result;
        if ($result['clayout_id'] > 0) {
            return $result['clayout_id'];
        }
        $id_partner = $this->get1CompanyInfo($id_company, 'id_partners');
        $result = DB::table('partners')->select('layout_id')->where('id', '=', $id_partner)->first();
        $result = (array) $result;
        return $result['layout_id'];
    }

    function getCompanyNameById($id_companies) {
        $company_name = $this->select('company_name')->where('id', $id_companies)->first();
        return $company_name['company_name'];
    }

    function getCompanyBySubdomain($subdomain) {
        $company = $this->where('subdomain_companies', $subdomain)->first();
        return $company;
    }

    function getCompanyInfo($id) {
        $result = DB::table('companies')->where('id', '=', $id)->first();
        $result->logo = $this->getCompanyLogo($id, $result->id_partners);
        return $result;
    }

    function getGroupByFilter($level, $idlevel, $filter = null) {
            $query = DB::table($this->table)
                    ->where('companies.status', 1)
                    ->join('partners', 'companies.id_partners', 'partners.id')
                    ->leftjoin('layout', 'companies.clayout_id', 'layout.id_layout');
            if($level=='B'){
                $partnersA=DB::table('branch_partner')->whereIn('branch_id',$idlevel)->select('id_partners')->get();
                $partners=array();
                foreach($partnersA as $pa){
                    $partners[]=$pa->id_partners;
                }
                $query->whereIn('companies.id_partners',$partners);
            }
            elseif($level=='P'){
                $query->whereIn('companies.id_partners',$idlevel);
            }
            $query->select('companies.id as id', 'partners.partner_title as partner', 'compositeID_companies as compositeID_companies', 'company_name', 'contact_name', 'contact_email', 'phone_number', 'layout.lay_name as layout', 'clayout_id');
        return $query;
    }

    function saveGroup($groups) {
        DB::table($this->table)->insert([
            ['id_partners' => $groups['ddlpartner'],
                'compositeID_companies' => $groups['txtcompid'],
                'company_name' => $groups['txtcname'],
                'subdomain_companies' => $groups['txtsdcname'],
                'contact_name' => $groups['txtcontactname'],
                'contact_email' => $groups['txtemail'],
                'address' => $groups['txtaddress'],
                'city' => $groups['txtcity'],
                'state' => $groups['ddlstate'],
                'zip' => $groups['txtzip'],
                'phone_number' => $groups['txtphone'],
                'status' => 1,
                'clayout_id' => $groups['ddllayout'],
                'last_updated_by' => $groups['updated_by'],
                'logo_group' => $groups['logo']]
        ]);
    }

    Public function deleteGroup($id) {
        DB::table($this->table)
                ->where('id', $id)
                ->update(['status' => 0]);
    }

    Public function getGroupdetail($id) {
        $groupdetails = DB::table($this->table)
                ->leftjoin('layout', 'companies.clayout_id', 'layout.id_layout')
                ->leftjoin('partners', 'companies.id_partners', 'partners.id')
                ->select('companies.id as id', 'id_partners','partners.partner_title', 'company_name', 'compositeID_companies as compositeID_companies', 'subdomain_companies', 'contact_name', 'contact_email', 'address', 'city', 'state', 'zip', 'phone_number', 'companies.status as status', 'layout.lay_name as layout', 'clayout_id as lid', 'companies.last_updated as last_updated', 'companies.last_updated_by as last_updated_by', 'logo_group', 'partners.partner_name as partner_name')
                ->where('companies.id', '=', $id)
                ->first();

        return $groupdetails;
    }

    Public function updateGroup($groups, $id) {

        DB::table($this->table)
                ->where('id','=',$id)
                ->update(
                        [   'compositeID_companies' => $groups['txtcompid'],
                            'company_name' => $groups['txtcname'],
                            'subdomain_companies' => $groups['txtsdcname'],
                            'contact_name' => $groups['txtcontactname'],
                            'contact_email' => $groups['txtemail'],
                            'address' => $groups['txtaddress'],
                            'city' => $groups['txtcity'],
                            'state' => $groups['ddlstate'],
                            'zip' => $groups['txtzip'],
                            'phone_number' => $groups['txtphone'],
                            'status' => 1,
                            'clayout_id' => $groups['ddllayout'],
                            'last_updated_by' => $groups['updated_by'],
                            'logo_group' => $groups['logo']]
        );
    }


}
