<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class CronReport extends Model
{

    protected $table = 'cron_task_report';
    protected $softDelete = false;
    public $timestamps = false;

    function getListForTime($time = "")
    {
        $glist = DB::table($this->table)->where('target', '!=', '')->where('scope', '!=', '');
        if ($time != '') {
            $glist->where('cron_time', '=', $time);
        }
        $result = $glist->get();
        return $result;
    }

    function getCronReports($id, $type, $option = 0)
    {
        $reports = null;
        switch ($type) {
            case 'P':
                $reports = DB::table($this->table)->where('idp', '=', $id);
                break;
            case 'G':
                $reports = DB::table($this->table)->where('idc', '=', $id);
                break;
            case 'M':
                $reports = DB::table($this->table)->where('idm', '=', $id);
                break;
        }
        if ($reports) {
            if ($option == 0) {
                return $reports->get();
            } else {
                return $reports;
            }
        }

        return false;
    }

    function getCronReportById($id)
    {
        return DB::table($this->table)->where('id', '=', $id)->get();
    }

    function set1Info($id, $key, $value)
    {
        DB::table($this->table)->where('id', '=', $id)->update(array($key => $value));
    }
}
