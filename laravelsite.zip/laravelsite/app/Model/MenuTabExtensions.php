<?php

namespace App\Model;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


class MenuTabExtensions extends Model {
    
    protected $table = 'menu_tab_extensions';
    
    function getMenuTabPaymentPage($id_property){
        $obj_property= new Properties();
        $layout_id=$obj_property->getLayoutID($id_property);
        $lables= $obj_property->getLabels_Layout($layout_id);
        
        if(empty($lables['make_payment'])) $lables['make_payment']="Make a Payment";
        if(empty($lables['link_account'])) $lables['link_account']="Link Accounts to Profile";
        
        $result=$this->select('name','title','image','target','visible')->where('id_property',$id_property)->orderBy('priority', 'asc')->get();
        
        if(empty($result->toArray())){
            $this->createItemDefaultMenuTab($id_property);
            $result=$this->select('name','title','image','target','visible')->where('id_property',$id_property)->orderBy('priority', 'asc')->get();
        }
        
        $menuTab=array();
        for ($i=0; $i<count($result);$i++){
            //layout id
            if($result[$i]['name']=='pay'){
                $result[$i]['title']=$lables['make_payment']="Make a Payment";
            }elseif($result[$i]['name']=='linkaccount'){
                $result[$i]['title']=$lables['link_account']="Link Accounts to Profile";
                $result[$i]['class']='submenu';
            }elseif($result[$i]['name']=='notifications'){
                $result[$i]['class']='submenu';
            }elseif($result[$i]['name']=='changepassword'){
                $result[$i]['class']='submenu';
            }
            
            $result[$i]['link']=$result[$i]['name'];
            $result[$i]['name']=route($result[$i]['name']);
            $menuTab[]=$result[$i];
        }
        
        return $menuTab;
    }
    
    public function addItemMenuTab($idproperty,$name,$priority){
            $id=  $this->getItemMenuTab3($idproperty, $name, $priority);
            if(!empty($id)){return true;}
            $id=  $this->getItemMenuTab2($idproperty, $name);
            if(!empty($id)){
                $this->updateItemMenuTab($id, $idproperty, $name, $priority);
                return true;
            }
        
        switch ($name){
            case 'showdashboard':
                    $title="Dashboard";
                    $image="fa fa-home";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'pay':
                    $title="Make a Payment";
                    $image="fa fa-credit-card";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'autopay':
                    $title="Manage AutoPay";
                    $image="fa fa-calendar";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'paymethods':
                    $title="My Payment Methods";
                    $image="fa fa-database";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'payhistory':
                    $title="Payment History";
                    $image="fa fa-bar-chart";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'myprofile':
                    $title="My Profile";
                    $image="fa fa-gear";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    //change Password
                    $name='changepassword';
                    $title="Change Password";
                    $image="";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority."1"
                    ]);
                    //notification
                    $name='notifications';
                    $title="Notifications";
                    $image="";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority."2"
                    ]);
                    //link account
                    $name='linkaccount';
                    $title="Link Accounts to Profile";
                    $image="";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority."3"
                    ]);
                    break;
            case 'helpticket':
                    $title="Help Request";
                    $image="fa fa-question-circle";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'listbills':   
                    $title="Statements";
                    $image="fa fa-file-text-o";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'invoices':
                    $title="Invoices";
                    $image="fa fa-file-text-o";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'newviewbill':
                    $title="View Bills";
                    $image="fa fa-file-text-o";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'gsbbill':
                    $title="View GSB Bills";
                    $image="fa fa-file-text-o";
                    $target="";
                    $this->insert([
                        'id_property'=>$idproperty,'name'=>$name,
                        'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            case 'maintenance': 
                    $title="Maintenance Request";
                    $image="fa fa-wrench";
                    $target="";
                    $this->insert([
                            'id_property'=>$idproperty,'name'=>$name,
                            'title'=>$title,'image'=>$image,'priority'=>$priority
                    ]);
                    break;
            default : 
                return false;
                break;
        }
        return true;
    }
    
    public function removeItemMenuTab($idproperty,$name){
        $this->where('id_property',$idproperty)->where('name',$name)->delete();
        if($name=='myprofile'){
            $this->where('id_property',$idproperty)->where('name','linkaccount')->delete();
            $this->where('id_property',$idproperty)->where('name','changepassword')->delete();
            $this->where('id_property',$idproperty)->where('name','notifications')->delete();
        }
        return true;
    }
    
    public function removeItemMenuTabbyID($id){
        $this->where('menu_tab_id',$id)->delete();
        return true;
    }
     
    public function getAllItemMenuTab($idproperty){
        $result=  $this->where('id_property',$idproperty);
        return $result;
    }
    
    public function getItemMenuTab3($idproperty,$name,$priority){
        $result=$this->where('id_property',$idproperty)
                 ->where('name',$name)
                 ->where('priority',$priority)
                 ->select('menu_tab_id')
                 ->first();
            return $result['menu_tab_id'];
    }
    
    public function getItemMenuTab2($idproperty,$name){
        $result=$this->where('id_property',$idproperty)
                 ->where('name',$name)
                 ->select('menu_tab_id')
                 ->first();
            return $result['menu_tab_id'];
    }
    
    public function updateItemMenuTab($id,$idproperty,$name,$priority){
        $this->where('menu_tab_id',$id)->update([
            'id_property'=>$idproperty,
            'name'=>$name,
            'priority'=>$priority
        ]);
    }
    
    public function createItemDefaultMenuTab($idproperty){
        $obj_property = new Properties();
        $layout=$obj_property->getLayoutID($idproperty);
        if($layout==6){
            $listDefault = array (
            ['name'=>'invoices','title'=>'Invoices','image'=>'fa fa-file-text-o','priority'=>1],
            ['name'=>'paymethods','title'=>'My Payment Methods','image'=>'fa fa-database','priority'=>2],
            ['name'=>'payhistory','title'=>'Payment History','image'=>'fa fa-bar-chart','priority'=>5],    
            ['name'=>'myprofile','title'=>'My Profile','image'=>'fa fa-gear','priority'=>6],
            ['name'=>'notifications','title'=>'Notifications','image'=>'','priority'=>6.1],
            ['name'=>'changepassword','title'=>'Change Password','image'=>'','priority'=>6.2],
            ['name'=>'linkaccount','title'=>'Link Accounts to Profile','image'=>'','priority'=>6.3],
            ['name'=>'helpticket','title'=>'Help Request','image'=>'fa fa-question-circle','priority'=>7]
            
        );
        }else{
            $listDefault = array (
            ['name'=>'showdashboard','title'=>'Dashboard','image'=>'fa fa-home','priority'=>1],
            ['name'=>'pay','title'=>'Make a Payment','image'=>'fa fa-credit-card','priority'=>2],
            ['name'=>'autopay','title'=>'Manage AutoPay','image'=>'fa fa-calendar','priority'=>3],
            ['name'=>'paymethods','title'=>'My Payment Methods','image'=>'fa fa-database','priority'=>4],
            ['name'=>'payhistory','title'=>'Payment History','image'=>'fa fa-bar-chart','priority'=>5],
            ['name'=>'myprofile','title'=>'My Profile','image'=>'fa fa-gear','priority'=>6],
            ['name'=>'notifications','title'=>'Notifications','image'=>'','priority'=>6.1],
            ['name'=>'changepassword','title'=>'Change Password','image'=>'','priority'=>6.2],
            ['name'=>'linkaccount','title'=>'Link Accounts to Profile','image'=>'','priority'=>6.3],
            ['name'=>'helpticket','title'=>'Help Request','image'=>'fa fa-question-circle','priority'=>7]
            );
        }
        
        for($i=0;$i<count($listDefault);$i++){
            $this->insert([
                'id_property'=>$idproperty,
                'name'=>$listDefault[$i]['name'],
                'title'=>$listDefault[$i]['title'],
                'image'=>$listDefault[$i]['image'],
                'priority'=>$listDefault[$i]['priority']
            ]);
        }
        
        return true;
    }

    public function getAllItemMenuTabOrder($idproperty){

        $result=DB::table($this->table)
            ->where('id_property',$idproperty)
            ->orderby('priority','ASC')
            ->get();
        return $result;
    }

    public function getAllItemMenuTabOrderGroup($idgroup){

        $result = null;
        $prop=DB::table('properties')
            ->where('id_companies',$idgroup)
            ->select('id')    
            ->get();

        if(!$prop->isEmpty()){
            $prop = $prop->all();
            foreach($prop as $pid){
                $pid = (array)$pid;
                $result = $this->getAllItemMenuTabOrder($pid['id']);

                if(!$result->isEmpty()){
                    return $result;
                }
            }
        }

        return $result;
    }



    public function updateTab($id, $data){
        DB::table($this->table)->where('menu_tab_id',$id)->update($data);
    }

    public function insertTab($data){
        DB::table($this->table)->insert($data);
    }

    public function removeTab($id){
        DB::table($this->table)->where('menu_tab_id',$id)->delete();
    }

    function removeTabGroup($idlevel){
        DB::table($this->table)->whereIn('id_property', function($query) use($idlevel){
            $query->select('id as id_property')
                  ->from('properties')
                  ->where('id_companies',$idlevel);
            })->delete();
    }

    function removeTabMerchant($idlevel){
        DB::table($this->table)->where('id_property',$idlevel)->delete();
    }

    static function hasMenuTab($id_property,$tab){
        $ct= DB::table('menu_tab_extensions')->where('id_property',$id_property)->where('name','like',$tab)->count();
        return $ct;
    }
}
