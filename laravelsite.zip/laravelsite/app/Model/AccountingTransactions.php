<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AccountingTransactions extends Model
{

    protected $table = 'accounting_transactions';
    protected $primaryKey = 'trans_id';
    protected $softDelete = false;
    public $timestamps = false;

    public function getAccountingTransactions($whereCondition = array())
    {
        $accountingtransactions = array();
        $daterangecondition = array();

        $accountingtransactions = DB::table($this->table)
                ->join('web_users', 'web_users.web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->leftJoin('properties', 'properties.id', '=', 'accounting_transactions.property_id')
                ->leftJoin('companies', 'companies.id', '=', 'properties.id_companies')
                ->join('partners', 'partners.id', '=', 'properties.id_partners')
                ->select('trans_card_type', 'properties.id as idproperty', 'properties.id_companies', 'properties.id_partners', 'trans_net_amount', 'trans_last_post_date', 'accounting_transactions.trans_account_number', 'bank_id', 'misc_field', 'lockbox_id', 'compositeID_clients', 'trans_id', 'partners.partner_title as partner', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.address_unit', 'web_users.account_number as webuser', 'trans_first_post_date as trans_date', 'web_users.first_name', 'web_users.last_name', DB::raw('CONCAT(web_users.first_name, \' \', web_users.last_name) as web_user_name'), 'trans_payment_type as pay_method', 'trans_card_type as pay_type', 'trans_net_amount as net_amount', 'trans_convenience_fee as net_fee', 'trans_total_amount as net_charge', 'source as trans_source', 'trans_result_auth_code as auth_code', 'trans_status as status', 'trans_type as stype')
                ->where('is_convenience_fee_trans', '=', 0);
        return $accountingtransactions;
    }

    public function getTransactionDetail($trans_id)
    {

        //echo $idlevel;
        $acctransactiondetail = array();


        $query = DB::table($this->table)
                ->leftJoin('web_users', 'web_users.web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->leftJoin('properties', 'properties.id', '=', 'accounting_transactions.property_id')
                ->leftJoin('companies', 'companies.id', '=', 'properties.id_companies')
                ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                ->leftjoin('transaction_events', 'transaction_events.trans_id', '=', 'accounting_transactions.trans_id')
                ->select('accounting_transactions.trans_id', 'partners.partner_title as partner', 'transaction_events.event', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.address_unit', 'web_users.account_number as webuser', 'trans_first_post_date as trans_date', 'web_users.first_name', 'web_users.last_name', 'trans_payment_type as pay_method', 'trans_card_type as pay_type', 'trans_net_amount as net_amount', 'trans_convenience_fee as net_fee', 'trans_total_amount as net_charge', 'source as trans_source', 'trans_result_auth_code as auth_code', 'trans_status as status', 'trans_type as stype', 'trans_descr')
                ->where('is_convenience_fee_trans', '=', 0)
                ->where('accounting_transactions.trans_id', '=', $trans_id);
        $acctransactiondetail = $query->get();


        return $acctransactiondetail;
    }

    public function getTransactionDetailWithPartner($trans_id)
    {

        $transactiondetail = DB::table($this->table)
                ->leftJoin('properties', 'properties.id', '=', 'accounting_transactions.property_id')
                ->leftJoin('companies', 'companies.id', '=', 'properties.id_companies')
                ->join('partners', 'partners.id', '=', 'properties.id_partners')
                ->select('partners.id as partner_id', 'companies.id as company_id', 'properties.id as merchant_id', 'accounting_transactions.*')
                ->where('trans_id', '=', $trans_id)
                ->get();

        return $transactiondetail;
    }

    public function updateTransactionStatusType($trans_id)
    {

        DB::table($this->table)
                ->where('trans_id', $trans_id)
                ->update(['trans_status' => '4', 'trans_type' => '9']);
    }

    public function getMerchantDetail($id_property, $trans_source_key)
    {

        $merchantdetail = DB::table('merchant_account')
                ->select('gateway', 'payment_source_store_id')
                ->where('property_id', $id_property)
                ->where('payment_method', 'like', '%cc%')
                ->where('payment_source_key', $trans_source_key)
                ->get();

        return $merchantdetail;
    }

    public function getMerchantAllDetail($id_property, $trans_source_key)
    {

        $merchantalldetail = DB::table('merchant_account')
                ->where('property_id', $id_property)
                ->where('payment_method', 'like', '%cc%')
                ->where('payment_source_key', $trans_source_key)
                ->get();

        return $merchantalldetail;
    }

    public function getPropertyEmail($trans_id)
    {

        $propertyemail = DB::table($this->table)
                ->join('properties', 'properties.id', '=', 'accounting_transactions.property_id')
                ->select('properties.accounting_email_address_clients')
                ->where('accounting_transactions.trans_id', '=', $trans_id)
                ->get();

        return $propertyemail;
    }

    public function getWebUserEmail($trans_id)
    {

        $webuserdetail = DB::table($this->table)
                ->join('web_users', 'web_users.web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->select('trans_web_user_id', 'accounting_transactions.property_id', 'web_users.email_address')
                ->where('accounting_transactions.trans_id', '=', $trans_id)
                ->get();

        return $webuserdetail;
    }

    public function getWebUserDetail($web_user_id)
    {

        $webuserdetail = DB::table('web_users')
                ->where('web_user_id', '=', $web_user_id)
                ->get();

        return $webuserdetail;
    }

    public function saveReceipt($id_property, $id_user, $trans_id, $receipt, $from_email, $to_email, $update = false)
    {
        //to save in log Events
        return true;
    }
}
