<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Transations extends Model {

    protected $table = 'accounting_transactions';

    function getDepositInfoList($partnerID, $companyID, $paypointID, $filters, $skip = 0, $limit = 250) {
        $dates = array();
        $from = strtotime("now");
        $to = $from;
        $whereArray = array();
        if (!empty($filters)) {
            foreach ($filters as $rule) {
                $tofind = $rule['data'];
                if ($tofind == '') {
                    continue;
                }
                $tocmp = $rule['op'];
                $field = "";
                switch ($rule['field']) {
                    case 'batch_id':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "settlement_report.batch='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "settlement_report.batch!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "settlement_report.batch<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "settlement_report.batch<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "settlement_report.batch>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "settlement_report.batch>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'trans_id':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "settlement_report.trans_id='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "settlement_report.trans_id!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "settlement_report.trans_id<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "settlement_report.trans_id<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "settlement_report.trans_id>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "settlement_report.trans_id>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'company':
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(settlement_report.company_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(settlement_report.company_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "settlement_report.company_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "settlement_report.company_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "settlement_report.company_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "settlement_report.company_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'paypoint':
                    case 'merchant':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(settlement_report.property_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(settlement_report.property_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "settlement_report.property_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "settlement_report.property_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "settlement_report.property_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "settlement_report.property_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'account_number':
                    case 'webuser':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(settlement_report.customer_id LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(settlement_report.customer_id NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "settlement_report.customer_id LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "settlement_report.customer_id NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "settlement_report.customer_id LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "settlement_report.customer_id NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'name':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(settlement_report.customer_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(settlement_report.customer_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "settlement_report.customer_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "settlement_report.customer_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "settlement_report.customer_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "settlement_report.customer_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'pay_method':
                        switch ($tocmp) {
                            case 'eq':
                                if ('ec' == strtolower($tofind)) {
                                    $tofind = "eCheck";
                                } else {
                                    $tofind = "Credit Card";
                                }
                                $field = "settlement_report.transaction_type like '" . $tofind . "'";
                                break;
                            case 'ne':
                                if ('ec' == $tofind) {
                                    $tofind = "eCheck";
                                } else {
                                    $tofind = "Credit Card";
                                }
                                $field = "settlement_report.transaction_type not like '" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'settlement_date':
                    case 'deposit_date':
                        switch ($tocmp) {
                            case 'ge':
                                $from = strtotime($tofind);
                                break;
                            case 'le':
                                $to = strtotime($tofind);
                                break;
                        }
                    case 'operation':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "settlement_report.operation like '" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "settlement_report.operation not like '" . $tofind . "'";
                                break;
                        }
                        break;
                }
                if ($field != "") {
                    $whereArray[] = $field;
                }
            }
        }
        $whereRaw = "";
        $whereArray[] = "1";
        if (count($whereArray) > 0) {
            $whereRaw .= implode(" AND ", $whereArray);
        }

        if (!empty($paypointID)) {
            $whereRaw .= ' AND id_property=' . $paypointID;
        } elseif (!empty($companyID)) {
            $whereRaw .= ' AND id_company=' . $companyID;
        } elseif (!empty($partnerID)) {
            $whereRaw .= ' AND id_partner=' . $partnerID;
        }


        while ($from <= $to) {
            $dates[] = date('m/d/Y', $from);
            $from = strtotime('+1 days', $from);
        }

        $transInfo = DB::table('settlement_report')
                ->whereRaw($whereRaw)
                ->whereIn('date_formatted', $dates)
                ->select('date_formatted as settlement_date', 'trans_date', 'batch as batch_id', 'trans_id', 'company_name as group', 'company_id as companyID', 'property_name as merchant', 'property_id as paypointID', 'customer_id as webuser', 'customer_name as name', 'transaction_type as pay_method', 'debit', 'credit', 'trans_recurring as frequency')
                ->skip($skip)->take($limit)
                ->get();
        $transInfoback = array();
        foreach ($transInfo as $txinfo) {
            $txinfo['returned'] = false;
            $txinfo['return_details'] = array();
            if ($txinfo['debit'] > 0) {
                $rdetails = DB::table('accounting_returned')->where('trans_id', $txinfo['trans_id'])->select('rcode', 'reason')->first();
                if (isset($rdetails['rcode'])) {
                    $txinfo['returned'] = true;
                    $txinfo['return_details'] = $rdetails;
                    $orig = DB::table('accounting_transactions')->where('parent_trans_id', $txinfo['trans_id'])->where('trans_type', 2)->select('trans_id')->first();
                    if (isset($orig['trans_id'])) {
                        $txinfo['orig_trans_id'] = $txinfo['trans_id'];
                        $txinfo['trans_id'] = $orig['trans_id'];
                    }
                } else {
                    //verify in tx report
                    $rdetails = DB::table('accounting_transactions')->where('trans_id', $txinfo['trans_id'])->select('parent_trans_id', 'trans_type')->first();
                    if (isset($rdetails['parent_trans_id'])) {
                        if ($rdetails['parent_trans_id'] > 0) {
                            $txinfo['orig_trans_id'] = $rdetails['parent_trans_id'];
                        } else {
                            $orig = DB::table('accounting_transactions')->where('parent_trans_id', $txinfo['trans_id'])->where('trans_type', 5)->select('trans_id')->orderBy('trans_id', 'desc')->first();
                            if (isset($orig['trans_id'])) {
                                $txinfo['orig_trans_id'] = $txinfo['trans_id'];
                                $txinfo['trans_id'] = $orig['trans_id'];
                            }
                        }
                    }
                }
            }
            $transInfoback[] = $txinfo;
        }
        return $transInfoback;
    }

    function validateCardNumber_LUHM($cardnumber) {
        if (empty($cardnumber)) {
            return false;
        }
        $obj_ivr = new Ivr();
        if ($obj_ivr->isValidCardNumber($cardnumber)) {
            return true;
        } else {
            return false;
        }
    }

    function getRoutingNumber($routing) {
        if (empty($routing)) {
            return false;
        }
        $obj_ivr = new Ivr();
        if ($obj_ivr->isValidRouting($routing)) {
            return true;
        } else {
            return false;
        }
    }

    /* function getRoutingNumber($routing){
      $routingNumber = DB::table('fedach')->where('routing',$routing)
      ->select('routing','bankname','bankaddr','bankcity','bankstate','bankzip','bankphone','bankcode')
      ->first();
      return $routingNumber;
      } */

    function getTransInfoSummary($partnerID, $companyID, $paypointID, $filters) {
        $whereArray = array();
        if (!empty($filters)) {
            foreach ($filters as $rule) {
                $tofind = $rule['data'];
                if ($tofind == '') {
                    continue;
                }
                $tocmp = $rule['op'];
                $field = "";
                switch ($rule['field']) {
                    case 'partner':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(partners.partner_title LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(partners.partner_title NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "partners.partner_title LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "partners.partner_title NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "partners.partner_title LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "partners.partner_title NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(companies.company_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(companies.company_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "companies.company_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "companies.company_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "companies.company_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "companies.company_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'merchant':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(properties.name_clients LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(properties.name_clients NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "properties.name_clients LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "properties.name_clients NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "properties.name_clients LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "properties.name_clients NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'account_number':
                    case 'webuser':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.account_number LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.account_number NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.account_number LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.account_number NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.account_number LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.account_number NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'first_name':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.first_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.first_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.first_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.first_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.first_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.first_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'last_name':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.last_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.last_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.last_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.last_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.last_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.last_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'address_unit':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "web_users.address_unit='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "web_users.address_unit!='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'trans_date':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_first_post_date<='" . $tofind . " 23:59:59'";
                                break;
                            case 'gt':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_first_post_date>='" . $tofind . " 00:00:00'";
                                break;
                        }
                        break;
                    case 'pay_method':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_payment_type='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_payment_type!='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'source':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.source LIKE '%" . $tofind . "%'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.source NOT LIKE '%" . $tofind . "%'";
                                break;
                        }
                        break;
                }
                if ($field != "") {
                    $whereArray[] = $field;
                }
            }
        }
        $whereArray[] = 'is_convenience_fee_trans=0';
        $whereRaw = "";
        if (count($whereArray) > 0) {
            $whereRaw .= implode(" AND ", $whereArray);
            $whereRaw .= " AND ";
        }

        if (!empty($paypointID)) {
            $whereRaw .= 'properties.id=' . $paypointID;
        } elseif (!empty($companyID)) {
            $whereRaw .= 'companies.id=' . $companyID;
        } elseif (!empty($partnerID)) {
            $whereRaw .= 'partners.id=' . $partnerID;
        }

        $transInfo = $this->join('properties', 'accounting_transactions.property_id', '=', 'properties.id')
                ->join('companies', 'properties.id_companies', '=', 'companies.id')
                ->join('partners', 'properties.id_partners', '=', 'partners.id')
                ->join('web_users', 'web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->whereRaw($whereRaw)
                ->where('accounting_transactions.trans_status', '=', 1)
                ->where('accounting_transactions.trans_type', '<', 2)
                ->where('accounting_transactions.is_convenience_fee_trans', 0)
                ->select(DB::raw('COUNT(accounting_transactions.trans_id) as ctx'), 'companies.company_name as company', 'properties.name_clients as paypoint', 'accounting_transactions.trans_payment_type as pay_method', DB::raw('SUM(accounting_transactions.trans_net_amount) as net_amount'))
                ->groupBy('companies.company_name')
                ->groupBy('properties.name_clients')
                ->groupBy('accounting_transactions.trans_payment_type')
                ->get();
        $total = 0;
        $tcount = 0;
        if (!empty($transInfo)) {
            for ($i = 0; $i < count($transInfo); $i++) {
                $total += $transInfo[$i]['net_amount'];
                $tcount += $transInfo[$i]['ctx'];
            }
        }
        $summary = array('total' => $total, 'count' => $tcount, 'details' => $transInfo);
        return $summary;
    }

    function getTransInfoSummaryChart($partnerID, $companyID, $paypointID, $filters, $frq) {
        $whereArray = array();
        if (!empty($filters)) {
            foreach ($filters as $rule) {
                $tofind = $rule['data'];
                if ($tofind == '') {
                    continue;
                }
                $tocmp = $rule['op'];
                $field = "";
                switch ($rule['field']) {
                    case 'partner':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(partners.partner_title LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(partners.partner_title NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "partners.partner_title LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "partners.partner_title NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "partners.partner_title LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "partners.partner_title NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(companies.company_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(companies.company_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "companies.company_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "companies.company_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "companies.company_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "companies.company_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'merchant':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(properties.name_clients LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(properties.name_clients NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "properties.name_clients LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "properties.name_clients NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "properties.name_clients LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "properties.name_clients NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'account_number':
                    case 'webuser':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.account_number LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.account_number NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.account_number LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.account_number NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.account_number LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.account_number NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'first_name':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.first_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.first_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.first_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.first_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.first_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.first_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'last_name':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.last_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.last_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.last_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.last_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.last_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.last_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'address_unit':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "web_users.address_unit='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "web_users.address_unit!='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'trans_date':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_first_post_date<='" . $tofind . " 23:59:59'";
                                break;
                            case 'gt':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_first_post_date>='" . $tofind . " 00:00:00'";
                                break;
                        }
                        break;
                    case 'pay_method':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_payment_type='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_payment_type!='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'source':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.source LIKE '%" . $tofind . "%'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.source NOT LIKE '%" . $tofind . "%'";
                                break;
                        }
                        break;
                }
                if ($field != "") {
                    $whereArray[] = $field;
                }
            }
        }
        $whereRaw = "";
        $whereArray[] = 'is_convenience_fee_trans=0';
        if (count($whereArray) > 0) {
            $whereRaw .= implode(" AND ", $whereArray);
            $whereRaw .= " AND ";
        }

        if (!empty($paypointID)) {
            $whereRaw .= 'properties.id=' . $paypointID;
        } elseif (!empty($companyID)) {
            $whereRaw .= 'companies.id=' . $companyID;
        } elseif (!empty($partnerID)) {
            $whereRaw .= 'partners.id=' . $partnerID;
        }
        $fcontrol = '1';
        if ($frq == 'monthly') {
            $fcontrol = 'CONCAT(YEAR(accounting_transactions.trans_first_post_date),MONTH(accounting_transactions.trans_first_post_date))';
        } elseif ($frq == 'annually') {
            $fcontrol = 'CONCAT(YEAR(accounting_transactions.trans_first_post_date))';
        } elseif ($frq == 'weekly') {
            $fcontrol = 'CONCAT(YEAR(accounting_transactions.trans_first_post_date),WEEK(accounting_transactions.trans_first_post_date))';
        } elseif ($frq == 'daily') {
            $fcontrol = 'CONCAT(YEAR(accounting_transactions.trans_first_post_date),MONTH(accounting_transactions.trans_first_post_date),DAY(accounting_transactions.trans_first_post_date))';
        }
        $transInfo = DB::table($this->table)->join('properties', 'accounting_transactions.property_id', '=', 'properties.id')
                ->join('companies', 'properties.id_companies', '=', 'companies.id')
                ->join('partners', 'properties.id_partners', '=', 'partners.id')
                ->join('web_users', 'web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->whereRaw($whereRaw)
                ->where('accounting_transactions.trans_status', '=', 1)
                ->where('accounting_transactions.trans_type', '<', 2)
                ->where('accounting_transactions.is_convenience_fee_trans', 0)
                ->select(DB::raw('COUNT(accounting_transactions.trans_id) as ctx'), 'accounting_transactions.trans_payment_type as pay_method', DB::raw('SUM(accounting_transactions.trans_net_amount) as net_amount'), DB::raw($fcontrol . ' as fdata'))
                ->groupBy('accounting_transactions.trans_payment_type')
                ->groupBy('fdata')
                ->get();

        $total = 0;
        $tcount = 0;
        if (!empty($transInfo)) {
            for ($i = 0; $i < count($transInfo); $i++) {
                $total += $transInfo[$i]['net_amount'];
                $tcount += $transInfo[$i]['ctx'];
            }
        }
        $summary = array('total' => $total, 'count' => $tcount, 'details' => $transInfo);
        return $summary;
    }

    function getTransInfoList($partnerID, $companyID, $paypointID, $filters, $from = 0, $limit = 250, $order = 'D', $showevents = false, $scat = false) {
        $whereArray = array();
        if (!empty($filters)) {
            foreach ($filters as $rule) {
                $tofind = $rule['data'];
                if ($tofind == '') {
                    continue;
                }
                $tocmp = $rule['op'];
                $field = "";
                switch ($rule['field']) {
                    case 'trans_id':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_id='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_id!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "accounting_transactions.trans_id<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_id<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "accounting_transactions.trans_id>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_id>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'partner':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(partners.partner_title LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(partners.partner_title NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "partners.partner_title LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "partners.partner_title NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "partners.partner_title LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "partners.partner_title NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(companies.company_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(companies.company_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "companies.company_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "companies.company_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "companies.company_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "companies.company_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'merchant':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(properties.name_clients LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(properties.name_clients NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "properties.name_clients LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "properties.name_clients NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "properties.name_clients LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "properties.name_clients NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'account_number':
                    case 'webuser':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.account_number LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.account_number NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.account_number LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.account_number NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.account_number LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.account_number NOT LIKE '%" . $tofind . "'";
                                break;
                            case 'eq':
                                $field = "(TRIM(web_users.account_number) = '" . trim($tofind) . "')";
                                break;
                        }
                        break;
                    case 'first_name':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.first_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.first_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.first_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.first_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.first_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.first_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'last_name':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(web_users.last_name LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(web_users.last_name NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "web_users.last_name LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "web_users.last_name NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "web_users.last_name LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "web_users.last_name NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'address_unit':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "web_users.address_unit='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "web_users.address_unit!='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'trans_date':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_first_post_date<='" . $tofind . " 23:59:59'";
                                break;
                            case 'gt':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_first_post_date>='" . $tofind . " 00:00:00'";
                                break;
                        }
                        break;
                    case 'pay_method':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_payment_type like '" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_payment_type not like '" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'pay_type':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(accounting_transactions.trans_card_type LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(accounting_transactions.trans_card_type NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "accounting_transactions.trans_card_type LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "accounting_transactions.trans_card_type NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "accounting_transactions.trans_card_type LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "accounting_transactions.trans_card_type NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'authcode':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(accounting_transactions.trans_result_auth_code LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(accounting_transactions.trans_result_auth_code NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "accounting_transactions.trans_result_auth_code LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "accounting_transactions.trans_result_auth_code NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "accounting_transactions.trans_result_auth_code LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "accounting_transactions.trans_result_auth_code NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'net_amount':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_net_amount='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_net_amount!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "accounting_transactions.trans_net_amount<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_net_amount<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "accounting_transactions.trans_net_amount>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_net_amount>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'net_charge':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_total_amount='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_total_amount!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "accounting_transactions.trans_total_amount<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_total_amount<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "accounting_transactions.trans_total_amount>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_total_amount>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'net_fee':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_convenience_fee='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_convenience_fee!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "accounting_transactions.trans_convenience_fee<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_convenience_fee<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "accounting_transactions.trans_convenience_fee>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_convenience_fee>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'type':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_type LIKE '%" . $tofind . "%' AND is_convenience_fee_trans=0";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_type NOT LIKE '%" . $tofind . "%' AND is_convenience_fee_trans=0";
                                break;
                        }
                        break;
                    case 'source':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.source LIKE '%" . $tofind . "%'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.source NOT LIKE '%" . $tofind . "%'";
                                break;
                        }
                        break;
                    case 'invoice_number':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(accounting_transactions.invoice_number LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(accounting_transactions.invoice_number NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "accounting_transactions.invoice_number LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "accounting_transactions.invoice_number NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "accounting_transactions.invoice_number LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "accounting_transactions.invoice_number NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'orderid':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(accounting_transactions.orderid LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(accounting_transactions.orderid NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "accounting_transactions.orderid LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "accounting_transactions.orderid NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "accounting_transactions.orderid LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "accounting_transactions.orderid NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'settled':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.settled='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.settled!='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'status':
                        switch ($tocmp) {
                            case 'eq':
                                if ($tofind <= 1) { //Approved and Errored
                                    $field = "accounting_transactions.trans_status='1' and accounting_transactions.trans_type<=1";
                                } elseif ($tofind == 2) { //Declined
                                    $field = "(accounting_transactions.trans_status='2' OR accounting_transactions.trans_status='3')";
                                } elseif ($tofind == 3) { //Returned
                                    $field = "accounting_transactions.trans_type='2' and accounting_transactions.trans_status='1'";
                                } elseif ($tofind == 4) { //Void
                                    $field = "accounting_transactions.trans_type='9'";
                                }
                                break;
                        }
                        break;
                }
                if ($field != "") {
                    $whereArray[] = $field;
                }
            }
        }
        $whereArray[] = 'is_convenience_fee_trans=0';
        if ($from == -999) {
            $from = 0;
            $last_x = DB::table('last_inquiries')->where('property_id', $paypointID)->where('company_id', $companyID)->where('partner_id', $partnerID)->select('last_id')->first();
            if (isset($last_x['last_id'])) {
                $whereArray[] = 'accounting_transactions.trans_id>' . $last_x['last_id'];
            }
        }
        $whereRaw = "";
        if (count($whereArray) > 0) {
            $whereRaw .= implode(" AND ", $whereArray);
        }

        if (!empty($paypointID)) {
            $whereRaw .= ' AND properties.id=' . $paypointID;
        } elseif (!empty($companyID)) {
            $whereRaw .= ' AND companies.id=' . $companyID;
        } elseif (!empty($partnerID)) {
            $whereRaw .= ' AND partners.id=' . $partnerID;
        }
        if ($order == 'A') {
            $order = 'ASC';
        } else {
            $order = 'DESC';
        }
        $transInfo = $this->join('properties', 'accounting_transactions.property_id', '=', 'properties.id')
                ->join('companies', 'properties.id_companies', '=', 'companies.id')
                ->join('partners', 'properties.id_partners', '=', 'partners.id')
                ->join('web_users', 'web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->whereRaw($whereRaw)
                ->select('accounting_transactions.trans_id', 'partners.partner_title as partner', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.account_number as webuser', 'web_users.first_name', 'web_users.last_name', 'web_users.address_unit', 'accounting_transactions.trans_first_post_date as trans_date', 'accounting_transactions.trans_payment_type as pay_method', 'accounting_transactions.trans_card_type as pay_type', 'accounting_transactions.trans_result_refnum as authcode', 'accounting_transactions.trans_net_amount as net_amount', 'accounting_transactions.trans_convenience_fee as net_fee', 'accounting_transactions.trans_total_amount as net_charge', 'accounting_transactions.trans_result_auth_code as authcode', 'accounting_transactions.trans_type as type', 'accounting_transactions.source', 'accounting_transactions.settled', 'accounting_transactions.invoice_number', 'accounting_transactions.orderid', 'accounting_transactions.trans_status as status', 'companies.compositeID_companies as companyID', 'properties.compositeID_clients as paypointID', 'accounting_transactions.trans_auto_id as frequency')
                ->skip($from)->take($limit)
                ->orderBy('accounting_transactions.trans_first_post_date', $order)
                ->get();

        if (!empty($transInfo)) {
            for ($i = 0; $i < count($transInfo); $i++) {
                if ($transInfo[$i]['type'] == 1) {
                    if ($transInfo[$i]['frequency'] > 0) {
                        $df = DB::table('accounting_recurring_transactions')->where('trans_id', $transInfo[$i]['frequency'])->select('trans_schedule')->first();
                        if (!empty($df)) {
                            $transInfo[$i]['frequency'] = $df['trans_schedule'];
                        } else {
                            $transInfo[$i]['frequency'] = 'unknows';
                        }
                    } else {
                        $transInfo[$i]['frequency'] = 'unknows';
                    }
                } else {
                    $transInfo[$i]['frequency'] = 'onetime';
                }
                if ($showevents) {
                    $events = DB::table('transaction_events')->where('trans_id', $transInfo[$i]['trans_id'])
                                    ->select('event', 'date')->get();
                    $transInfo[$i]['events'] = $events;
                }
                if ($scat) {
                    $rcats = DB::table('trans_categories')->where('trans_id', $transInfo[$i]['trans_id'])->get();
                    $cats = array();
                    if (!empty($rcats)) {
                        foreach ($rcats as $ct) {
                            $tct = array();
                            $tct['name'] = $ct['category_name'];
                            $tct['amount'] = $ct['amount'];
                            $tct['qty'] = $ct['qty'];
                            if ($ct['category_id'] == 0) {
                                $tct['code'] = '88';
                            } else {
                                $ccode = DB::table('web_users_category')->where('web_user_id', $ct['web_user_id'])->where('id', $ct['category_id'])->select('code')->first();
                                if (empty($ccode)) {
                                    //find in merchant
                                    $ccode = DB::table('payment_type')->where('payment_type_id', $ct['category_id'])->where('property_id', $ct['id_properties'])->select('payment_type_code as code')->first();
                                    if (empty($ccode)) {
                                        $tct['code'] = '88';
                                    } else {
                                        $tct['code'] = $ccode['code'];
                                    }
                                } else {
                                    $tct['code'] = $ccode['code'];
                                }
                            }
                            $cats[] = $tct;
                        }
                    }
                    $transInfo[$i]['categories'] = $cats;
                }
                $transInfo[$i]['status'] = $this->GetTrans_Status($transInfo[$i]);
            }
        }
        return $transInfo;
    }

    function GetTrans_Status($trans) {
        if ($trans['status'] == 0) {
            return "Errored";
        } elseif ($trans['status'] == 1 && $trans['type'] == 2) {
            return "Returned";
        } elseif ($trans['status'] == 1 && $trans['type'] == 20) {
            return "Disputed";
        } elseif ($trans['status'] == 4 && $trans['type'] == 9) {
            return "Voided";
        } elseif ($trans['status'] == 1 && $trans['type'] == 0) {
            return "Approved";
        } elseif ($trans['status'] == 1 && $trans['type'] == 1) {
            return "Approved";
        } elseif ($trans['status'] == 1 && $trans['type'] == 99) {
            return "Approved";
        } elseif ($trans['status'] == 1 && $trans['type'] == 5) {
            return "Refunded";
        } else {
            return "Declined";
        }
    }

    function getTransByUsrId_5($web_user_id) {
        $transactions = $this->select('trans_id', 'trans_result_error_desc', 'trans_status', 'trans_first_post_date', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'trans_result_auth_code', 'trans_card_type')->where('trans_web_user_id', $web_user_id)->where('is_convenience_fee_trans', 0)->take(5)->orderBy('trans_id', 'desc')->get();
        if ($transactions === null) {
            return "";
        }
        return $transactions;
    }

    function getTransByUsrId($web_user_id) {
        $transactions = $this->select('trans_id', 'trans_result_error_desc', 'trans_status', 'trans_first_post_date', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'trans_result_auth_code', 'trans_card_type', 'trans_type', 'invoice_number', 'data')->where('trans_web_user_id', $web_user_id)->where('is_convenience_fee_trans', 0)->orderBy('trans_id', 'desc')->paginate(10);
        if ($transactions === null) {
            return "";
        }
        return $transactions;
    }

    function getTransdetailById($trans_id) {
        $transactions = $this->select('invoice_number', 'trans_id', 'trans_descr', 'trans_result_error_desc', 'trans_status', 'trans_first_post_date', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'trans_result_auth_code', 'trans_card_type')->where('trans_id', $trans_id)->first();
        if ($transactions === null) {
            return "";
        }
        return $transactions;
    }

    function getAutopayByUsrId($web_user_id) {
        $freqName = array(
            'onetime' => 'One time',
            'monthly' => 'Monthly',
            'quarterly' => 'Quarterly',
            'quaterly' => 'Quarterly',
            'triannually' => 'Triannually',
            'biannually' => 'Twice a Year',
            'annually' => 'Annually',
            'yearly' => 'Annually',
            'weekly' => 'Weekly',
            'biweekly' => 'Twice a Month'
        );

        $transactions = DB::table('accounting_recurring_transactions')->select('profile_id', 'trans_id', 'trans_recurring_net_amount', 'trans_recurring_convenience_fee', 'data', 'trans_status', 'dynamic', 'trans_first_post_date', 'trans_next_post_date', 'trans_last_post_date', 'trans_numleft', 'trans_schedule', 'trans_card_type', 'last_updated')->where('trans_web_user_id', $web_user_id)->orderBy('trans_status', 'asc')->get();
        if ($transactions === null) {
            return "";
        }
        for ($i = 0; $i < count($transactions); $i++) {
            $transactions[$i]['nextpay'] = date("M d, Y", strtotime($transactions[$i]['trans_next_post_date']));
            $transactions[$i]['created_on'] = date("M d, Y", strtotime($transactions[$i]['trans_first_post_date']));
            $transactions[$i]['day'] = date("jS", strtotime($transactions[$i]['trans_next_post_date'])) . ' of the Month';
            $transactions[$i]['last_updated'] = date('m/d/y', strtotime($transactions[$i]['last_updated']));

            if ($transactions[$i]['dynamic'] == 1) {
                $transactions[$i]['enddate'] = 'Until Canceled';
                $transactions[$i]['trans_numleft'] = 'Until Canceled';
            } else {
                $transactions[$i]['enddate'] = $this->getendDate($transactions[$i]);
            }
            if (isset($transactions[$i]['trans_schedule'])) {
                if (is_numeric($transactions[$i]['trans_schedule'])) {
                    $dkeys = array_keys($freqName);
                    $nm = $dkeys[$transactions[$i]['trans_schedule']];
                    $transactions[$i]['trans_schedule'] = $freqName[$nm];
                } else {
                    if (isset($freqName[strtolower($transactions[$i]['trans_schedule'])])) {
                        $transactions[$i]['trans_schedule'] = $freqName[strtolower($transactions[$i]['trans_schedule'])];
                    } else {
                        $transactions[$i]['trans_schedule'] = 'Monthly';
                    }
                }
            }
        }
        return $transactions;
    }

    function getAutopayByTransId($web_user_id, $trans_id) {
        $freqName = array(
            'onetime' => 'One time',
            'monthly' => 'Monthly',
            'quarterly' => 'Quarterly',
            'quaterly' => 'Quarterly',
            'triannually' => 'Triannually',
            'biannually' => 'Twice a Year',
            'annually' => 'Annually',
            'yearly' => 'Annually',
            'weekly' => 'Weekly',
            'biweekly' => 'Twice a Month'
        );

        $transactions = DB::table('accounting_recurring_transactions')->select('profile_id', 'trans_id', 'trans_recurring_net_amount', 'trans_recurring_convenience_fee', 'data', 'trans_status', 'dynamic', 'trans_first_post_date', 'trans_next_post_date', 'trans_last_post_date', 'trans_numleft', 'trans_schedule', 'trans_card_type', 'last_updated')->where('trans_web_user_id', $web_user_id)->where('trans_id', $trans_id)->first();
        if ($transactions === null) {
            return "";
        }

        $transactions = (array) $transactions;
        $transactions['nextpay'] = date("M d, Y", strtotime($transactions['trans_next_post_date']));
        $transactions['created_on'] = date("M d, Y", strtotime($transactions['trans_first_post_date']));
        $transactions['day'] = date("jS", strtotime($transactions['trans_next_post_date'])) . ' of the Month';
        $transactions['last_updated'] = date('m/d/y', strtotime($transactions['last_updated']));

        if ($transactions['dynamic'] == 1) {
            $transactions['enddate'] = 'Until Canceled';
            $transactions['trans_numleft'] = 'Until Canceled';
        } else {
            $transactions['enddate'] = $this->getendDate($transactions);
        }
        if (empty($transactions['trans_schedule'])) {
            $transactions['trans_schedule'] = 'monthly';
            DB::table('accounting_recurring_transactions')->where('trans_web_user_id', '=', $web_user_id)->update(array('trans_schedule' => 'monthly'));
        }

        $transactions['trans_schedule'] = $freqName[strtolower($transactions['trans_schedule'])];

        return $transactions;
    }

    function getAutoTrans_dash($web_user_id, $property_id) {
        $transactions = DB::table('accounting_recurring_transactions')->select('trans_id', 'trans_recurring_net_amount', 'dynamic', 'trans_first_post_date', 'trans_next_post_date', 'trans_last_post_date', 'trans_numleft', 'trans_schedule', 'trans_card_type', 'last_updated')->where('trans_web_user_id', $web_user_id)->where('trans_status', 1)->where('property_id', $property_id)->get();
        if ($transactions === null) {
            return "";
        }

        for ($i = 0; $i < count($transactions); $i++) {
            $transactions[$i]['nextpay'] = date("M d, Y", strtotime($transactions[$i]['trans_next_post_date']));
            $transactions[$i]['day'] = date("j", strtotime($transactions[$i]['trans_next_post_date']));
            $transactions[$i]['enddate'] = $this->getendDate($transactions[$i]);
            $transactions[$i]['schedule'] = $this->getDashboardArrayAutopay($transactions[$i]['trans_schedule'], $transactions[$i]['trans_next_post_date'], $transactions[$i]['enddate']);
        }
        return $transactions;
    }

    function addTransaction($paymentInfo, $key) {
        $orderID = "";
        if (isset($paymentInfo['orderid']) && !empty($paymentInfo['orderid'])) {
            $orderID = $paymentInfo['orderid'];
        }
        if (isset($paymentInfo['payment_id']) && !empty($paymentInfo['payment_id'])) {
            $orderID = $paymentInfo['payment_id'];
        }

        if (isset($paymentInfo['inv_number']) && !empty($paymentInfo['inv_number'])) {
            $json = array();
            $json['invoices'][] = "";
            $json['amounts'][] = $paymentInfo['total_amount'];
            $json['invoices_numbers'][] = $paymentInfo['inv_number'];
            $json_encode = json_encode($json);
        }

        //search user information(account #, name)
        $name = "";
        $web_user = DB::table('web_users')->select('account_number', 'first_name', 'last_name')->where('web_user_id', '=', $paymentInfo['web_user_id'])->first();
        $name = trim($web_user->first_name . ' ' . $web_user->last_name);
        if ($name == "") {
            if (isset($paymentInfo['payor_name'])) {
                $name = $paymentInfo['payor_name'];
            } else {
                $name = 'Unknow or empty';
            }
        }

        if (!isset($paymentInfo['profile_id'])) {
            $paymentInfo['profile_id'] = 0;
        }
        if (isset($paymentInfo['swipe'])) {
            $paymentInfo['source'] = 'Swipe';
        }
        if (isset($json_encode)) {
            $id = $this->insertGetId([
                'data' => $json_encode,
                'property_id' => $paymentInfo['id_property'], 'trans_net_amount' => $paymentInfo['net_amount'],
                'trans_convenience_fee' => $paymentInfo['fee'], 'trans_total_amount' => $paymentInfo['total_amount'],
                'trans_descr' => $paymentInfo['descr'],
                'trans_source_key' => $key, 'trans_payment_type' => $paymentInfo['card_info']['payment_type'],
                'trans_card_type' => $paymentInfo['card_info']['card_type'], 'trans_gw_custnum' => $paymentInfo['profile_id'],
                'trans_web_user_id' => $paymentInfo['web_user_id'], 'trans_account_number' => $web_user->account_number, 'trans_user_name' => $name, 'trans_status' => 0,
                'last_updated_by' => 'system', 'source' => $paymentInfo['source'],
                'trans_type' => $paymentInfo['trans_type'], 'nacha_type' => $paymentInfo['nacha_type'],
                'trans_first_post_date' => date('Y-m-d H:i:s'), 'orderid' => $orderID,
                'trans_last_post_date' => date('Y-m-d H:i:s'), 'trans_final_post_date' => date('Y-m-d H:i:s'),
                'trans_profile_id' => $paymentInfo['profile_id']
            ]);
        } else {
            $id = $this->insertGetId([
                'property_id' => $paymentInfo['id_property'], 'trans_net_amount' => $paymentInfo['net_amount'],
                'trans_convenience_fee' => $paymentInfo['fee'], 'trans_total_amount' => $paymentInfo['total_amount'],
                'trans_descr' => $paymentInfo['descr'],
                'trans_source_key' => $key, 'trans_payment_type' => $paymentInfo['card_info']['payment_type'],
                'trans_card_type' => $paymentInfo['card_info']['card_type'], 'trans_gw_custnum' => $paymentInfo['profile_id'],
                'trans_web_user_id' => $paymentInfo['web_user_id'], 'trans_account_number' => $web_user->account_number, 'trans_user_name' => $name, 'trans_status' => 0,
                'last_updated_by' => 'system', 'source' => $paymentInfo['source'],
                'trans_type' => $paymentInfo['trans_type'], 'nacha_type' => $paymentInfo['nacha_type'],
                'trans_first_post_date' => date('Y-m-d H:i:s'), 'orderid' => $orderID,
                'trans_last_post_date' => date('Y-m-d H:i:s'), 'trans_final_post_date' => date('Y-m-d H:i:s'),
                'trans_profile_id' => $paymentInfo['profile_id']
            ]);
        }


        return $id;
    }

    function updatePayment($trans_id, $response, $swipe = 0) {

        if (isset($response['transactionid']) && !isset($response['reference'])) {
            $response['reference'] = $response['transactionid'];
        }
        $response['responsetext'] = $this->setErrorDescr($response);

        if (!isset($response['authcode'])) {
            $response['authcode'] = '';
        }
        if (!isset($response['reference'])) {
            $response['reference'] = '';
        }
        //check array
        foreach ($response as $key => $value) {
            if (is_array($value) && $key != 'batch' && $key != 'card') {
                $response[$key] = implode(' ', $value);
            }
        }
        $rerror = $response['responsetext'];
        if (isset($response['extresponsetext'])) {
            $rerror .= ' ' . $response['extresponsetext'];
        }
      /*  if ($swipe == 1) {
            $trans_card_type = "Swipe(XXXX)";
            if (isset($response['card']['CardNumberMasked'])) {
                $cardn = substr($response['card']['CardNumberMasked'], -4);
                $trans_card_type = "Swipe( $cardn )";
            }
        } else {
            $trans_card_type1 = DB::table('accounting_transactions')->select('trans_card_type')->where('trans_id', '=', $trans_id)->first();
            $trans_card_type = $trans_card_type1->trans_card_type;
        }*/
        $trans_card_type1 = DB::table('accounting_transactions')->select('trans_card_type')->where('trans_id', '=', $trans_id)->first();
        $trans_card_type = $trans_card_type1->trans_card_type;
        $batchid = '';
        if (isset($response['batch'])) {
            if (isset($response['batch']['HostBatchID']) && isset($response['batch']['HostItemID'])) {
                $batchid = $response['batch']['HostBatchID'] . '|' . $response['batch']['HostItemID'];
                if (isset($response['batch']['HostBatchAmount'])) {
                    $batchid .= '|' . $response['batch']['HostBatchAmount'];
                }
            }
        }
        
        DB::table($this->table)->where('trans_id', '=', $trans_id)->update([
            'trans_result_auth_code' => $response['authcode'],
            'trans_result_code' => $response['response'],
            'trans_result_error_code' => $response['response'],
            'trans_result_error_desc' => $rerror,
            'trans_result_refnum' => $response['reference'],
            'batchID' => $batchid,
            'trans_status' => $response['response'],
            'trans_card_type' => $trans_card_type]);
    }

    function updatePaymentInv($trans_id, $response, $inv_id, $amount) {
        $obj_inv = new Invoices();

        if ($response['response'] == 1) {
            $date = $obj_inv->get1InvData($inv_id, 'invoice_date');
            $property_id = $obj_inv->get1InvData($inv_id, 'property_id');
            $paid = $obj_inv->get1InvData($inv_id, 'paid');
            $total = $obj_inv->get1InvData($inv_id, 'amount');

            $discount = $obj_inv->getDiscountByInvoice($inv_id, $property_id, $total, $date);
            $discount = $discount['discount'];
            $tmpTotal = $discount + $amount;
            if ($paid == 0 && $tmpTotal >= $total) {
                $total = $amount;
            }

            $paid = $amount + $paid;
            $obj_inv->set1InvInfo($inv_id, 'paid', $paid);

            if ($paid >= $total) {
                $obj_inv->set1InvInfo($inv_id, 'status', 'closed');
            } else {
                $obj_inv->set1InvInfo($inv_id, 'status', 'paid');
            }
        }

        $inv_number = $obj_inv->get1InvData($inv_id, 'invoice_number');
        $json = array(
            "invoices" => [$inv_id],
            "amounts" => [$amount],
            "invoices_numbers" => [$inv_number]
        );

        $json_encode = json_encode($json);
        DB::table($this->table)->where('trans_id', '=', $trans_id)->update([
            'data' => $json_encode,
            'invoice_number' => $inv_number]);
    }

    function addCfeeTransaction($paymentInfo, $key) {
        $data = array(
            'property_id' => $paymentInfo['id_property'], 'trans_net_amount' => $paymentInfo['net_amount'],
            'trans_convenience_fee' => $paymentInfo['fee'], 'trans_total_amount' => $paymentInfo['total_amount'],
            'trans_descr' => $paymentInfo['descr'],
            'trans_source_key' => $key, 'trans_payment_type' => $paymentInfo['card_info']['payment_type'],
            'trans_card_type' => $paymentInfo['card_info']['card_type'],
            'trans_web_user_id' => $paymentInfo['web_user_id'], 'trans_status' => 0,
            'last_updated_by' => 'system', 'source' => $paymentInfo['source'],
            'trans_type' => $paymentInfo['trans_type'], 'nacha_type' => $paymentInfo['nacha_type'],
            'trans_first_post_date' => date('Y-m-d H:i:s'),
            'trans_last_post_date' => date('Y-m-d H:i:s'), 'trans_final_post_date' => date('Y-m-d H:i:s'),
            'parent_trans_id' => $paymentInfo['parent_trans_id'], 'is_convenience_fee_trans' => 1
        );

        if (isset($paymentInfo['profile_id'])) {
            $data['trans_gw_custnum'] = $paymentInfo['profile_id'];
        }
        $id = $this->insertGetId($data);

        return $id;
    }

    function addCCRecurringTransaction($paymentInfo, $key) {
        $orderID = "";
        if (isset($paymentInfo['orderid']) && !empty($paymentInfo['orderid'])) {
            $orderID = $paymentInfo['orderid'];
        }
        if (isset($paymentInfo['payment_id']) && !empty($paymentInfo['payment_id'])) {
            $orderID = $paymentInfo['payment_id'];
        }

        $id = DB::table('accounting_recurring_transactions')->insertGetId([
            'property_id' => $paymentInfo['id_property'], 'trans_recurring_net_amount' => $paymentInfo['net_amount'],
            'trans_recurring_convenience_fee' => $paymentInfo['fee'], 'trans_descr' => $paymentInfo['descr'],
            'trans_source_key' => $key, 'trans_payment_type' => $paymentInfo['card_info']['payment_type'],
            'trans_card_type' => $paymentInfo['card_info']['card_type'], 'profile_id' => $paymentInfo['profile_id'],
            'trans_schedule' => $paymentInfo['freq'], 'trans_numleft' => $paymentInfo['numleft'],
            'trans_web_user_id' => $paymentInfo['web_user_id'], 'trans_gw_custnum' => $paymentInfo['token']['vid'],
            'trans_status' => 1, 'trans_first_post_date' => date('Y-m-d 00:00:00'),
            'trans_last_post_date' => date('Y-m-d 00:00:00'), 'trans_next_post_date' => $paymentInfo['trans_next_post_date'],
            'last_updated_by' => 'system', 'ppd' => $paymentInfo['dynamic'], 'orderid' => $orderID,
            'dynamic' => $paymentInfo['dynamic'],
            'eomonth' => $paymentInfo['eomonth']
        ]);

        if ($paymentInfo['source'] != 'eterm') {
            $this->PutUsrActive($paymentInfo);
        }
        return $id;
    }

    function addECRecurringTransaction($paymentInfo, $key) {
        $orderID = "";
        if (isset($paymentInfo['orderid']) && !empty($paymentInfo['orderid'])) {
            $orderID = $paymentInfo['orderid'];
        }
        if (isset($paymentInfo['payment_id']) && !empty($paymentInfo['payment_id'])) {
            $orderID = $paymentInfo['payment_id'];
        }

        $id = DB::table('accounting_recurring_transactions')->insertGetId([
            'property_id' => $paymentInfo['id_property'], 'trans_recurring_net_amount' => $paymentInfo['net_amount'],
            'trans_recurring_convenience_fee' => $paymentInfo['fee'], 'trans_descr' => $paymentInfo['descr'],
            'trans_source_key' => $key, 'trans_payment_type' => $paymentInfo['card_info']['payment_type'],
            'trans_card_type' => $paymentInfo['card_info']['card_type'], 'profile_id' => $paymentInfo['profile_id'],
            'trans_schedule' => $paymentInfo['freq'], 'trans_numleft' => $paymentInfo['numleft'],
            'trans_web_user_id' => $paymentInfo['web_user_id'], 'echeck_account_holder' => $paymentInfo['token']['ec_account_holder'],
            'trans_status' => 1, 'trans_first_post_date' => date('Y-m-d 00:00:00'),
            'trans_last_post_date' => date('Y-m-d 00:00:00'), 'trans_next_post_date' => $paymentInfo['trans_next_post_date'],
            'last_updated_by' => 'System', 'dynamic' => $paymentInfo['dynamic'], 'ppd' => $paymentInfo['dynamic'],
            'echeck_account_type' => $paymentInfo['token']['ec_checking_savings'], 'echeck_routing_number' => $paymentInfo['token']['ec_routing_number'],
            'echeck_account_number' => $paymentInfo['token']['ec_account_number'], 'data' => '',
            'echeck_token' => \Illuminate\Support\Facades\Crypt::encrypt($paymentInfo['token']['ec_account_holder'] . '|' . $paymentInfo['token']['ec_routing_number'] . '|' . $paymentInfo['token']['ec_account_number']),
            'fenc' => 1,
            'orderid' => $orderID,
            'eomonth' => $paymentInfo['eomonth']
        ]);

        if ($paymentInfo['source'] != 'eterm') {
            $this->PutUsrActive($paymentInfo);
        }
        return $id;
    }

    function PutUsrActive($paymentInfo) {
        $obj_email = new \App\CustomClass\Email();
        $usr = DB::table('web_users')
                ->where('web_user_id', $paymentInfo['web_user_id'])
                ->select('web_status', 'email_address')
                ->first();
        if ($usr['web_status'] == 998) {
            $email = "";
            if (!empty($usr['email_address'])) {
                $email = $usr['email_address'];
            } elseif (isset($paymentInfo['email']) && !empty($paymentInfo['email'])) {
                $email = $paymentInfo['email'];
            }

            if (!empty($email)) {
                $user = DB::table('web_users')
                        ->where('property_id', $paymentInfo['id_property'])
                        ->where('username', $email)
                        ->select('web_user_id')
                        ->get();

                if (empty($user)) {
                    DB::table('web_users')->where('web_user_id', $paymentInfo['web_user_id'])
                            ->update([
                                'email_address' => $email
                    ]);
                    $username = $email;
                } else {
                    $username = $this->CreateUsr($paymentInfo);
                }
            } else {
                $username = $this->CreateUsr($paymentInfo);
            }

            if (!empty($username)) {
                DB::table('web_users')->where('web_user_id', $paymentInfo['web_user_id'])
                        ->update([
                            'username' => $username,
                            'web_status' => 1,
                ]);
                $obj_email->NewAutoPayForgotPassw($paymentInfo);
            }
        }
    }

    function CreateUsr($paymentInfo) {
        $usr = DB::table('web_users')->where('web_user_id', $paymentInfo['web_user_id'])
                        ->select('first_name', 'last_name')->first();

        $first_name = $this->cleanString($usr['first_name']);
        $last_name = $this->cleanString($usr['last_name']);
        $username = "";
        if (!empty($first_name) && !empty($last_name)) {
            $username = substr($first_name, 0, 1);
            $username .= $last_name;
        } elseif (!empty($first_name)) {
            $username = $first_name;
        } elseif (!empty($last_name)) {
            $username = $last_name;
        } else {
            $string = "0123456789";
            $string1 = "abcdefghijklmnopqrstuvwxyz";
            $lenght = strlen($string) - 1;
            $lenght1 = strlen($string1) - 1;
            $username = substr($string1, rand(0, $lenght), 1) .
                    substr($string1, rand(0, $lenght), 1) .
                    substr($string1, rand(0, $lenght), 1) .
                    substr($string1, rand(0, $lenght), 1) .
                    substr($string1, rand(0, $lenght), 1) .
                    substr($string1, rand(0, $lenght), 1) .
                    substr($string, rand(0, $lenght), 1) .
                    substr($string, rand(0, $lenght), 1);
        }
        $i = 0;

        do {
            $uresponse = $username . $i;
            $exist = DB::table('web_users')
                    ->where('property_id', $paymentInfo['id_property'])
                    ->where('username', $uresponse)
                    ->select('web_user_id')
                    ->first();
            $i++;
        } while (!empty($exist['web_user_id']));

        return $uresponse;
    }

    function cleanString($string) {
        if (!empty($string)) {
            $keep = '0-9a-z'; // keep character
            $rpl = sprintf('~[^%s]++~i', $keep); // case insensitive
            $string = preg_replace($rpl, '', $string);
        }
        return strtolower($string);
    }

    function addTransCategories($categories, $trans_id, $id_property, $web_user_id) {
        $obj_properties = new Properties();
        $var = $obj_properties->getOnlyIds($id_property);
        $id_partners = $var['id_partners'];
        $id_companies = $var['id_companies'];

        for ($i = 0; $i < count($categories); $i++) {
            if ($categories[$i]['amount'] > 0.00) {
                if (!isset($categories[$i]['qty'])) {
                    $categories[$i]['qty'] = 1;
                }
                DB::table('trans_categories')->insert([
                    'trans_id' => $trans_id, 'id_properties' => $id_property,
                    'id_companies' => $id_companies, 'id_partners' => $id_partners,
                    'amount' => $categories[$i]['amount'], 'category_name' => $categories[$i]['name'],
                    'category_id' => $categories[$i]['id'], 'web_user_id' => $web_user_id, 'qty' => $categories[$i]['qty']
                ]);
            }
        }
    }

    function addReccuringTransCategories($categories, $trans_id, $id_property, $web_user_id) {
        $obj_properties = new Properties();
        $var = $obj_properties->getOnlyIds($id_property);
        $id_partners = $var['id_partners'];
        $id_companies = $var['id_companies'];
        for ($i = 0; $i < count($categories); $i++) {
            if (!isset($categories[$i]['id']) && isset($categories[$i]['payment_type_id'])) {
                $categories[$i]['id'] = $categories[$i]['payment_type_id'];
            }
            if ($categories[$i]['amount'] > 0.00) {
                if (!isset($categories[$i]['qty'])) {
                    $categories[$i]['qty'] = 1;
                }
                DB::table('recurring_trans_categories')->insert([
                    'trans_id' => $trans_id, 'id_properties' => $id_property,
                    'id_companies' => $id_companies, 'id_partners' => $id_partners,
                    'amount' => $categories[$i]['amount'], 'category_name' => $categories[$i]['name'],
                    'category_id' => $categories[$i]['id'], 'web_user_id' => $web_user_id, 'qty' => $categories[$i]['qty']
                ]);
            }
        }
    }

    function updateReccuringTransCategories($autopayInfo, $id_property, $web_user_id) {

        $obj_properties = new Properties();
        $var = $obj_properties->getOnlyIds($id_property);
        $id_partners = $var['id_partners'];
        $id_companies = $var['id_companies'];
        $total_amount = $autopayInfo['total_amount'];

        $result = DB::table('accounting_recurring_transactions')->select('trans_payment_type', 'trans_card_type')->where('trans_id', $autopayInfo['trans_id'])->first();
        $type = $result['trans_payment_type'];
        $card_type = $result['trans_card_type'];
        if (strtolower(substr($card_type, 0, 1) == 'a')) {
            $type = 'am';
        }

        $credential = array();
        $credential = $obj_properties->getCredentialtype_isrecurring($type, $id_property, 1);

        $conv_fee = $this->getFee($credential, $total_amount);
        if ($conv_fee['ERROR'] == 1) {
            return $conv_fee['ERRORCODE'];
        }

        if (isset($autopayInfo['convfee'])) { //using by Api
            $conv_fee['CFEE'] = $autopayInfo['convfee'];
        }

        DB::table('recurring_trans_categories')->where('trans_id', $autopayInfo['trans_id'])->delete();

        for ($i = 0; $i < count($autopayInfo['categories']); $i++) {
            if ($autopayInfo['categories'][$i]['amount'] > 0.00) {
                if (!isset($categories[$i]['qty'])) {
                    $categories[$i]['qty'] = 1;
                }
                DB::table('recurring_trans_categories')->insert([
                    'trans_id' => $autopayInfo['trans_id'], 'id_properties' => $id_property,
                    'id_companies' => $id_companies, 'id_partners' => $id_partners,
                    'amount' => $autopayInfo['categories'][$i]['amount'], 'category_name' => $autopayInfo['categories'][$i]['name'],
                    'category_id' => $autopayInfo['categories'][$i]['id'], 'web_user_id' => $web_user_id, 'qty' => $categories[$i]['qty']
                ]);
            }
        }

        $descr = $this->getPaymentDescr($autopayInfo['categories'], $conv_fee['CFEE'], '', '');

        DB::table('accounting_recurring_transactions')->where('trans_id', $autopayInfo['trans_id'])->update([
            'trans_recurring_net_amount' => $total_amount,
            'trans_descr' => $descr,
            'trans_recurring_convenience_fee' => $conv_fee['CFEE']
        ]);

        return 'Amount successfully changed';
    }

    function getPaymentDescr($categories, $cfee, $memo, $invnumber) {
        $detail = '';
        if (!empty($memo)) {
            $detail .= 'Memo- ' . $memo . "\n";
        }
        $detail .= 'Payment Details:' . "\n";
        if (!empty($invnumber)) {
            $detail .= 'Invoice #:' . $invnumber . "\n";
        }
        $total = 0;
        for ($i = 0; $i < count($categories); $i++) {
            if ($categories[$i]['amount'] > 0.00) {
                $total += $categories[$i]['amount'];
                $detail .= $categories[$i]['name'] . ': $' . number_format($categories[$i]['amount'], 2, '.', ',') . "\n";
            }
        }

        if (!empty($cfee) && $cfee > 0) {
            $detail .= 'Convenience Fee: $' . number_format($cfee, 2);
            $detail .= "\n";
        }
        $detail .= '---------------------' . "\n";
        $detail .= 'Total Payment: $' . number_format($cfee + $total, 2, '.', ',');

        return $detail;
    }

    function getFee($credentials, $amount, $card_type_fee = 'cc', $service_type = "") {

        if (count($credentials) < 1) {
            $result['ERROR'] = 1;
            $result['ERRORCODE'] = 'Sorry! You are unable to make this type of payment. Please contact your Payment Provider for assistance.';
            return $result;
        }
        $tier = array();
        $result = array();
        $convenience_fee = 0;
        $flag = false;
        $paymethod = "";
        //velocities by subtype

        if ($service_type != "") {
            if ($credentials[0]->payment_method == 'eterm-ec') {
                $paymethod = 'ec';
            } else {
                if ($credentials[0]->payment_method == 'eterm-cc') {
                    $paymethod = 'cc';
                } else {
                    if ($credentials[0]->payment_method == 'eterm-amex') {
                        $paymethod = 'amex';
                    }
                }
            }

            $credentialssubtype = DB::table('service_fee')->where('id_property', $credentials[0]->property_id)->where('service_type', $service_type)->where('payment_method', $paymethod)->get();

            if ($credentialssubtype != "") {
                $flag = true;
                $min = $credentialssubtype[0]->low_pay_range;
                $max = $credentialssubtype[0]->high_pay_range;
                $tier_applied = 0;

                if ($amount >= $min && $amount <= $max) {
                    $tier['min'] = $credentialssubtype[0]->low_pay_range;
                    $tier['max'] = $credentialssubtype[0]->high_pay_range;
                    $tier['ht'] = $credentialssubtype[0]->high_ticket;
                    $tier['cfee'] = $credentialssubtype[0]->convenience_fee;
                    $tier['cffee'] = $credentialssubtype[0]->convenience_fee_float;
                    $tier_applied = 0;
                } else {
                    for ($i = 1; $i < count($credentialssubtype); $i++) {
                        if ($min > $credentialssubtype[$i]->low_pay_range) {
                            $min = $credentialssubtype[$i]->low_pay_range;
                        }
                        if ($max < $credentialssubtype[$i]->high_pay_range) {
                            $max = $credentialssubtype[$i]->high_pay_range;
                        }

                        if ($amount >= $credentialssubtype[$i]->low_pay_range && $amount <= $credentialssubtype[$i]->high_pay_range) {
                            $tier['min'] = $credentialssubtype[$i]->low_pay_range;
                            $tier['max'] = $credentialssubtype[$i]->high_pay_range;
                            $tier['ht'] = $credentialssubtype[$i]->high_ticket;
                            $tier['cfee'] = $credentialssubtype[$i]->convenience_fee;
                            $tier['cffee'] = $credentialssubtype[$i]->convenience_fee_float;
                            $tier_applied = $i;
                            break;
                        }
                    }
                }
            }
        }

        if (!$flag) {
            //velocities
            $min = $credentials[0]->low_pay_range;
            $max = $credentials[0]->high_pay_range;


            $tier_applied = 0;

            if ($amount >= $min && $amount <= $max) {
                $tier['min'] = $credentials[0]->low_pay_range;
                $tier['max'] = $credentials[0]->high_pay_range;
                $tier['ht'] = $credentials[0]->high_ticket;
                $tier['cfee'] = $credentials[0]->convenience_fee;
                $tier['cffee'] = $credentials[0]->convenience_fee_float;
                if ($credentials[0]->payment_method == 'cc' || $credentials[0]->payment_method == 'swipe' || $credentials[0]->payment_method = 'eterm-cc') {
                    $cfee = DB::table('card_type_fee')->where('id_merchant_account', '=', $credentials[0]->merchant_account_id)->where('type', '=', $card_type_fee)->select('convenience_fee', 'convenience_fee_float')->get();
                    if ($cfee != "" && !$cfee->isEmpty()) {
                        $tier['cfee'] = $cfee[0]->convenience_fee;
                        $tier['cffee'] = $cfee[0]->convenience_fee_float;
                    }
                }
                $tier_applied = 0;
            }

            for ($i = 1; $i < count($credentials); $i++) {
                if ($min > $credentials[$i]->low_pay_range) {
                    $min = $credentials[$i]->low_pay_range;
                }
                if ($max < $credentials[$i]->high_pay_range) {
                    $max = $credentials[$i]->high_pay_range;
                }

                if ($amount >= $credentials[$i]->low_pay_range && $amount <= $credentials[$i]->high_pay_range) {
                    $tier['min'] = $credentials[$i]->low_pay_range;
                    $tier['max'] = $credentials[$i]->high_pay_range;
                    $tier['ht'] = $credentials[$i]->high_ticket;
                    $tier['cfee'] = $credentials[$i]->convenience_fee;
                    $tier['cffee'] = $credentials[$i]->convenience_fee_float;
                    if ($credentials[$i]->payment_method == 'cc' || $credentials[$i]->payment_method == 'swipe' || $credentials[$i]->payment_method = 'eterm-cc') {
                        $cfee = DB::table('card_type_fee')->where('id_merchant_account', '=', $credentials[$i]->merchant_account_id)->where('type', '=', $card_type_fee)->select('convenience_fee', 'convenience_fee_float')->get();
                        if ($cfee != "" && !$cfee->isEmpty()) {
                            $tier['cfee'] = $cfee[$i]->convenience_fee;
                            $tier['cffee'] = $cfee[$i]->convenience_fee_float;
                        }
                    }
                    $tier_applied = $i;
                    break;
                }
            }
        }
        if ($amount < $min * 1) {// error lower_range
            $result['ERROR'] = 1;
            $result['ERRORCODE'] = 'The minimum payment amount is ' . number_format($min, 2, ".", ",");
            return $result;
        }

        if ($amount > $max * 1) {//error high_range
            $result['ERROR'] = 1;
            $result['ERRORCODE'] = 'The maximum payment amount is ' . number_format($max, 2, ".", ",");
            return $result;
        }
        if (!empty($tier)) {
            $convenience_fee = $tier['cfee'];
            $convenience_fee += $tier['cffee'] * $amount / 100;

            if ($amount + $convenience_fee > $tier['ht'] * 1) {// error high ticket
                $result['ERROR'] = 1;
                $result['ERRORCODE'] = 'The maximum payment amount is ' . number_format($tier['ht'], 2, ".", ",");
                return $result;
            }
        }
        $result['ERROR'] = 0;
        $result['CFEE'] = number_format($convenience_fee, 2);
        $result['TIER_APPLIED'] = $tier_applied;

        return $result;
    }

    function getFeeDRP($credentials, $amount, $card_type_fee = 'cc') {
        if (count($credentials) < 1) {
            $result['ERROR'] = 1;
            $result['ERRORCODE'] = 'Sorry! You are unable to make this type of payment. Please contact your Payment Provider for assistance.';
            return $result;
        }
        $tier = array();
        $result = array();
        $convenience_fee = 0;
        //velocities
        $min = $credentials[0]->low_pay_range;
        $max = $credentials[0]->high_pay_range;


        $tier_applied = 0;

        if ($amount >= $min && $amount <= $max) {
            $tier['min'] = $credentials[0]->low_pay_range;
            $tier['max'] = $credentials[0]->high_pay_range;
            $tier['ht'] = $credentials[0]->high_ticket;
            $tier['cfee'] = $credentials[0]->convenience_fee_drp;
            $tier['cffee'] = $credentials[0]->convenience_fee_float_drp;
            $tier_applied = 0;
        }
        $credentials = (array) $credentials;
        for ($i = 1; $i < count($credentials); $i++) {
            if ($min > $credentials[$i]['low_pay_range']) {
                $min = $credentials[$i]['low_pay_range'];
            }
            if ($max < $credentials[$i]['high_pay_range']) {
                $max = $credentials[$i]['high_pay_range'];
            }

            if ($amount >= $credentials[$i]['low_pay_range'] && $amount <= $credentials[$i]['high_pay_range']) {
                $tier['min'] = $credentials[$i]['low_pay_range'];
                $tier['max'] = $credentials[$i]['high_pay_range'];
                $tier['ht'] = $credentials[$i]['high_ticket'];
                $tier['cfee'] = $credentials[$i]['convenience_fee_drp'];
                $tier['cffee'] = $credentials[$i]['convenience_fee_float_drp'];

                if ($credentials[$i]['payment_method'] == 'cc') {
                    $cfee = DB::table('card_type_fee')->where('id_merchant_account', '=', $credentials[$i]['merchant_account_id'])->where('type', '=', $card_type_fee)->select('convenience_fee', 'convenience_fee_float')->get();
                    if ($cfee != "" && !empty($cfee)) {
                        $tier['cfee'] = $cfee[0]['convenience_fee'];
                        $tier['cffee'] = $cfee[0]['convenience_fee_float'];
                    }
                }
                $tier_applied = $i;
            }
        }

        if ($amount < $min * 1) {// error lower_range
            $result['ERROR'] = 1;
            $result['ERRORCODE'] = 'The minimum payment amount is ' . number_format($min, 2, ".", ",");
            return $result;
        }

        if ($amount > $max * 1) {//error high_range
            $result['ERROR'] = 1;
            $result['ERRORCODE'] = 'The maximum payment amount is ' . number_format($max, 2, ".", ",");
            return $result;
        }

        $convenience_fee = $tier['cfee'];
        $convenience_fee += $tier['cffee'] * $amount / 100;

        if ($amount + $convenience_fee > $tier['ht'] * 1) {// error high ticket
            $result['ERROR'] = 1;
            $result['ERRORCODE'] = 'The maximum payment amount is ' . number_format($tier['ht'], 2, ".", ",");
            return $result;
        }

        $result['ERROR'] = 0;
        $result['CFEE'] = number_format($convenience_fee, 2);
        $result['TIER_APPLIED'] = $tier_applied;

        return $result;
    }

    function getAutopayInfoByTrans_id($trans_id, $property_id, $trans_web_user_id) {
        $result = DB::table('accounting_recurring_transactions')->select('trans_last_post_date', 'dynamic', 'trans_status', 'trans_payment_type', 'trans_card_type', 'trans_next_post_date', 'trans_schedule', 'trans_numleft', 'trans_recurring_net_amount', 'trans_recurring_convenience_fee')->where('trans_id', $trans_id)->where('property_id', $property_id)->where('trans_web_user_id', $trans_web_user_id)->first();
        return $result;
    }

    function getNumleft($freq, $startdate, $enddate) {
        if ($enddate == -1) {
            return 9999;
        }
        $start = strtotime($startdate);
        $end = strtotime($enddate);
        $numleft = 1;

        switch ($freq) {
            case 'weekly':
                while ($end > $start) {
                    if ($end >= strtotime('+1 week', $start)) {
                        $numleft++;
                    }
                    $start = strtotime('+1 week', $start);
                }
                break;
            case 'annually':
            case 'yearly':
                while ($end > $start) {
                    if ($end >= strtotime('+1 year', $start)) {
                        $numleft++;
                    }
                    $start = strtotime('+1 year', $start);
                }
                break;
            case 'biannually':
                while ($end > $start) {
                    if ($end >= strtotime('+6 months', $start)) {
                        $numleft++;
                    }
                    $start = strtotime('+6 months', $start);
                }
                break;
            case 'quaterly':
            case 'quarterly':
                while ($end > $start) {
                    if ($end >= strtotime('+3 months', $start)) {
                        $numleft++;
                    }
                    $start = strtotime('+3 months', $start);
                }
                break;
            case 'triannually':
                while ($end > $start) {
                    if ($end >= strtotime('+4 months', $start)) {
                        $numleft++;
                    }
                    $start = strtotime('+4 months', $start);
                }
                break;
            case 'biweekly':
                while ($end > $start) {
                    if ($end >= strtotime('+14 days', $start)) {
                        $numleft++;
                    }
                    $start = strtotime('+14 days', $start);
                }
                break;
            case 'monthly':
                while ($end > $start) {
                    if ($end >= strtotime('+1 months', $start)) {
                        $numleft++;
                    }
                    $start = strtotime('+1 months', $start);
                }
                break;
            default:
                $numleft = 0;
                break;
        }
        //var_dump($freq,$start,$end,$numleft);die;
        return $numleft;
    }

    function updateAutopayFreq($autopayInfo) {
        DB::table('accounting_recurring_transactions')->where('trans_id', $autopayInfo['trans_id'])->update([
            'trans_next_post_date' => $autopayInfo['next_day'], 'trans_numleft' => $autopayInfo['trans_numleft'],
            'trans_schedule' => $autopayInfo['freq'], 'trans_status' => 1
        ]);
    }

    function updateECReccurringMethod($trans_id, $autopayInfo, $web_user_id, $type, $cfee) {
        $autopayInfo['trans_card_type'] = str_replace('x', "", $autopayInfo['name']);
        $autopayInfo['trans_card_type'] = str_replace('X', "", $autopayInfo['trans_card_type']);
        $autopayInfo['trans_card_type'] = str_replace('-', "", $autopayInfo['trans_card_type']);
        $autopayInfo['trans_card_type'] = str_replace(" ", "", $autopayInfo['trans_card_type']);
        $autopayInfo['trans_card_type'] = $autopayInfo['ec_checking_savings'] . " (" . $autopayInfo['trans_card_type'] . ")";

        DB::table('accounting_recurring_transactions')->where('trans_id', $trans_id)->where('trans_web_user_id', $web_user_id)->update([
            'trans_card_type' => $autopayInfo['trans_card_type'],
            'echeck_account_type' => $autopayInfo['ec_checking_savings'],
            'echeck_account_holder' => $autopayInfo['ec_account_holder'],
            'echeck_routing_number' => $autopayInfo['ec_routing_number'],
            'echeck_account_number' => $autopayInfo['ec_account_number'],
            'trans_payment_type' => $type,
            'trans_recurring_convenience_fee' => $cfee,
            'last_updated_by' => 'User, updated profile',
            'profile_id' => $autopayInfo['profile_id']
        ]);
    }

    function updateCCReccurringMethod($trans_id, $autopayInfo, $web_user_id, $type, $cfee) {
        $autopayInfo['trans_card_type'] = str_replace('x', "", $autopayInfo['name']);
        $autopayInfo['trans_card_type'] = str_replace('X', "", $autopayInfo['trans_card_type']);
        $autopayInfo['trans_card_type'] = str_replace('-', "", $autopayInfo['trans_card_type']);
        $autopayInfo['trans_card_type'] = str_replace(" ", "", $autopayInfo['trans_card_type']);
        $autopayInfo['trans_card_type'] = $autopayInfo['cc_type'] . " (" . $autopayInfo['trans_card_type'] . ")";

        DB::table('accounting_recurring_transactions')->where('trans_id', $trans_id)->where('trans_web_user_id', $web_user_id)->update([
            'trans_gw_custnum' => $autopayInfo['vid'],
            'trans_card_type' => $autopayInfo['trans_card_type'],
            'trans_payment_type' => $type,
            'trans_recurring_convenience_fee' => $cfee,
            'last_updated_by' => 'User, updated profile',
            'profile_id' => $autopayInfo['profile_id']
        ]);
    }

    function getDashboardArrayAutopay($freq, $startdate, $enddate) {
        $schedule = array();

        $nowPlus2year = strtotime('+2 years');

        if ($enddate == -1) {
            $enddate = $nowPlus2year;
        } else {
            if ($enddate > $nowPlus2year) {
                $enddate = $nowPlus2year;
            }
        }

        $start = strtotime($startdate);
        $end = strtotime($enddate);

        switch ($freq) {
            case 'weekly':
                while ($end > $start) {
                    if ($end >= strtotime('+1 week', $start)) {
                        $schedule[] = date('Y|m', $start);
                    }
                    $start = strtotime('+1 week', $start);
                }
                break;
            case 'annually':
            case 'yearly':
                while ($end > $start) {
                    if ($end >= strtotime('+1 year', $start)) {
                        $schedule[] = date('Y|m', $start);
                    }
                    $start = strtotime('+1 year', $start);
                }
                break;
            case 'biannually':
                while ($end > $start) {
                    if ($end >= strtotime('+6 months', $start)) {
                        $schedule[] = date('Y|m', $start);
                    }
                    $start = strtotime('+6 months', $start);
                }
                break;
            case 'quaterly':
            case 'quarterly':
                while ($end > $start) {
                    if ($end >= strtotime('+3 months', $start)) {
                        $schedule[] = date('Y|m', $start);
                    }
                    $start = strtotime('+3 months', $start);
                }
                break;
            case 'triannually':
                while ($end > $start) {
                    if ($end >= strtotime('+4 months', $start)) {
                        $schedule[] = date('Y|m', $start);
                    }
                    $start = strtotime('+4 months', $start);
                }
                break;
            case 'biweekly':
                while ($end > $start) {
                    if ($end >= strtotime('+14 days', $start)) {
                        $schedule[] = date('Y|m', $start);
                    }
                    $start = strtotime('+14 days', $start);
                }
                break;
            case 'monthly':
                while ($end > $start) {
                    if ($end >= strtotime('+1 months', $start)) {
                        $schedule[] = date('Y|m', $start);
                    }
                    $start = strtotime('+1 months', $start);
                }
                break;
            default:
                break;
        }
        $schedule[] = date('Y|m', $end);
        return $schedule;
    }

    function getformatenddate($start, $end) {
        if ($end == '-1') {
            $date = new \DateTime('now');
            $date->modify('+100 years');
            return $date->format('Y-m-d');
        }

        $exp_start = explode("-", $start);
        $exp_end = explode("-", $end);
        $day = str_pad($exp_start[2], 2, "0", STR_PAD_LEFT);
        $month = str_pad($exp_end[1], 2, "0", STR_PAD_LEFT);
        return $exp_end[0] . "-" . $month . "-" . $day;
    }

    function getendDate($transactions) {
        $left = $transactions['trans_numleft'];
        if ($transactions['trans_numleft'] != 0) {
            $left = $transactions['trans_numleft'] - 1;
        }
        switch ($transactions['trans_schedule']) {
            case 'weekly':
                $transactions['enddate'] = date('M d, Y', strtotime('+' . $left . ' week', strtotime($transactions['trans_next_post_date'])));
                break;
            case 'annually':
                $transactions['enddate'] = date('M d, Y', strtotime('+' . $left . ' year', strtotime($transactions['trans_next_post_date'])));
                break;
            case 'biannually':
                $left = 6 * $left;
                $transactions['enddate'] = date('M d, Y', strtotime('+' . $left . ' months', strtotime($transactions['trans_next_post_date'])));
                break;
            case 'quaterly':
            case 'quarterly':
                $left = 3 * $left;
                $transactions['enddate'] = date('M d, Y', strtotime('+' . $left . ' months', strtotime($transactions['trans_next_post_date'])));
                break;
            case 'triannually':
                $left = 4 * $left;
                $transactions['enddate'] = date('M d, Y', strtotime('+' . $left . ' months', strtotime($transactions['trans_next_post_date'])));
                break;
            case 'biweekly':
                $left = 14 * $left;
                $transactions['enddate'] = date('M d, Y', strtotime('+' . $left . ' days', strtotime($transactions['trans_next_post_date'])));
                break;
            case 'monthly':
                $left = $left;

                $transactions['enddate'] = date('M d, Y', strtotime('+' . $left . ' month', strtotime($transactions['trans_next_post_date'])));
                break;
            default:
                $transactions['enddate'] = date('M d, Y', strtotime($transactions['trans_next_post_date']));
                break;
        }

        return $transactions['enddate'];
    }

    function getTransBy_wuid_tid_pid($trans_id, $property_id, $web_user_id) {
        $transactions = $this->select('trans_profile_id', 'invoice_number', 'trans_id', 'trans_descr', 'trans_result_error_desc', 'trans_status', 'trans_first_post_date', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'trans_result_auth_code', 'trans_card_type', 'trans_type', 'trans_profile_id', 'source')->where('trans_id', $trans_id)->where('trans_web_user_id', $web_user_id)->where('property_id', $property_id)->first();
        if (empty($transactions)) {
            return "";
        }
        return $transactions;
    }

    function getRecTransBy_wuid_tid_pid($trans_id, $property_id, $web_user_id) {
        $transactions = DB::table('accounting_recurring_transactions')->select('profile_id', 'trans_id', 'trans_descr', 'trans_status', 'trans_next_post_date', 'trans_recurring_net_amount as trans_net_amount', 'trans_recurring_convenience_fee as trans_convenience_fee', 'dynamic', 'trans_card_type', 'profile_id as trans_profile_id')->where('trans_id', $trans_id)->where('trans_web_user_id', $web_user_id)->where('property_id', $property_id)->first();
        if ($transactions === null) {
            return "";
        }
        return $transactions;
    }

    function getTransPaymentType($trans_id, $property_id, $web_user_id) {
        $categories = DB::table('trans_categories')->select('amount', 'category_name', 'qty')->where('trans_id', $trans_id)->where('id_properties', $property_id)->where('web_user_id', $web_user_id)->get();
        return $categories;
    }

    function getRecTransPaymentType($trans_id, $property_id, $web_user_id) {
        $categories = DB::table('recurring_trans_categories')->select('amount', 'category_name', 'qty', 'category_id as id', 'category_name as name')->where('trans_id', $trans_id)->where('id_properties', $property_id)->where('web_user_id', $web_user_id)->get();
        return $categories;
    }

    function getRecTransPaymentSum($trans_id, $property_id, $web_user_id) {
        $acategories = DB::table('recurring_trans_categories')->where('trans_id', $trans_id)->where('id_properties', $property_id)->where('web_user_id', $web_user_id)->sum('amount');
        return $acategories;
    }

    //Fraud Control (fraud12)
    function getFraudMaxTrans1day($web_user_id) {
        $count = DB::table('accounting_transactions')->where('trans_status', '!=', 1)->where('trans_payment_type', '=', 'cc')->where('trans_first_post_date', '>=', date('Y-m-d H:i:s', strtotime('-1 day')))->where('trans_web_user_id', '=', $web_user_id)->count();
        if (empty($count)) {
            return 0;
        }
        return $count;
    }

    //Fraud Control (fraud11)
    function getFraudMaxTrans1hour($web_user_id) {
        $count = DB::table('accounting_transactions')->where('trans_status', '!=', 1)->where('trans_payment_type', '=', 'cc')->where('trans_first_post_date', '>=', date('Y-m-d H:i:s', strtotime('-60 minutes')))->where('trans_web_user_id', '=', $web_user_id)->count();
        if (empty($count)) {
            return 0;
        }
        return $count;
    }

    //Fraud Control Insert Hash (fraud2)
    function insertFraudHash($hash, $idproperty) {
        $id = DB::table('fraud_hashing')->insert([
            'property_id' => $idproperty,
            'hashing' => $hash
        ]);
    }

    //Fraud Control (fraud2)
    function getFraudControlHash($hash, $idproperty) {
        $count = DB::table('fraud_hashing')->where('hashing', $hash)->where('property_id', $idproperty)->where('hdate', date('Y-m-d H:i:s', strtotime('-1 minutes')))->count();
        if (empty($count)) {
            return 0;
        }
        return $count;
    }

    //Fraud Control (fraud1)
    function getFraudControlUnitCount($idproperty) {
        $count = DB::table('accounting_transactions')->where('property_id', $idproperty)->where('trans_first_post_date', '>=', date('Y-m-d 00:00:00'))->where('trans_payment_type', 'cc')->where('is_convenience_fee_trans', '0')->count();
        if (empty($count)) {
            return 0;
        }
        return $count;
    }

    //Fraud Control (Default)
    function getFraudMaxTrans1hourXProperty($idproperty) {
        $count = DB::table('accounting_transactions')
                ->where('trans_status', '!=', 1)
                ->where('trans_type', 0)
                ->where('trans_payment_type', '=', 'cc')
                ->where('trans_first_post_date', '>=', date('Y-m-d H:i:s', strtotime('-60 minutes')))
                ->where('property_id', '=', $idproperty)
                ->count();

        if (empty($count)) {
            return 0;
        }
        return $count;
    }

    //Fraud Control
    function getFraudMaxTransDeclined1hourbyProperty($idproperty) {
        $count = DB::table('accounting_transactions')
                ->where('trans_status', '!=', 1)
                ->where('trans_type', 0)
                ->where('trans_payment_type', '=', 'cc')
                ->where('trans_first_post_date', '>=', date('Y-m-d H:i:s', strtotime('-60 minutes')))
                ->where('property_id', '=', $idproperty)
                ->count();

        if (empty($count)) {
            return 0;
        }
        return $count;
    }

    //Cancel Autopay
    function cancelAutopay($trans_id) {
        if (empty($trans_id)) {
            return false;
        }
        DB::table('accounting_recurring_transactions')->where('trans_id', '=', $trans_id)
                ->update(['last_updated_by' => "cancelled by web_user",
                    'trans_status' => 4]);
        return true;
    }

    //get amounts and convenience fee for a AutoPay
    function getAutopayAmount($web_user_id, $trans_id, $property_id) {
        $values = DB::table('accounting_recurring_transactions')
                ->where('trans_id', $trans_id)
                ->where('trans_web_user_id', $web_user_id)
                ->where('property_id', $property_id)
                ->where('trans_status', 1)
                ->select('trans_recurring_net_amount', 'trans_recurring_convenience_fee', 'trans_payment_type')
                ->first();
        if (!empty($values)) {
            return $values;
        }
        return 0;
    }

    //get 1 value accounting recurring transactions
    function get1recurringInfo($trans_id, $key) {
        $info = DB::table('accounting_recurring_transactions')->select($key)->where('trans_id', $trans_id)->first();
        $info = (array) $info;
        if (empty($info)) {
            return null;
        }
        return $info[$key];
    }

    //get 1 value accounting transactions
    function get1TransInfo($trans_id, $key) {
        $info = DB::table('accounting_transactions')->select($key)->where('trans_id', $trans_id)->first();

        return $info->$key;
    }

    //override trans_result_error_desc
    function setErrorDescr($response) {
        $result = "";
        if (isset($response['avsresponse']) || isset($response['cvvresponse'])) {
            if (isset($response['exact_message'])) {
                $result .= $response['exact_message'] . "\n";
            }
            if (isset($response['avsresponse'])) {
                $result .= "AVS Result: " . $response['avsresponse'] . "\n";
            }
            if (isset($response['cvvresponse'])) {
                $result .= "CVV Result: " . $response['cvvresponse'] . "\n";
            }
        }
        if (isset($response['responsetext'])) {
            $result .= $response['responsetext'] . "\n";
        }
        return $result;
    }

    function getexpTransByUsrId($web_user_id) {
        $transactions = $this->select('trans_id', 'trans_result_error_desc', 'trans_status', 'trans_first_post_date', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'trans_result_auth_code', 'trans_card_type')->where('trans_web_user_id', $web_user_id)->where('is_convenience_fee_trans', 0)->orderBy('trans_id', 'desc')->get();
        if ($transactions === null) {
            return "";
        }
        return $transactions;
    }

    //getOneClick Reminder
    function getOneClickReminderToday() {
        $result = DB::table('oneclick_reminder')->where('next_reminder', date("Y-m-d"))->where('status', 1)->get();
        return $result;
    }

    //source oneclick per user in 1 day
    function get1dayoneclick($web_user_id) {
        $result = $this->where('source', 'oneclick')->where('trans_web_user_id', $web_user_id)->where('trans_status', 1)->where('trans_first_post_date', '>', date("Y-m-d 00:00:00"))->select('trans_id')->first();
        return $result['trans_id'];
    }

    function existProfId($trans_profile_id) {
        $result = DB::table('profiles')->where('id', $trans_profile_id)->select('id')->first();
        if (empty($result['id'])) {
            return false;
        }
        return true;
    }

    function getUserById($trans_id) {
        $result = $this->where('trans_id', '=', $trans_id)->select('trans_web_user_id')->first();
        return $result['trans_web_user_id'];
    }

    function addApprovedTransEvent($trans_id, $property_id, $gateway, $date = null) {
        $data = array();
        $data['id_properties'] = $property_id;
        $data['gateway'] = $gateway;
        $data['trans_id'] = $trans_id;
        $data['event'] = 'Approved';
        if (!empty($date)) {
            $data['date'] = $date;
        }
        DB::table('transaction_events')->insert($data);
    }

    function addTransEvent($trans_id, $property_id, $gateway, $date, $event, $batch = '') {
        $data = array();
        $data['id_properties'] = $property_id;
        $data['gateway'] = $gateway;
        $data['trans_id'] = $trans_id;
        $data['event'] = $event;
        $data['date'] = $date;
        if ($batch != '') {
            $data['batch'] = $batch;
        }
        DB::table('transaction_events')->insert($data);
    }

    function findApprovedTransEvent($trans_id, $property_id, $gateway) {
        $ds = DB::table('transaction_events')->where('id_properties', '=', $property_id)
                        ->where('gateway', '=', $gateway)
                        ->where('trans_id', '=', $trans_id)
                        ->where('event', '=', 'Approved')->count();
        return $ds;
    }

    function findTransEvent($trans_id, $property_id, $gateway, $event, $date) {
        $ds = DB::table('transaction_events')->where('id_properties', '=', $property_id)
                        ->where('gateway', '=', $gateway)
                        ->where('trans_id', '=', $trans_id)
                        ->where('date', '=', $date)
                        ->where('event', '=', $event)->count();
        return $ds;
    }

    function getTransactionsFromTx($idproperty, $txid) {
        $result = $this->where('property_id', '=', $idproperty)->where('trans_id', '>', $txid)->where('trans_status', '=', 1)->where('trans_type', '<', 2)->where('is_convenience_fee_trans', '=', 0)->get();
        return $result;
    }

    function SetTransData($trans_id, $profile_id) {
        $data = (Array) DB::table('profiles')->where('id', $profile_id)->where('type', 'ec')->select('token')->first();

        if (empty($data['token'])) {
            return -1;
        }

        DB::table('trans_data')->insert([
            'trans_id' => $trans_id,
            'token' => $data['token']
        ]);
    }

    function getTransData($trans_id) {
        $data = DB::table('trans_data')->where('trans_id', $trans_id)->select('token')->first();
        if (empty($data['token'])) {
            return -1;
        }
        return $data['token'];
    }

    function getTransInfo($trans_id) {
        $data = DB::table('accounting_transactions')->where('trans_id', $trans_id)->first();
        return $data;
    }

    function removeTokenAP($token, $trans_id) {
        DB::table("autopay_extend")->where('token', $token)->where('trans_id', $trans_id)->update([
            'token' => ''
        ]);
    }

    function setAutoPayex($token, $web_user_id, $trans_id, $id_property, $id_companies, $id_partners) {
        $date = date("Y-m-d H:i:s");
        DB::table('autopay_extend')->insert([
            'token' => $token,
            'id_partners' => $id_partners,
            'id_companies' => $id_companies,
            'id_properties' => $id_property,
            'trans_id' => $trans_id,
            'web_user_id' => $web_user_id,
            'created_at' => $date
        ]);
    }

    function updateRTxByUserDynamic($web_user_id, $fields, $type) {
        $result = DB::table('accounting_recurring_transactions')->where('trans_payment_type', $type)->where('trans_web_user_id', $web_user_id)->where('dynamic', 1)->where('trans_status', '=', 1)->update($fields);
    }

    function updateRTxByUser($web_user_id, $fields, $dyn = false) {
        $dynamic = 0;
        if ($dyn) {
            $dynamic = 1;
        }

        //asking if trans_recurring_convenience_fee is comming inside of var $fields
        if (!isset($fields["trans_recurring_convenience_fee"])) {
            $objWebUser = new WebUsers();
            $prop_id = $objWebUser->get1UserInfo($web_user_id, 'property_id');

            //ec
            //calculate conv_fee for ec transactions -> return 0 if doesn't have none
            $fields["trans_recurring_convenience_fee"] = $this->getREC_ConvFee($fields['trans_recurring_net_amount'], $prop_id, "ec", $dynamic);
            //validate if user has at least one ec-recurring_payment
            $rec_ec = DB::table('accounting_recurring_transactions')->where('property_id', $prop_id)->where('trans_web_user_id', $web_user_id)->where('trans_payment_type', 'ec')->where('trans_status', '=', 1)->where('dynamic', $dynamic)->first();
            //update all ec-recurring_payment
            if (!empty($rec_ec)) {
                if (isset($fields['trans_recurring_net_amount'])) {
                    $saveB = $fields['trans_recurring_net_amount'];
                    $fields['trans_recurring_net_amount'] = $this->verifyRECAmount($fields['trans_recurring_net_amount'], $prop_id, "ec");
                }
                $result = DB::table('accounting_recurring_transactions')->where('property_id', $prop_id)->where('trans_web_user_id', $web_user_id)->where('trans_payment_type', 'ec')->where('dynamic', $dynamic)->where('trans_status', '=', 1)->update($fields);
                if (isset($saveB)) {
                    $fields['trans_recurring_net_amount'] = $saveB;
                }
            }

            //cc
            //calculate conv_fee for cc transactions -> return 0 if doesn't have none
            $fields["trans_recurring_convenience_fee"] = $this->getREC_ConvFee($fields['trans_recurring_net_amount'], $prop_id, "cc", $dynamic);
            //validate if user has at least one cc-recurring_payment
            $rec_cc = DB::table('accounting_recurring_transactions')->where('property_id', $prop_id)->where('trans_web_user_id', $web_user_id)->where('trans_payment_type', 'cc')->where('trans_status', '=', 1)->where('dynamic', $dynamic)->first();
            //update all cc-recurring_payment
            if (!empty($rec_cc)) {
                if (isset($fields['trans_recurring_net_amount'])) {
                    $saveB = $fields['trans_recurring_net_amount'];
                    $fields['trans_recurring_net_amount'] = $this->verifyRECAmount($fields['trans_recurring_net_amount'], $prop_id, "cc");
                }
                $result = DB::table('accounting_recurring_transactions')->where('property_id', $prop_id)->where('trans_web_user_id', $web_user_id)->where('trans_payment_type', 'cc')->where('dynamic', $dynamic)->where('trans_status', '=', 1)->update($fields);
                if (isset($saveB)) {
                    $fields['trans_recurring_net_amount'] = $saveB;
                }
            }

            //amex
            //calculate conv_fee for amex transactions -> return 0 if doesn't have none
            $fields["trans_recurring_convenience_fee"] = $this->getREC_ConvFee($fields['trans_recurring_net_amount'], $prop_id, "amex", $dynamic);
            //validate if user has at least one amex-recurring_payment
            $rec_amex = DB::table('accounting_recurring_transactions')->where('property_id', $prop_id)->where('trans_web_user_id', $web_user_id)->where('trans_payment_type', 'amex')->where('trans_status', '=', 1)->where('dynamic', $dynamic)->first();
            //update all amex-recurring_payment
            if (!empty($rec_amex)) {
                if (isset($fields['trans_recurring_net_amount'])) {
                    $saveB = $fields['trans_recurring_net_amount'];
                    $fields['trans_recurring_net_amount'] = $this->verifyRECAmount($fields['trans_recurring_net_amount'], $prop_id, "amex");
                }
                $result = DB::table('accounting_recurring_transactions')->where('property_id', $prop_id)->where('trans_web_user_id', $web_user_id)->where('trans_payment_type', 'amex')->where('dynamic', $dynamic)->where('trans_status', '=', 1)->update($fields);
                if (isset($saveB)) {
                    $fields['trans_recurring_net_amount'] = $saveB;
                }
            }
        } else { // $field has trans_recurring_convenience_fee
            //update all-recurring_payment (amex,cc,ec) with a fix conveniece_fee
            $result = DB::table('accounting_recurring_transactions')->where('property_id', $prop_id)->where('trans_web_user_id', $web_user_id)->where('dynamic', $dynamic)->where('trans_status', '=', 1)->update($fields);
        }

        //return $result;
    }

    function getAccountNumFromApp($idp) {
        $result = DB::table('application')->where('id_property', $idp)->select('content')->first();
        if (!empty($result['content'])) {
            $res_decode = json_decode(base64_decode($result['content']), true);
            if (isset($res_decode) && !empty($res_decode['banknumber'])) {
                return $res_decode['banknumber'];
            }
        }
        return 0;
    }

    //Danieyis Santiago

    function getVolTrans($month) {
        if (($month == "-3 month") || ($month == "-6 month") || ($month == "-12 month")) {
            //-12 month
            $dateold = date('Y-m-01 00:00:00', strtotime($month));

            // BIS
            $result = DB::table('accounting_transactions')
                            ->WhereIn('trans_payment_type', array('cc', 'ec'))
                            ->Where('trans_first_post_date', '>', $dateold)
                            ->Where('trans_first_post_date', '<=', 'DATE_FORMAT(NOW(),"%Y-%m-%d 23:59:59")')
                            ->Where('trans_status', '=', 1)
                            ->Where('trans_type', '<', 2)
                            ->Select('trans_first_post_date', 'trans_payment_type', 'trans_net_amount')->get();
        } else {
            $result = 'Incorrect Param';
        }
        //var_dump($json);die;
        return $result;
    }

    public function getTotalAuto($level, $idlevel) {
        $result = array();
        if ($level == 'M') {
            $result = DB::table('accounting_recurring_transactions')->select(DB::raw('SUM(accounting_recurring_transactions.trans_recurring_net_amount) AS stotal,COUNT(accounting_recurring_transactions.trans_id) as ctotal'))->join('properties', 'properties.id', '=', 'accounting_recurring_transactions.property_id')->where('accounting_recurring_transactions.trans_status', '=', 1)->where('accounting_recurring_transactions.property_id', '=', $idlevel)->get();
        } elseif ($level == 'G') {
            $result = DB::table('accounting_recurring_transactions')->select(DB::raw('SUM(accounting_recurring_transactions.trans_recurring_net_amount) AS stotal,COUNT(accounting_recurring_transactions.trans_id) as ctotal'))->join('properties', 'properties.id', '=', 'accounting_recurring_transactions.property_id')->where('accounting_recurring_transactions.trans_status', '=', 1)->where('properties.id_companies', '=', $idlevel)->get();
        } elseif ($level == 'P') {
            $result = DB::table('accounting_recurring_transactions')->select(DB::raw('SUM(accounting_recurring_transactions.trans_recurring_net_amount) AS stotal,COUNT(accounting_recurring_transactions.trans_id) as ctotal'))->join('properties', 'properties.id', '=', 'accounting_recurring_transactions.property_id')->where('accounting_recurring_transactions.trans_status', '=', 1)->where('properties.id_partners', '=', $idlevel)->get();
        }
        return $result;
    }

    public function getPayments($idlevel, $level, $status = 1, $whereCondition = array(), $gfee = 0) {

        $query = DB::table($this->table)
                ->join('web_users', 'web_users.web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->leftJoin('properties', 'properties.id', '=', 'accounting_transactions.property_id')
                ->leftJoin('companies', 'companies.id', '=', 'properties.id_companies')
                ->join('partners', 'partners.id', '=', 'properties.id_partners')
                ->select('trans_id', 'partners.partner_title as partner', 'companies.company_name as group', 'properties.name_clients as merchant', 'web_users.address_unit', 'web_users.account_number as webuser', 'trans_first_post_date as trans_date', 'trans_result_auth_code as authcode', 'web_users.first_name', 'web_users.last_name', 'trans_payment_type as pay_method', 'trans_card_type as pay_type', 'trans_net_amount as net_amount', 'trans_convenience_fee as net_fee', 'trans_total_amount as net_charge', 'trans_type as type', 'source', 'settled', 'invoice_number', 'orderid', 'companies.compositeID_companies as companyID', 'properties.compositeID_clients as paypointID', 'accounting_transactions.trans_auto_id as frequency')
                ->where('trans_status', '=', $status)
                ->where('is_convenience_fee_trans', '=', $gfee)
                ->where('properties.status_clients', '=', 1);

        if ($level == "G") {
            $query->where('companies.id', '=', $idlevel);
        } elseif ($level == "M") {
            $query->where('properties.id', '=', $idlevel);
        } elseif ($idlevel != '-954581') {
            $query->where('partners.id', '=', $idlevel);
        }

        //building search parameter if any only for export
        if (!empty($whereCondition)) {
            foreach ($whereCondition as $key => $value) {
                if (stristr($value, 'date')) {
                    $valueArray = explode('=', $value);
                    if ($valueArray[1] != '') {
                        $date = explode('/', $valueArray[1]);
                        $daterangecondition[] = $date[2] . '-' . $date[0] . '-' . $date[1];
                    }
                } else {
                    $valueArray = explode('=', $value);
                    if ($valueArray[0] != 'search') {
                        $query->where($valueArray[0], 'like', '%' . $valueArray[1] . '%');
                    }
                }
            }

            if (!empty($daterangecondition)) {
                if (($daterangecondition[0] != '' && isset($daterangecondition[0])) && ($daterangecondition[1] == '' && isset($daterangecondition[1]))) {
                    $query->where('trans_first_post_date', '>=', $daterangecondition[0] . ' 00:00:00');
                } elseif (($daterangecondition[0] == '' && isset($daterangecondition[0])) && ($daterangecondition[1] != '' && isset($daterangecondition[1]))) {
                    $query->where('trans_first_post_date', '<=', $daterangecondition[1] . ' 23:59:59');
                } elseif (($daterangecondition[0] != '' && isset($daterangecondition[0])) && ($daterangecondition[1] != '' && isset($daterangecondition[1]))) {
                    $query->where('trans_first_post_date', '>=', $daterangecondition[0] . ' 00:00:00');
                    $query->where('trans_first_post_date', '<=', $daterangecondition[1] . ' 23:59:59');
                }
            }
        }
        $accountingrecurrtransactions = $query;
        return $accountingrecurrtransactions;
    }

    function getPaymentsToday($web_user_id, $property_id) {
        $now = date("Y-m-d");
        $result = DB::table('accounting_transactions')->where('trans_web_user_id', $web_user_id)->where('property_id', $property_id)->where('trans_first_post_date', '>=', $now)->count();
        return $result;
    }

    function getAutopayToday($web_user_id, $property_id) {
        $trans_next_post_date = date("Y-m-d 00:00:00");
        $result = DB::table('accounting_recurring_transactions')->where('property_id', $property_id)->where('trans_web_user_id', $web_user_id)->where('trans_next_post_date', $trans_next_post_date)->count();
        return $result;
    }

    function getPaymentHistoryByUserId($idlevel, $level, $web_user_id) {

        $accounting_transactions = DB::table('accounting_transactions')
                ->Where('trans_web_user_id', $web_user_id)
                ->Select('trans_id', 'trans_first_post_date as trans_date', 'trans_convenience_fee', 'trans_total_amount', 'trans_descr', 'trans_source_key', 'trans_type', 'trans_card_type', 'trans_status', 'source');

        return $accounting_transactions;
    }

    function getWebUserAutoPayHistoryByUserId($idlevel, $level, $web_user_id) {

        $autopay_transactions = DB::table('accounting_recurring_transactions')
                ->Where('trans_web_user_id', $web_user_id)
                ->where('trans_status', 1)
                ->Select('trans_id', 'trans_next_post_date as trans_next_date', 'trans_numleft', 'trans_payment_type', 'trans_recurring_net_amount', 'trans_recurring_convenience_fee', 'dynamic as stype', 'trans_card_type', DB::raw('trans_recurring_net_amount+trans_recurring_convenience_fee as net_charge'));

        return $autopay_transactions;
    }

    function getWebUserPayHistoryDetail($idlevel, $level, $trans_id) {

        $userpayhistorydetail = DB::table('accounting_transactions')
                ->leftjoin('custom_fields_transaction', 'custom_fields_transaction.trans_id', 'accounting_transactions.trans_id')
                ->Where('accounting_transactions.trans_id', $trans_id)
                ->Select('accounting_transactions.trans_id as trans_id', 'trans_first_post_date as trans_date', 'trans_convenience_fee', 'trans_total_amount', 'trans_net_amount', 'trans_descr', 'trans_result_auth_code', 'trans_source_key', 'trans_type', 'trans_payment_type', 'trans_card_type', 'trans_status', 'source', 'custom_fields_transaction.field_description as fd', 'custom_fields_transaction.field_value as fv')
                ->get();

        return $userpayhistorydetail;
    }

    function getWebUserAutoPayHistoryDetail($idlevel, $level, $trans_id) {

        $userpayhistorydetail = DB::table('accounting_recurring_transactions')
                ->Where('trans_id', $trans_id)
                ->Select('trans_id', 'trans_next_post_date as trans_next_date', 'trans_numleft', 'trans_payment_type', 'trans_recurring_net_amount', 'trans_recurring_convenience_fee', 'dynamic as stype', 'trans_card_type', DB::raw('trans_recurring_net_amount+trans_recurring_convenience_fee as net_charge'))
                ->first();

        return $userpayhistorydetail;
    }

    function getTxByParent($txid) {
        $result = DB::table('accounting_transactions')->select('trans_id')->where('parent_trans_id', '=', $txid)->where('trans_type', '=', 2)->first();
        if (empty($result)) {
            return 0;
        }
        return $result['trans_id'];
    }

    function set1Info($txid, $key, $value) {
        DB::table('accounting_transactions')->where('trans_id', '=', $txid)->update(array($key => $value));
    }

    function cancelRTxByUser($web_user_id) {
        $result = DB::table('accounting_recurring_transactions')->where('trans_web_user_id', '=', $web_user_id)->where('trans_status', '=', 1)->update(array('trans_status' => 4));
    }

    //funtion to create the Refund transaction

    function addRefundTransaction($paymentInfo) {

        $trans_id = DB::table('accounting_transactions')->insertGetId([
            'property_id' => $paymentInfo['property_id'], 'trans_net_amount' => $paymentInfo['trans_net_amount'],
            'trans_convenience_fee' => $paymentInfo['trans_convenience_fee'], 'trans_total_amount' => $paymentInfo['trans_total_amount'],
            'trans_descr' => $paymentInfo['trans_descr'], 'parent_trans_id' => $paymentInfo['parent_trans_id'],
            'trans_source_key' => $paymentInfo['trans_source_key'], 'trans_payment_type' => $paymentInfo['trans_payment_type'],
            'trans_card_type' => $paymentInfo['trans_card_type'], 'trans_gw_custnum' => $paymentInfo['trans_gw_custnum'],
            'trans_web_user_id' => $paymentInfo['trans_web_user_id'], 'trans_status' => 1, 'is_convenience_fee_trans' => $paymentInfo['is_convenience_fee_trans'],
            'last_updated_by' => 'system', 'source' => $paymentInfo['source'],
            'trans_result_code' => $paymentInfo['trans_result_code'], 'trans_result_auth_code' => $paymentInfo['trans_result_auth_code'],
            'trans_result_error_code' => $paymentInfo['trans_result_error_code'], 'trans_result_error_desc' => $paymentInfo['trans_result_error_desc'],
            'trans_type' => 5, 'trans_result_refnum' => $paymentInfo['trans_result_refnum'], 'trans_account_number' => $paymentInfo['trans_account_number'], 'trans_user_name' => $paymentInfo['trans_user_name'], 'batchID' => $paymentInfo['batchID'],
            'trans_first_post_date' => date('Y-m-d H:i:s'), 'orderid' => $paymentInfo['orderid'],
            'trans_last_post_date' => date('Y-m-d H:i:s'), 'trans_final_post_date' => date('Y-m-d H:i:s'),
            'trans_profile_id' => $paymentInfo['trans_profile_id']
        ]);

        return $trans_id;
    }

    function createRefund($trans_id, $amount, $gateway, $refundcfee = false, $result = "") {
        $obj_email = new \App\CustomClass\Email();
        $trans_data = DB::table('accounting_transactions')->where('trans_id', $trans_id)->first();
        $trans_data = (array) $trans_data;
        $event = $trans_data['trans_net_amount'] > $amount ? 'Partial Refund: $' . number_format($amount, 2, '.', ',') : 'To Refund: $' . number_format($amount, 2, '.', ',');
        if (isset($result['transactionid']) && !empty($result['transactionid'])) {
            $trans_data['trans_result_refnum'] = $result['transactionid'];
        }
        if (isset($result['response']) && !empty($result['response'])) {
            $trans_data['trans_result_code'] = $result['response'];
        }
        if (isset($result['response_code']) && !empty($result['response_code'])) {
            $trans_data['trans_result_error_code'] = $result['response_code'];
        }
        if (isset($result['responsetext']) && !empty($result['responsetext'])) {
            $trans_data['trans_result_error_desc'] = $result['responsetext'];
        }
        if (isset($result['authcode']) && !empty($result['authcode'])) {
            $trans_data['trans_result_auth_code'] = $result['authcode'];
        }
        if (isset($result['batch'])) {
            if (isset($result['batch']['HostBatchID']) && isset($result['batch']['HostItemID'])) {
                $trans_data['batchID'] = $result['batch']['HostBatchID'] . '|' . $result['batch']['HostItemID'];
                if (isset($result['batch']['HostBatchAmount'])) {
                    $trans_data['batchID'] .= '|' . $result['batch']['HostBatchAmount'];
                }
            }
        }

        $feemessage = "";
        if (!$refundcfee && $trans_data['is_convenience_fee_trans'] == 0 && $trans_data['trans_convenience_fee'] > 0) {
            $feemessage = "The convenience fee will be not refunded";
            $trans_data['trans_convenience_fee'] = 0.00;
            $trans_data['trans_net_amount'] = $amount;
            $trans_data['trans_total_amount'] = $amount;
        } else {
            if ($trans_data['trans_net_amount'] > $amount) {
                $trans_data['trans_net_amount'] = $amount;
                $trans_data['trans_convenience_fee'] = 0.00;
                $trans_data['trans_total_amount'] = $amount;
            }
        }

        $fullamount = $trans_data['trans_net_amount'] + $trans_data['trans_convenience_fee'];
        $description = $trans_data['trans_descr'];
        //update description to Refunded transaction
        $refunddetails = '<dd style="margin-left: 10px;">Reference to: <strong>' . $trans_id . '</strong></dd><dd class="box-content" style="background:#7fb5dc; color:#ffffff ;margin-left: 10px;">Refund Details:</dd><dd style="margin-left: 10px;">Amount to Refund:<strong>$' . number_format($fullamount, 2, '.', ',') . '</strong>';
        $trans_data['trans_descr'] = $refunddetails;
        $trans_data['parent_trans_id'] = $trans_id;

        //create transaction refund with Approve event
        $transrefund_id = $this->addRefundTransaction($trans_data);

        //update description to Approved transaction
        $trans_description = $description . '<br><br>Refund Details:<br>Refund Transaction:<strong>' . $transrefund_id . '</strong><br>Amount to Refund:<strong>$' . number_format($fullamount, 2, '.', ',') . '</strong></dd>';
        if ($feemessage != "") {
            $trans_description = $trans_description . '<br><strong style="color:red">' . $feemessage . '</strong>';
        }
        DB::table('accounting_transactions')
                ->where('trans_id', '=', $trans_id)
                ->update(['trans_descr' => $trans_description]);


        //create Event "To Refund" to original transaction
        DB::table('transaction_events')->insert([
            'id_properties' => $trans_data['property_id'],
            'trans_id' => $trans_id,
            'gateway' => $gateway,
            'more' => $transrefund_id,
            'event' => $event
        ]);
        $property_id = $trans_data['property_id'];
        //create event to new refund transaction
        $this->addApprovedTransEvent($transrefund_id, $property_id, $gateway);

        //send email
        $data = array();
        $data['TransID'] = $transrefund_id;
        $obj_email->sendOpenApiReceipt($data);
        return $transrefund_id;
    }

    function VoidTransaction($trans_id) {
        $obj_email = new \App\CustomClass\Email();
        DB::table('accounting_transactions')->where('trans_id', $trans_id)->update([
            'trans_type' => 9,
            'trans_status' => 4
        ]);
        $property_id = $this->get1TransInfo($trans_id, 'property_id');
        DB::table('transaction_events')->insert([
            'id_properties' => $property_id,
            'trans_id' => $trans_id,
            'more' => 'done',
            'event' => 'Voided'
        ]);

        $data = array();
        $data['TransID'] = $trans_id;
        $obj_email->sendOpenApiReceipt($data);
    }

    function GetConvFee($parent_trans_id) {
        $convFee_transaction = $this->where('is_convenience_fee_trans', 1)
                        ->where('parent_trans_id', $parent_trans_id)
                        ->select('trans_id', 'trans_result_refnum', 'trans_net_amount')->first();
        if (!empty($convFee_transaction)) {
            return $convFee_transaction;
        }
        return "";
    }

    function getTransID_OrderID($property_id, $OrderID) {
        $trans = $this->where('property_id', $property_id)
                        ->where('Orderid', $OrderID)
                        ->select('trans_id')->first();
        if (!empty($trans['trans_id'])) {
            return $trans['trans_id'];
        }
        return "";
    }

    function getReccuringTransID_OrderID($property_id, $OrderID) {
        $trans = DB::table('accounting_recurring_transactions')->where('property_id', $property_id)
                        ->where('Orderid', $OrderID)
                        ->select('trans_id')->first();
        if (!empty($trans['trans_id'])) {
            return $trans['trans_id'];
        }
        return "";
    }

    function getRecTransData($trans_id) {
        $trans = DB::table('accounting_recurring_transactions')->where('trans_id', $trans_id)->first();
        return $trans;
    }

    function getREC_ConvFee($net_amount, $prop_id, $type, $dynamic = 0) {
        //get convenience fee
        $convFee = DB::table('merchant_account')
                ->where('property_id', $prop_id)
                ->where('payment_method', $type)
                ->where('is_recurring', 1)
                ->where('low_pay_range', '<=', $net_amount)
                ->where('high_pay_range', '>=', $net_amount)
                ->select('convenience_fee_float_drp', 'convenience_fee_drp', 'convenience_fee_float', 'convenience_fee')
                ->first();

        if (empty($convFee)) {
            return 0;
        }

        if ($dynamic) { //calulate DRP convenience_fee
            return (($convFee->convenience_fee_float_drp / 100) * $net_amount) + $convFee->convenience_fee_drp;
        } else { //calulate convenience_fee
            return (($convFee->convenience_fee_float / 100) * $net_amount) + $convFee->convenience_fee;
        }
    }

    function verifyRECAmount($amount, $prop_id, $type) {
        //verify balance and high pay range
        $highT = DB::table('merchant_account')
                ->where('property_id', $prop_id)
                ->where('payment_method', $type)
                ->where('is_recurring', 1)
                ->max('high_ticket');
        if (empty($highT)) {
            return 0;
        }
        if ($amount > $highT) {
            return 0;
        }
        return $amount;
    }

    /**
     * Gets the last id transaction for an invoice
     * @param type $property_id the merchant id
     * @param type $web_user_id the user id
     * @param type $invoice_number the invoice number
     * @return string the id of the transaction
     */
    function getLastTransIdByInvNum($property_id, $web_user_id, $invoice_number) {
        $obj = $this->select('trans_id')
                ->where('property_id', $property_id)
                ->where('trans_web_user_id', $web_user_id)
                ->where('invoice_number', $invoice_number)
                ->orderBy('trans_id', 'desc')
                ->first();
        if (!isset($obj['trans_id'])) {
            return "";
        }
        return $obj['trans_id'];
    }

    /*
     * Return if this transaction has a previous Partial Refund
     * @param int $trans_id
     * @return bool
     * @author rrofes@revopay.com
     */

    function hasPartialRefund($trans_id) {
        $event = DB::table('transaction_events')
                ->where('trans_id', $trans_id)
                ->where('event', 'like', '%Refund%')
                ->select('id', 'event')
                ->first();
        return empty($event) ? false : true;
    }

    /*
     * get amount refunded to that transaction
     * @param int $trans_id
     * @return bool
     * @author dsantiago@revopay.com
     */

    function getRefundAmount($trans_id, $property_id) {
        //Sum net amount to transactions with trans_type=5 and trans_parent_id=$trans_id
        $amount = DB::table('accounting_transactions')
                ->where('property_id', $property_id)
                ->where('parent_trans_id', $trans_id)
                ->where('trans_type', 5)
                ->sum('trans_net_amount');

        return $amount;
    }

    function getTransInfoLimited($partnerID, $companyID, $paypointID, $filters) {
        $whereArray = array();
        if (!empty($filters)) {
            foreach ($filters as $rule) {
                $tofind = $rule['data'];
                if ($tofind == '') {
                    continue;
                }
                $tocmp = $rule['op'];
                $field = "";
                switch ($rule['field']) {
                    case 'trans_date':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_first_post_date<='" . $tofind . " 23:59:59'";
                                break;
                            case 'gt':
                                $field = "SUBSTRING(accounting_transactions.trans_first_post_date,1,10)>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_first_post_date>='" . $tofind . " 00:00:00'";
                                break;
                        }
                        break;
                    case 'pay_method':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_payment_type='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_payment_type!='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'pay_type':
                        switch ($tocmp) {
                            case 'cn':
                                $field = "(accounting_transactions.trans_card_type LIKE '%" . $tofind . "%')";
                                break;
                            case 'nc':
                                $field = "(accounting_transactions.trans_card_type NOT LIKE '%" . $tofind . "%')";
                                break;
                            case 'bw':
                                $field = "accounting_transactions.trans_card_type LIKE '" . $tofind . "%'";
                                break;
                            case 'bn':
                                $field = "accounting_transactions.trans_card_type NOT LIKE '" . $tofind . "%'";
                                break;
                            case 'ew':
                                $field = "accounting_transactions.trans_card_type LIKE '%" . $tofind . "'";
                                break;
                            case 'en':
                                $field = "accounting_transactions.trans_card_type NOT LIKE '%" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'net_amount':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_net_amount='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_net_amount!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "accounting_transactions.trans_net_amount<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_net_amount<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "accounting_transactions.trans_net_amount>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_net_amount>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'net_charge':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_total_amount='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_total_amount!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "accounting_transactions.trans_total_amount<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_total_amount<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "accounting_transactions.trans_total_amount>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_total_amount>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'net_fee':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_convenience_fee='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_convenience_fee!='" . $tofind . "'";
                                break;
                            case 'lt':
                                $field = "accounting_transactions.trans_convenience_fee<'" . $tofind . "'";
                                break;
                            case 'le':
                                $field = "accounting_transactions.trans_convenience_fee<='" . $tofind . "'";
                                break;
                            case 'gt':
                                $field = "accounting_transactions.trans_convenience_fee>'" . $tofind . "'";
                                break;
                            case 'ge':
                                $field = "accounting_transactions.trans_convenience_fee>='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'type':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.trans_type LIKE '%" . $tofind . "%' AND is_convenience_fee_trans=0";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.trans_type NOT LIKE '%" . $tofind . "%' AND is_convenience_fee_trans=0";
                                break;
                        }
                        break;
                    case 'source':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.source LIKE '%" . $tofind . "%'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.source NOT LIKE '%" . $tofind . "%'";
                                break;
                        }
                        break;
                    case 'settled':
                        switch ($tocmp) {
                            case 'eq':
                                $field = "accounting_transactions.settled='" . $tofind . "'";
                                break;
                            case 'ne':
                                $field = "accounting_transactions.settled!='" . $tofind . "'";
                                break;
                        }
                        break;
                    case 'status':
                        switch ($tocmp) {
                            case 'eq':
                                if ($tofind <= 1) { //Approved and Errored
                                    $field = "accounting_transactions.trans_status='1' and accounting_transactions.trans_type<=1";
                                } elseif ($tofind == 2) { //Declined
                                    $field = "(accounting_transactions.trans_status='2' OR accounting_transactions.trans_status='3')";
                                } elseif ($tofind == 3) { //Returned
                                    $field = "accounting_transactions.trans_type='2' and accounting_transactions.trans_status='1'";
                                } elseif ($tofind == 4) { //Void
                                    $field = "accounting_transactions.trans_type='9'";
                                } elseif ($tofind == 5) { //Void
                                    $field = "accounting_transactions.trans_type='5'";
                                }
                                break;
                        }
                        break;
                }
                if ($field != "") {
                    $whereArray[] = $field;
                }
            }
        }
        $whereRaw = "";
        if (count($whereArray) > 0) {
            $whereRaw = implode(" AND ", $whereArray);
            $whereRaw .= " AND ";
        }

        if (!empty($paypointID)) {
            $whereRaw .= 'properties.id=' . $paypointID;
        } elseif (!empty($companyID)) {
            $whereRaw .= 'companies.id=' . $companyID;
        } elseif (!empty($partnerID)) {
            $whereRaw .= 'partners.id=' . $partnerID;
        }

        $transInfo = DB::table($this->table)->join('properties', 'accounting_transactions.property_id', '=', 'properties.id')
                ->join('companies', 'properties.id_companies', '=', 'companies.id')
                ->join('partners', 'properties.id_partners', '=', 'partners.id')
                ->join('web_users', 'web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->whereRaw($whereRaw)
                ->select('accounting_transactions.trans_id', 'partners.partner_title as partner', 'companies.company_name as group', 'companies.compositeID_companies', 'properties.name_clients as merchant', 'properties.compositeID_clients', 'web_users.account_number as webuser', 'web_users.first_name', 'web_users.last_name', 'properties.id as idproperty', 'properties.id_companies', 'properties.id_partners', 'web_users.address_unit', 'accounting_transactions.trans_first_post_date as trans_date', 'accounting_transactions.trans_payment_type as pay_method', 'accounting_transactions.trans_card_type as pay_type', 'accounting_transactions.trans_result_refnum as authcode', 'accounting_transactions.trans_net_amount as net_amount', 'accounting_transactions.trans_convenience_fee as net_fee', 'accounting_transactions.trans_total_amount as net_charge', 'accounting_transactions.trans_type as type', 'accounting_transactions.source', 'accounting_transactions.settled', 'accounting_transactions.invoice_number', 'accounting_transactions.orderid', 'accounting_transactions.trans_status as status', 'accounting_transactions.parent_trans_id')
                ->get();

        return $transInfo;
    }

    function getRecByUser($web_user_id, $dynamic = 1) {
        $ct = \Illuminate\Support\Facades\DB::table('accounting_recurring_transactions')->where('trans_status', 1)->where('trans_web_user_id', $web_user_id)->where('dynamic', $dynamic)->count();
        return $ct;
    }

    function getRecListByUser($web_user_id, $dynamic = 1) {
        $ct = \Illuminate\Support\Facades\DB::table('accounting_recurring_transactions')->where('trans_status', 1)->where('trans_web_user_id', $web_user_id)->where('dynamic', $dynamic)->select('trans_id')->get();
        return (array) $ct;
    }

    public function getCustomFields($trans_id) {
        return DB::table("custom_fields_transaction")
            ->where('trans_id', $trans_id)
            ->select('id', 'field_description','field_value')
            ->get();
    }
}
