<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Partners extends Model {

    protected $table = 'partners';
    public $timestamps = false;

    function getPartnerLogo($id_partners) {
        if (empty($id_partners)) {
            return '/img/revo.png';
        }
        $logo = $this->select('logo')->where('id', $id_partners)->first();
        if (empty($logo)) {
            return '/img/revo.png';
        }
        if (empty($logo['logo'])) {
            return '/img/revo.png';
        }
        if (file_exists('logos/partners/' . $logo['logo'])) {
            return '/logos/partners/' . $logo['logo'];
        } else {
            return '/img/revo.png';
        }
    }

    function get1PartnerInfo($id, $key) {
        $result = $this->where('id', '=', $id)->select($key)->first();
        return $result[$key];
    }

    function set1PartnerInfo($id, $key, $value) {
        DB::table($this->table)->where('id', '=', $id)->update(array($key => $value));
    }

    function getPartnerInfo($id) {

        $result = DB::table($this->table)->where('id', '=', $id)->select('partners.id', 'partner_name', 'partner_title', 'partner_composite_id', 'partners.logo', 'partners.layout_id')->first();
        if (!empty($result)) {
            $result->logo = $this->getPartnerLogo($id);
        }

        return $result;
    }

    function getDomain($idpartner) {
        $result = $this->where('id', '=', $idpartner)->select('partner_name')->first();
        return $result['partner_name'];
    }

    public function getPartnerLayout($idpar) {
        $layout = DB::table($this->table)->where('id', $idpar)->select('layout_id')->first();
        if ($layout) {
            return $layout->layout_id;
        }
    }

    public function getPartnersByFilter($level, $idlevel, $filter = null) {
        if($level=="B"){
            $partnersA=DB::table('branch_partner')->whereIn('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
        }
        $query = DB::table($this->table)
                ->where('status', 1)
                ->join('layout', 'partners.layout_id', 'layout.id_layout');
        if(isset($partners)){
            $query->whereIn('partners.id',$partners);
        }
        $query->select('id', 'partner_name', 'partner_title', 'status', 'layout_id', 'layout.lay_name as layout', 'last_updated', 'last_updated_by');
        return $query;
    }

    public function savePartner($partners) {

        DB::table($this->table)->insert([
            ['partner_title' => $partners['title'],
                'partner_name' => $partners['name'],
                'partner_composite_id' => $partners['ID'],
                'layout_id' => $partners['layout'],
                'last_updated_by' => $partners['updated_by'],
                'status' => 1,
                'logo' => $partners['logo']]
        ]);
    }

    Public function deletePartner($id) {
        DB::table($this->table)
                ->where('id', $id)
                ->update(['status' => 0]);
    }

    Public function getPartnerdetail($id) {
        $partnerdetails = DB::table($this->table)
                ->join('layout', 'partners.layout_id', 'layout.id_layout')
                ->select('id', 'partner_name', 'partner_title', 'partner_composite_id', 'logo', 'status', 'layout_id', 'layout.lay_name as layout', 'last_updated', 'last_updated_by')
                ->where('id', '=', $id)
                ->first();

        return $partnerdetails;
    }

    Public function updatePartner($partners, $id) {
        DB::table($this->table)
                ->where('id', $id)
                ->update(
                        ['partner_title' => $partners['title'],
                            'partner_name' => $partners['name'],
                            'partner_composite_id' => $partners['ID'],
                            'layout_id' => $partners['layout'],
                            'last_updated_by' => $partners['updated_by'],
                            'status' => 1,
                            'logo' => $partners['logo']]
        );
    }

    Public Function getPartners() {
        $result = DB::table($this->table)->where('status', 1)->get();
        return $result;
    }

    public function getPartnersbySubdomain($subdomain){
        $result = DB::table('partners')->where('status', 1)->where('partner_name', $subdomain)->get();
        return $result;
    }

    Public Function getPartners1($idlevel) {
        $result = DB::table($this->table)->where('status', 1)->where('branch_id', $idlevel)->get();
        return $result;
    }

    public function getAllPartners() {
        $result = DB::table($this->table)->get();
        return $result;
    }

    public function getPartnersByIds($arrayIds){
        if(is_array($arrayIds)){
            $partnerdetails = DB::table($this->table)
                ->whereIn('id', $arrayIds)
                ->get();
        }
        else{
            $partnerdetails = DB::table($this->table)
                ->where('id', '=', $arrayIds)
                ->get();
        }

        return $partnerdetails;
    }

    public function getPartnersByBranch($id){
        $data = DB::table('branch_partner')
            ->where('branch_id', '=', $id)
            ->get();
        return $data;
    }

}
