<?php

namespace App\Model;

use App\Model\Properties;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
//use Illuminate\Auth\Passwords\CanResetPassword;
//use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
//use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use DB;

class User extends Model {
//    use Authenticatable,
//        CanResetPassword;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'web_users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['username', 'password'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token'];
    public $timestamps = false;

    function sqlPassword($input) {
        $pass = strtoupper(sha1(sha1($input, true)));
        $pass = '*' . $pass;
        return $pass;
    }

    function verifyUser($usr, $pass, $idproperty) {
        //$result=$this->whereRaw("username='".$usr."' AND `password`=PASSWORD('".$pass."') AND property_id=".$idproperty." AND web_status=1")->select('web_user_id')->first();
        $result = $this->where('username', '=', $usr)->where('password', '=', $this->sqlPassword($pass))->where('property_id', '=', $idproperty)->where('web_status', '=', 1)->select('web_user_id')->first();
        if (empty($result)) {
            return 0;
        }
        if (!isset($result['web_user_id'])) {
            return 0;
        }
        return $result['web_user_id'];
    }

    function getFullNameById($idusr) {
        $result = $this->where('web_user_id', '=', $idusr)->select('first_name', 'last_name')->first();
        return $result['first_name'] . ' ' . $result['last_name'];
    }

    function getFullAdmNameById($idusr) {
        $result = DB::table('users')->where('id', '=', $idusr)->select('first_name', 'last_name')->first();
        return $result['first_name'] . ' ' . $result['last_name'];
    }

    function getUsrInfo($web_user_id) {
        $usr = array();
        $result = DB::table($this->table)->select('companyname', 'balance', 'balance_start_date', 'balance_due', 'suppression', 'email_address', 'first_name', 'account_number', 'address', 'address_unit', 'city', 'state', 'zip', 'last_name', 'photo', 'phone_number', 'username', 'web_user_id', 'property_id', 'web_status')->where('web_user_id', '=', $web_user_id)->first();
        $usr = $result;
        if (empty($usr)) {
            return $result;
        }
        if (empty($result->photo)) {
            $usr->photo = '/img/user1.jpg';
        } else {
            $usr->photo = $result->photo;
        }
        $usr->name = $result->first_name . " " . $result->last_name;
        return $usr;
    }

    function getUsernameByEmail($email, $idproperty) {
        $result = $this->where('email_address', 'LIKE', $email)->where('property_id', '=', $idproperty)->where('web_status', '=', 1)->select('username', 'web_user_id')->first();
        if (empty($result)) {
            return null;
        }
        return $result;
    }

    function getIdByEmailStatus($email, $idproperty) {
        $result = $this->where('email_address', 'LIKE', $email)->where('property_id', '=', $idproperty)->whereIn('web_status', array(1, 998))->select('web_user_id')->first();
        if (empty($result)) {
            return null;
        }
        return $result['web_user_id'];
    }

    function getUsernameByEmailAccount($email, $account, $idproperty) {
        $result = $this->where('email_address', 'LIKE', $email)->where('account_number', '=', $account)->where('property_id', '=', $idproperty)->where('web_status', '=', 1)->select('username', 'web_user_id')->first();
        if (empty($result)) {
            return null;
        }
        return $result;
    }

    function getIdByUserEmail($email, $username, $idproperty) {
        $result = $this->where('email_address', 'LIKE', $email)->where('username', '=', $username)->where('property_id', '=', $idproperty)->whereIn('web_status', [1, 46])->select('web_user_id', 'web_status')->first();
        if (empty($result)) {
            return null;
        }
        if ($result['web_status'] == 46) {
            $this->where('web_user_id', $result['web_user_id'])->update([
                'web_status' => 1
            ]);
        }
        return $result;
    }

    function getPaymentProfiles($web_user_id) {
        $result = DB::table('profiles')->where('web_user_id', $web_user_id)->select('id', 'name', 'type', 'token')->orderBy('id', 'desc')->get();
        return $result;
    }

    function getPaymentProfileById($web_user_id, $id_profile) {
        $result = DB::table('profiles')->where('web_user_id', $web_user_id)->where('id', $id_profile)->select('id', 'name', 'type', 'token', 'data', 'wallet')->first();
        return $result;
    }

    function getPaymentProfileById1($id_profile) {
        $result = DB::table('profiles')->where('id', $id_profile)->select('id', 'name', 'type', 'token')->first();
        return $result;
    }

    function convert64() {
        $result = DB::table('profiles')->select('token', 'id')->get();
        foreach ($result as $rdata) {
            $clean = base64_decode($rdata['token']);
            $bad = \Illuminate\Support\Facades\Crypt::encrypt($clean);
            DB::table('profiles')->where('id', '=', $rdata['id'])->update(array('token' => $bad));
        }
    }

    function convertback64() {
        $result = DB::table('profiles')->where('web_user_id', '<', 0)->select('token', 'id')->get();
        foreach ($result as $rdata) {
            $clean = $rdata['token'];
            $bad = \Illuminate\Support\Facades\Crypt::decrypt($clean);
            DB::table('profiles')->where('id', '=', $rdata['id'])->update(array('token' => $bad));
        }
    }

    function insertECpaymethod($data, $idproperty, $web_user_id) {
        $obj_property = new Properties();
        $merchant = $obj_property->getPropertyInfo($idproperty);
        $profile = json_decode($data, true);
        $ec_name = "XXXX- " . substr($profile['ec_account_number'], -4);
        $secure = \Illuminate\Support\Facades\Crypt::encrypt($data);

        $pid = DB::table('profiles')->insertGetId(['id_partner' => $merchant['id_partners'], 'id_company' => $merchant['id_companies'], 'id_property' => $idproperty, 'web_user_id' => $web_user_id, 'token' => $secure, 'name' => $ec_name, 'type' => 'ec']);
        return $pid;
    }

    function insertCCpaymethod($data, $cc_name, $type, $idproperty, $web_user_id, $walletData = null) {
        $obj_property = new Properties();
        $merchant = $obj_property->getPropertyInfo($idproperty);
        $secure = \Illuminate\Support\Facades\Crypt::encrypt($data);
        $var = 'name:' . $cc_name . ', type' . $type;

        $walletType = $profileDataAux = null;
        if ($walletData) {
            if (isset($walletData['walletType'])) {
                $walletType = $walletData['walletType'];
            }

            if (isset($walletData['oauth_verifier']) && $walletData['oauth_verifier']) {
                $profileDataAux = json_encode(['oauth_verifier' => $walletData['oauth_verifier']]);
            }
        }

        $pid = DB::table('profiles')->insertGetId(['data' => $profileDataAux, 'wallet' => $walletType, 'id_partner' => $merchant['id_partners'], 'id_company' => $merchant['id_companies'], 'id_property' => $idproperty, 'web_user_id' => $web_user_id, 'token' => $secure, 'name' => $cc_name, 'type' => $type]);
        return $pid;
    }

    function updateECpaymethod($data, $idproperty, $web_user_id, $profileID) {
        $obj_property = new Models\Properties();
        $merchant = $obj_property->getPropertyInfo($idproperty);
        $profile = json_decode($data, true);
        $ec_name = "XXXX- " . substr($profile['ec_account_number'], -4);
        $secure = \Illuminate\Support\Facades\Crypt::encrypt($data);
        DB::table('profiles')
                ->where('id', $profileID)
                ->update(['id_partner' => $merchant['id_partners'], 'id_company' => $merchant['id_companies'], 'id_property' => $idproperty, 'web_user_id' => $web_user_id, 'token' => $secure, 'name' => $ec_name, 'type' => 'ec']);
        return true;
    }

    function updateCCpaymethod($data, $cc_name, $type, $idproperty, $web_user_id, $profileID) {
        $obj_property = new Models\Properties();
        $merchant = $obj_property->getPropertyInfo($idproperty);
        $secure = \Illuminate\Support\Facades\Crypt::encrypt($data);
        DB::table('profiles')
                ->where('id', $profileID)
                ->update(['id_partner' => $merchant['id_partners'], 'id_company' => $merchant['id_companies'], 'id_property' => $idproperty, 'web_user_id' => $web_user_id, 'token' => $secure, 'name' => $cc_name, 'type' => $type]);
        return true;
    }

    function deleteProfile($id) {
        if (empty($id)) {
            return;
        }
        DB::table('accounting_recurring_transactions')
                ->where('profile_id', $id)
                ->update(['trans_status' => 4]);

        DB::table('profiles')->where('id', $id)->delete();
    }

    function deleteProfileByPropertyID($id, $idproperty) {
        if (empty($id)) {
            return;
        }
        DB::table('profiles')
                ->where('id', $id)
                ->where('id_property', $idproperty)
                ->delete();
    }

    function deleteUsrProfiles($web_user_id) {
        DB::table('profiles')->where('web_user_id', '=', $web_user_id)->delete();
    }

    function updateUsrprofile($array_usr, $web_user_id) {
        if (!isset($array_usr['balance_start_date']) && isset($array_usr['balance'])) {
            $array_usr['balance_start_date'] = date('Y-m-d H:i:s');
        }
        if (empty($array_usr)) {
            return;
        }
        DB::table('web_users')->where('web_user_id', $web_user_id)->update($array_usr);
        if (isset($array_usr['web_status']) && $array_usr['web_status'] >= 1000) {
            $this->deleteUsrProfiles($web_user_id);
            $objtx = new Models\Transations();
            $objtx->cancelRTxByUser($web_user_id);
            return;
        }
        if (isset($array_usr['balance'])) {
            $balance = $array_usr['balance'] * 1;
            if ($balance < 0) {
                $balance = 0;
            }
            //update autopayments
            $fld = array();
            $fld['trans_recurring_net_amount'] = $balance;
            $fld['trans_descr'] = 'Payment:      ' . number_format($balance, 2);
            $objtx = new Models\Transations();
            $objtx->updateRTxByUser($web_user_id, $fld, true);
        }
    }

    function updatePassword($array_usr, $web_user_id) {
        DB::table('web_users')->where('web_user_id', $web_user_id)->update(array('password' => ['Password', $array_usr['xpassword']], 'username' => $array_usr['xusername']));
    }

    function getUserSettings($web_user_id, $key) {
        $result = DB::table('settings_web_user')->where('key', $key)->where('user_id', $web_user_id)->select('value')->first();
        if (empty($result)) {
            return null;
        }
        $result = (array) $result;
        return $result['value'];
    }

    function setUserSettings($property_id, $web_user_id, $key, $value) {
        $getsetting = $this->getUserSettings($web_user_id, $key);
        if ($getsetting !== null) {
            DB::table('settings_web_user')->where('user_id', $web_user_id)->where('key', $key)->update(array('value' => $value));
        } else {
            DB::insert('insert into settings_web_user (`property_id`, `key`,`user_id`,`value`) values (?,?,?,?)', [$property_id, $key, $web_user_id, $value]);
        }
    }

    function set1UserInfo($web_user_id, $key, $value) {
        DB::table('web_users')->where('web_user_id', $web_user_id)->update(array($key => $value));
    }

    function setPasswordRaw($pass, $id) {
        DB::update("update web_users set password = PASSWORD('" . $pass . "') where web_user_id = ?", [$id]);
    }

    function get1UserInfo($web_user_id, $key) {
        $info = DB::table('web_users')->select($key)->where('web_user_id', $web_user_id)->first();
        return $info->$key;
    }

    function findByAccLastnameOption($xacc, $xlastname, $xfirstname, $xaddress) {
        $query = "account_number like '$xacc' and last_name like '$xlastname' and web_status in (1,998) ";
        if (!empty($xfirstname)) {
            $query.=" and first_name like '$xfirstname'";
        }
        if (!empty($xaddress)) {
            $query.=" and address like '%$xaddress%'";
        }
        $result = DB::table('web_users')->whereRaw($query)->select('web_user_id', 'account_number', 'first_name', 'last_name', 'address', 'address_unit', 'city', 'state', 'zip', 'phone_number', 'email_address', 'web_status')->first();
        return $result;
    }

    function findByAccOption($xacc, $xlastname, $xfirstname, $xaddress, $idproperty) {
        if (empty($xacc) && empty($xaddress) && empty($xlastname) && empty($xfirstname)) {
            return null;
        }
        $query = "web_status in (1,998) and property_id=" . $idproperty;
        if (!empty($xacc)) {
            $query.=" and account_number like '$xacc'";
        }
        if (!empty($xlastname)) {
            $query.=" and (last_name like '$xlastname' OR first_name like '$xlastname')";
        }
        if (!empty($xfirstname)) {
            $query.=" and (first_name like '$xfirstname' OR last_name like '$xfirstname')";
        }
        if (!empty($xaddress)) {
            $query.=" and address like '%$xaddress%'";
        }
        $result = DB::table('web_users')->whereRaw($query)->select('web_user_id', 'account_number', 'first_name', 'last_name', 'address', 'address_unit', 'city', 'state', 'zip', 'phone_number', 'email_address', 'web_status')->first();
        return $result;
    }

    function findByAccOptionList($xacc, $xlastname, $xfirstname, $xaddress, $idproperty) {
        if (empty($xacc) && empty($xaddress) && empty($xlastname) && empty($xfirstname)) {
            return null;
        }
        if ($idproperty <= 0) {
            return null;
        }
        $query = "web_status<1000 AND property_id=" . $idproperty;
        if (!empty($xacc)) {
            $query.=" and account_number like '$xacc'";
        }
        if (!empty($xlastname)) {
            $query.=" and (last_name like '$xlastname' OR first_name like '$xlastname')";
        }
        if (!empty($xfirstname)) {
            $query.=" and (first_name like '$xfirstname' OR last_name like '$xfirstname')";
        }
        if (!empty($xaddress)) {
            $query.=" and address like '%$xaddress%'";
        }
        $result = DB::table('web_users')->whereRaw($query)->select('web_user_id', 'account_number', 'first_name', 'last_name', 'address', 'address_unit', 'city', 'state', 'zip', 'phone_number', 'email_address', 'web_status')->get();
        return $result;
    }

    function findByMailOptionList($xacc, $xlastname, $xfirstname, $xaddress, $idproperty) {
        if (empty($xacc) && empty($xaddress) && empty($xlastname) && empty($xfirstname)) {
            return null;
        }
        if ($idproperty <= 0) {
            return null;
        }
        $query = "web_status<1000 AND property_id=" . $idproperty;
        if (!empty($xacc)) {
            $query.=" and email_address like '$xacc'";
        }
        if (!empty($xlastname)) {
            $query.=" and (last_name like '$xlastname' OR first_name like '$xlastname')";
        }
        if (!empty($xfirstname)) {
            $query.=" and (first_name like '$xfirstname' OR last_name like '$xfirstname')";
        }
        if (!empty($xaddress)) {
            $query.=" and address like '%$xaddress%'";
        }
        $result = DB::table('web_users')->whereRaw($query)->select('web_user_id', 'account_number', 'first_name', 'last_name', 'address', 'address_unit', 'city', 'state', 'zip', 'phone_number', 'email_address', 'web_status')->get();
        return $result;
    }

    function CreateUser($fields) {
        if (!isset($fields['balance_start_date'])) {
            $fields['balance_start_date'] = date('Y-m-d H:i:s');
        }
        if (!isset($fields['entered'])) {
            $fields['entered'] = date('Y-m-d H:i:s');
        }
        if (!isset($fields['account_number']) || empty($fields['account_number'])) {
            if (isset($fields['username']) && !empty($fields['username'])) {
                $same_acc = DB::table('web_users')->whereIn('web_status', [1, 46, 998])->where('username', $fields['username'])->where('property_id', $fields['property_id'])->select('web_user_id')->first();
                if (!empty($same_acc['web_user_id'])) {
                    return -1;
                }
            }
            $result = DB::table('web_users')->insertGetId($fields);
            return $result;
        }
        $same_acc = DB::table('web_users')->whereIn('web_status', [1, 46, 998])->where('account_number', $fields['account_number'])->where('property_id', $fields['property_id'])->select('web_user_id')->first();
        if (empty($same_acc->web_user_id)) {
            if (isset($fields['username']) && !empty($fields['username'])) {
                $same_acc = DB::table('web_users')->whereIn('web_status', [1, 46, 998])->where('username', $fields['username'])->where('property_id', $fields['property_id'])->select('web_user_id')->first();
                if (!empty($same_acc['web_user_id'])) {
                    return -1;
                }
            }
            $result = DB::table('web_users')->insertGetId($fields);
            return $result;
        }
        return false;
    }

    function getUsrFirstName_Photo($web_user_id) {
        $result = $this->select('first_name', 'photo')->where('web_user_id', $web_user_id)->first();
        if (empty($result['photo'])) {
            $result['photo'] = '/img/user1.jpg';
        }
        return $result;
    }

    function getMinimalDataFind($idproperty, $acc) {
        $result = $this->where('property_id', '=', $idproperty)->whereIn('web_status', array(1, 998, 999))->where('account_number', '=', $acc)->select('first_name', 'last_name', 'email_address', 'web_user_id', 'phone_number')->first();
        return $result;
    }

    function countingUserAttempt($idproperty, $username) {
        $result = DB::table('web_users_attempts')->where('property_id', '=', $idproperty)->where('username', 'LIKE', $username)->select('counter')->first();
        if (empty($result)) {
            return 0;
        }
        return $result['counter'];
    }

    function findIDByUsername($idproperty, $email) {
        $result = $this->where('property_id', '=', $idproperty)->where('username', 'LIKE', $email)->where('web_status', '<', 1000)->select('web_user_id')->first();
        if (empty($result)) {
            return 0;
        }
        return $result['web_user_id'];
    }

    function setCounterAttempt($idproperty, $email, $cattempts) {
        if ($cattempts == 1) {
            //create
            DB::table('web_users_attempts')->insert(array('property_id' => $idproperty, 'username' => $email, 'counter' => $cattempts, 'ipaddr' => $_SERVER['REMOTE_ADDR']));
        } else {
            if ($cattempts == 0) {
                //delete
                DB::table('web_users_attempts')->where('property_id', '=', $idproperty)->where('username', 'LIKE', $email)->delete();
            } else {
                DB::table('web_users_attempts')->where('property_id', '=', $idproperty)->where('username', 'LIKE', $email)->update(array('counter' => $cattempts));
            }
        }
    }

    function isBlocked($idproperty, $email) {
        $result = $this->where('property_id', '=', $idproperty)->where('username', 'LIKE', $email)->where('web_status', '<', 1000)->select('web_status')->first();
        if (empty($result)) {
            return false;
        }
        if ($result['web_status'] == 46) {
            return true;
        }
        return false;
    }

    function findByEmail($nemail, $idproperty) {
        $result = DB::table('web_users')->where('email_address', 'LIKE', $nemail)->where('property_id', '=', $idproperty)->where('web_status', '<', 1000)->select('web_user_id', 'web_status')->first();
        return $result;
    }

    function getUsrByAccPwEmail($array) {
        $result = $this->whereRaw(" account_number='" . $array['xaccount_number'] . "' and email_address='" . $array['xemail'] . "' and web_user_id!=" . $array['web_user_id'] . " and web_status=1 and password=PASSWORD('" . $array['xpassword'] . "')")->first();
        if (empty($result)) {
            return 0;
        }
        if ($result == null) {
            return 0;
        }
        return $result['web_user_id'];
        $result = DB::raw("select web_user_id from web_users where account_number='" . $array['xaccount_number'] . "' and email_address='" . $array['xemail'] . "' and password=PASSWORD('" . $array['xpassword'] . "')");
    }

    function setLinked_id($web_user1, $web_user2) {
        $result = DB::table('web_users_linked')->where('web_user_id', $web_user1)->select('linked_id')->first();
        if ($result == null) {
            $linked_id1 = '';
        }
        $linked_id1 = $result['linked_id'];

        $result = DB::table('web_users_linked')->where('web_user_id', $web_user2)->select('linked_id')->first();
        if ($result == null) {
            $linked_id2 = '';
        }
        $linked_id2 = $result['linked_id'];

        if (!empty($linked_id1) && !empty($linked_id2)) {
            $this->UpdateLinkedAccount($linked_id1, $linked_id2);
        } elseif (empty($linked_id1) && !empty($linked_id2)) {
            $this->addLinkedAccountByLinkId($web_user1, $linked_id2);
        } elseif (!empty($linked_id1) && empty($linked_id2)) {
            $this->addLinkedAccountByLinkId($web_user2, $linked_id1);
        } else {
            $this->addnewLinkedAccount($web_user2);
            $this->addnewLinkedAccount($web_user1);
        }

        return $result;
    }

    function UpdateLinkedAccount($newlinked, $oldlikend) {
        DB::table('web_users_linked')->where('linked_id', $oldlikend)
                ->update(['linked_id' => $newlinked
        ]);
    }

    function addnewLinkedAccount($web_user_id) {
        DB::table('web_users_linked')->insert([
            'web_user_id' => $web_user_id, 'linked_id' => time()
        ]);
    }

    function addLinkedAccountByLinkId($web_user_id, $linked_id) {
        DB::table('web_users_linked')->insert([
            'web_user_id' => $web_user_id, 'linked_id' => $linked_id
        ]);
    }

    function findAccount($account, $idproperty) {
        $result = DB::table('web_users')->whereRaw("TRIM(account_number) LIKE '" . trim($account) . "'")->where('property_id', '=', $idproperty)->where('web_status', '<', 1000)->select('web_user_id', 'web_status')->first();
        return $result;
    }

    function findAccountUnderLevel($account, $idlevel, $level) {
        $query = DB::table('web_users')
                ->join('properties', 'properties.id', '=', 'web_users.property_id')
                ->join('companies', 'companies.id', '=', 'properties.id_companies')
                ->leftJoin('partners', 'partners.id', '=', 'properties.id_partners')
                ->whereRaw("TRIM(account_number) LIKE '" . trim($account) . "'")
                ->where('web_status', '<', 1000);
        if ($level == 'P') {
            $query->where('properties.id_partnes', '=', $idlevel);
        } elseif ($level == 'G') {
            $query->where('properties.id_companies', '=', $idlevel);
        } else {
            $query->where('properties.id', '=', $idlevel);
        }
        $result = $query->select('web_user_id', 'web_status')->first();
        return $result;
    }

    function getLinkedIdbyUsrId($web_user_id) {
        $linked_id = DB::table('web_users_linked')->select('linked_id')->where('web_user_id', $web_user_id)->first();
        if ($linked_id == null) {
            return 0;
        }
        return $linked_id['linked_id'];
    }

    function getAccountsLinked($linked_id) {
        $linkinfo = DB::table('web_users_linked')
                        ->join('web_users', 'web_users.web_user_id', '=', 'web_users_linked.web_user_id')
                        ->join('properties', 'web_users.property_id', '=', 'properties.id')
                        ->where('web_users_linked.linked_id', '=', $linked_id)
                        ->select('web_users.account_number', 'web_users.first_name', 'web_users.last_name', 'properties.name_clients', 'properties.id', 'web_users.web_user_id', 'web_users_linked.id_web_users_linked')->get();
        if ($linkinfo == null) {
            return 0;
        }

        return $linkinfo;
    }

    function deleteLinkedAccount($id) {
        DB::table('web_users_linked')
                ->where('id_web_users_linked', '=', $id)
                ->delete();
    }

    function updateCompanyName($company_name, $property_id, $web_user_id) {
        $tmp = strtolower($company_name);
        $id_company = DB::table('web_companies')->where('property_id', $property_id)->where('name', $tmp)->select('web_company_id')->first();
        $id_company = $id_company['web_company_id'];
        if (empty($id_company)) {
            $id_company = 0;
        }
        $id_webuser_company = DB::table('web_companies_users')->where('user_id', $web_user_id)->where('property_id', $property_id)->select('id')->first();
        if (empty($webuser_company)) {
            $webuser_company = 0;
        }
        if ($id_company == 0) {
            $array_user = DB::table('web_users')->where('web_user_id', $web_user_id)->select('address', 'city', 'state', 'zip', 'phone_number', 'first_name', 'last_name')->first();
            //insert company name
            $id_company = DB::table('web_companies')->insertGetId([
                'property_id' => $property_id,
                'name' => $company_name,
                'address' => $array_user['address'],
                'city' => $array_user['city'],
                'state' => $array_user['state'],
                'zip' => $array_user['zip'],
                'phone' => $array_user['phone_number'],
                'contact_name' => $array_user['first_name'] . " " . $array_user['last_name'],
                'last_updated_by' => $array_user['first_name'] . " " . $array_user['last_name'] . "-MY PROFILE"
            ]);
        }
        if ($id_webuser_company['id'] == 0) {
            DB::table('web_companies_users')->insert([
                'property_id' => $property_id,
                'user_id' => $web_user_id,
                'company_id' => $id_company
            ]);
        } else {
            DB::table('web_companies_users')->where('id', $id_webuser_company['id'])->update([
                'company_id' => $id_company
            ]);
        }
    }

    function getCompanyName($web_user_id, $property_id) {
        $company_name = DB::table('web_companies_users')
                ->join('web_companies', 'web_companies_users.company_id', '=', 'web_companies.web_company_id')
                ->where('web_companies_users.user_id', $web_user_id)
                ->where('web_companies_users.property_id', $property_id)
                ->select('web_companies.name')
                ->first();
        if (empty($company_name)) {
            return "";
        }
        return $company_name['name'];
    }

    function getAutoCountByUser($web_user_id, $id_property) {
        $result = DB::table('accounting_recurring_transactions')->where('property_id', $id_property)->where('trans_web_user_id', $web_user_id)->where('trans_status', 1)->count();
        if (empty($result)) {
            return 0;
        }
        return $result;
    }

    function getAutoCountNoDRPByUser($web_user_id, $id_property) {
        $result = DB::table('accounting_recurring_transactions')->where('property_id', $id_property)->where('trans_web_user_id', $web_user_id)->where('trans_status', 1)->where('dynamic', 0)->count();
        if (empty($result)) {
            return 0;
        }
        return $result;
    }

    function getDRPByUser($web_user_id, $id_property) {
        $result = DB::table('accounting_recurring_transactions')->where('property_id', $id_property)->where('trans_web_user_id', $web_user_id)->where('trans_status', 1)->where('dynamic', 1)->count();
        if (empty($result)) {
            return 0;
        }
        return $result;
    }

    function validApiUsr($usr, $password) {
        $result = DB::table('api_user')->whereRaw("apiusername='" . $usr . "' AND `apipasswd`=SHA1('" . $password . "') AND ustatus=1")->select('idapi')->first();
        if (empty($result['idapi'])) {
            return 0;
        }
        return $result;
    }

    function validApiKey($key, $ipaddr) {
        if ($ipaddr == '255.255.255.255') {
            $result = DB::table('app_auth')->where('appid', $key)->where('status', 1)->select('id')->first();
        } else {
            $result = DB::table('app_auth')->where('ipaddr', $ipaddr)->where('appid', $key)->where('status', 1)->select('id')->first();
        }
        if (empty($result['id'])) {
            return 0;
        }
        return $result['id'];
    }

    function gethasUsrActivePromotion($web_user_id, $property_id, $type) {
        $value = DB::table('promo_done')->where('id_user', $web_user_id)->where('property_id', $property_id)->where('id_promo', $type)->select('id_pusr')->first();
        if (empty($value) || empty($value->id_pusr)) {
            return false;
        }
        return true;
    }

    function getPromotions($property_id) {
        $value = DB::table('promo_applied')->where('id_property', $property_id)->select('id_promo')->first();
        if (!empty($value->id_promo) && $value->id_promo != 0) {
            return $value->id_promo;
        }
        $obj_properties = new Properties();

        $ids = $obj_properties->getOnlyIds($property_id);
        $value = DB::table('promo_applied')->where('id_companies', $ids['id_companies'])->select('id_promo')->first();
        if (!empty($value->id_promo) && $value->id_promo != 0) {
            return $value->id_promo;
        }

        $value = DB::table('promo_applied')->where('id_partners', $ids['id_partners'])->select('id_promo')->first();
        if (!empty($value->id_promo) && $value->id_promo != 0) {
            return $value->id_promo;
        }

        return 0;
    }

    function getPromotionName($id_promo) {
        $value = DB::table('promotions')->where('id_p', $id_promo)->select('promo_name')->first();
        //var_dump($value);die;
        if(!empty($value))
        {
            return $value->promo_name;
        }else {
            return null;
        }

    }

    function getNextAvailablePromo($type) {
        $value = DB::table('promo_data')->where('id_promo', $type)->where('exp', 0)->select('data', 'id_pd')->first();
        if (empty($value->data)) {
            return "EMPTY";
        }

        if (!empty($value['id_pd'])) {
            DB::table('promo_data')->where('id_pd', '=', $value['id_pd'])->update(array('exp' => 1));
        }

        return $value->data;
    }

    function insertPromoDone($type, $web_user_id, $property_id, $trans_id, $code) {
        $pid = DB::table('promo_done')->insert(['id_promo' => $type, 'property_id' => $property_id, 'id_user' => $web_user_id, 'done_data' => $code, 'trans_id' => $trans_id]);
    }

    function getPromoApplied($trans_id) {
        $value = DB::table('promo_done')->where('trans_id', $trans_id)->select('done_data')->first();
        return $value->done_data;
    }

    function isValidVisaPromotion($trans_id, $id_property, $web_user_id) {
        if ($this->gethasUsrActivePromotion($web_user_id, $id_property, 1)) {
            return false;
        }
        $value = DB::table('accounting_recurring_transactions')->where('trans_web_user_id', $web_user_id)->where('trans_id', $trans_id)->where('trans_status', 1)->select('trans_numleft', 'trans_card_type')->first();
        if (empty($value->trans_numleft)) {
            return false;
        }
        if (strtolower(substr($value->trans_card_type, 0, 1)) != "v") {
            return false;
        }
        if ($value->trans_numleft > 2) {
            return true;
        }
        return false;
    }

    function isValidMCPromotion($trans_id, $id_property, $web_user_id) {
        if ($this->gethasUsrActivePromotion($web_user_id, $id_property, 1)) {
            return false;
        }
        $value = DB::table('accounting_recurring_transactions')->where('trans_web_user_id', $web_user_id)->where('trans_id', $trans_id)->where('trans_status', 1)->select('trans_numleft', 'trans_card_type')->first();
        if (empty($value['trans_numleft'])) {
            return false;
        }
        if (strtolower(substr($value['trans_card_type'], 0, 1)) != "m") {
            return false;
        }
        if ($value['trans_numleft'] > 2) {
            return true;
        }
        return false;
    }

    function setupAutoPayInv($idproperty, $web_user_id, $inv_id, $profile_id) {
        DB::table('invoice_automatic_payment')->insert(['property_id' => $idproperty, 'web_user_id' => $web_user_id, 'invoice_id' => $inv_id, 'profile_id' => $profile_id]);
    }

    function getAutoPayInv($idproperty, $web_user_id) {
        $value = DB::table('invoice_automatic_payment')->where('property_id', $idproperty)->where('web_user_id', $web_user_id)->select('invoice_auto_id')->first();
        if (!empty($value['invoice_auto_id'])) {
            return $value['invoice_auto_id'];
        }
        return 0;
    }

    function getPromoDoneInfo($trans_id, $web_user_id, $property_id) {
        $value = DB::table('promo_done')->where('trans_id', $trans_id)->where('id_user', $web_user_id)->where('property_id', $property_id)->first();
        return $value;
    }

    function updateUserBalance($id, $balance, $auto = true) {
        $this->where('web_user_id', '=', $id)->update(array('balance' => $balance, 'balance_start_date' => date('Y-m-d H:i:s')));
        if ($auto) {
            DB::table('accounting_recurring_transactions')->where('trans_web_user_id', '=', $id)->where('trans_status', '=', 1)->update(array('trans_recurring_net_amount' => $balance, 'trans_descr' => "Payment: " . $balance));
        }
    }

    function existsUsername($idproperty, $username, $uid) {
        $ext = $this->where('property_id', '=', $idproperty)->where('username', '=', $username)->where('web_status', '<', 1000)->where('web_user_id', '!=', $uid)->count();
        if ($ext > 0) {
            return true;
        }
        return false;
    }

    function getAdminInfo($user_id) {
        $result = DB::table('users')->where('id', $user_id)->select('login', 'first_name', 'last_name', 'email_address', 'phone', 'street', 'city', 'state', 'country', 'zip', 'active')->first();
        return $result;
    }

    function DeleteUser($web_user_id) {
        DB::table($this->table)->where('web_user_id', '=', $web_user_id)->update(array('web_status' => 9999));
        DB::table('web_users_linked')->where('web_user_id', '=', $web_user_id)->delete();
        DB::table('profiles')->where('web_user_id', '=', $web_user_id)->delete();
        DB::table('accounting_recurring_transactions')->where('trans_web_user_id', '=', $web_user_id)->update(array('trans_status' => 4));
        DB::table('social_web_users')->where('social_web_user_id', '=', $web_user_id)->delete();
        DB::table('settings_web_user')->where('user_id', '=', $web_user_id)->delete();
    }

    function DeleteUserByAccount($acc, $idproperty) {
        DB::table($this->table)->where('account_number', '=', $acc)->where('property_id', '=', $idproperty)->update(array('web_status' => 9999));
        DB::table('web_users_linked')->where('web_user_id', '=', $web_user_id)->delete();
        DB::table('profiles')->where('web_user_id', '=', $web_user_id)->delete();
        DB::table('accounting_recurring_transactions')->where('trans_web_user_id', '=', $web_user_id)->update(array('trans_status' => 4));
        DB::table('social_web_users')->where('social_web_user_id', '=', $web_user_id)->delete();
        DB::table('settings_web_user')->where('user_id', '=', $web_user_id)->delete();
    }

    function DeActivateByAccount($acc, $idproperty) {
        DB::table($this->table)->where('account_number', '=', $acc)->where('web_status', '=', 998)->where('property_id', '=', $idproperty)->update(array('web_status' => 999));
        DB::table($this->table)->where('account_number', '=', $acc)->where('web_status', '=', 1)->where('property_id', '=', $idproperty)->update(array('web_status' => 0));
        DB::table($this->table)->where('account_number', '=', $acc)->where('web_status', '=', 46)->where('property_id', '=', $idproperty)->update(array('web_status' => 0));
    }

    function existAccNum($account_number, $idproperty) {
        $user = DB::table('web_users')->where('account_number', $account_number)->where('property_id', $idproperty)->where('web_status', '<', 1000)->select('web_user_id')->first();
        if (empty($user->web_user_id)) {
            return false;
        }
        return true;
    }

    function findByAccEOptionList($xacc, $xaddress, $xfirstname, $xlastname, $idproperty) {
        if (empty($xacc) && empty($xaddress) && empty($xlastname) && empty($xfirstname)) {
            return null;
        }
        if ($idproperty <= 0) {
            return null;
        }
        $query = "(web_status < 1000) AND property_id=" . $idproperty;
        if (!empty($xacc)) {
            $query.=" and TRIM(account_number) like '$xacc'";
        }
        if (!empty($xlastname)) {
            $query.=" and (TRIM(last_name) like '%$xlastname%' OR TRIM(first_name) like '%$xlastname%')";
        }
        if (!empty($xfirstname)) {
//error_log('first_name'.$xfirstname,3,'/var/tmp/etermfund.log');
            $query.=" and (TRIM(first_name) like '%$xfirstname%' OR TRIM(last_name) like '%$xfirstname%')";
        }
        if (!empty($xaddress)) {
            $addr_spl = explode(" ", $xaddress);
            for ($i = 0; $i < count($addr_spl); $i++) {
                $query.=" and address like '%$addr_spl[$i]%'";
            }
        }
        $result = DB::table('web_users')->select('companyname', 'property_id', 'web_user_id', 'account_number', 'first_name', 'last_name', 'address', 'address_unit', 'city', 'state', 'zip', 'phone_number', 'email_address', 'web_status', 'balance', 'balance_start_date', 'balance_due')->whereRaw($query)->paginate(5);
        //    error_log('result'.print_r($result,true),3,'/var/tmp/etermfund.log');
        return $result;
    }

    function findUsr_wid($web_user_id, $idproperty) {
        if ($idproperty <= 0) {
            return null;
        }
        if (empty($web_user_id)) {
            return null;
        }
        $query = "(web_status=1 OR web_status = 998 OR web_status= 46) AND web_user_id=" . $web_user_id . " AND property_id=" . $idproperty;
        $result = DB::table('web_users')->whereRaw($query)->select('companyname', 'property_id', 'web_user_id', 'account_number', 'first_name', 'last_name', 'address', 'address_unit', 'city', 'state', 'zip', 'phone_number', 'email_address', 'web_status', 'balance', 'balance_start_date', 'balance_due')->paginate(5);
        return $result;
    }

    function customInfo($usr, $companyName = 0) {
        $str = "";
        $usr = (object) $usr;
        if ($companyName == 1) {
            if (!empty($usr->companyname)) {
                $str.="<div class='col-xs-4'><b>Company Name</b>: </div><div class='col-xs-8'>" . $usr->companyname;
                $str.= '</div>';
            }
        }
        if (!empty($usr->first_name . $usr->last_name)) {
            $str.="<div class='col-xs-4'><b>Name</b>: </div><div class='col-xs-8'>" . $usr->first_name . " " . $usr->last_name;
            $str.= '</div>';
        }
        if (!empty($usr->address . $usr->address_unit)) {
            $str.="<div class='col-xs-4'><b>Address</b>: </div><div class='col-xs-8'>" . $usr->address . " " . $usr->address_unit;
            $str.= '</div>';
        }
        if (!empty($usr->city . $usr->state . $usr->zip)) {
            $str.="<div class='col-xs-4'></div><div class='col-xs-8'>" . $usr->city . ' ' . $usr->state . ' ' . $usr->zip;
            $str.= '</div>';
        }
        if (!empty($usr->phone_number)) {
            $str.= "<div class='col-xs-4'><b>Phone</b>: </div><div class='col-xs-8'>" . $usr->phone_number;
            $str.= '</div>';
        }
        if (!empty($usr->email_address)) {
            $str.= "<div class='col-xs-4'><b>Email</b>: </div><div class='col-xs-8'>" . $usr->email_address;
            $str.= '</div><br>';
        }
        return $str;
    }

    function customSimpleInfo($usr, $companyName = 0) {
        $str = "";
        $usr = (object) $usr;
        if ($companyName == 1) {
            if (!empty($usr->companyname)) {
                $str.= $usr->companyname;
                $str.= '<br>';
            }
        }
        if (!empty($usr->first_name . $usr->last_name)) {
            $str.= $usr->first_name . " " . $usr->last_name;
            $str.= '<br>';
        }
        if (!empty($usr->address . $usr->address_unit)) {
            $str.= $usr->address . " " . $usr->address_unit;
            $str.= '<br>';
        }
        if (!empty($usr->city . $usr->state . $usr->zip)) {
            $str.= $usr->city . ' ' . $usr->state . ' ' . $usr->zip;
            $str.= '<br>';
        }
        if (!empty($usr->phone_number)) {
            $str.= 'Phone: ' . $usr->phone_number;
            $str.= '<br>';
        }
        if (!empty($usr->email_address)) {
            $str.= 'Email: ' . $usr->email_address;
            $str.= '<br>';
        }
        return $str;
    }

    function getPaymentProfiles_Credentials($web_user_id, $idproperty, $isrecurring) {

        $paymethods = DB::table('merchant_account')->where('property_id', $idproperty)->where('is_recurring', $isrecurring)->select('payment_method')->get();
        $methods = [];
        $count = count($paymethods);

        for ($i = 0; $i < $count; $i++) {
            $methods[] = $paymethods[$i]->payment_method;
            if ($paymethods[$i]->payment_method == 'amex' || $paymethods[$i]->payment_method == 'eterm-amex') {
                $methods[] = "am";
                $methods[] = "amex";
            }
            if ($paymethods[$i]->payment_method == 'eterm-cc' || $paymethods[$i]->payment_method == 'ivr-cc') {
                $methods[] = "cc";
            }
            if ($paymethods[$i]->payment_method == 'eterm-ec' || $paymethods[$i]->payment_method == 'eivr-ec') {
                $methods[] = "ec";
            }
        }

        $result = DB::table('profiles')->where('web_user_id', $web_user_id)->whereIn('type', $methods)->select('id', 'name', 'type', 'token')->orderBy('id', 'desc')->get();
        return $result;
    }

    function isInactiveUser($web_user_id) {
        $usr = DB::table('web_users')->where('web_user_id', $web_user_id)->whereIn('web_status', [1, 46, 998])->select('web_status')->first();
        if (empty($usr)) {
            return true;
        }
        return false;
    }

    function updateOneClickToken($idproperty, $web_user_id, $trans_id) {
        DB::table('oneclick_reminder')->where('trans_id', $trans_id)->where('id_properties', $idproperty)->where('web_user_id', $web_user_id)->update([
            'token' => ''
        ]);
    }

    function getProfileIDbyToken($idproperty, $web_user_id, $token) {
        $profiles = DB::table('profiles')
                ->where('id_property', '=', $idproperty)
                ->where('web_user_id', '=', $web_user_id)
                ->where('token', '=', $token)
                ->first();

        return $profiles;
    }

    function getProfileIDbyProperty($idproperty) {
        $profilesx = DB::table('profiles')
                ->where('id_property', '=', $idproperty)
                ->select('id', 'name', 'type', 'token')
                ->get();
        $profiles = array();
        foreach ($profilesx as $pf) {
            $tmp = array();
            $tmp['id'] = $pf['id'];
            $tmp['name'] = $pf['name'];
            $tmp['type'] = $pf['type'];
            if ($pf['type'] != 'ec') {
                $pmtoken = \Illuminate\Support\Facades\Crypt::decrypt($pf['token']);
                $js_token = json_decode($pmtoken, true);
                if ($pf['type'] == 'am') {
                    $tmp['card'] = 'AmericanExpress';
                } else {
                    if (isset($js_token['cc_type'])) {
                        $tmp['card'] = trim($js_token['cc_type']);
                    } else {
                        $tmp['card'] = 'Unknow';
                    }
                }
                if (isset($js_token['exp_date'])) {
                    $tmp['exp_date'] = $js_token['exp_date'];
                } else {
                    $tmp['exp_date'] = '';
                }
            }
            $profiles[] = $tmp;
        }
        return $profiles;
    }

    function getProfileIDbyWebUsrId($idproperty, $web_user_id) {
        $profilesx = DB::table('profiles')
                ->where('id_property', '=', $idproperty)
                ->where('web_user_id', '=', $web_user_id)
                ->select('id', 'name', 'type', 'token')
                ->get();
        $profiles = array();
        foreach ($profilesx as $pf) {
            $tmp = array();
            $tmp['id'] = $pf['id'];
            $tmp['name'] = $pf['name'];
            $tmp['type'] = $pf['type'];
            if ($pf['type'] != 'ec') {
                $pmtoken = \Illuminate\Support\Facades\Crypt::decrypt($pf['token']);
                $js_token = json_decode($pmtoken, true);
                if ($pf['type'] == 'am') {
                    $tmp['card'] = 'AmericanExpress';
                } else {
                    if (isset($js_token['cc_type'])) {
                        $tmp['card'] = trim($js_token['cc_type']);
                    } else {
                        $tmp['card'] = 'Unknow';
                    }
                }
                if (isset($js_token['exp_date'])) {
                    $tmp['exp_date'] = $js_token['exp_date'];
                } else {
                    $tmp['exp_date'] = '';
                }
            }
            $profiles[] = $tmp;
        }
        return $profiles;
    }

    function ExistProfile($id, $property_id) {
        $profile = DB::table('profiles')
                ->where('id_property', '=', $property_id)
                ->where('id', '=', $id)
                ->select('id')
                ->first();
        if (empty($profile)) {
            return false;
        } else {
            return true;
        }
    }

    function getTokenID3($id, $web_user_id, $property_id) {
        $profile = DB::table('profiles')
                ->where('id_property', '=', $property_id)
                ->where('id', '=', $id)
                ->where('web_user_id', '=', $web_user_id)
                ->select('id')
                ->first();
        return $profile;
    }

    function getWebUserId($account_number, $property_id) {
        $usr = $this->where('property_id', '=', $property_id)
                ->where('account_number', '=', $account_number)
                ->select('web_user_id')
                ->first();
        return $usr['web_user_id'];
    }

}
