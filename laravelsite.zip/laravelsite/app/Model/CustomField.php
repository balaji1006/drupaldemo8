<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class CustomField extends Model {

    protected $table = 'custom_fields';
    protected $primaryKey = 'id';

    public function getCustomFields($idlevel) {
        $query = DB::table($this->table)
                ->where('id_property', $idlevel)
                ->where('is_active',1)
                ->select('id', 'field_description', 'type', 'position', 'in_txreport', 'in_dpreport');
        return $query;
    }

    public function saveCustomField($data) {
        $query = DB::table($this->table)->insert([
            ['field_description' => $data['txtfd'],
                'type' => $data['ddlfieldtype'],
                'position' => $data['ddlposition'],
                'id_property' => $data['property_id'],
                'in_txreport' => $data['ddlvtr'],
                'in_dpreport' => $data['ddlvsr'],
            ]
        ]);
        return $query;
    }

    public function deleteCustomField($id) {
        DB::table($this->table)->where('id', '=', $id)->update(
            ["is_active" => 0]
        );
    }

    public function selectCustomField($id, $idlevel) {
        $query = DB::table($this->table)
                ->select('field_description', 'type', 'position', 'in_txreport', 'in_dpreport')
                ->where('id_property', $idlevel)
                ->where('id', $id)
                ->where('is_active',1)
                ->first();

        return $query;
    }

    public function updateCustomField($data) {
        DB::table($this->table)
                ->where('id', $data['txtid'])
                ->where('is_active',1)
                ->where('id_property', $data['property_id'])
                ->update(
                        ['field_description' => $data['txtfd'],
                            'type' => $data['ddlfieldtype'],
                            'position' => $data['ddlposition'],
                            'in_txreport' => $data['ddlvtr'],
                            'in_dpreport' => $data['ddlvsr'],
                        ]
        );
    }

    public function getTransactionField($idlevel) {
        $result = DB::table($this->table)
                ->where('id_property', $idlevel)
                ->where('is_active',1)
                ->where('in_txreport', '=', 1)
                ->select('field_description')
                ->get();
        return $result;
    }

    public function getCustomfieldDetails($idproperty) {
        $result = DB::table($this->table)
                        ->where('id_property', $idproperty)
                        ->where('is_active',1)
                        ->select('id', 'field_description', 'type', 'position')
                        ->get()->toArray();
        return $result;
    }

    public function addTransaction($transid, $customfield, $idproperty, $web_user_id) {
        for ($i = 0; $i < count($customfield); $i++) {
            DB::table('custom_fields_transaction')->insert([
                ['field_description' => $customfield[$i]['field_description'],
                    'field_value' => $customfield[$i]['field_value'],
                    'property_id' => $idproperty,
                    'trans_id' => $transid,
                    'custom_field_id' => $customfield[$i]['id'],
                    'web_user_id' => $web_user_id,
                ]
            ]);
        }
    }

}
