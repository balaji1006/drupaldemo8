<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class ImportBatchFile extends Model
{

    protected $table = 'import_batch_file';
    protected $softDelete = false;
    public $timestamps = false;
    
    function createBatchTask($data){
        $nid=DB::table($this->table)->insertGetId($data);
        return $nid;
    }
    
    function updateBatchTask($tid,$data){
        DB::table($this->table)->where('idimport_batch_file',$tid)->update($data);
    }
    
    function updateStatus($tid,$errcode){
        DB::table($this->table)->where('idimport_batch_file',$tid)->update(['status'=>$errcode]);
    }
    
    function getBatchInfo($tid){
        $result=DB::table($this->table)->where('idimport_batch_file',$tid)->first();
        return $result;
    }
    
    function getBackList($level,$idlevel){
        $result=DB::table($this->table)->where('level',$level)->where('idlevel',$idlevel);
        return $result;
    }
    
    function insertSummaryLine($idbatch,$line,$text){
        \Illuminate\Support\Facades\DB::table('importbatch_summary')->insert(['id_batch_file'=>$idbatch,'line'=>$line,'error'=>$text]);
    }
    
    function getBackSummaryList($id){
        $query= \Illuminate\Support\Facades\DB::table('importbatch_summary')->where('id_batch_file',$id);
        return $query;
    }
    
}