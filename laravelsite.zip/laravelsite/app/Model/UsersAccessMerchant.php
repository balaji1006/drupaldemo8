<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class UsersAccessMerchant extends Model
{

    protected $table = 'users_access_merchant';
    protected $primaryKey = null;
    public $timestamps = false;
    public $incrementing = false;

    public function user()
    {
        return $this->belongsTo('App\Model\UsersAdmin', 'users_admin_id');
    }

    public function merchant()
    {
         return $this->belongsTo('App\Model\Properties', 'property_id');
    }
}
