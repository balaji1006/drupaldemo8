<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class UsersAccessBranch extends Model
{

    protected $table = 'users_access_branch';
    protected $primaryKey = null;
    public $timestamps = false;
    public $incrementing = false;

    public function user()
    {
        return $this->belongsTo('App\Model\UsersAdmin', 'users_admin_id');
    }

    public function branch()
    {
        return $this->belongsTo('App\Model\Branch', 'branch_id');
    }
}
