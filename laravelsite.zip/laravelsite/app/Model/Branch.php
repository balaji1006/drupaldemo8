<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Branch extends Model
{

    protected $table = 'branch';
    public $timestamps = false;
    
    function getByFilter(){
        $query= DB::table($this->table);
        return $query;
    }
    
    function getNPartners($id){
        return DB::table('branch_partner')->where('branch_id',$id)->count();
    }
    
    function deleteBranch($id){
        DB::table('branch_partner')->where('branch_id',$id)->delete();
        DB::table('users_access_branch')->where('branch_id',$id)->delete();
        DB::table($this->table)->where('id',$id)->delete();
    }

    function getById($id){
        return DB::table($this->table)->where('id',$id)->first();
    }

    function getPartnersByBranchId($id){
        return DB::table('branch_partner')
            ->join('partners','partners.id','branch_partner.id_partners')
            ->where('branch_partner.branch_id',$id)->get();
    }
}
