<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Permissions extends Model
{

    protected $table = 'permissions_new';
    protected $primaryKey = 'permissions_id';
//    public $incrementing = false;
    public $timestamps = false;

    function getParent($id)
    {
        return $this->where(['permissions_id' => $id])->first();
    }

    function getPermissions($level){
        $level = strtoupper($level);
        $data = array();
        switch (strtoupper($level)){
            case "B":
                $data = DB::select('SELECT auxt.permissions_name as parent, ft.permissions_name, ft.permissions_id, ft.permissions_parent,ft.permissions_level 
                            FROM permissions_new as ft JOIN permissions_new as auxt On ft.permissions_parent = auxt.permissions_id 
                            WHERE ft.permissions_parent != 0 AND (ft.permissions_level LIKE "%B%" OR ft.permissions_level LIKE "%P%" OR ft.permissions_level LIKE "%G%" OR ft.permissions_level LIKE "%M%")');
                $result = array();
                foreach ($data as $item) {
                    $result[$item->parent][] = $item;
                }
                return $result;

            case "P":
                $data = DB::select('SELECT auxt.permissions_name as parent, ft.permissions_name, ft.permissions_id, ft.permissions_parent,ft.permissions_level 
                            FROM permissions_new as ft JOIN permissions_new as auxt On ft.permissions_parent = auxt.permissions_id 
                            WHERE ft.permissions_parent != 0 AND (ft.permissions_level LIKE "%P%" OR ft.permissions_level LIKE "%G%" OR ft.permissions_level LIKE "%M%")');
                $result = array();
                foreach ($data as $item) {
                    $result[$item->parent][] = $item;
                }
                return $result;

            case "G":
                $data = DB::select('SELECT auxt.permissions_name as parent, ft.permissions_name, ft.permissions_id, ft.permissions_parent,ft.permissions_level 
                            FROM permissions_new as ft JOIN permissions_new as auxt On ft.permissions_parent = auxt.permissions_id 
                            WHERE ft.permissions_parent != 0 AND (ft.permissions_level LIKE "%G%" OR ft.permissions_level LIKE "%M%")');
                $result = array();
                foreach ($data as $item) {
                    $result[$item->parent][] = $item;
                }
                return $result;

            case "M":
                $data = DB::select('SELECT auxt.permissions_name as parent, ft.permissions_name, ft.permissions_id, ft.permissions_parent,ft.permissions_level 
                            FROM permissions_new as ft JOIN permissions_new as auxt On ft.permissions_parent = auxt.permissions_id 
                            WHERE ft.permissions_parent != 0 AND ft.permissions_level LIKE "%M%"');
                $result = array();
                foreach ($data as $item) {
                    $result[$item->parent][] = $item;
                }
                return $result;

            case "A":
                $data = DB::select('SELECT auxt.permissions_name as parent, ft.permissions_name, ft.permissions_id, ft.permissions_parent,ft.permissions_level 
                            FROM permissions_new as ft JOIN permissions_new as auxt On ft.permissions_parent = auxt.permissions_id 
                            WHERE ft.permissions_parent != 0 AND (ft.permissions_level LIKE "%A%" OR ft.permissions_level LIKE "%B%" OR ft.permissions_level LIKE "%P%" OR ft.permissions_level LIKE "%G%" OR ft.permissions_level LIKE "%M%")');
                $result = array();
                foreach ($data as $item) {
                    $result[$item->parent][] = $item;
                }
                return $result;

        }

        return $data;
    }
}
