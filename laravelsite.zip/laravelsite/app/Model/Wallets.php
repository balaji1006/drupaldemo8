<?php

namespace App\Model;
use Illuminate\Database\Eloquent\Model;
use DB;

class Wallets extends Model {

    protected $table = 'merchant_wallet';

    function getWallets($idproperty){
        $result=DB::table($this->table)->where('property_id','=',$idproperty)->where('enabled',1)->get();
        return $result;
    }

    function removeAllWallets($idproperty){
        DB::table($this->table)->where('property_id','=',$idproperty)->delete();

    }

    function insertWallet($idproperty, $type,$data = null){
        DB::table($this->table)->insert(
            [
                'property_id' => $idproperty,
                'method' => 'cc',
                'type' => $type,
                'enabled' => 1,
                'data'=>$data
            ]
        );
    }

    function getMassterpassData($idproperty){
        $result=DB::table($this->table)
            ->where('property_id',$idproperty)
            ->where('type','mp')
            ->first();
        return $result;
    }

}