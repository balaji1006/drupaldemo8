<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Tickets extends Model
{

    protected $table = 'tickets';
    protected $softDelete = false;
    public $timestamps = false;
    
    function getTickets($idlevel,$level){
         switch (strtolower($level)) {
            case 'b':
                $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
                $partners=array();
                foreach($partnersA as $pa){
                    $partners[]=$pa->id_partners;
                }
                $result = DB::table('tickets')
                        ->join('partners', 'tickets.ticket_partner', '=', 'partners.id')
                        ->join('companies', 'tickets.ticket_company', '=', 'companies.id')
                        ->join('properties', 'tickets.ticket_property', '=', 'properties.id')
                        ->whereIn('properties.id_partners', $partners)
                        ->where('ticket_user_type',0)
                        ->select('ticket_id','tickets.ticket_date_submitted', 'partners.partner_title', 'properties.id', 'companies.company_name', 'properties.name_clients', 'ticket_name','ticket_email', 'ticket_phone', 'ticket_type', 'ticket_status', 'ticket_user_type', 'ticket_user_id');
                return $result;
                break;
            case 'a':
                $result = DB::table('tickets')
                        ->join('partners', 'tickets.ticket_partner', '=', 'partners.id')
                        ->join('companies', 'tickets.ticket_company', '=', 'companies.id')
                        ->join('properties', 'tickets.ticket_property', '=', 'properties.id')
                        ->where('ticket_user_type',0)
                        ->select('ticket_id','tickets.ticket_date_submitted', 'partners.partner_title', 'properties.id', 'companies.company_name', 'properties.name_clients', 'ticket_name','ticket_email', 'ticket_phone', 'ticket_type', 'ticket_status', 'ticket_user_type', 'ticket_user_id');
                return $result;
                break;
            case 'p':
                $result = DB::table('tickets')
                        ->join('companies', 'tickets.ticket_company', '=', 'companies.id')
                        ->join('properties', 'tickets.ticket_property', '=', 'properties.id')
                        ->where('companies.id_partners', $idlevel)
                        ->where('ticket_user_type',0)
                        ->select('ticket_id','tickets.ticket_date_submitted', 'companies.company_name', 'properties.id', 'properties.name_clients', 'ticket_name','ticket_email', 'ticket_phone', 'ticket_type', 'ticket_status', 'ticket_user_type', 'ticket_user_id');
                return $result;
                break;
            case 'g':
                $result = DB::table('tickets')
                        ->join('properties', 'tickets.ticket_property', '=', 'properties.id')
                        ->where('properties.id_companies', $idlevel)
                        ->where('ticket_user_type',0)
                        ->select('ticket_id','tickets.ticket_date_submitted', 'properties.name_clients', 'properties.id','ticket_email', 'ticket_name', 'ticket_phone', 'ticket_type', 'ticket_status', 'ticket_user_type', 'ticket_user_id');
                return $result;
                break;
            case 'm':
                $result = DB::table('tickets')
                        ->where('tickets.ticket_property', $idlevel)
                        ->where('ticket_user_type',0)
                       ->select('ticket_id','tickets.ticket_date_submitted', 'ticket_name','ticket_email', 'ticket_phone', 'ticket_type', 'ticket_status', 'ticket_user_type', 'ticket_user_id');
                return $result;
                break;

            default:
                return null;
        }
    }
    
    function closeTicket($id,$iduser,$notes=''){
        DB::table($this->table)->where('ticket_id',$id)->update(['ticket_status'=>1,'ticket_user_id_closed'=>$iduser,'ticket_close_note'=>$notes,'ticket_date_closed'=>date('Y-m-d H:i:s')]);
    }
    
    function getTicketByID($id){
        $ticket=DB::table($this->table)->where('ticket_id',$id)->first();
        return $ticket;
    }
}
