<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class MicroCredential extends Model
{

    protected $table = 'micro_credentials';

    function getDataFromProperty($idp){
        $mc = DB::table($this->table)->where('property_id',$idp)->first();
        return $mc;
    }

    function saveData($data_save){
        if(isset($data_save['property_id'])){
            $mc = DB::table($this->table)->where('property_id',$data_save['property_id'])->first();
            if($mc){
                //update
                DB::table($this->table)->where('property_id','=',$data_save['property_id'])->update($data_save);
            }
            else{
                //create
                DB::table($this->table)->insert($data_save);
            }
        }

    }
}