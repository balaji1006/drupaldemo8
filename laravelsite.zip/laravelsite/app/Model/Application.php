<?php

namespace App\Model;

use App\Model\Properties;
use Illuminate\Database\Eloquent\Model;
use DB;

class Application extends Model
{

    public function getApplications($type, $id)
    {
        $applications = null;
        switch ($type) {
            case 'B':
                $partnersA=DB::table('branch_partner')->where('branch_id',$id)->select('id_partners')->get();
                $partners=array();
                foreach($partnersA as $pa){
                    $partners[]=$pa->id_partners;
                }
                $applications = DB::table('application')
                        ->select('application.id', 'partners.partner_name', 'companies.subdomain_companies', 'application.content', 'companies.company_name','properties.name_clients', 'partners.partner_title', 'application.status', 'application.datenew', 'envelope')
                        ->leftjoin('partners', 'application.id_partner', '=', 'partners.id')
                        ->leftjoin('companies', 'application.id_company', '=', 'companies.id')
                        ->leftjoin('properties', 'application.id_property', '=', 'properties.id')
                        ->whereIn('application.id_partner', $partners);
                break;
            case 'P':
                $applications = DB::table('application')
                        ->select('application.id', 'partners.partner_name', 'companies.subdomain_companies', 'application.content', 'companies.company_name','properties.name_clients', 'partners.partner_title', 'application.status', 'application.datenew', 'envelope')
                        ->join('partners', 'application.id_partner', '=', 'partners.id')
                        ->leftjoin('companies', 'application.id_company', '=', 'companies.id')
                        ->leftjoin('properties', 'application.id_property', '=', 'properties.id')
                        ->whereIn('id_partner', $id)
                        ->whereIn('application.status', array(4, 2, 5));

                break;
            case 'G':
                $applications = DB::table('application')
                        ->select('application.id', 'partners.partner_name', 'companies.subdomain_companies', 'application.content', 'companies.company_name','properties.name_clients', 'partners.partner_title', 'application.status', 'application.datenew', 'envelope')
                        ->join('partners', 'application.id_partner', '=', 'partners.id')
                        ->join('companies', 'application.id_company', '=', 'companies.id')
                        ->leftjoin('properties', 'application.id_property', '=', 'properties.id')
                        ->where('id_company', $id)
                        ->whereIn('application.status', array(4, 2, 5));
                break;
            case 'A':
            default:
                $applications = DB::table('application')
                        ->select('application.id', 'partners.partner_name', 'companies.subdomain_companies', 'application.content', 'companies.company_name','properties.name_clients', 'partners.partner_title', 'application.status', 'application.datenew', 'envelope')
                        ->leftjoin('partners', 'application.id_partner', '=', 'partners.id')
                        ->leftjoin('companies', 'application.id_company', '=', 'companies.id')
                        ->leftjoin('properties', 'application.id_property', '=', 'properties.id');
                break;
        }
        return $applications;
    }

    public function getEXTOAPPsetting($partner, $company = 0)
    {

        $obj_pro = new Properties();
        $idpartner = $this->getIdPartner($partner);

        $idcompany = 0;
        if (!empty($company)) {
            $idcompany = $this->getIdCompany($company);
        }
        return $obj_pro->getPropertySettings(0, $idcompany, $idpartner, 'EXTOAPP');
    }

    public function getIdPartner($partner)
    {
        $partner_db = DB::table('partners')->where('partner_name', $partner)->first();
        if ($partner_db) {
            return $partner_db->id;
        } else {
            return 0;
        }
    }

    public function getAppAll($id)
    {
        $app_db = DB::table('application')
                        ->select(
                            'application.id',
                            'application.id_property',
                            'application.content',
                            'application.id_company',
                            'application.id_partner',
                            'external_app.token',
                            'partners.partner_title',
                            'partners.partner_name',
                            'companies.subdomain_companies',
                            'application.status'
                        )
                        ->leftjoin('partners', 'partners.id', '=', 'application.id_partner')
                        ->leftjoin('companies', 'companies.id', '=', 'application.id_company')
                        ->leftjoin('external_app', 'application.id', '=', 'external_app.idapp')
                        ->where('external_app.token', '!=', '')
                        ->where('application.id', $id)->first();
        if ($app_db) {
            return $app_db;
        } else {
            return null;
        }
    }

    public function getAppAllAux($id)
    {
        $app_db = DB::table('application')
                        ->select(
                            'application.id',
                            'application.content',
                            'application.id_property',
                            'application.id_company',
                            'application.id_partner',
                            'partners.partner_title',
                            'partners.partner_name',
                            'companies.subdomain_companies',
                            'companies.company_name',
                            'application.status'
                        )
                        ->leftjoin('partners', 'partners.id', '=', 'application.id_partner')
                        ->leftjoin('companies', 'companies.id', '=', 'application.id_company')
                        ->where('application.id', $id)->first();
        if ($app_db) {
            return $app_db;
        } else {
            return null;
        }
    }

    public function getExternalAppApplication($token)
    {
        $externalapp_db = DB::table('external_app')
                ->join('application', 'application.id', '=', 'external_app.idapp')
                ->where('token', $token)
                ->first();
        if ($externalapp_db) {
            return $externalapp_db;
        } else {
            return null;
        }
    }

    public function getPricingServices($partner, $company)
    {

        $company_db = DB::table('companies')->where('subdomain_companies', $company)->select('id')->first();
        $partner_db = DB::table('partners')->where('partner_name', $partner)->select('id')->first();

        $ps = null;

        if (!empty($company_db)) {
            $ps = DB::table('price_applied_to')
                            ->join('pricing', 'pricing.id_table', '=', 'price_applied_to.id_pricing')
                            ->join('bill_item', 'bill_item.id_bill', '=', 'pricing.service')
                            ->where('id_companies', $company_db->id)
                            ->get()->toArray();
        }

        if ($partner_db && !$ps) {
            $ps = DB::table('price_applied_to')
                            ->join('pricing', 'pricing.id_table', '=', 'price_applied_to.id_pricing')
                            ->join('bill_item', 'bill_item.id_bill', '=', 'pricing.service')
                            ->where('id_partners', $partner_db->id)
                            ->get()->toArray();
        }
        if (!$ps) {
            $ps = DB::table('price_applied_to')
                            ->join('pricing', 'pricing.id_table', '=', 'price_applied_to.id_pricing')
                            ->join('bill_item', 'bill_item.id_bill', '=', 'pricing.service')
                            ->where('id_companies', 0)
                            ->where('id_partners', 0)
                            ->get()->toArray();
        }

        return $ps;
    }

    public function getExternalApp($token)
    {
        $externalapp_db = DB::table('external_app')
                ->join('partners', 'partners.id', '=', 'external_app.id_partners')
                ->where('token', $token)
                ->first();
        if ($externalapp_db) {
            return $externalapp_db;
        } else {
            return null;
        }
    }

    public function getPartners($ids)
    {

        $partners = DB::table('partners');
        if (is_array($ids)) {
            $ids = implode('!', $ids);
        }
        $partners->whereIn('id', explode('!', $ids));
        return $partners->get();
    }

    public function getIdCompanies($company)
    {
        $company_db = DB::table('companies')->where('subdomain_companies', $company)->first();
        if ($company_db) {
            return $company_db->id_companies;
        } else {
            return 0;
        }
    }

    public function getIdCompany($company)
    {
        $company_db = DB::table('companies')->where('subdomain_companies', $company)->first();
        if ($company_db) {
            return $company_db->id;
        } else {
            return 0;
        }
    }

    public function getApp($id)
    {
        $app_db = DB::table('application')
                        ->select(['application.status', 'companies.subdomain_companies', 'partners.partner_name'])
                        ->leftJoin('external_app', 'application.id', '=', 'external_app.idapp')
                        ->leftJoin('partners', 'partners.id', '=', 'external_app.id_partners')
                        ->leftJoin('companies', 'companies.id', '=', 'external_app.id_companies')
                        ->where('application.id', $id)->first();

        if ($app_db) {
            return $app_db;
        } else {
            return null;
        }
    }

    public function getPricingByCode($code)
    {
        $ps = DB::table('pricing')
                ->join('bill_item', 'bill_item.id_bill', '=', 'pricing.service')
                ->join('price_table', 'price_table.idpt', '=', 'pricing.id_table')
                ->where('price_table.tlabel', $code)
                ->get();
        return $ps;
    }

    public function getIdPricing($id_partner, $id_company)
    {
        $pat = null;
        $pat = DB::table('price_applied_to')
                ->where('id_companies', $id_company)
                ->first();
        if (!$pat) {
            $pat = DB::table('price_applied_to')
                    ->where('id_partners', $id_partner)
                    ->first();
        }
        return $pat->id_pricing;
    }

    public function getCompany($id)
    {
        $company_db = DB::table('companies')
                ->where('id', $id)
                ->first();
        if ($company_db) {
            return $company_db;
        } else {
            return null;
        }
    }
}
