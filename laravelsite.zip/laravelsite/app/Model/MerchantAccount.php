<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class MerchantAccount extends Model
{

    protected $table = 'merchant_account';
    protected $primaryKey = 'merchant_account_id';
    public $timestamps = false;

    public function property()
    {
        return $this->belongsTo('App\Model\Properties', 'property_id');
    }

    public function getproprtyid($mid)
    {
        $var = $this->select('property_id')->where('merchant_account_id', $mid)->first();

        if ($var == null) {
            return null;
        }
        return $var->property_id;
    }

    function getByProperty($idproperty){
        $result=DB::table($this->table)
            ->where('property_id','=',$idproperty)
            ->orderBy('merchant_account_id','ASC')
            ->get();
        return $result;
    }
}
