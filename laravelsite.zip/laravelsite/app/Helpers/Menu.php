<?php

namespace App\Helpers;

use Illuminate\Support\Facades\Auth;
use App\Model\UsersPermissions;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;

class Menu
{

    function getUserMenu($level='', $token = null)
    {
        //@TODO At this point we should use just the token because it has the level and level_id
        if (!empty($token)) {
            $arrayToken = decrypt($token);
            $idLevel = $arrayToken['level_id'];
        }

        //$idlevel = $array_token['level_id'];var_dump($array_token);die;
        $user_menu = UsersPermissions::where(['users_admin_id' => Auth::id()])->get();
        $menu = [];
        foreach ($user_menu as $row) {
            $permission = $row->Permissions;
            if (!empty($permission)) {
                $applylevel = explode(',', $permission->permissions_level);
                if (in_array($level, $applylevel)) {
                    if ($permission->permissions_parent > 0) {
                        //Validate the TOPS submenu
                        if ($permission->permissions_route_name == 'topsconfig') {
                            if (isset($idLevel) && $idLevel > 0 && isset($level) && $level == 'M') {
                                $obj_prop = new \App\Model\Properties();
                                $idPartner = $obj_prop->get1PropertyInfo($idLevel, 'id_partners');
                                $idCompany = $obj_prop->get1PropertyInfo($idLevel, 'id_companies');
                                $obj_customize = new \App\Model\Customize();
                                //Gets the TOPSTAB setting value by partner or company as heritage
                                $setting = $obj_customize->getSettingValueProperty($idPartner, $idCompany, $idLevel, 'TOPSTAB');
                                //if TOPS setting is active it adds the submenu 'TOPS Integration'
                                if (isset($setting) && $setting == 1) {
                                    $parent = $permission->getParent($permission->permissions_parent);
                                    $menu[$parent->permissions_name][] = [
                                        'route_name' => $permission->permissions_route_name,
                                        'name' => $permission->permissions_name
                                    ];
                                }
                            }
                        } else {
                            $parent = $permission->getParent($permission->permissions_parent);
                            $menu[$parent->permissions_name][] = [
                                'route_name' => $permission->permissions_route_name,
                                'name' => $permission->permissions_name
                            ];
                        }
                    }
                }
            }
        }
        return $menu;
    }

    function getToken()
    {

    }
    
    function HasPermission($p){
        $ct= DB::table('users_permissions')->join('permissions_new','users_permissions.permissions_id','permissions_new.permissions_id')->where('users_admin_id',Auth::id())->where('permissions_new.permissions_route_name',$p)->count();
        if($ct>0)return true;
        return false;
    }
    
    static function createToken($idlevel,$level)
    {
        return encrypt(['level_id' => $idlevel, 'level' => $level, 'time'=>time()]);
    }
}
