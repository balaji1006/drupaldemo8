<?php

use Illuminate\Contracts\Encryption\DecryptException;
use App\Model;

function validateToken($token = null)
{
# Check Token
    if (empty($token)) {
        return false;
    } else {
# Token Validation
        try {
            decrypt($token);
            return true;
        } catch (DecryptException $e) {
            return false;
        }
    }
}

function getLogo($token)
{

    switch (strtolower($token['level'])) {
        case 'm':
            $property = Model\Properties::find($token['level_id']);
            if (!empty($property)) {
                if (is_file(base_path().'/public/'.'logos/merchants/'.$property->logo)) {
                    return asset('logos/merchants/'.$property->logo);
                }
                $token['level_id'] = $property->id_companies;
                $token['level'] = "g";
                return getLogo($token);
            }
            break;
        case 'g':

            $company = Model\Companies::find($token['level_id']);
            if (!empty($company)) {
                if (is_file(base_path().'/public/'.'logos/companies/'.$company->logo_group)) {
                    return asset('logos/companies/'.$company->logo_group);
                }
                $token['level_id'] = $company->id_partners;
                $token['level'] = "p";
                return getLogo($token);
            }
            break;
        case 'p':

            $partner = Model\Partners::find($token['level_id']);
            if (!empty($partner)) {
                if (is_file(base_path().'/public/'.'logos/partners/'.$partner->logo)) {
                    return asset('logos/partners/'.$partner->logo);
                }
                $token['level_id'] = $partner->branch_id;
                $token['level'] = "b";
                return getLogo($token);
            }
            break;
        case 'b':
            $branch = Model\Branch::find($token['level_id']);
            if (!empty($branch)) {
                if (is_file(base_path().'/public/'.'logos/branches/'.$branch->logo)) {
                    return asset('logos/branches/'.$branch->logo);
                }
                return asset('img/revo.svg');
            }
            break;
        default:
            return asset('img/revo.svg');
            break;
    }
    return asset('img/revo.svg');
}

function getLevelName($token = null)
{
    $token = decrypt($token);
    $data = ['level' => null, 'entity' => null];
    
    switch ($token['level']) {
        case 'B':
            $obj = Model\Branch::find($token['level_id']);
            $data['entity'] = $obj->name;
            $data['level'] = 'Branch';
            $data['tlevel'] = $token['level'];
            break;
        case 'P':
            $obj = Model\Partners::find($token['level_id']);
            $data['entity'] = $obj->partner_title;
            $data['level'] = 'Partner';
            $data['tlevel'] = $token['level'];
            break;
        case 'G':
            $obj = Model\Companies::find($token['level_id']);
            $data['entity'] = $obj->company_name;
            $data['level'] = 'Group';
            $data['tlevel'] = $token['level'];
            break;
        case 'M':
            $obj = Model\Properties::find($token['level_id']);
            $data['entity'] = $obj->name_clients;
            $data['level'] = 'Merchant';
            $data['tlevel'] = $token['level'];
            break;
        case 'A':
            $data['entity'] = 'Master';
            $data['level'] = 'Master';
            $data['tlevel'] = $token['level'];
            break;
    }
    return $data;
}

