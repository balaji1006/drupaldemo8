<?php

namespace App\Helpers;

class Layout {

    function getLayout($token) {
        $array_values = array();
        if (!empty($token)) {
            $arrayToken = decrypt($token);
            $idLevel = $arrayToken['level_id'];
            $level = $arrayToken['level'];

            $layout = new \App\Model\Layout();
            $data_layout = $layout->getLayoutValues($idLevel, $level);

            foreach ($data_layout as $d) {
                $array_values[$d->label] = $d->text;
            }
        }
        return $array_values;
    }

}
