<?php
namespace App\Helpers;
//use App\Model;

class Reports {

     static function AutopaymentDetails($txnId){
        $obj = new \App\Http\Models\Autopayments();
        $details = $obj->getDetails($txnId);
        return view('reports.autopayments.details',['details'=>$details]);
        
    }
     static function AutopaymentEditForm($txnId,$token){
        $obj = new \App\Http\Models\Autopayments();
        $details = $obj->getDetails($txnId);        
        return view('reports.autopayments.recurringtransactionedit',['details'=>$details,'token'=>$token]);        
    }

    static function AutopaymentStartTomorrow($txnId,$token){
        $obj = new \App\Http\Models\Autopayments();
        $details = $obj->getDetails($txnId);
        return view('reports.autopayments.restartomorrow',['details'=>$details,'token'=>$token]);

    }

    static function AutopaymentStartNextMonth($txnId,$token){
        $obj = new \App\Http\Models\Autopayments();
        $details = $obj->getDetails($txnId);
        return view('reports.autopayments.restarnextmonth',['details'=>$details,'token'=>$token]);

    }
    
    static function getExportFormats(){
        $formatlist=[
            [
                'name'=>'Excel',
                'idx'=>0,
                'separator'=>'none',
                'separatorOpt'=>false,
                'fix'=>false,
                'template'=>false,
                'fields'=>-1
                ],
            [
                'name'=>'CSV',
                'idx'=>1,
                'separator'=>'comma',
                'separatorOpt'=>true,
                'template'=>false,
                'fix'=>false,
                'fields'=>-1
                ],
            [
                'name'=>'Text',
                'idx'=>2,
                'separator'=>'space',
                'separatorOpt'=>true,
                'fix'=>false,
                'template'=>false,
                'fields'=>-1
                ],
            [
                'name'=>'Jenark',
                'idx'=>3,
                'separator'=>'space',
                'separatorOpt'=>false,
                'fix'=>true,
                'template'=>true,
                'templateformat'=>[
                   [ 
                    ["name"=>"field","value"=>"trans_account_number"],
                    ["name"=>"fixsize","value"=>"8"],
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_first_post_date"],
                    ["name"=>"fixsize","value"=>"8"],
                    ["name"=>"fixformat","value"=>"mmddyyyy"],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_net_amount"],
                    ["name"=>"fixsize","value"=>"10"],
                    ["name"=>"fixcharacter","value"=>"0"],   
                    ["name"=>"fixformat","value"=>"nnnncc"],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_id"],
                    ["name"=>"fixsize","value"=>"-8"]   
                   ]    
                ],
                'fields'=>4
                ],
            [
                'name'=>'TOPS',
                'idx'=>4,
                'separator'=>'none',
                'separatorOpt'=>false,
                'template'=>true,
                'templateformat'=>[
                   [ 
                    ["name"=>"field","value"=>"properties.compositeID_clients"],
                    ["name"=>"fixsize","value"=>"13"],
                    ["name"=>"fixcharacter","value"=>"+"],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_account_number"],
                    ["name"=>"fixsize","value"=>"14"],
                    ["name"=>"fixcharacter","value"=>"0"],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_first_post_date"],
                    ["name"=>"fixsize","value"=>"6"],
                    ["name"=>"fixformat","value"=>"yymmdd"],   
                   ], 
                   [ 
                    ["name"=>"field","value"=>"trans_id"],
                    ["name"=>"fixsize","value"=>"-10"]   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_net_amount"],
                    ["name"=>"fixsize","value"=>"8"],
                    ["name"=>"fixcharacter","value"=>"0"],   
                    ["name"=>"fixformat","value"=>"nnnncc"],   
                   ],    
                ],
                'fix'=>true,
                'fields'=>5
                ],
            [
                'name'=>'TOPS (Lockbox)',
                'idx'=>5,
                'separator'=>'none',
                'separatorOpt'=>false,
                'template'=>true,
                'templateformat'=>[
                   [ 
                    ["name"=>"field","value"=>"properties.compositeID_clients"],
                    ["name"=>"fixsize","value"=>"13"],
                    ["name"=>"fixcharacter","value"=>" "],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_account_number"],
                    ["name"=>"fixsize","value"=>"13"],
                    ["name"=>"fixcharacter","value"=>"0"],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_first_post_date"],
                    ["name"=>"fixsize","value"=>"6"],
                    ["name"=>"fixformat","value"=>"yymmdd"],   
                   ], 
                   [ 
                    ["name"=>"field","value"=>"trans_id"],
                    ["name"=>"fixsize","value"=>"-10"]   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_net_amount"],
                    ["name"=>"fixsize","value"=>"8"],
                    ["name"=>"fixcharacter","value"=>"0"],   
                    ["name"=>"fixformat","value"=>"nnnncc"],   
                   ],    
                ],
                'fix'=>true,
                'fields'=>5
                ],
            [
                'name'=>'CM LockBox',
                'idx'=>6,
                'separator'=>'none',
                'separatorOpt'=>false,
                'template'=>true,
                'templateformat'=>[
                   [ 
                    ["name"=>"field","value"=>""],
                    ["name"=>"fixsize","value"=>"6"],
                    ["name"=>"fixcharacter","value"=>"0"],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_account_number"],
                    ["name"=>"fixsize","value"=>"10"],
                    ["name"=>"fixcharacter","value"=>" "],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_net_amount"],
                    ["name"=>"fixsize","value"=>"20"],
                    ["name"=>"fixcharacter","value"=>" "],   
                    ["name"=>"fixformat","value"=>"nnnn.cc"],   
                   ], 
                   [ 
                    ["name"=>"field","value"=>"trans_user_name"],
                    ["name"=>"fixsize","value"=>"75"],
                    ["name"=>"fixcharacter","value"=>" "],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_id"],
                    ["name"=>"fixsize","value"=>"25"],   
                    ["name"=>"fixcharacter","value"=>" "],   
                   ],    
                   [ 
                    ["name"=>"field","value"=>"trans_first_post_date"],
                    ["name"=>"fixsize","value"=>"8"],
                    ["name"=>"fixformat","value"=>"mmddyyyy"],   
                   ], 
                ],
                'fix'=>true,
                'fields'=>5
                ],
            [
                'name'=>'IIF QuickBooks',
                'idx'=>7,
                'separator'=>'none',
                'separatorOpt'=>false,
                'fix'=>false,
                'fields'=>0
                ]
    ];
    return $formatlist;    
    }
}

