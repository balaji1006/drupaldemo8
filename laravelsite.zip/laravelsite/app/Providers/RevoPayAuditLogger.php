<?php

namespace App\Providers;

use Illuminate\Auth\GenericUser;
use Illuminate\Support\ServiceProvider;
use DB;

class RevoPayAuditLogger extends ServiceProvider
{

    /*
    Example:

    <?php

    // require the service provider
    use Illuminate\Support\ServiceProvider\RevoPayAuditLogger;

    // log an audit event
    RevoPayAuditLogger::userProfileCreate(
        "user",              // one of: "system", "user", "admin"
        "the data to save",  // the data to save (string)
        $user,               // the user whose data was changed
        $admin,              // the user that changed $user's data
    );

    ?>
    */

    /**
     * Writes to the audit log
     *
     * @param object $params  Log data
     */
    private static function log($event, $type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        // assert that $type is valid
        $type = strtolower($type);
        if (! in_array($type, [ "system", "user", "admin" ])) {
            throw new \InvalidArgumentException("\$type must be one of: 'system', 'user', 'admin'");
        }

        // serialize objects into JSON strings
        if (is_array($data)) {
            $data = json_encode($data);
        }
        // insert the record into the database
        DB::table('audit')->insert([
            "event"       => $event,
            "type"        => $type,
            "data"        => $data,
            "level"       => $level,
            "idlevel"     => $idlevel,  
            "user"        => $user->id,
            "name"        => $user->name,
            "modified_by" => $modifiedBy->id,
            "modified_by_name"=>$modifiedBy->name
        ]);
    }

    /**
     * Logs a "user_profile_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function userProfileCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('user_profile_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs a "user_profile_update" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function userProfileUpdate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('user_profile_update', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs a "user_profile_delete" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function userProfileDelete($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('user_profile_delete', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs a "password_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function passwordCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('password_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs a "password_update" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function passwordUpdate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('password_update', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs a "payment_method_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function paymentMethodCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('payment_method_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs a "payment_method_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function paymentMethodDelete($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('payment_method_delete', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs a "payment_success" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function paymentSuccess($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('payment_success', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs a "payment_failure" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function paymentFailure($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('payment_failure', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "autopayment_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function autopaymentCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('autopayment_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "autopayment_update" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function autopaymentUpdate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('autopayment_update', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "autopayment_delete" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function autopaymentDelete($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('autopayment_delete', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    //added by LNorat 04/04/18
    /**
     * Logs an "entity_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function createEntity($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('entity_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "edit_entity" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function editEntity($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('entity_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "entity_delete" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function deleteEntity($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('entity_delete', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "export_report" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function exportReport($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('export_report', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "application_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function applicationCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('application_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "application_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function applicationEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('application_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "application_delete" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function applicationDelete($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('application_delete', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "bill_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function billCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('bill_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "bill_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function billEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('bill_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "admin_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function adminCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('admin_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "admin_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function adminEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('admin_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "admin_delete" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function adminDelete($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('admin_delete', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "admin_login" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function adminLogin($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('admin_login', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "admin_logout" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function adminLogout($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('admin_logout', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "entity_open" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function entityOpen($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('entity_open', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "setting_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function settingEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('setting_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "vendor_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function vendorCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('vendor_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "vendor_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function vendorEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('vendor_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "vendor_delete" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function vendorDelete($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('vendor_delete', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "category_create" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function categoryCreate($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('category_create', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "category_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function categoryEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('category_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "category_delete" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function categoryDelete($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('category_delete', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
    /**
     * Logs an "credential_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function credentialEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('credential_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "wallet_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function walletEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('wallet_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }

    /**
     * Logs an "fraud_edit" event
     *
     * @param string $type  Event type
     * @param object $user  Logged-in user object
     */
    public static function fraudEdit($type, $data, $level, $idlevel, $user, $modifiedBy)
    {
        self::log('fraud_edit', $type, $data, $level, $idlevel, $user, $modifiedBy);
    }
    
}
