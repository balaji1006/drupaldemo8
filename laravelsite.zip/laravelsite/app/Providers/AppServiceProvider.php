<?php

namespace App\Providers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
class AppServiceProvider extends ServiceProvider
{

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Validator::extend('routingnumber', function ($attribute, $value, $parameters, $validator) {
            if (!is_numeric($value) || strlen($value) != 9) {
                return false;
            }

            $len = strlen($value);
            $first_two = substr($value, 0, 2);

            if (!(($first_two >= 01 && $first_two <= 15) ||
                    ($first_two >= 21 && $first_two <= 32) ||
                    ($first_two >= 61 && $first_two <= 72))
            ) {
                return false;
            }

            for ($j = 0; $j < $len; $j++) {
                $temp = + substr($value, $j, 1);

                if ($temp < 0 || $temp > 9) {
                    return false;
                }
            }

            $iTotal = 0;
            for ($i = 0; $i < $len; $i += 3) {
                $iTotal += substr($value, $i, 1) * 3 + substr($value, $i + 1, 1) * 7 + substr($value, $i + 2, 1);
            }

            if ($iTotal != 0 && $iTotal % 10 == 0) {
                return true;
            } else {
                return false;
            }
        });
//         DB::listen(function ($query) {
//             Log::error($query->sql,$query->bindings);
//        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        require_once app_path() . '/Helpers/Token.php';
    }
}
