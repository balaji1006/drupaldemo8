<?php
namespace App\CustomClass;

class RevoAPI {
    
    function sendPayment($data,$idproperty){
        $token=$this->getTokenMerchant($idproperty);
        $route='/api2/open/makepayment';
        $response=$this->postAPI($route, $data, $token);
        return $response;
    }
    
    private function getTokenMerchant($idproperty) {
        $adata = array('id' => $idproperty, 'pwd' => '*');
        $newtoken = \Illuminate\Support\Facades\Crypt::encrypt(json_encode($adata) . '|' . time() . '|' . config('app.appAPIkey'));
        return $newtoken;
    }
    
    private function postAPI($route,$data,$token,$url=''){
        if($url=='')$url=env('api_url');
        $ch = curl_init();
        $params=array('token'=>$token,'request'=>json_encode($data));
        curl_setopt($ch, CURLOPT_URL, $url.$route);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $result=array();
        try {
            $result = curl_exec($ch);
            curl_close($ch);
        }
        catch(\Exception $e){
            $this->anyerror=$e->getMessage();
        }
        finally {
            return json_decode($result,true);
        }
    }
}