<?php
namespace App\CustomClass;

use App\CustomClass\TOPSconnection;
use App\Models\Properties;
use App\Models\Companies;
use App\Models\TopsData;
use App\Models\Vendors;
use App\User;

class TOPSintegration {
    
    function ImportfromTOPS($ckey,$groupid,$newp=true,$uvendor=true,$updu=true,$apps=false){
        if(empty($ckey))return false;
        if($groupid==0)return false;
        $tops=new TOPSconnection($ckey);
        //get community data
        $tmp=$tops->getCommunityList();
        if(count($tmp)>0){
            $community=$tmp[0];
            $prop=new Properties();
            $cmp=new Companies();
            $topdata=new TopsData();
            $idp=$prop->getIdByCompanyComposite($groupid, $community['CommunityID']);
            if(empty($idp)){
                if(!$newp)return false;
                //create the property
                $data=array();
                $data['name_clients']=trim($community['Name']);
                $data['compositeID_clients']=trim($community['CommunityID']);
                $data['address_clients']=trim($community['Address1'].' '.$community['Address2']);
                $data['city_clients']=trim($community['City']);
                if(empty($data['city_clients']))$data['city_clients']=$community['DefaultCity'];
                $data['state_clients']=trim($community['State']);
                if(empty($data['state_clients']))$data['state_clients']=$community['DefaultState'];
                $data['zip_clients']=trim($community['Zip']);
                if(empty($data['zip_clients']))$data['zip_clients']=$community['DefaultZip'];
                $general=$tops->getGeneralInfo();
                $data['units']=$general['MaxNumOfHomes'];
                $data['email_address_clients']=$general['PropertyManagerEmail'];
                $data['accounting_email_address_clients']=$data['email_address_clients'];
                $data['contact_name_clients']=$general['PropertyManagerName'];
                $data['phone_clients']=trim($community['Phone1']);
		$ccid=$community['CommunityKey'];
                
                $idpartner=$cmp->get1CompanyInfo($groupid, 'id_partners');
                $subdomain=str_replace(' ','',  strtolower($data['name_clients']));
                $data['id_partners']=$idpartner;
                $data['id_companies']=$groupid;
                $data['status_clients']=1;
                $idp=$prop->createProperty($data);
                $tdata=array();
                $tdata['id_property']=$idp;
                $tdata['id_company']=$groupid;
                $tdata['id_partner']=$idpartner;
                $tdata['ckey']=$ckey;
                $tdata['community_id']=$ccid;
                $topdata->createTOPS($tdata);
            }
            else {
                //verify in tops integration
                $idtops=$topdata->getIDfromMerchant($idp);
                if($idtops>0){
                    //update ckey
                    $tdata=array();
                    $tdata['ckey']=$ckey;
                    $tdata['community_id']=$community['CommunityKey'];
                    $topdata->updateTOPS($idtops, $tdata);
                }
                else {
                    $ccid=$community['CommunityKey'];
                    $idpartner=$cmp->get1CompanyInfo($groupid, 'id_partners');
                    $tdata=array();
                    $tdata['id_property']=$idp;
                    $tdata['id_company']=$groupid;
                    $tdata['id_partner']=$idpartner;
                    $tdata['ckey']=$ckey;
                    $tdata['community_id']=$ccid;
                    $idtops=$topdata->createTOPS($tdata);
                }
            }
            //pull the units(properties)
            $this->SyncTOPS2Property($idp, false);
            if($uvendor)$this->SyncTOPSVendors($idp);
            return true;
        }
        else return false;
    }

    function getCapabilitiesListFromKey($ckey){
        if(empty($ckey))return false;
        $tops=new TOPSconnection($ckey);
        $caps=$tops->getCapability();
        return $caps;
    }
    
    function SyncTOPS2Property($id_property,$upd_prop=true,$upd_task=false,$idtask=0,  \App\Models\CronBack $cron=null){
        //TODO what happen with records not existing in TOPS?
        //TODO how update users and units changing owners?
        
        if($id_property==0)return false;
        //get the ckey
        $topsdata=new TopsData();
        $prop=new Properties();
        $usr=new User();
        $idtops=$topsdata->getIDfromMerchant($id_property);
        $ckey=$topsdata->get1Info($idtops, 'ckey');
        $cid=$topsdata->get1Info($idtops, 'community_id');
        if(empty($ckey))return false;
        $admin=json_decode($topsdata->get1Info($idtops, 'admin_options'),true);
        $tops=new TOPSconnection($ckey);
        //get community data
        $tmp=$tops->getCommunityList();
        $idp=$id_property;
        if(isset($admin['ccode']) && $admin['ccode']!=''){
            //sync glcodes
            $vlopt=json_decode($topsdata->get1Info($idtops, 'glcode_options'),true);
            if(!empty($vlopt)){
                $obj_cat=new \App\Models\Categories(); 
                foreach($vlopt as $key=>$value){
                    $vgl=$tops->getChargeCodeByKey($value);
                    if(!empty($vgl)){
                        $ccode=$vgl['ChargeCodeKey'];
                        $ccname=trim($vgl['Description']);
                        $cgl=$vgl['Code'];
                        $cat=$obj_cat->getCatByName($ccname,$id_property);
                        if(!empty($cat)){
                            $idcat=$cat['payment_type_id'];
                            $datcat=array();
                            $datcat['payment_type_name']=$ccname;
                            $datcat['payment_type_code']=$cgl;
                            $datcat['payment_type_code_id']=$ccode;
                            $obj_cat->UpdateCat($idcat, $datcat);
                        }
                        else {
                            $datcat=array();
                            $datcat['payment_type_name']=$ccname;
                            $datcat['payment_type_code']=$cgl;
                            $datcat['payment_type_code_id']=$ccode;
                            $datcat['property_id']=$id_property;
                            $obj_cat->InsertCat($datcat);
                        }
                    }
                }
            }
        }
        if(count($tmp)>0 && isset($tmp[$cid-1])){
            $upd_prop=false;
            if($upd_prop){
                $community=$tmp[$cid-1];
                //update the property
                $prop->set1PropertyInfo($idp,'name_clients',trim($community['Name']));
                $prop->set1PropertyInfo($idp,'compositeID_clients', trim($community['CommunityID']));
                $prop->set1PropertyInfo($idp,'address_clients',trim($community['Address1'].' '.$community['Address2']));
                $city=trim($community['City']);
                if(empty($city))$city=$community['DefaultCity'];
                $prop->set1PropertyInfo($idp,'city_clients',$city);
                $state=trim($community['State']);
                if(empty($state))$state=$community['DefaultState'];
                $prop->set1PropertyInfo($idp,'state_clients',$state);
                $zip=trim($community['Zip']);
                if(empty($zip))$zip=$community['DefaultZip'];
                $prop->set1PropertyInfo($idp,'zip_clients',$zip);
                $general=$tops->getGeneralInfo();
                $units=$general['MaxNumberOfHomes'];
                $prop->set1PropertyInfo($idp,'units',$units);
                $email=$general['PropertyManagerEmail'];
                $prop->set1PropertyInfo($idp,'email_address_clients',$email);
                $prop->set1PropertyInfo($idp,'accounting_email_address_clients',$email);
                $cname=$general['PropertyManagerName'];
                $prop->set1PropertyInfo($idp,'contact_name_clients',$cname);
                $cphone=trim($community['Phone1']);
                $prop->set1PropertyInfo($idp,'phone_clients',$cphone);
            }
            //pull the units(properties)
            $tmp=$tops->getPropertyList();
            if(count($tmp)>0){
                $ct=count($tmp);
                if($upd_task && $idtask>0){
                    if(!empty($cron)){
                        $cron->set1CronInfo($idtask, 'total', $ct);
                    }
                }
                $cf=0;
                foreach($tmp as $punit){
                    $acc=trim($punit['AccountNumber']);
                    $uaddr=$punit['Street'];
                    $uunit=$punit['AddressNumber'];
                    $ucity=$punit['City'];
                    $ustate=$punit['State'];
                    $uzip=$punit['Zip'];
                    $users=$usr->findAccount($acc, $id_property);
                    if(!isset($users['web_user_id'])){
                        //insert user
                        $udata=array();
                        if(!empty($acc)){
                            $udata['account_number']=$acc;
                        }
                        $udata['property_id']=$id_property;
                        if(!empty($uaddr)){
                            $udata['address']=$uaddr;
                        }
                        if(!empty($uunit)){
                            $udata['address_unit']=$uunit;
                        }
                        if(!empty($ucity)){
                            $udata['city']=$ucity;
                        }
                        if(!empty($ustate)){
                            $udata['state']=$ustate;
                        }
                        if(!empty($uzip)){
                            $udata['zip']=$uzip;
                        }
                        $udata['web_status']=998;
                        $uid=$usr->CreateUser($udata);
                    }
                    else {
                        //update
                        $uid=$users['web_user_id'];
                        if(!empty($uaddr))$usr->set1UserInfo($uid, 'address', $uaddr);
                        if(!empty($uunit))$usr->set1UserInfo($uid, 'address_unit', $uunit);
                        if(!empty($ucity))$usr->set1UserInfo($uid, 'city', $ucity);
                        if(!empty($ustate))$usr->set1UserInfo($uid, 'state', $ustate);
                        if(!empty($uzip))$usr->set1UserInfo($uid, 'zip', $uzip);
                    }
                    //get name for user
                    $prop_key=$punit['PropertyKey'];
                    $cmt_key=$punit['CommunityKey'];
                    $uemail='';
                    $udatas=$tops->getOwnerDataByProperty($prop_key, $cmt_key);
                    $usdata=array("punit"=>$punit,"udata"=>array(''));
                    foreach($udatas as $udata){
                        if(empty($udata))continue;
                        if(isset($udata['ResidentType']) && strtolower($udata['ResidentType'])=='owner'){
                        if(isset($udata['OwnerKey'])){
                            $balance=0;
                            if(isset($admin['balance'])&&$admin['balance']=='on'){
                                $ubalance=$tops->getOwnerBalanceByKey($udata['OwnerKey']);
                                if(isset($ubalance['BalanceTotal']))
                                {
                                $balance=$ubalance['BalanceTotal'];
                                }
                                if(empty($balance))$balance=0.00;
                            }
                            $utm=$tops->getOwnerEmail($udata['OwnerKey']);
                            if(is_array($utm) && count($utm)>0){
                                if(isset($utm[0]['EmailValue'])){
                                    $uemail=$utm[0]['EmailValue'];
                                }
                            }
                            if(isset($udata['Metadata']['HoldPayment'])){
                                if($udata['Metadata']['HoldPayment']){
                                    $usr->set1UserInfo($uid, 'web_status', 0);
                                }else{
                                $usrstatus = $usr->get1UserInfo($uid,'web_status');
                                if($usrstatus == 0)
                                {
                                    $usr->set1UserInfo($uid, 'web_status', 998);
                                }  
                                }
                            }else{
                                //change the user 998 only if the user has status inactive(0) and !isset(HoldPayment)
                                $usrstatus = $usr->get1UserInfo($uid,'web_status');
                                if($usrstatus == 0)
                                {
                                    $usr->set1UserInfo($uid, 'web_status', 998);
                                }                         
                                
                               }
                            
                        }
                        else $balance=0.00;
                        if(isset($udata['LegalName'])){
                            $uname=explode(' ',  $udata['LegalName']);
                            $lname=  array_pop($uname);
                            $fname=implode(' ',$uname);
                            $uphone=trim($udata['PhoneHome']);
                            $usr->set1UserInfo($uid, 'first_name', $fname);
                            $usr->set1UserInfo($uid, 'last_name', $lname);
                            $usr->set1UserInfo($uid, 'balance', $balance);
                            $usr->set1UserInfo($uid,'balance_start_date',date('Y-m-d H:i:s'));
                            $usr->set1UserInfo($uid, 'email_address', $uemail);
                            $usr->set1UserInfo($uid, 'phone_number', $uphone);
                        }
                        break;
                    }
                    }
                    $usr->set1UserInfo($uid, 'topsdata', json_encode($usdata));
                    $cf++;
                    if($upd_task && $idtask>0){
                        if(!empty($cron)){
                            $cron->set1CronInfo($idtask, 'var1', $cf);
                            $cp=ceil(($cf*100/$ct));
                            $cron->set1CronInfo($idtask, 'var2', $cp);
                        }
                    }
                }
                return true;
            }
        else return false;
        }
        else return false;
    
    }
    
    
    function pushPayment2TOPS($payment,$bankkey){
        //push a payment to TOPS
        //payment contain the transaction to push (accounting transactions or settlement report)
        if(empty($payment))return false;
        if(!isset($payment['property_id']))return false;
        $id_property=$payment['property_id'];
        if($id_property==0)return false;
        //get the ckey
        $topsdata=new TopsData();
        $idtops=$topsdata->getIDfromMerchant($id_property);
        $ckey=$topsdata->get1Info($idtops, 'ckey');
        if(empty($ckey))return false;
        $accpay=$topsdata->get1Info($idtops, 'pay_account_id');
        $accpaycc=$topsdata->get1Info($idtops, 'paycc_account_id');
        $cid=$topsdata->get1Info($idtops, 'community_id');
        $tops=new TOPSconnection($ckey);
        $amount=$payment['trans_net_amount'];
        if($payment['trans_type']==2)$amount=-1*$amount;
        $uid=$payment['trans_web_user_id'];
        $date=$payment['trans_first_post_date'];
        $check=$payment['trans_id'];
        $usr=new User();
        $owner=$usr->get1UserInfo($uid, 'topsdata');
        if(empty($owner))return false;
        $downer=  json_decode($owner,true);
        if(!isset($downer['udata']['OwnerKey']))return false;
        $ownerkey=$downer['udata']['OwnerKey'];
        $acckey=$accpay;
        if($payment['trans_payment_type']=='cc'){
            if($accpaycc>0)$acckey=$accpaycc;
        }
        if($acckey==0)return false;
        //$bankkey=$this->getBankforAcc($ckey,$acckey);
        if($bankkey==0)return false;
        $record=array();
        $record['CommunityKey']=$cid;
        $record['BankKey']=$bankkey;
        $record['ReceiptDate']=substr(date('c',strtotime($date)),0,19);
        $record['ReceiptItems'][0]=array('OwnerKey'=>$ownerkey,'ReceivedDate'=>substr(date('c',strtotime($date)),0,19),'CheckNumber'=>$check,'Amount'=>$amount);
        $rcode=$tops->postReceiptBatch($record);
        if($rcode==240)return true;
        return false;
    }
    
    private function getBankforAcc($ckey,$acckey,$banks){
        $bkey=0;
        foreach($banks as $bnk){
            if(!isset($bnk['AccountKey']))continue;
            if($bnk['AccountKey']==$acckey){
                $bkey=$bnk['BankKey'];
                return $bkey;
            }
        }
        return $bkey;
    }
    
    function getAccountsWithBank($ckey){
        $accounts=array();
        $tps=new TOPSconnection($ckey);
        $list=$tps->getAccountingList();
        $banks=$tps->getBankList();
        foreach($list as $alist){
            $akey=$alist['AccountKey'];
            $bk=$this->getBankforAcc($ckey, $akey,$banks);
            if($bk>0){
                $accounts[]=array('name'=>$alist['AccountName'],'key'=>$akey);
            }
        }
        return $accounts;
    }
    
    function getBanks($ckey){
        $banks=array();
        $tps=new TOPSconnection($ckey);
        $banks=$tps->getBankList();
        return $banks;
    }
    
    function SyncTOPSVendors($id_property,$upd_vendor=true){
        if($id_property==0)return false;
        //get the ckey
        $topsdata=new TopsData();
        $prop=new Properties();
        $usr=new Vendors();
        $idtops=$topsdata->getIDfromMerchant($id_property);
        $ckey=$topsdata->get1Info($idtops, 'ckey');
        if(empty($ckey))return false;
        $tops=new TOPSconnection($ckey);    
        $vlist=$tops->getVendorList();
        foreach($vlist as $vendor){
            $eid=$vendor['Number'];
            $addr=$vendor['Address1'].' '.$vendor['Address2'];
            $name=$vendor['Name'];
            $phone=$vendor['Phone'];
            $contact=$vendor['Contact'];
            $notes=$vendor['FederalTaxID'];
            $uemail='';
            $utm=$tops->getOwnerEmail($vendor['VendorKey'],'Vendor');
            if(count($utm)>0){
                $uemail=$utm[0]['EmailValue'];
            }
            $data=array();
            $data['name']=$name;
            $data['address']=$addr;
            $data['work_phone']=$phone;
            $data['contact']=$contact;
            $data['mail']=$uemail;
            $data['eid']=$eid;
            $data['notes']=$notes;
            $data['data']=json_encode($vendor);
            $usr->InsertUpdate($id_property, $data);
        }
    }
    
    function updateVendor($id_vendor,$id_property){
        if($id_vendor==0)return false;
        $usr=new Vendors();
        $row=$usr->getVendorByIdx($id_property, $id_vendor);
        //get the ckey
        $topsdata=new TopsData();
        $prop=new Properties();
        $usr=new Vendors();
        $idtops=$topsdata->getIDfromMerchant($id_property);
        $ckey=$topsdata->get1Info($idtops, 'ckey');
        if(empty($ckey))return false;
        $olddata=$row['data'];
        $tdata=json_decode($olddata,true);
        if(empty($tdata))return false;
        $vendor=$tdata[0];
        if(empty($vendor))return false;
        $tops=new TOPSconnection($ckey);
        $vendor['Number']=$row['eid'];
        $vendor['Address1']=$row['address'];
        $vendor['Address2']=$row['city'].', '.$row['state'].' '.$row['zip'];
        $vendor['Name']=$row['name'];
        $vendor['Phone']=$row['work_phone'];
        $vendor['Contact']=$row['contact'];
        unset($vendor['Links']);
        unset($vendor['Metadata']);
        $key=$vendor['VendorKey'];
        $rcode=$tops->sendVendor($key, 'PUT', $vendor);
        //update or add email
        if($row['mail']!=""){
            $utm=$tops->getOwnerEmail($key,'Vendor');
            if(count($utm)>0){
                $uemail=$utm[0]['EmailValue'];
                if($uemail!=$row['mail']){
                    //update
                    $umail=$utm[0];
                    $umail['EmailValue']=$row['email_address'];
                    unset($umail['Links']);
                    unset($umail['Metadata']);
                    $key=$umail['EmailKey'];
                    $tops->sendEmail($key,'PUT',$umail);
                }
            }
        }
        if($rcode==240)return true;
        return false;
    }
    
    function addVendor($id_vendor,$id_property){
        if($id_vendor==0)return false;
        $usr=new Vendors();
        $row=$usr->getVendorByIdx($id_property, $id_vendor);
        //get the ckey
        $topsdata=new TopsData();
        $prop=new Properties();
        $usr=new Vendors();
        $idtops=$topsdata->getIDfromMerchant($id_property);
        $ckey=$topsdata->get1Info($idtops, 'ckey');
        $community_key=$topsdata->get1Info($idtops, 'community_id');
        if(empty($ckey))return false;
        $vendor=array();
        $tops=new TOPSconnection($ckey);
        $vendor['Number']=$row['eid'];
        $vendor['Address1']=$row['address'];
        $vendor['Address2']=$row['city'].', '.$row['state'].' '.$row['zip'];
        $vendor['Address3']="";
        $vendor['CommunityKey']=$community_key;
        $vendor['Name']=$row['name'];
        $vendor['Phone']=$row['work_phone'];
        $vendor['Phone2']="";
        $vendor['Contact']=$row['contact'];
        $vendor['Contact2']="";
        $vendor['FederalTaxID']="";
        $vendor['LiabilityCompany']="";
        $vendor['LiabilityExpirationDate']="";
        $vendor['LiabilityPolicyNumber']="";
        $vendor['WorkersCompCompany']="";
        $vendor['WorkersCompExpirationDate']="";
        $vendor['WorkersCompPolicyNumber']="";
        $vendor['AccountKey']="";
        $rcode=$tops->sendVendor($key, 'POST', $vendor);
        $data=json_decode($rcode,true);
        if(isset($data['VendorKey'])){
            $vdata=array();
            $vdata[]=$data;
            $usr->set1Info($id_vendor,'data',json_encode($vdata));
            //update or add email
            if($row['mail']!=""){
                    //add
                    $umail=array();
                    $umail['CommunityKey']=$community_key;
                    $umail['ContactKey']=$data['VendorKey'];
                    $umail['ContactType']='Vendor';
                    $umail['EmailValue']=$row['mail'];
                    $umail['IsOptedIn']=true;
                    $umail['IsPrimary']=true;
                    $tops->sendEmail('','POST',$umail);
            }
            return true;
        }
        return false;
    }

    function updatePropertyOwner($iduser,$id_property){
        if($iduser==0)return false;
        $usr=new User();
        $row=$usr->getUsrInfo($iduser);
        //get the ckey
        $topsdata=new TopsData();
        $prop=new Properties();
        $idtops=$topsdata->getIDfromMerchant($id_property);
        $ckey=$topsdata->get1Info($idtops, 'ckey');
        $community_key=$topsdata->get1Info($idtops, 'community_id');
        if(empty($ckey))return false;
        $datos=$row['topsdata'];
        $dattmp=  json_decode($datos,true);
        if(!isset($dattmp['udata']))return false;
        if(!isset($dattmp['punit']))return false;
        $punit=$dattmp['punit'];
        $owner=$dattmp['udata'];
        $punit['AccountNumber']=trim($row['account_number']);
        $punit['Street']=$row['address'];
        $punit['AddressNumber']=$row['address_unit'];
        $punit['City']=$row['city'];
        $punit['State']=$row['state'];
        $punit['Zip']=$row['zip'];
        unset($punit['Links']);
        unset($punit['Metadata']);
        $key=$punit['PropertyKey'];
        $tops=new TOPSconnection($ckey);
        $rcode=$tops->putPropertyDataByKey($key, $punit);
        if(!isset($dattmp['udata']))return false;
        $owner['LegalName']=$row['first_name'].' '.$row['last_name'];
        $owner['PhoneHome']=$row['phone_number'];
        $key=$owner['OwnerKey'];
        $rcode1=$tops->putOwnerDataByKey($key, $owner);
        //update or add email
        if($row['email_address']!=""){
            $utm=$tops->getOwnerEmail($key);
            if(count($utm)>0){
                $uemail=$utm[0]['EmailValue'];
                if($uemail!=$row['email_address']){
                    //update
                    $umail=$utm[0];
                    $umail['EmailValue']=$row['email_address'];
                    unset($umail['Links']);
                    unset($umail['Metadata']);
                    $key=$umail['EmailKey'];
                    $tops->sendEmail($key,'PUT',$umail);
                }
            }
            else {
                //add
                $umail=array();
                $umail['CommunityKey']=$community_key;
                $umail['ContactKey']=$owner['OwnerKey'];
                $umail['ContactType']='Owner';
                $umail['EmailValue']=$row['email_address'];
                $umail['IsOptedIn']=true;
                $umail['IsPrimary']=true;
                $tops->sendEmail('','POST',$umail);
            }
        }
        if($rcode!=240)return false;
        return true;
    }
    
    function getGList($ckey){
        if(empty($ckey))return false;
        $tops=new TOPSconnection($ckey); 
        $glist=$tops->getChargeCodeList();
        return $glist;
    }
    function getCList($ckey){
        if(empty($ckey))return false;
        $tops=new TOPSconnection($ckey); 
        $glist=$tops->getPropertyList();
        return $glist;
    }
    
    function getCompaniesKeys($ckey){
        if(empty($ckey))return false;
        $tops=new TOPSconnection($ckey); 
        $glist=$tops->getCompanies();
        return $glist;
    }
    
}    