<?php

namespace App\CustomClass;

use App\Model\PromotionsModel;
use App\Model\User;
use DB;

/*
 * Promotions Type:
 * 1- Visa
 * 2- Grubhub
 * 3- Lift
 *
 */

class GSBBilling
{
    private $webUserId;
    private $accountId;
    private $destURL;
    private $shKey;
    private $propertyId;

    public function __construct($webUserId)
    {
        $this->webUserId = $webUserId;
        $this->assignVariables();
    }

    public function assignVariables()
    {
        $userDetails = $this->_getUserDetails();
        if (!empty($userDetails)) {
            $this->accountId = (!empty($userDetails['account_number'])) ? $userDetails['account_number'] : '';
            $this->propertyId = (!empty($userDetails['property_id'])) ? $userDetails['property_id'] : '';
        }
        $variables = $this->_getVariables();
        if (!empty($variables)) {
            $this->destURL = (!empty($variables['domain'])) ? 'https://'.$variables['domain'].'.reviewmyinvoice.com/ws/v1/get_bills/' : '';
            $this->shKey = (!empty($variables['shKey'])) ? $variables['shKey'] : '';
        }
    }

    public static function getEncryptedShkey($shKey, $accountId)
    {
        if (!empty($accountId) && !empty($shKey)) {
            return sha1($shKey.','.$accountId);
        }

        return false;
    }

    public function getBills()
    {
        if (!empty($this->destURL) && !empty($this->shKey) && !empty($this->accountId)) {
            return $this->_send2TAPI();
        }
        return false;
    }

    private function _getUserDetails() {
        try {
            $result = (array)$app_db = DB::table('web_users')->where('web_user_id', $this->webUserId)->first();
            if(!empty($result)){
                return array(
                    'account_number' => $result['account_number'],
                    'property_id' => $result['property_id']
                );
            }
        } catch (\Exception $e) {
            // return false;
        }

        return false;
    }

    private function _getVariables()
    {
        try {
            $result = (array)$app_db = DB::table('shared_keys')->where('property_id', $this->propertyId)->first();
            if (!empty($result)) {
                return array(
                    'domain' => $result['biller_domain'],
                    'shKey' => self::getEncryptedShkey($result['sharedkey'], $this->accountId)
                );
            }
        } catch (\Exception $e) {
            // return false;
        }

        return false;
    }

    private function _send2TAPI(){
        $url = $this->destURL.'?acct='.$this->accountId.'&sig='.$this->shKey;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_TIMEOUT, 600);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $result = curl_exec($ch);
        $rcode=curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $result;
    }
}
