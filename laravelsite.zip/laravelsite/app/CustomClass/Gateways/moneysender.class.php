<?php
 namespace App\CustomClass;
 
class moneysender
{
    private $gw_url = 'https://ws.eps.profitstars.com/PV/TransactionProcessing.asmx';

    private $gw_mid = '43461';
    private $gw_lid ='127225';
    private $gw_sid ="128492";
    private $gw_key="S5cCiJ1Y7oqjFitU2ZcYi6CDIKMR";
    
    private $b2b='0';
    private $account_type='Checking';
    private $memo='';
    private $amount=0;
    private $trans_id;
    private $routing_number;
    private $account_number;
    private $name;
    private $state;
    private $email='';

    public function __construct($options = array())
    {
        if (isset($options['gw_url'])) {
            $this->gw_url=trim($options['gw_url']);
        }
        if (isset($options['gw_mid'])) {
            $this->gw_mid=trim($options['gw_mid']);
        }
        if (isset($options['gw_lid'])) {
            $this->gw_lid=trim($options['gw_lid']);
        }
        if (isset($options['gw_sid'])) {
            $this->gw_sid=trim($options['gw_sid']);
        }
        if (isset($options['gw_key'])) {
            $this->gw_key=trim($options['gw_key']);
        }
    }
    
    private function sendRequest($request, $action)
    {
        $url=$this->gw_url;
        $header = array(
                        "Content-type: text/xml;charset=\"utf-8\"",
                        "Accept: text/xml",
                        "Cache-Control: no-cache",
                        "Pragma: no-cache",
                        "SOAPAction: \"https://ws.eps.profitstars.com/PV/".$action."\"",
                        "Content-length: ".strlen($request),
                        );
            $ch = curl_init();
            // set the target url
            curl_setopt($ch, CURLOPT_URL, $url);
            // howmany parameter to post
            curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            //curl_setopt($ch, CURLOPT_VERBOSE, true);

            $result = curl_exec($ch);
            curl_close($ch);
            return $result;
    }


    function setB2B()
    {
        $this->b2b='1';
    }

    function setAccountTypeSavings()
    {
        $this->account_type='Savings';
    }

    function setMemo($text)
    {
        $this->memo=$text;
    }

    function setRoutingNumber($text)
    {
        $this->routing_number=$text;
    }

    function setAccountNumber($text)
    {
        $this->account_number=$text;
    }

    function setOrderId($text)
    {
        $this->trans_id=$text;
    }

    function setAmount($text)
    {
        $this->amount=$text;
    }

    function setName($text)
    {
        $this->name=$text;
    }

    function setState($text)
    {
        $this->state=substr($text, 0, 2);
    }

    function setEmail($text)
    {
        $this->email=$text;
    }

    function Credit()
    {
        $result=array();
        if (empty($this->gw_key) || empty($this->gw_lid) || empty($this->gw_mid) || empty($this->gw_sid) || empty($this->gw_url)) {
            $result['response']=4;
            $result['responsetext']='Error with credentials';
            return $result;
        }
        if ($this->amount<=0) {
            $result['response']=4;
            $result['responsetext']='The amount cannot be zero';
            return $result;
        }
        if (empty($this->trans_id)) {
            $result['response']=4;
            $result['responsetext']='Invalid OrderID';
            return $result;
        }
        if (empty($this->routing_number)) {
            $result['response']=4;
            $result['responsetext']='Empty Routing Number';
            return $result;
        }
        if (empty($this->account_number)) {
            $result['response']=4;
            $result['responsetext']='Empty Account Number';
            return $result;
        }
        if (empty($this->name)) {
            $result['response']=4;
            $result['responsetext']='Empty Customer Name';
            return $result;
        }
        if (empty($this->state)) {
            $result['response']=4;
            $result['responsetext']='Empty State';
            return $result;
        }
        if ($this->account_type!='Checking' && $this->account_type!='Savings') {
            $result['response']=4;
            $result['responsetext']='Invalid Account Type';
            return $result;
        }
        $ds=explode(' ', $this->name);
        if (count($ds)>1) {
            $fname=$ds[0];
            $lname=$ds[1];
        } else {
            if ($this->b2b) {
                $fname='';
                $lname=$ds[0];
            } else {
                $fname=$ds[0];
                $lname='';
            }
        }
        $request='<?xml version="1.0" encoding="utf-8"?>
                            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                              <soap:Body>
                              <AuthorizeMoneyCenterTransaction>
                                <MethodParameters>
                                <storeId>'.$this->gw_sid.'</storeId>
                                <storeKey>'.$this->gw_key.'</storeKey>
                                <customerNumber isNull="false" />
                                <accountReferenceId></accountReferenceId>
                                <moneycenterTransaction>
                                <EntityId>'.$this->gw_mid.'</EntityId>
                                <LocationId>'.$this->gw_lid.'</LocationId>
                                <PaymentOrigin>Signature_Original</PaymentOrigin>
                                <AccountType>'.$this->account_type.'</AccountType>
                                <OperationType>Credit</OperationType>
                                <EffectiveDate>'.date('Y-m-d').'</EffectiveDate>
                                <Description>'.$this->memo.'</Description>
                                <TotalAmount>'.$this->amount.'</TotalAmount>
                                <BatchNumber isNull="false" />
                                <TransactionNumber>'.$this->trans_id.'</TransactionNumber>
                                <Field1 isNull="false" />
                                <Field2 isNull="false" />
                                <Field3 isNull="false" />
                                <RoutingNumber>'.$this->routing_number.'</RoutingNumber>
                                <AccountNumber>'.$this->account_number.'</AccountNumber>
                                <CheckNumber></CheckNumber>
                                <IsBusinessPayment>'.$this->b2b.'</IsBusinessPayment>
                                <NameOnAccount>'.$this->name.'</NameOnAccount>
                                <BillingStateRegion>'.$this->state.'</BillingStateRegion>
                                <IpAddressOfOriginator isNull="false" />
                                <EmailAddress>'.$this->email.'</EmailAddress>
                                </moneycenterTransaction>
                                </MethodParameters>
                                </AuthorizeMoneyCenterTransaction>
                              </soap:Body>
                            </soap:Envelope>';

        $response=$this->sendRequest($request, 'AuthorizeMoneyCenterTransaction');
        $resultx=$this->parseResponse($response);
        if ($resultx['AuthorizeMoneyCenterTransactionResponse']['AuthorizeTransactionWithCustomerResult']['ResponseCode']=='Success') {
            $result['response']=1;
            $result['responsetext']='Success';
            $result['authcode']=$resultx['AuthorizeTransactionWithCustomerResponse']['AuthorizeTransactionWithCustomerResult']['ReferenceNumber'];
        } else {
            $result['response']=3;
            $result['responsetext']=$resultx['AuthorizeTransactionWithCustomerResponse']['AuthorizeTransactionWithCustomerResult']['ResponseCode'].' '.$resultx['AuthorizeTransactionWithCustomerResponse']['AuthorizeTransactionWithCustomerResult']['ResponseMessage'];
        }
        return $result;
    }

    function Sale()
    {
        $result=array();
        if (empty($this->gw_key) || empty($this->gw_lid) || empty($this->gw_mid) || empty($this->gw_sid) || empty($this->gw_url)) {
            $result['response']=4;
            $result['responsetext']='Error with credentials';
            return $result;
        }
        if ($this->amount<=0) {
            $result['response']=4;
            $result['responsetext']='The amount cannot be zero';
            return $result;
        }
        if (empty($this->trans_id)) {
            $result['response']=4;
            $result['responsetext']='Invalid OrderID';
            return $result;
        }
        if (empty($this->routing_number)) {
            $result['response']=4;
            $result['responsetext']='Empty Routing Number';
            return $result;
        }
        if (empty($this->account_number)) {
            $result['response']=4;
            $result['responsetext']='Empty Account Number';
            return $result;
        }
        if (empty($this->name)) {
            $result['response']=4;
            $result['responsetext']='Empty Customer Name';
            return $result;
        }
        if (empty($this->state)) {
            $result['response']=4;
            $result['responsetext']='Empty State';
            return $result;
        }
        if ($this->account_type!='Checking' && $this->account_type!='Savings') {
            $result['response']=4;
            $result['responsetext']='Invalid Account Type';
            return $result;
        }
        $ds=explode(' ', $this->name);
        if (count($ds)>1) {
            $fname=$ds[0];
            $lname=$ds[1];
        } else {
            if ($this->b2b) {
                $fname='';
                $lname=$ds[0];
            } else {
                $fname=$ds[0];
                $lname='';
            }
        }
        $request='<?xml version="1.0" encoding="utf-8"?>
                            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                              <soap:Body>
                              <AuthorizeMoneyCenterTransaction>
                                <MethodParameters>
                                <storeId>'.$this->gw_sid.'</storeId>
                                <storeKey>'.$this->gw_key.'</storeKey>
                                <customerNumber isNull="false" />
                                <accountReferenceId></accountReferenceId>
                                <moneycenterTransaction>
                                <EntityId>'.$this->gw_mid.'</EntityId>
                                <LocationId>'.$this->gw_lid.'</LocationId>
                                <PaymentOrigin>Signature_Original</PaymentOrigin>
                                <AccountType>'.$this->account_type.'</AccountType>
                                <OperationType>Sale</OperationType>
                                <EffectiveDate>'.date('Y-m-d').'</EffectiveDate>
                                <Description>'.$this->memo.'</Description>
                                <TotalAmount>'.$this->amount.'</TotalAmount>
                                <BatchNumber isNull="false" />
                                <TransactionNumber>'.$this->trans_id.'</TransactionNumber>
                                <Field1 isNull="false" />
                                <Field2 isNull="false" />
                                <Field3 isNull="false" />
                                <RoutingNumber>'.$this->routing_number.'</RoutingNumber>
                                <AccountNumber>'.$this->account_number.'</AccountNumber>
                                <CheckNumber></CheckNumber>
                                <IsBusinessPayment>'.$this->b2b.'</IsBusinessPayment>
                                <NameOnAccount>'.$this->name.'</NameOnAccount>
                                <BillingStateRegion>'.$this->state.'</BillingStateRegion>
                                <IpAddressOfOriginator isNull="false" />
                                <EmailAddress>'.$this->email.'</EmailAddress>
                                </moneycenterTransaction>
                                </MethodParameters>
                                </AuthorizeMoneyCenterTransaction>
                              </soap:Body>
                            </soap:Envelope>';

        $response=$this->sendRequest($request, 'AuthorizeMoneyCenterTransaction');
        $resultx=$this->parseResponse($response);
        if ($resultx['AuthorizeMoneyCenterTransactionResponse']['AuthorizeTransactionWithCustomerResult']['ResponseCode']=='Success') {
            $result['response']=1;
            $result['responsetext']='Success';
            $result['authcode']=$resultx['AuthorizeTransactionWithCustomerResponse']['AuthorizeTransactionWithCustomerResult']['ReferenceNumber'];
        } else {
            $result['response']=3;
            $result['responsetext']=$resultx['AuthorizeTransactionWithCustomerResponse']['AuthorizeTransactionWithCustomerResult']['ResponseCode'].' '.$resultx['AuthorizeTransactionWithCustomerResponse']['AuthorizeTransactionWithCustomerResult']['ResponseMessage'];
        }
        return $result;
    }
    
    private function parseResponse($str)
    {
        $xml = simplexml_load_string(str_replace("soap:", "", $str));
        $json = json_encode($xml);
        $array = json_decode($json, true);
        $result=$array['Body'];
        return $result;
    }
}
