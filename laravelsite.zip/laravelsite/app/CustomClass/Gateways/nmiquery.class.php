<?php

namespace App\CustomClass;

/**
*/
class nmiquery
{
   
    private $nmi_url = 'https://secure.nmi.com/api/query.php';
    private $nmi_user = '';
    private $nmi_password = '';

    /*
     * @param array $options
     * - nmi_url
     * - nmi_user
     * - nmi_password
     */
    public function __construct($options = array())
    {
//        if (isset($options['nmi_url'])) $this->setNmiUrl($options['nmi_url']);
        if (isset($options['nmi_user'])) {
            $this->setNmiUser(trim($options['nmi_user']));
        }
        if (isset($options['nmi_password'])) {
            $this->setNmiPassword(trim($options['nmi_password']));
        }
    }
    
    public function setNmiUser($nmi_user)
    {
        $this->nmi_user = $nmi_user;
    }

    
    public function setNmiPassword($nmi_password)
    {
        $this->nmi_password = $nmi_password;
    }
    
    private function getNmiUrl()
    {
        return $this->nmi_url;
    }
    
    public function getReport($parameters)
    {
        $str=$this->getNmiUrl().'?username='.$this->nmi_user.'&password='.$this->nmi_password;
        foreach ($parameters as $key => $value) {
            $str.='&'.$key.'='.$value;
        }
        $result=$this->execute($str);
        return $result;
    }
    /*
     * @param string $query_string
     *  Properly formatted name-value-pair query string
     *
     * $return array[string] $result
     *  array containing response code, message and other fail or pass codes
     */
    protected function execute($query_string)
    {
        if (in_array("curl", get_loaded_extensions())) {
            $ch = curl_init($query_string);
            curl_setopt($ch, CURLOPT_POST, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_REFERER, "");
            $response = curl_exec($ch);
            curl_close($ch);

            $result = array();
            $result['query_string'] = $query_string;

            
            if (!$response) {
                $result['response'] = 2;
                $result['responsetext'] = 'There was an error communicating with the NMI gateway';
            } else {
                $xml = simplexml_load_string($response);
                $json = json_encode($xml);
                $result['result'] = json_decode($json, true);
            }
            return $result;
        } else {
            throw new Exception('Could not load cURL libraries. Make sure PHP is compiled with cURL');
        }
    }
}
