<?php
namespace App\CustomClass;

/*
 * To change this license header, choose License Headers in Project Properties.
*/
class fd4
{
    
    private $fd4_url = "https://api.globalgatewaye4.firstdata.com/transaction/v11";
    private $gatewayID = '';
    private $password = '';

    /*
     * @param array $options
     * - fd4_url
     * - fd4_user
     * - fd4_password
     */
    public function __construct($options = array())
    {
        if (isset($options['fd4_user'])) {
            $this->gatewayID=trim($options['fd4_user']);
        }
        if (isset($options['fd4_password'])) {
            $this->password=trim($options['fd4_password']);
        }
    }
    

       
    private function setFd4Url($fd4_url)
    {
        $this->fd4_url = $fd4_url;
    }

    
    private function setFd4User($fd4_user)
    {
        $this->fd4_user = $fd4_user;
    }

    
    private function setFd4Password($fd4_password)
    {
        $this->fd4_password = $fd4_password;
    }
    
     
    protected function execute($query_string)
    {
              $url=$this->fd4_url;
              $this->header= array(
                       "Content-Type: application/json; charset=UTF-8",
                       "Accept: application/json"
                     );
         
               $ch = curl_init();
               // set the target url
               curl_setopt($ch, CURLOPT_URL, $url);
               curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
               curl_setopt($ch, CURLOPT_POST, true);
               curl_setopt($ch, CURLOPT_HEADER, true);
               curl_setopt($ch, CURLOPT_HTTPHEADER, $this->header);
               curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
               $result = curl_exec($ch);
               $this->curl_erno = curl_errno($ch);
               $this->curl_error =  curl_error($ch);
               curl_close($ch);
               return $result;
    }
    
    function getFd4_url()
    {
        return $this->fd4_url;
    }

    function getGatewayID()
    {
        return $this->gatewayID;
    }

    function getPassword()
    {
        return $this->password;
    }
}
