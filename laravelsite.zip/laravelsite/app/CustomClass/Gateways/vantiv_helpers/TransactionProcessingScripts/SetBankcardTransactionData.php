<?php

// Credit Card Info
function setBCPTenderData($data)
{
    $statesh=array('AL' ,'AK' ,'AZ' ,'AR' ,'CA' ,'CO' ,'CT' ,'DE' ,'DC' ,'FL' ,'GA' ,'HI' ,'ID' ,'IL' ,'IN' ,'IA' ,'KS' ,'KY' ,'LA' ,'ME' ,'MD' ,'MA' ,'MI' ,'MN' ,'MS' ,'MO' ,'MT' ,'NE' ,'NV' ,'NH' ,'NJ' ,'NM' ,'NY' ,'NC' ,'ND' ,'OH' ,'OK' ,'OR' ,'PA' ,'RI' ,'SC' ,'SD' ,'TN' ,'TX' ,'UT' ,'VT' ,'VA' ,'WA' ,'WV' ,'WI' ,'WY');
    $umname = preg_replace('/\s+/', ' ', $data['UMname']);
    $umname = $this->avoidSpaceBug($umname);
    list($fname,$lname) = split(' ', $umname);
    if ($lname=='') {
        $lname='xxx';
    }
    $umcity=trim($data['UMcity']);
    if ($umcity=='') {
        $umcity='miami';
    }
    $umstate=trim($data['UMstate']);
    if (!in_array($umstate, $statesh)) {
        $umstate='FL';
    }
    $umzip=substr($data['UMzip'], 0, 5);
    if (strlen($umzip)!=5) {
        $umzip='33130';
    }
    $umaddress=trim($data['UMstreet']);
    $tenderData = new creditCard();
    $tenderData->name = $fname.' '.$lname;
    $tenderData->address = $umaddress;
    $tenderData->city = $umcity;
    $tenderData->state = $umstate;
    $tenderData->zip = $umzip;
    if (isset($data['profile_id'])&&!empty($data['profile_id'])) {
        $tenderData->paymentAccountDataToken = $data['profile_id'];
    } else {
        $umexpira=trim(str_replace(array('/','-'), '', $data['UMexpir']));
        if (trim($umexpira)<4) {
            $data['UMexpir']=str_pad($umexpira, 4, '0', STR_PAD_LEFT);
        }
        $tenderData->type = $data['payment_type'];
        $tenderData->number = trim($data['UMcard']);
        $tenderData->expiration = $umexpira; // MMYY
        $tenderData->cvv = trim($data['UMcvv2']); // Security code
    }
    return $tenderData;
}
    
function setBCPTxnData($data)
{
    // Transaction information
    if (isset($data['description'])) {
        $umdescription=trim($data['description']);
    } else {
        $umdescription='Revo Payments';
    }
    $transactionData = new transDataPro();
    $transactionData->OrderNumber = $data['new_trans_id']; // Order Number needs to be unique
    $transactionData->InvoiceNumber = $transactionData->OrderNumber;
    $transactionData->CustomerPresent = Settings::CustomerPresent; // Present, Ecommerce, MOTO, NotPresent
    $transactionData->EntryMode = Settings::TxnData_EntryMode; // Keyed, TrackDataFromMSR
    $transactionData->GoodsType = 'DigitalGoods'; // DigitalGoods - PhysicalGoods - Used only for Ecommerce
    $transactionData->IndustryType = Settings::TxnData_IndustryType; // Retail, Restaurant, Ecommerce, MOTO
    $transactionData->Amount = sprintf("%0.2f", $data['net_amount']); // in a decimal format xx.xx
    $transactionData->CashBackAmount = ''; // in a decimal format. used for PINDebit transactions
    $transactionData->CurrencyCode = 'USD'; // TypeISOA3 Currency Codes USD CAD
    $transactionData->SignatureCaptured = Settings::TxnData_SignatureCaptured; // boolean true or false
    $transactionData->ReportingData = new TransactionReportingData();
    $transactionData->ReportingData->Description = $umdescription;
    $transactionData->LaneId = "1";
    $transactionData->CFeeAmount=sprintf("%0.2f", $data['convenience_fee']);
    $level2Data = new Level2Data();
    $level2Data->BaseAmount = sprintf("%0.2f", ($data['net_amount']-$data['convenience_fee']));
    $level2Data->OrderDate = DateTime::ISO8601;
    $level2Data->OrderNumber = $data['new_trans_id'];
    $level2Data->TaxExempt = new TaxExempt();
    $level2Data->TaxExempt = 'IsTaxExempt';
    $level2Data->Tax = new Tax();
    $level2Data->Tax->Amount = '0.00';
    $transactionData->Level2Data = $level2Data;
    $dateTime = new DateTime("now", new DateTimeZone('America/Los_Angeles'));
    $transactionData->DateTime = $dateTime->format(DATE_RFC3339);
    return $transactionData;
}



/*
 *
 * Build a bankcardtransaction on the provided data.
 *
 */

function buildTransactionXML($credit_info, $trans_info)
{
    $trans =
    '<transaction i:type="b:BankcardTransactionPro" xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard/Pro">'.
                '<a:CustomerData i:nil="true"/>';
    if ($trans_info->ReportingData != null) {
        $trans = $trans.'<a:ReportingData>'.
                            '<a:Comments>'.$trans_info->ReportingData->Comments.'</a:Comments>'.
                            '<a:Description>'.$trans_info->ReportingData->Description.'</a:Description>'.
                            '<a:Reference>'.$trans_info->ReportingData->Reference.'</a:Reference>'.
                        '</a:ReportingData>';
    }

                '<a:ReportingData i:nil="true"/>';
    if ($trans_info->Creds != null) {
        $trans = $trans.'<Addendum>'.
                            '<Any>'.
                                '<string>'.$trans_info->Creds.'</string>'.
                            '</Any>'.
                        '</Addendum>';
    }
    $trans = $trans.'<ApplicationConfigurationData i:nil="true" xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard"/>'.
                '<TenderData xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">';
    if ($credit_info->paymentAccountDataToken != '') {
        $trans = $trans.'<a:PaymentAccountDataToken>'.$credit_info->paymentAccountDataToken.'</a:PaymentAccountDataToken>';
    }
    if ($credit_info->paymentAccountDataToken == '') {
        $trans = $trans.
                    '<CardData>'.
                        '<CardType>'.$credit_info->type.'</CardType>'.
                        '<CardholderName>'.$credit_info->name.'</CardholderName>'.
                        '<PAN>'.$credit_info->number.'</PAN>'.
                        '<Expire>'.$credit_info->expiration.'</Expire>'.
                        '<Track1Data>'.$credit_info->track1.'</Track1Data>'.
                        '<Track2Data>'.$credit_info->track2.'</Track2Data>'.
                    '</CardData>';
    }
    if ($credit_info->zip != '' or $credit_info->cvv != '') {
        $trans = $trans.'<CardSecurityData>';
        if ($credit_info->zip != '') {
            $trans = $trans.'<AVSData>'.
                            '<CardholderName>'.$credit_info->name.'</CardholderName>'.
                            '<Street>'.$credit_info->address.'</Street>'.
                            '<City>'.$credit_info->city.'</City>'.
                            '<StateProvince>'.$credit_info->state.'</StateProvince>'.
                            '<PostalCode>'.$credit_info->zip.'</PostalCode>'.
                            '<Country>'.$credit_info->country.'</Country>'.
                            '<Phone>'.$credit_info->phone.'</Phone>'.
                        '</AVSData>';
        }
        if ($credit_info->cvv != '') {
            $trans = $trans.
            '<CVDataProvided>Provided</CVDataProvided>'.
            '<CVData>'.$credit_info->cvv.'</CVData>';
        }
        $trans = $trans.
                    '</CardSecurityData>';
    }
    $trans = $trans.'<EcommerceSecurityData i:nil="true"/>'.
                '</TenderData>'.
                '<TransactionData i:type="b:BankcardTransactionDataPro" xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">';

    $trans = $trans. '<a:Amount>'.sprintf("%0.2f", $trans_info->Amount).'</a:Amount>';
    $trans = $trans.'<a:CurrencyCode>'.$trans_info->CurrencyCode.'</a:CurrencyCode>'.
                    '<a:TransactionDateTime>'.$trans_info->DateTime.'</a:TransactionDateTime>';
    if ($trans_info->AccountType != '') {
        $trans = $trans. '<AccountType>'.$trans_info->AccountType.'</AccountType>';
    }
    if ($trans_info->AltMerchantData != null) {
        $trans = $trans.'<AlternativeMerchantData>'.
                        '<a:CustomerServiceInternet>'.$trans_info->AltMerchantData->CustomerServiceInternet.'</a:CustomerServiceInternet>'.
                        '<a:CustomerServicePhone>'.$trans_info->AltMerchantData->CustomerServicePhone.'</a:CustomerServicePhone>'.
                        '<a:Description>'.$trans_info->AltMerchantData->Description.'</a:Description>'.
                        '<a:SIC>'.$trans_info->AltMerchantData->SIC.'</a:SIC>'.
                        '<a:Address>'.
                            '<a:Street1>'.$trans_info->AltMerchantData->Address->Street1.'</a:Street1>'.
                            '<a:Street2>'.$trans_info->AltMerchantData->Address->Street2.'</a:Street2>'.
                            '<a:City>'.$trans_info->AltMerchantData->Address->City.'</a:City>'.
                            '<a:StateProvince>'.$trans_info->AltMerchantData->Address->StateProvince.'</a:StateProvince>'.
                            '<a:PostalCode>'.$trans_info->AltMerchantData->Address->PostalCode.'</a:PostalCode>'.
                            '<a:CountryCode>'.$trans_info->AltMerchantData->Address->PostalCode.'</a:CountryCode>'.
                        '</a:Address>'.
                        '<a:MerchantId>'.$trans_info->AltMerchantData->MerchantId.'</a:MerchantId>'.
                        '<a:Name>'.$trans_info->AltMerchantData->Name.'</a:Name>'.
                    '</AlternativeMerchantData>';
    }

    if ($trans_info->ApprovalCode != '') {
        $trans = $trans. '<ApprovalCode>'.$trans_info->ApprovalCode.'</ApprovalCode>';
    }
    if ($trans_info->CashBackAmount != '') {
        $trans = $trans. '<CashBackAmount>'.sprintf("%0.2f", $trans_info->CashBackAmount).'</CashBackAmount>';
    }
    $trans = $trans.'<CustomerPresent>'.$trans_info->CustomerPresent.'</CustomerPresent>';
    if ($trans_info->IndustryType != 'Ecommerce') {
        $trans = $trans.'<EmployeeId>'.$trans_info->EmployeeId.'</EmployeeId>';
    }
    $trans = $trans.'<EntryMode>'.$trans_info->EntryMode.'</EntryMode>';
    if ($trans_info->CFeeAmount != '0.00') {
        $trans = $trans.'<FeeAmount>'.sprintf("%0.2f", $trans_info->CFeeAmount).'</FeeAmount>';
    }
    $trans = $trans.'<GoodsType>'.$trans_info->GoodsType.'</GoodsType>'.
                    '<IndustryType>'.$trans_info->IndustryType.'</IndustryType>';
    if ($trans_info->InternetTransactionData != null) {
        $trans = $trans.'<InternetTransactionData i:nil="true"/>';
    }
    $trans = $trans.'<InvoiceNumber>'.$trans_info->InvoiceNumber.'</InvoiceNumber>'.
                    '<OrderNumber>'.$trans_info->OrderNumber.'</OrderNumber>'.
                    '<IsPartialShipment>false</IsPartialShipment>'.
                    '<SignatureCaptured>'.$trans_info->SignatureCaptured.'</SignatureCaptured>';
    if ($trans_info->TerminalId != '') {
        $trans = $trans.'<TerminalId>'.$trans_info->TerminalId.'</TerminalId>';
    }
    if ($trans_info->LaneId != '') {
        $trans = $trans.'<LaneId>'.$trans_info->LaneId.'</LaneId>';
    }
    $trans = $trans.'<TipAmount>'.sprintf("%0.2f", $trans_info->TipAmount).'</TipAmount>'.
                    '<BatchAssignment i:nil="true"/>'.
                    '<b:ManagedBilling i:nil="true"/>'.
                    '<b:Level2Data i:nil="true"/>'.
                    '<b:LineItemDetails i:nil="true"/>'.
                    '<b:PINlessDebitData i:nil="true"/>'.
                    '</TransactionData>';
    if ($trans_info->InterchangeData != '') {
        $trans = $trans.'<b:InterchangeData>';
        if ($trans_info->InterchangeData->BillPayment != '') {
            $trans = $trans.'<b:BillPayment>'.$trans_info->InterchangeData->BillPayment.'</b:BillPayment>';
        }
    
        if ($trans_info->InterchangeData->RequestCommercialCard != '') {
            $trans = $trans.'<b:RequestCommercialCard>'.$trans_info->InterchangeData->RequestCommercialCard.'</b:RequestCommercialCard>';
        }
    
        if ($trans_info->InterchangeData->ExistingDebt != '') {
            $trans = $trans.'<b:ExistingDebt>'.$trans_info->InterchangeData->ExistingDebt.'</b:ExistingDebt>';
        }
    
        if ($trans_info->InterchangeData->RequestACI != '') {
            $trans = $trans.'<b:RequestACI>'.$trans_info->InterchangeData->RequestACI.'</b:RequestACI>';
        }
    
        if ($trans_info->InterchangeData->TotalNumberOfInstallments != '') {
            $trans = $trans.'<b:TotalNumberOfInstallments>'.$trans_info->InterchangeData->TotalNumberOfInstallments.'</b:TotalNumberOfInstallments>';
        }
    
        if ($trans_info->InterchangeData->CurrentInstallmentNumber != '') {
            $trans = $trans.'<b:CurrentInstallmentNumber>'.$trans_info->InterchangeData->CurrentInstallmentNumber.'</b:CurrentInstallmentNumber>';
        }
    
        if ($trans_info->InterchangeData->RequestAdvice != '') {
            $trans = $trans.'<b:RequestAdvice>'.$trans_info->InterchangeData->RequestAdvice.'</b:RequestAdvice>';
        }
    
        $trans = $trans.'</b:InterchangeData>';
    } else {
        $trans = $trans.'<b:InterchangeData i:nil="true"/>';
    }
                    $trans = $trans.'</transaction>';
    return $trans;
}
/*
 *
 * Build a CaptureDifferenceData object on the provided data.
 *
 */
function buildCaptureXML($captureDiffData, $creds = '')
{
    $capture = '<differenceData i:type="b:BankcardCapturePro" xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard/Pro">';
    if (is_array($captureDiffData->TransactionId)) {
        foreach ($captureDiffData->TransactionId as $txnId) {
            $capture = $capture.'<a:TransactionId>'.$txnId.'</a:TransactionId>';
        }
    } else {
        $capture = $capture.'<a:TransactionId>'.$captureDiffData->TransactionId.'</a:TransactionId>';
    }
    if ($creds != '') {
        $capture = $capture.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
    }
    $capture = $capture.'<Amount xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$captureDiffData->Amount.'</Amount>';
    if ($captureDiffData->ChargeType != '') {
        $capture = $capture.'<ChargeType xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$captureDiffData->ChargeType.'</ChargeType>';
    }
    if ($captureDiffData->ShipDate != '') {
        $capture = $capture.'<ShipDate xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$captureDiffData->ShipDate.'</ShipDate>';
    }
    if ($captureDiffData->TipAmount != '') {
        $capture = $capture.'<TipAmount xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$captureDiffData->TipAmount.'</TipAmount>';
    }
    if ($captureDiffData->MultiplePartialCapture != '') {
        $capture = $capture.'<b:MultiplePartialCapture>'.$captureDiffData->MultiPartialCapture.'</b:MultiplePartialCapture>';
    }
    $capture = $capture.'<b:Level2Data i:nil="true" xmlns:c="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard"/>'.
                '<b:LineItemDetails i:nil="true" xmlns:c="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard"/>'.
                '<b:ShippingData i:nil="true"/>'.
            '</differenceData>';
    return $capture;
}
/*
 *
 * Build a CaptureDifferenceData object on the provided data.
 *
 */
function buildCaptureSelectiveXML($captureDiffData, $creds = '')
{
    $capture = '<differenceData xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">';
    $i = 0;
    $count = count($captureDiffData->TransactionId);
    if (is_array($captureDiffData->TransactionId)) {
        for ($i = 0; $i < $count; $i++) {
            if ($captureDiffData->TransactionId[$i] != null) {
                $capture = $capture.'<a:Capture i:type="b:BankcardCapture" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.
                    '<a:TransactionId>'.$captureDiffData->TransactionId[$i].'</a:TransactionId>';
                if ($creds != '') {
                    $capture = $capture.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
                }
                $capture=$capture.'<b:Amount>'.$captureDiffData->Amount.'</b:Amount>';
                if ($captureDiffData->ChargeType != null) {
                    $capture=$capture.'<b:ChargeType>'.$captureDiffData->ChargeType.'</b:ChargeType>';
                }
                if ($captureDiffData->ChargeType != null) {
                    $capture=$capture.'<b:ShipDate>'.$captureDiffData->ShipDate.'</b:ShipDate>';
                }
                if ($captureDiffData->ChargeType != null) {
                    $capture=$capture.'<b:TipAmount>'.$captureDiffData->TipAmount.'</b:TipAmount>';
                }
                $capture=$capture.'</a:Capture>';
                $i++;
            } elseif ($captureDiffData->TransactionId[$i] == null) {
                break;
            }
        }
        $capture=$capture.'</differenceData>';
    } else {
        $capture = '<differenceData xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">';
        $capture = $capture.'<a:Capture i:type="b:BankcardCapture" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.
                    '<a:TransactionId>'.$captureDiffData->TransactionId.'</a:TransactionId>';
        if ($creds != '') {
            $capture = $capture.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
        }
        $capture=$capture.'<b:Amount>'.$captureDiffData->Amount.'</b:Amount>';
        if ($captureDiffData->ChargeType != null) {
            $capture=$capture.'<b:ChargeType>'.$cap->ChargeType.'</b:ChargeType>';
        }
        if ($captureDiffData->ChargeType != null) {
            $capture=$capture.'<b:ShipDate>'.$captureDiffData->ShipDate.'</b:ShipDate>';
        }
        if ($captureDiffData->ChargeType != null) {
            $capture=$capture.'<b:TipAmount>'.$captureDiffData->TipAmount.'</b:TipAmount>';
        }
        $capture=$capture.'</a:Capture>';
        $capture=$capture.'</differenceData>';
    }

    return $capture;
}
function buildTxnIdsXML($transactionIds)
{

    $txnIds = '<transactionIds xmlns:a="http://schemas.microsoft.com/2003/10/Serialization/Arrays" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">';
    if (is_array($transactionIds)) {
        foreach ($transactionIds as $txnId) {
            if ($txnId != null) {
                $txnIds = $txnIds.'<a:string>'.$txnId.'</a:string>';
            } elseif ($txnId == null) {
                break;
            }
        }
    } else {
        $txnIds = $txnIds.'<a:string>'.$transactionIds.'</a:string>';
    }
    $txnIds=$txnIds.'</transactionIds>';
    return $txnIds;
}

/*
 *
 * Build a ReturnDifferenceData object on the provided data.
 *
 */
function buildReturnByIdXML($returnDiffData, $creds = '')
{

    $return = '<differenceData i:type="b:BankcardReturn" xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.
                '<a:TransactionId>'.$returnDiffData->TransactionId.'</a:TransactionId>';
    if ($creds != '') {
        $return = $return.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
    }
    $return = $return.'<a:TransactionDateTime>'.$returnDiffData->TransactionDateTime.'</a:TransactionDateTime>'.
                '<Amount xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$returnDiffData->Amount.'</Amount>'.
            '</differenceData>';
    return $return;
}

/*
 *
 * Build a ReturnDifferenceData object on the provided data.
 *
 */
function buildUndoXML($undoDiffData, $creds = '')
{

    $undo = '<differenceData i:type="b:BankcardUndo" xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.
                '<a:TransactionId>'.$undoDiffData->TransactionId.'</a:TransactionId>';
    if ($creds != '') {
        $undo = $undo.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
    }
    if ($undoDiffData->PINDebitReason != null) {
        $undo = $undo.'<b:PINDebitReason>'.$undoDiffData->PINDebitReason.'</b:PINDebitReason>';
    }
    if ($undoDiffData->TenderData != null) {
        $undo = $undo.'<b:TenderData i:nil="true"/>';
    }
    $undo = $undo.'</differenceData>';
    return $undo;
}
