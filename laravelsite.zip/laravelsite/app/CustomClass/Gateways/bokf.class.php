<?php
 namespace App\CustomClass;
 
class bokf
{
    
    private $account_number='';
    private $routing_number='';
    private $trans_id;
    
    function setRoutingNumber($text)
    {
        $this->routing_number=$text;
    }

    function setAccountNumber($text)
    {
        $this->account_number=$text;
    }
    
    function auth()
    {
        $result=array();
        if (empty($this->account_number)) {
                $result['response']=3;
                $result['responsetext']='Invalid Account Number';
                return $result;
        }
        if (empty($this->routing_number)) {
                $result['response']=3;
                $result['responsetext']='Invalid Routing Number';
                return $result;
        }
        $result['response']=1;
        $result['authcode']= $this->getAuthCode($this->trans_id);
        $result['reference']=$result['authcode'];
        $result['responsetext']='Success';
        return $result;
    }
    
    function void($paymentInfo)
    {
         $result['response']=1;
         $result['authcode']= $this->getAuthCode($paymentInfo['trans_id']);
         $result['responsetext']='Success';
    }
    
    function refund($paymentInfo)
    {
         $result['response']=3;
         $result['responsetext']= 'Function not allowed in this gateway';
    }
    
    public function setOrderId($text)
    {
        $this->trans_id=$text;
    }
    
    function getAuthCode($trans_id)
    {
        $string = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $lenght = strlen($string) - 1;
        return substr($string, rand(0, $lenght), 1).
            substr($string, rand(0, $lenght), 1).
            substr($string, rand(0, $lenght), 1).
            substr($string, rand(0, $lenght), 1).$trans_id;
    }
}
