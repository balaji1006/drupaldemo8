<?php
namespace App\CustomClass;

define('ABSPATH', __DIR__.'/vantiv_helpers');
require_once ABSPATH.'/WebServiceProxies/HTTPClient.php'; // Require and bring in all required classes
require_once ABSPATH.'/WebServiceProxies/HelperMethods.php'; // Require and bring in all helper functions
require_once ABSPATH.'/ConfigFiles/app.config.php';

class vantiv
{
    
    protected $response;
    // This is where all the customization happens
    // set this file to handle the incoming form data and bundle it up for submission
    // to the gateway.
    private $_serviceKey = '';
    private $credentials = null;
    private $_identityToken = '';
    private $_serviceId;
    private $_applicationProfileId;
    private $_merchProfileId;
    private $_merchServiceId;
    private $client;
    private $_bankcardServices;
    private $_electronicCheckingServices;
    private $_storedValueServices;
    private $_serviceInformation;
    private $_achs;
    private $_bcs;
    private $merchProfileId='RevoM172045_000000001';
    private $merchServiceId='DEDC61300C';
    private $gw_mid;
    private $gw_sid;
    private $gw_key;
    private $isFee=false;
    private $TEXTSIC='6513';
    private $TEXTTID='001';
    private $TEXTCHN='0M0314';
    private $TEXTBIN='1340';
    private $payment_data=array();
    private $_baseURL = Settings::URL_BaseURL;

    
    public function __construct($options = array())
    {
        $this->readConfig();

        $this->client = new HTTPClient($this->_identityToken, $this->_baseURL);
        $this->_serviceInformation = $this->client->getServiceInformation();
        if (count($this->_serviceInformation['BankcardServices'] == 1) && isset($this->_serviceInformation['BankcardServices']['BankcardService'])) {
            $this->_bankcardServices = $this->_serviceInformation['BankcardServices']['BankcardService'];
        }

        if (isset($options['gw_mid'])) {
            $this->gw_mid=trim($options['gw_mid']);
        }
        if (isset($options['gw_sid'])) {
            $this->gw_sid=trim($options['gw_sid']);
        }
        if (isset($options['gw_key'])) {
            $this->gw_key=trim($options['gw_key']);
            list($merch,$serv)=explode('|||', $this->gw_key);
            $this->merchProfileId =$merch;
            $this->merchServiceId=$serv;
        }
        if (isset($options['isFee'])) {
            $this->isFee=true;
        }
        if (empty($this->gw_key) && !$this->isFee) {
            if (!empty($this->gw_mid) && !empty($this->gw_sid)) {
                            $datos=array();
                $datos['mid']=$this->gw_mid;
                $datos['locationid']='';
                $datos['storeid']='';
                $datos['clientid']=$this->gw_sid;
                $datos['aba']='';
                $datos['chain']=$this->TEXTCHN;
                $datos['bank']=$this->TEXTBIN;
                $datos['sic']=$this->TEXTSIC;
                $datos['bin']='';
                $datos['tid']=$this->TEXTTID;
                $datos['pts']='cc';
                $datos['address']='';
                $datos['city']='';
                $datos['state']='';
                $datos['zip']='';
                $datos['name']='';
    
                $this->gw_key=$this->createMProfile($datos);
            }
        }
    }
    
    function Sale()
    {
        $this->_bcs = null;
        $data=$this->payment_data;
        $bcpTxn = new \App\CustomClass\newTransaction();
        $bcpTxn->TxnData = $this->setBCPTxnData($data);
        $bcpTxn->TndrData = $this->setBCPTenderData($data);
        $bcpTxnXML = $this->buildTransactionXML($bcpTxn->TndrData, $bcpTxn->TxnData);
        $this->client = new HTTPClient($this->_identityToken, $this->_baseURL, $this->merchProfileId, $this->merchServiceId, $this->_applicationProfileId, $this->_bcs);
        $response = $this->client->authorize($bcpTxnXML);
        $result=array();
        $result['response']=$this->getResultCode($response);
        $result['responsetext']=$this->getResponseMsg($response);
        $result['authcode']=$this->getAuthCode($response);
        $result['avsresponse'] =$this->getAVS($response);
        $result['cvvresponse']=$this->getCVV($response);
        $result['reference']=$this->getReference($response);
        $result['token']=$response['PaymentAccountDataToken'];
        $result['key']=$this->gw_key;
        return $result;
    }
    
    function Void($reference, $amount = 0)
    {
                $this->_bcs = null;
        $this->client = new HTTPClient($this->_identityToken, $this->_baseURL, $this->merchProfileId, $this->merchServiceId, $this->_applicationProfileId, $this->_bcs);
        $undoDiffData = new \UndoDifferenceData();
        $undoDiffData->TransactionId = $reference;
        if ($amount>0) {
            $undoDiffData->Amount = $amount;
        }
        $undoDiffXML = $this->buildUndoXML($undoDiffData);
        $response = $this->client->undo($undoDiffXML, null);
        $result=array();
        $result['response']=$this->getResultCode($response);
        $result['responsetext']=$this->getResponseMsg($response);
        $result['authcode']=$this->getAuthCode($response);
        $result['avsresponse'] =$this->getAVS($response);
        $result['cvvresponse']=$this->getCVV($response);
        $result['token']=$response['PaymentAccountDataToken'];
        $result['key']=$this->gw_key;
        return $result;
    }
    
    function Refund($reference, $amount = 0)
    {
            $this->_bcs = null;
            $this->client = new HTTPClient($this->_identityToken, $this->_baseURL, $this->merchProfileId, $this->merchServiceId, $this->_applicationProfileId, $this->_bcs);
           $returnDiffData = new \ReturnByIdDifferenceData();
          $returnDiffData->TransactionId = $reference;
        if ($amount>0) {
            $returnDiffData->Amount = $amount;
        }
        $returnDiffXML = $this->buildReturnByIdXML($returnDiffData);
        $response = $this->client->returnByID($returnDiffXML);
        $result=array();
        $result['response']=$this->getResultCode($response);
        $result['responsetext']=$this->getResponseMsg($response);
        $result['authcode']=$this->getAuthCode($response);
        $result['avsresponse'] =$this->getAVS($response);
        $result['cvvresponse']=$this->getCVV($response);
        $result['reference']=$this->getReference($response);
        $result['token']=$response['PaymentAccountDataToken'];
        $result['key']=$this->gw_key;
        return $result;
    }
    
    function Credit()
    {
        $this->_bcs = null;
        $data=$this->payment_data;
        $bcpTxn = new \App\CustomClass\newTransaction();
        $bcpTxn->TxnData = $this->setBCPTxnData($data);
        $bcpTxn->TndrData = $this->setBCPTenderData($data);
        $bcpTxnXML = $this->buildTransactionXML($bcpTxn->TndrData, $bcpTxn->TxnData);
        $this->client = new HTTPClient($this->_identityToken, $this->_baseURL, $this->merchProfileId, $this->merchServiceId, $this->_applicationProfileId, $this->_bcs);
        $response = $this->client->returnUnlinked($bcpTxnXML);
        $result=array();
        $result['response']=$this->getResultCode($response);
        $result['responsetext']=$this->getResponseMsg($response);
        $result['authcode']=$this->getAuthCode($response);
        $result['avsresponse'] =$this->getAVS($response);
        $result['cvvresponse']=$this->getCVV($response);
        $result['reference']=$this->getReference($response);
        $result['token']=$response['PaymentAccountDataToken'];
        $result['key']=$this->gw_key;
        return $result;
    }
    
    function AuthToken()
    {
        $this->_bcs = null;
        $data=$this->payment_data;
        $tokenTransaction = new \App\CustomClass\newTransaction();
        $tokenTransaction->TxnData = $this->setBCPTxnData($data);
        $tokenTransaction->TndrData = $this->setBCPTenderData($data);
        $tokenTxn = $this->buildTransactionXML($tokenTransaction->TndrData, $tokenTransaction->TxnData);
        $this->client = new HTTPClient($this->_identityToken, $this->_baseURL, $this->merchProfileId, $this->merchServiceId, $this->_applicationProfileId, $this->_bcs);
        $response = $this->client->authorize($tokenTxn);
        $result=array();
        $result['response']=$this->getResultCode($response);
        $result['responsetext']=$this->getResponseMsg($response);
        $result['authcode']=$this->getAuthCode($response);
        $result['avsresponse'] =$this->getAVS($response);
        $result['cvvresponse']=$this->getCVV($response);
        $result['reference']=$this->getReference($response);
        $result['token']=$response['PaymentAccountDataToken'];
        $result['key']=$this->gw_key;
        return $result;
    }
    
    function Capture($reference)
    {
        $this->_bcs = null;
        $txnIdCs[0] = $reference;
        $capDiffData = new \CaptureDifferenceData();
        $capDiffData->TransactionId = $txnIdCs;
        $capDiffData->Amount = '0.00';
        $capDiffXML = $this->buildCaptureSelectiveXML($capDiffData);
        $txnIdsXML = $this->buildTxnIdsXML($txnIdCs);
        $this->client = new HTTPClient($this->_identityToken, $this->_baseURL, $this->merchProfileId, $this->merchServiceId, $this->_applicationProfileId, $this->_bcs);
        $response2 = $this->client->captureSelective($txnIdsXML, null, null);
        $result=array();
        $result['response']=$this->getResultCode($response);
        $result['responsetext']=$this->getResponseMsg($response);
        $result['token']=$response['PaymentAccountDataToken'];
        $result['key']=$this->gw_key;
        return $result;
    }
    
    function CaptureAll()
    {
        $this->_bcs = null;
        $this->client = new HTTPClient($this->_identityToken, $this->_baseURL, $this->merchProfileId, $this->merchServiceId, $this->_applicationProfileId, $this->_bcs);
        $this->client->captureAllAsync(null, null);
        $result=array();
        $result['response']=$this->getResultCode($response);
        $result['responsetext']=$this->getResponseMsg($response);
        $result['token']=$response['PaymentAccountDataToken'];
        $result['key']=$this->gw_key;
        return $result;
    }

    function Verify()
    {
        
        $this->_bcs = null;
        $data=$this->payment_data;
        $bcpTxn = new \App\CustomClass\newTransaction();
        $bcpTxn->TxnData = $this->setBCPTxnData($data);
        $bcpTxn->TndrData = $this->setBCPTenderData($data);
       
        $bcpTxnXML = $this->buildTransactionXML($bcpTxn->TndrData, $bcpTxn->TxnData);

        $this->client = new HTTPClient($this->_identityToken, $this->_baseURL, $this->merchProfileId, $this->merchServiceId, $this->_applicationProfileId, $this->_bcs);
        $response = $this->client->verify($bcpTxnXML);
        $result=array();
        $result['response']=$this->getResultCode($response);
        $result['responsetext']=$this->getResponseMsg($response);
        $result['authcode']=$this->getAuthCode($response);
        $result['avsresponse'] =$this->getAVS($response);
        $result['cvvresponse']=$this->getCVV($response);
        $result['token']=$response['PaymentAccountDataToken'];
        $result['key']=$this->gw_key;
        return $result;
    }
    
    private function getResultCode($response)
    {
        $resultCode = $response['StatusCode'];
        if ($resultCode == "00"||$resultCode == "10"||$resultCode == "08"||$resultCode == "09"||$resultCode == "11"||$resultCode == "20"||$resultCode == "85"||$resultCode == "87"||$resultCode == "97") { //approved transaction
               return 1;
        } else { //declined transaction
               return 3;
        }
    }
    
    private function getResponseMsg($response)
    {
        if ($response['StatusCode']=='N7') {
            return "Invalid CVV. Cannot verify CVV code";
        }
        return $response['StatusMessage'];
    }

    private function getAuthCode($response)
    {
        if (isset($response['ApprovalCode'])) {
            return $response['ApprovalCode'];
        } else {
            return '';
        }
    }

    private function getAVS($response)
    {
        if (isset($response['AVSResult']['PostalCodeResult'])) {
            return $response['AVSResult']['PostalCodeResult'];
        } else {
            return '';
        }
    }

    private function getCVV($response)
    {
        if (isset($response['CVResult'])) {
            return $response['CVResult'];
        } else {
            return '';
        }
    }
    
    private function getReference($response)
    {
        return $response['TransactionId'];
    }
    
    private function createMProfile($datos)
    {
        $merchProfile = $this->setBCPMerchantProfile($datos);
        $mpXML = $this->createMerchantProfileXML($merchProfile);
            
        if (count($this->_serviceId)==1) {
            $servih=$this->_serviceId['singleService']['ServiceId'];
        } else {
            $servih=$this->_serviceId[0]['ServiceId'];
        }
        
        $client = new HTTPClient($this->_identityToken, $this->_baseURL);
        $response = $client->saveMerchantProfiles($mpXML, 'Credit', $servih);
        $merch=$merchProfile->ProfileId;
        $this->merchProfileId =$merch;
        $this->merchServiceId=$servih;
        return $merchProfile->ProfileId."|||".$servih;
    }
    
    public function getProfileKey()
    {
        return $this->gw_key;
    }
    
    private function readConfig()
    {
        if (file_exists(ABSPATH.'/ConfigFiles/CWS_Config_Values.xml')) {
 //          // parse XML
            $xml = new \DOMDocument();
            $xml->load(ABSPATH.'/ConfigFiles/CWS_Config_Values.xml');
            if (! $xml) {
                return false;
            }
            // access XML element values
            $this->_encryptedIdentityToken = $xml->getElementsByTagName("EncryptedIdentityToken")->item(0)->nodeValue;
              
            $this->_identityToken = decrypt1($this->_encryptedIdentityToken, Settings::key);
  
               $searchNode = $xml->getElementsByTagName("ServiceKey");
            foreach ($searchNode as $srchNode) {
                $this->_serviceKey = $xml->getElementsByTagName("ServiceKey")->item(0)->nodeValue;
            }

            $searchNode = $xml->getElementsByTagName("ServiceId");

            $i = 0;

            foreach ($searchNode as $srchNode) {
                $serviceName = $srchNode->getAttribute("serviceName");
                $serviceId = $xml->getElementsByTagName("ServiceId")->item($i)->nodeValue;
                $this->_serviceId[] = array ('ServiceId' => $serviceId, 'ServiceName' => $serviceName);
                $i++;
            }
            if ($i == 1) {
                $this->_serviceId = null;
                $this->_serviceId['singleService'] = array('ServiceId' => $serviceId, 'ServiceName' => $serviceName);
            }

            $this->_applicationProfileId = $xml->getElementsByTagName('ApplicationProfileId')->item(0)->nodeValue;

            return true;
        } else {
        //    /*
        // * If the above config file does not exist then parse the app.config.php file for values.
        // */
        //
        //// The Identity Token should be stored in an encrypted format and read into the application.
        //// This can be stored either in a database or on the disk, but must always be protected and encrypted.
        //// If the IdentityToken is compromised you must notify us immmediately so we can issue a new IdentityToken
         //This is main means of authentication to the platform, essentially this is your password.

            if (file_exists(ABSPATH.'/ConfigFiles/app.config.php')) {
                $this->_identityToken = Settings::IdentityToken;
            } else {
                return false;
            }
            return true;
        }
    }

    function setToken($token)
    {
        $this->payment_data['profile_id']=$token;
    }

    function setExpDate($text)
    {
        $text=str_replace(' ', '', $text);
        if (strlen($text)<4) {
            $text='0'.$text;
        }
    
        $this->payment_data['UMexpir']=$text;
    }

    function setZipCode($text)
    {
        $this->payment_data['UMzip']=$text;
    }

    function setCardType($text)
    {
        $this->payment_data['payment_type']=$text;
    }

    function setCardNumber($text)
    {
        $this->payment_data['UMcard']=$text;
    }

    function setCVV($text)
    {
        $this->payment_data['UMcvv2']=$text;
    }

    function setMemo($text)
    {
        $this->payment_data['description']=$text;
    }

    function setOrderId($text)
    {
        $this->payment_data['new_trans_id']=$text;
    }

    function setName($text)
    {
        $this->payment_data['UMname']=$text;
    }

    function setAmount($text)
    {
        $this->payment_data['net_amount']=$text;
    }

    function setFeeAmount($text)
    {
        $this->payment_data['convenience_fee']=$text;
    }

// Credit Card Info
    private function setBCPTenderData($udata = null)
    {
        $data=$this->payment_data;
        $statesh=array('AL' ,'AK' ,'AZ' ,'AR' ,'CA' ,'CO' ,'CT' ,'DE' ,'DC' ,'FL' ,'GA' ,'HI' ,'ID' ,'IL' ,'IN' ,'IA' ,'KS' ,'KY' ,'LA' ,'ME' ,'MD' ,'MA' ,'MI' ,'MN' ,'MS' ,'MO' ,'MT' ,'NE' ,'NV' ,'NH' ,'NJ' ,'NM' ,'NY' ,'NC' ,'ND' ,'OH' ,'OK' ,'OR' ,'PA' ,'RI' ,'SC' ,'SD' ,'TN' ,'TX' ,'UT' ,'VT' ,'VA' ,'WA' ,'WV' ,'WI' ,'WY');
        if (isset($data['UMname'])) {
            $umname = str_replace(array('&','<','>','|',',',';','*','/','+','-','^'), ' ', $data['UMname']);
        } else {
            $umname='';
        }
        
        //$umcity=trim($data['UMcity']);
        //if($umcity==''){
            $umcity='miami';
        //}
        //$umstate=trim($data['UMstate']);
        //if(!in_array($umstate, $statesh)){
            $umstate='FL';
        //}
        if (isset($data['UMzip'])) {
            $umzip=substr($data['UMzip'], 0, 5);
        } else {
            $umzip='';
        }
        if (strlen($umzip)!=5) {
            $umzip='33130';
        }
        //$umaddress=substr(trim($data['UMstreet']),0,20);
        //$umaddress=str_replace(array('<','/','>','&'),'',$umaddress);
        //if($umaddress==''){
            $umaddress='No Address';
        //}
        $tenderData = new \App\CustomClass\creditCard();
        $tenderData->name = $umname;
        $tenderData->address = $umaddress;
        $tenderData->city = $umcity;
        $tenderData->state = $umstate;
        $tenderData->zip = $umzip;
        if (isset($data['profile_id'])) {
            $tenderData->paymentAccountDataToken = $data['profile_id'];
        } else {
            $umexpira=trim(str_replace(array('/','-'), '', $data['UMexpir']));
            if (trim($umexpira)<4) {
                $data['UMexpir']=str_pad($umexpira, 4, '0', STR_PAD_LEFT);
            }
            $tdat=str_replace(" Card", "", $data['payment_type']);
            $tdat=str_replace(" ", "", $tdat);
            $tenderData->type = $tdat;
            if (isset($data['UMcard'])) {
                $tenderData->number = trim($data['UMcard']);
                switch (substr($tenderData->number, 0, 1)) {
                    case 3:
                        $tenderData->type='AmericanExpress';
                        break;
                    case 4:
                        $tenderData->type='Visa';
                        break;
                    case 5:
                        $tenderData->type='MasterCard';
                        break;
                    case 6:
                        $tenderData->type='Discover';
                        break;
                    default:
                        $tenderData->type='Unknown';
                        break;
                }
            }
            $tenderData->expiration = $umexpira; // MMYY
            if (isset($data['UMcvv2'])) {
                $tenderData->cvv = trim($data['UMcvv2']); // Security code
            }
        }
        return $tenderData;
    }
    
    private function setBCPTxnData($data)
    {
    // Transaction information
        if (isset($data['description'])) {
            $umdescription=trim($data['description']);
        } else {
            $umdescription='Revo Payments';
        }
        if (!isset($data['convenience_fee'])) {
            $data['convenience_fee']=0;
        }
        $data['total_transaction_amount']=$data['net_amount']+$data['convenience_fee'];
    // Transaction information
    /* SEE TRANSACTION INFORMATION CLASS IN CWSClient.php FOR MORE INFO */
        $transactionData = new \App\CustomClass\transData();
        if (!isset($data['new_trans_id'])) {
            $data['new_trans_id']=  time();
        }
        $transactionData->OrderNumber = $data['new_trans_id']; // Order Number needs to be unique
        $transactionData->InvoiceNumber = $transactionData->OrderNumber;
        $transactionData->CustomerPresent = Settings::CustomerPresent; // Present, Ecommerce, MOTO, NotPresent
    //$transactionData->EmployeeId = '12'; //Used for Retail, Restaurant, MOTO
        $transactionData->EntryMode = Settings::TxnData_EntryMode; // Keyed, TrackDataFromMSR
        $transactionData->GoodsType = 'DigitalGoods'; // DigitalGoods - PhysicalGoods - Used only for Ecommerce
        $transactionData->IndustryType = Settings::TxnData_IndustryType; // Retail, Restaurant, Ecommerce, MOTO
    //$transactionData->AccountType = ''; // SavingsAccount, CheckingAccount used only for PINDebit
        $transactionData->Amount = sprintf("%0.2f", $data['total_transaction_amount']); // in a decimal format xx.xx
        $transactionData->CashBackAmount = ''; // in a decimal format. used for PINDebit transactions
        $transactionData->CurrencyCode = 'USD'; // TypeISOA3 Currency Codes USD CAD
        $transactionData->SignatureCaptured = Settings::TxnData_SignatureCaptured; // boolean true or false
        $transactionData->LaneId = "1";
        $transactionData->FeeAmount=sprintf("%0.2f", $data['convenience_fee']);
    //$transactionData->TipAmount = ''; // in a decimal format

        if (Settings::Pro_IncludeLevel2OrLevel3Data) {
            // Transaction information
            /* SEE TRANSACTION INFORMATION CLASS IN CWSClient.php FOR MORE INFO */
            $transactionData = new \App\CustomClass\transDataPro();
            $transactionData->OrderNumber = $data['new_trans_id']; // Order Number needs to be unique
            $transactionData->InvoiceNumber = $transactionData->OrderNumber;
            $transactionData->CustomerPresent = Settings::CustomerPresent; // Present, Ecommerce, MOTO, NotPresent
            //$transactionData->EmployeeId = '12'; //Used for Retail, Restaurant, MOTO
            $transactionData->EntryMode = Settings::TxnData_EntryMode; // Keyed, TrackDataFromMSR
            $transactionData->GoodsType = 'DigitalGoods'; // DigitalGoods - PhysicalGoods - Used only for Ecommerce
            $transactionData->IndustryType = Settings::TxnData_IndustryType; // Retail, Restaurant, Ecommerce, MOTO
            //$transactionData->AccountType = ''; // SavingsAccount, CheckingAccount used only for PINDebit
            $transactionData->Amount = sprintf("%0.2f", $data['total_transaction_amount']); // in a decimal format xx.xx
            $transactionData->CashBackAmount = ''; // in a decimal format. used for PINDebit transactions
            $transactionData->CurrencyCode = 'USD'; // TypeISOA3 Currency Codes USD CAD
            $transactionData->SignatureCaptured = Settings::TxnData_SignatureCaptured; // boolean true or false
            //$transactionData->TipAmount = ''; // in a decimal format
            $transactionData->ReportingData = new \TransactionReportingData();
            $transactionData->ReportingData->Description = $umdescription;
            $transactionData->LaneId = "1";
            $transactionData->FeeAmount=sprintf("%0.2f", $data['convenience_fee']);
            $level2Data = new \Level2Data();
            $level2Data->BaseAmount = sprintf("%0.2f", $data['net_amount']);
            $level2Data->OrderDate = \DateTime::ISO8601;
            $level2Data->OrderNumber = $transactionData->OrderNumber;
            $level2Data->TaxExempt = new \TaxExempt();
            $level2Data->TaxExempt = 'IsTaxExempt';
            $level2Data->Tax = new \Tax();
            $level2Data->Tax->Amount = '0.00';
            $transactionData->Level2Data = $level2Data;
        }

        if (Settings::Pro_IncludeAlternativeMerchantData) {
            $reportingData = new \TransactionReportingData();
            $reportingData->Description = 'AltMerchName';
            $transactionData->ReportingData = $reportingData;
        }

        $dateTime = new \DateTime("now", new \DateTimeZone('America/Denver'));
        $transactionData->DateTime = $dateTime->format(DATE_RFC3339);
        if (isset($this->_serviceInformation->BankcardServices->BankcardService->Tenders)) {
            if ($this->_serviceInformation->BankcardServices->BankcardService->Tenders->CredentialsRequired) {
                    $credentials = '<UserId>100000007506657</UserId><Password>A1B2C3D4F6</Password>';
                    $transactionData->Creds = $credentials;
            }
        }
        if (Settings::Pro_InterchangeData) {
        /*
            $interchangeData = new interchangeData();
            $interchangeData->BillPayment = "Recurring";// Any time BillPayInd is set to either "DeferredBilling", "Installment", "SinglePayment" or "Recurring", CustomerPresent should be set to "BillPayment"
            //$interchangeData->RequestCommercialCard = "";
            $interchangeData->ExistingDebt = "NotExistingDebt";
            //$interchangeData->RequestACI = "";
            //$interchangeData->TotalNumberOfInstallments = "1"; //Used for Installment
            $interchangeData->CurrentInstallmentNumber = "1"; // Send 1 for the first payment and any number greater than 1 for the remaining payments.
            //$interchangeData->RequestAdvice = "1"; 
                        
            //Any time BillPayInd is set to either "DeferredBilling", "Installment" or "Recurring", CustomerPresent should be set to "BillPayment"
            if($interchangeData->BillPayment == "Installment" or $interchangeData->BillPayment == "DeferredBilling" or $interchangeData->BillPayment == "Recurring")
            $transactionData->CustomerPresent = 'BillPayment';
        
            $transactionData->InterchangeData = $interchangeData;
            */
        }

        //$transactionData->CFeeAmount=sprintf("%0.2f",$data['convenience_fee']);
    
        return $transactionData;
    }


/*
 *
 * Build a bankcardtransaction on the provided data.
 *
 */

    private function buildTransactionXML($credit_info, $trans_info)
    {
        $trans =
        '<transaction i:type="b:BankcardTransactionPro" xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard/Pro">'.
                '<a:CustomerData i:nil="true"/>';
        if ($trans_info->ReportingData != null) {
            $trans = $trans.'<a:ReportingData>';
            if (isset($trans_info->ReportingData->Comments)) {
                $trans.='<a:Comments>'.$trans_info->ReportingData->Comments.'</a:Comments>';
            }
            if (isset($trans_info->ReportingData->Description)) {
                    $trans.='<a:Description>'.$trans_info->ReportingData->Description.'</a:Description>';
            }
            if (isset($trans_info->ReportingData->Reference)) {
                $trans.='<a:Reference>'.$trans_info->ReportingData->Reference.'</a:Reference>';
            }
            $trans.='</a:ReportingData>';
        }

                '<a:ReportingData i:nil="true"/>';
        if ($trans_info->Creds != null) {
            $trans = $trans.'<Addendum>'.
                            '<Any>'.
                                '<string>'.$trans_info->Creds.'</string>'.
                            '</Any>'.
                        '</Addendum>';
        }
        $trans = $trans.'<ApplicationConfigurationData i:nil="true" xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard"/>'.
                '<TenderData xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">';
        if ($credit_info->paymentAccountDataToken != '') {
            $trans = $trans.'<a:PaymentAccountDataToken>'.$credit_info->paymentAccountDataToken.'</a:PaymentAccountDataToken>';
        }
        if ($credit_info->paymentAccountDataToken == '') {
            $trans = $trans.
                    '<CardData>'.
                        '<CardType>'.$credit_info->type.'</CardType>'.
                        '<CardholderName>'.$credit_info->name.'</CardholderName>'.
                        '<PAN>'.$credit_info->number.'</PAN>'.
                        '<Expire>'.$credit_info->expiration.'</Expire>'.
                        '<Track1Data>'.$credit_info->track1.'</Track1Data>'.
                        '<Track2Data>'.$credit_info->track2.'</Track2Data>'.
                    '</CardData>';
        }
        if ($credit_info->zip != '' or $credit_info->cvv != '') {
            $trans = $trans.'<CardSecurityData>';
            if ($credit_info->zip != '') {
                $trans = $trans.'<AVSData>'.
                            '<CardholderName>'.$credit_info->name.'</CardholderName>'.
                            '<Street>'.$credit_info->address.'</Street>'.
                            '<City>'.$credit_info->city.'</City>'.
                            '<StateProvince>'.$credit_info->state.'</StateProvince>'.
                            '<PostalCode>'.$credit_info->zip.'</PostalCode>'.
                            '<Country>'.$credit_info->country.'</Country>'.
                            '<Phone>'.$credit_info->phone.'</Phone>'.
                        '</AVSData>';
            }
            if ($credit_info->cvv != '') {
                $trans = $trans.
                '<CVDataProvided>Provided</CVDataProvided>'.
                '<CVData>'.$credit_info->cvv.'</CVData>';
            }
            $trans = $trans.
                    '</CardSecurityData>';
        }
        $trans = $trans.'<EcommerceSecurityData i:nil="true"/>'.
                '</TenderData>'.
                '<TransactionData i:type="b:BankcardTransactionDataPro" xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">';

        $trans = $trans. '<a:Amount>'.sprintf("%0.2f", $trans_info->Amount).'</a:Amount>';
        $trans = $trans.'<a:CurrencyCode>'.$trans_info->CurrencyCode.'</a:CurrencyCode>'.
                    '<a:TransactionDateTime>'.$trans_info->DateTime.'</a:TransactionDateTime>';
        if ($trans_info->AccountType != '') {
            $trans = $trans. '<AccountType>'.$trans_info->AccountType.'</AccountType>';
        }
        if ($trans_info->AltMerchantData != null) {
            $trans = $trans.'<AlternativeMerchantData>'.
                        '<a:CustomerServiceInternet>'.$trans_info->AltMerchantData->CustomerServiceInternet.'</a:CustomerServiceInternet>'.
                        '<a:CustomerServicePhone>'.$trans_info->AltMerchantData->CustomerServicePhone.'</a:CustomerServicePhone>'.
                        '<a:Description>'.$trans_info->AltMerchantData->Description.'</a:Description>'.
                        '<a:SIC>'.$trans_info->AltMerchantData->SIC.'</a:SIC>'.
                        '<a:Address>'.
                            '<a:Street1>'.$trans_info->AltMerchantData->Address->Street1.'</a:Street1>'.
                            '<a:Street2>'.$trans_info->AltMerchantData->Address->Street2.'</a:Street2>'.
                            '<a:City>'.$trans_info->AltMerchantData->Address->City.'</a:City>'.
                            '<a:StateProvince>'.$trans_info->AltMerchantData->Address->StateProvince.'</a:StateProvince>'.
                            '<a:PostalCode>'.$trans_info->AltMerchantData->Address->PostalCode.'</a:PostalCode>'.
                            '<a:CountryCode>'.$trans_info->AltMerchantData->Address->PostalCode.'</a:CountryCode>'.
                        '</a:Address>'.
                        '<a:MerchantId>'.$trans_info->AltMerchantData->MerchantId.'</a:MerchantId>'.
                        '<a:Name>'.$trans_info->AltMerchantData->Name.'</a:Name>'.
                    '</AlternativeMerchantData>';
        }

        if ($trans_info->ApprovalCode != '') {
            $trans = $trans. '<ApprovalCode>'.$trans_info->ApprovalCode.'</ApprovalCode>';
        }
        if ($trans_info->CashBackAmount != '') {
            $trans = $trans. '<CashBackAmount>'.sprintf("%0.2f", $trans_info->CashBackAmount).'</CashBackAmount>';
        }
        $trans = $trans.'<CustomerPresent>'.$trans_info->CustomerPresent.'</CustomerPresent>';
        if ($trans_info->IndustryType != 'Ecommerce') {
            $trans = $trans.'<EmployeeId>'.$trans_info->EmployeeId.'</EmployeeId>';
        }
        $trans = $trans.'<EntryMode>'.$trans_info->EntryMode.'</EntryMode>';
        $trans = $trans.'<GoodsType>'.$trans_info->GoodsType.'</GoodsType>'.
                    '<IndustryType>'.$trans_info->IndustryType.'</IndustryType>';
        if (isset($trans_info->InternetTransactionData) && $trans_info->InternetTransactionData != null) {
            $trans = $trans.'<InternetTransactionData i:nil="true"/>';
        }
        $trans = $trans.'<InvoiceNumber>'.$trans_info->InvoiceNumber.'</InvoiceNumber>'.
                    '<OrderNumber>'.$trans_info->OrderNumber.'</OrderNumber>'.
                    '<IsPartialShipment>false</IsPartialShipment>'.
                    '<SignatureCaptured>'.$trans_info->SignatureCaptured.'</SignatureCaptured>';
        if (isset($trans_info->TerminalId) &&  $trans_info->TerminalId != '') {
            $trans = $trans.'<TerminalId>'.$trans_info->TerminalId.'</TerminalId>';
        }
        if ($trans_info->FeeAmount != '0.00') {
            $trans = $trans.'<FeeAmount>'.sprintf("%0.2f", $trans_info->FeeAmount).'</FeeAmount>';
        }
        if (isset($trans_info->LaneId) && $trans_info->LaneId != '') {
            $trans = $trans.'<LaneId>'.$trans_info->LaneId.'</LaneId>';
        }
        $trans = $trans.'<TipAmount>'.sprintf("%0.2f", $trans_info->TipAmount).'</TipAmount>'.
                    '<BatchAssignment i:nil="true"/>'.
                    '<b:ManagedBilling i:nil="true"/>'.
                    '<b:Level2Data i:nil="true"/>'.
                    '<b:LineItemDetails i:nil="true"/>'.
                    '<b:PINlessDebitData i:nil="true"/>'.
                    '</TransactionData>';
        if (isset($trans_info->InterchangeData) && $trans_info->InterchangeData != '') {
            $trans = $trans.'<b:InterchangeData>';
            if ($trans_info->InterchangeData->BillPayment != '') {
                $trans = $trans.'<b:BillPayment>'.$trans_info->InterchangeData->BillPayment.'</b:BillPayment>';
            }
    
            if ($trans_info->InterchangeData->RequestCommercialCard != '') {
                $trans = $trans.'<b:RequestCommercialCard>'.$trans_info->InterchangeData->RequestCommercialCard.'</b:RequestCommercialCard>';
            }
    
            if ($trans_info->InterchangeData->ExistingDebt != '') {
                $trans = $trans.'<b:ExistingDebt>'.$trans_info->InterchangeData->ExistingDebt.'</b:ExistingDebt>';
            }
    
            if ($trans_info->InterchangeData->RequestACI != '') {
                $trans = $trans.'<b:RequestACI>'.$trans_info->InterchangeData->RequestACI.'</b:RequestACI>';
            }
    
            if ($trans_info->InterchangeData->TotalNumberOfInstallments != '') {
                $trans = $trans.'<b:TotalNumberOfInstallments>'.$trans_info->InterchangeData->TotalNumberOfInstallments.'</b:TotalNumberOfInstallments>';
            }
    
            if ($trans_info->InterchangeData->CurrentInstallmentNumber != '') {
                $trans = $trans.'<b:CurrentInstallmentNumber>'.$trans_info->InterchangeData->CurrentInstallmentNumber.'</b:CurrentInstallmentNumber>';
            }
    
            if ($trans_info->InterchangeData->RequestAdvice != '') {
                $trans = $trans.'<b:RequestAdvice>'.$trans_info->InterchangeData->RequestAdvice.'</b:RequestAdvice>';
            }
    
            $trans = $trans.'</b:InterchangeData>';
        } else {
            $trans = $trans.'<b:InterchangeData i:nil="true"/>';
        }
                    $trans = $trans.'</transaction>';
        return $trans;
    }

/*
 *
 * Build a CaptureDifferenceData object on the provided data.
 *
 */
    private function buildCaptureXML($captureDiffData, $creds = '')
    {
        $capture = '<differenceData i:type="b:BankcardCapturePro" xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard/Pro">';
        if (is_array($captureDiffData->TransactionId)) {
            foreach ($captureDiffData->TransactionId as $txnId) {
                $capture = $capture.'<a:TransactionId>'.$txnId.'</a:TransactionId>';
            }
        } else {
            $capture = $capture.'<a:TransactionId>'.$captureDiffData->TransactionId.'</a:TransactionId>';
        }
        if ($creds != '') {
            $capture = $capture.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
        }
        $capture = $capture.'<Amount xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$captureDiffData->Amount.'</Amount>';
        if ($captureDiffData->ChargeType != '') {
            $capture = $capture.'<ChargeType xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$captureDiffData->ChargeType.'</ChargeType>';
        }
        if ($captureDiffData->ShipDate != '') {
            $capture = $capture.'<ShipDate xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$captureDiffData->ShipDate.'</ShipDate>';
        }
        if ($captureDiffData->TipAmount != '') {
            $capture = $capture.'<TipAmount xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$captureDiffData->TipAmount.'</TipAmount>';
        }
        if ($captureDiffData->MultiplePartialCapture != '') {
            $capture = $capture.'<b:MultiplePartialCapture>'.$captureDiffData->MultiPartialCapture.'</b:MultiplePartialCapture>';
        }
        $capture = $capture.'<b:Level2Data i:nil="true" xmlns:c="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard"/>'.
                '<b:LineItemDetails i:nil="true" xmlns:c="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard"/>'.
                '<b:ShippingData i:nil="true"/>'.
            '</differenceData>';
        return $capture;
    }


/*
 *
 * Build a CaptureDifferenceData object on the provided data.
 *
 */
    private function buildCaptureSelectiveXML($captureDiffData, $creds = '')
    {
        $capture = '<differenceData xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">';
        $i = 0;
        $count = count($captureDiffData->TransactionId);
        if (is_array($captureDiffData->TransactionId)) {
            for ($i = 0; $i < $count; $i++) {
                if ($captureDiffData->TransactionId[$i] != null) {
                    $capture = $capture.'<a:Capture i:type="b:BankcardCapture" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.
                    '<a:TransactionId>'.$captureDiffData->TransactionId[$i].'</a:TransactionId>';
                    if ($creds != '') {
                        $capture = $capture.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
                    }
                    $capture=$capture.'<b:Amount>'.$captureDiffData->Amount.'</b:Amount>';
                    if ($captureDiffData->ChargeType != null) {
                        $capture=$capture.'<b:ChargeType>'.$captureDiffData->ChargeType.'</b:ChargeType>';
                    }
                    if ($captureDiffData->ChargeType != null) {
                        $capture=$capture.'<b:ShipDate>'.$captureDiffData->ShipDate.'</b:ShipDate>';
                    }
                    if ($captureDiffData->ChargeType != null) {
                        $capture=$capture.'<b:TipAmount>'.$captureDiffData->TipAmount.'</b:TipAmount>';
                    }
                    $capture=$capture.'</a:Capture>';
                    $i++;
                } elseif ($captureDiffData->TransactionId[$i] == null) {
                    break;
                }
            }
            $capture=$capture.'</differenceData>';
        } else {
            $capture = '<differenceData xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">';
            $capture = $capture.'<a:Capture i:type="b:BankcardCapture" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.
                    '<a:TransactionId>'.$captureDiffData->TransactionId.'</a:TransactionId>';
            if ($creds != '') {
                $capture = $capture.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
            }
            $capture=$capture.'<b:Amount>'.$captureDiffData->Amount.'</b:Amount>';
            if ($captureDiffData->ChargeType != null) {
                $capture=$capture.'<b:ChargeType>'.$cap->ChargeType.'</b:ChargeType>';
            }
            if ($captureDiffData->ChargeType != null) {
                $capture=$capture.'<b:ShipDate>'.$captureDiffData->ShipDate.'</b:ShipDate>';
            }
            if ($captureDiffData->ChargeType != null) {
                $capture=$capture.'<b:TipAmount>'.$captureDiffData->TipAmount.'</b:TipAmount>';
            }
            $capture=$capture.'</a:Capture>';
            $capture=$capture.'</differenceData>';
        }

        return $capture;
    }


    private function buildTxnIdsXML($transactionIds)
    {

        $txnIds = '<transactionIds xmlns:a="http://schemas.microsoft.com/2003/10/Serialization/Arrays" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">';
        if (is_array($transactionIds)) {
            foreach ($transactionIds as $txnId) {
                if ($txnId != null) {
                    $txnIds = $txnIds.'<a:string>'.$txnId.'</a:string>';
                } elseif ($txnId == null) {
                    break;
                }
            }
        } else {
            $txnIds = $txnIds.'<a:string>'.$transactionIds.'</a:string>';
        }
        $txnIds=$txnIds.'</transactionIds>';
        return $txnIds;
    }

/*
 *
 * Build a ReturnDifferenceData object on the provided data.
 *
 */
    private function buildReturnByIdXML($returnDiffData, $creds = '')
    {

        $return = '<differenceData i:type="b:BankcardReturn" xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.
                '<a:TransactionId>'.$returnDiffData->TransactionId.'</a:TransactionId>';
        if ($creds != '') {
            $return = $return.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
        }
        $return = $return.'<a:TransactionDateTime>'.$returnDiffData->TransactionDateTime.'</a:TransactionDateTime>'.
                '<Amount xmlns="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.$returnDiffData->Amount.'</Amount>'.
            '</differenceData>';
        return $return;
    }


/*
 *
 * Build a ReturnDifferenceData object on the provided data.
 *
 */
    private function buildUndoXML($undoDiffData, $creds = '')
    {

        $undo = '<differenceData i:type="b:BankcardUndo" xmlns:a="http://schemas.ipcommerce.com/CWS/v2.0/Transactions" xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns:b="http://schemas.ipcommerce.com/CWS/v2.0/Transactions/Bankcard">'.
                '<a:TransactionId>'.$undoDiffData->TransactionId.'</a:TransactionId>';
        if ($creds != '') {
            $undo = $undo.'<Addendum>'.
                                            '<Any>'.
                                                '<string>'.$creds.'</string>'.
                                            '</Any>'.
                                        '</Addendum>';
        }
        if ($undoDiffData->PINDebitReason != null) {
            $undo = $undo.'<b:PINDebitReason>'.$undoDiffData->PINDebitReason.'</b:PINDebitReason>';
        }
        if ($undoDiffData->TenderData != null) {
            $undo = $undo.'<b:TenderData i:nil="true"/>';
        }
        $undo = $undo.'</differenceData>';
        return $undo;
    }
        



    private function setBCPMerchantProfile($data)
    {
        // BankCard Merchant Data Object
        $bankCardMerchData = new \BankcardMerchantData();
        // <!--type: string--> Optional - Required for FTPS and TSYS
        $bankCardMerchData->ABANumber = $data['aba'];
        // <!--type: string--> Optional - Required for FTPS and TSYS
        $bankCardMerchData->AgentChain = $data['chain'];
        // <!--type: string--> Optional - Required for FTPS and TSYS
        $bankCardMerchData->AgentBank = $data['bank'];
        // <!--type: string--> Optional - Required for FTPS and TSYS
        $bankCardMerchData->AcquirerBIN = $data['bin'];
        // <!--type: string--> Optional - Required for FTPS and TSYS
        $bankCardMerchData->Location = $data['locationid'];
        // <!--type: string--> Optional - Required for TSYS
        $bankCardMerchData->ReimbursementAttribute = 'X';
        // <!--type: string--> Optional - Required for TSYS
        $bankCardMerchData->SettlementAgent = '0001';
        // <!--type: string--> Optional - Required for TSYS
        $bankCardMerchData->SharingGroup = '0001';
        // <!--type: string--> Optional - Required for TSYS
        $bankCardMerchData->StoreId = '0001';
        // <!--type: string--> Optional - Required for TSYS
        $bankCardMerchData->SecondaryTerminalId = '751';
        // <!--type: string--> Optional - Required for TSYS
        $bankCardMerchData->TimeZoneDifferential = '707';
        // <!--type: string-- Ecommerce, MOTO, Restaurant, Retail> Optional
        $bankCardMerchData->IndustryType = Settings::IndustryType;
        // <!--type: string--> Required, Standard Industry Code
        $bankCardMerchData->SIC = $data['sic'];
        // <!--type: string-->
        $bankCardMerchData->ClientNumber = $data['clientid'];
        // <!--type: boolean-->
        $bankCardMerchData->Aggregator = Settings::Pro_IncludeAlternativeMerchantData;
        // <!--type: string-->
        $bankCardMerchData->TerminalId = $data['tid'];
        // Merchant Address Info Object
        $merchAddressInfo = new \AddressInfo();
        // <!--type: string-->
        $data['address']='Revo Payments';
        $data['city']='Miami';
        $data['state']='FL';
        $data['zip']='33100';
        $data['name']='Revo Merchant';
        $merchAddressInfo->Street1 = substr(str_replace(array('.','&'), '', $data['address']), 0, 23);
        // <!--type: string-->
        $merchAddressInfo->Street2 = "";
        // <!--type: string-->
        $merchAddressInfo->City = substr($data['city'], 0, 13);
        // <!--type: TypeStateProvince - enumeration: [NotSet,AL,AK,AS,AZ,AR,CA,CO,CT,DE,DC,FM,FL,GA,GU,HI,ID,IL,IN,IA,KS,KY,LA,ME,MH,MD,MA,MI,MN,MS,MO,MT,NE,NV,NH,NJ,NM,NY,NC,ND,MP,OH,OK,OR,PW,PA,PR,RI,SC,SD,TN,TX,UT,VT,VI,VA,WA,WV,WI,WY,AA,AE,AP,AB,BC,MB,NB,NF,NT,NS,NU,ON,PE,QC,SK,YK]-->
        $merchAddressInfo->StateProvince = substr(strtoupper($data['state']), 0, 2);
        // <!--type: string-->
        $merchAddressInfo->PostalCode = substr($data['zip'], 0, 5);
        // <!--type: TypeISOCountryCodeA3 - enumeration: [NotSet,AFG,ALA,ALB,DZA,ASM,AND,AGO,AIA,ATA,ATG,ARG,ARM,ABW,AUS,AUT,AZE,BHS,BHR,BGD,BRB,BLR,BEL,BLZ,BEN,BMU,BTN,BOL,BIH,BWA,BVT,BRA,IOT,BRN,BGR,BFA,BDI,KHM,CMR,CAN,CPV,CYM,CAF,TCD,CHL,CHN,CXR,CCK,COL,COM,COG,COD,COK,CRI,CIV,HRV,CUB,CYP,CZE,DNK,DJI,DMA,DOM,ECU,EGY,SLV,GNQ,ERI,EST,ETH,FLK,FRO,FJI,FIN,FRA,FXX,GUF,PYF,ATF,GAB,GMB,GEO,DEU,GHA,GIB,GRC,GRL,GRD,GLP,GUM,GTM,GGY,GIN,GNB,GUY,HTI,HMD,VAT,HND,HKG,HUN,ISL,IND,IDN,IRN,IRQ,IRL,IMN,ISR,ITA,JAM,JPN,JEY,JOR,KAZ,KEN,KIR,PRK,KOR,KWT,KGZ,LAO,LVA,LBN,LSO,LBR,LBY,LIE,LTU,LUX,MAC,MKD,MDG,MWI,MYS,MDV,MLI,MLT,MHL,MTQ,MRT,MUS,MYT,MEX,FSM,MDA,MCO,MNG,MNE,MSR,MAR,MOZ,MMR,NAM,NRU,NPL,NLD,ANT,NCL,NZL,NIC,NER,NGA,NIU,NFK,MNP,NOR,OMN,PAK,PLW,PSE,PAN,PNG,PRY,PER,PHL,PCN,POL,PRT,PRI,QAT,REU,ROU,RUS,RWA,SHN,KNA,LCA,SPM,VCT,WSM,SMR,STP,SAU,SEN,SRB,SCG,SYC,SLE,SGP,SVK,SVN,SLB,SOM,ZAF,SGS,ESP,LKA,SDN,SUR,SJM,SWZ,SWE,CHE,SYR,TWN,TJK,TZA,THA,TLS,TGO,TKL,TMP,TON,TTO,TUN,TUR,TKM,TCA,TUV,UGA,UKR,ARE,GBR,USA,UMI,URY,UZB,VUT,VEN,VNM,VGB,VIR,WLF,ESH,YEM,YUG,ZMB,ZWE]-->
        $merchAddressInfo->CountryCode = 'USA';
        // Merchant Transaction Data Object
        $merchantTxnDataDefaults = new \BankcardTransactionDataDefaults();
        // <!--type: TypeISOCurrencyCodeA3 - enumeration: [NotSet,AFN,ALL,DZD,USD,EUR,AOA,XCD,ARS,AMD,AWG,AUD,AZN,BSD,BHD,BDT,BBD,BYR,BZD,BMD,BTN,BOB,BOV,BAM,BWP,BRL,BND,BGN,XOF,BIF,KHR,CAD,CVE,KYD,CLP,CLF,CNY,COP,COU,KMF,XAF,CDF,CRC,HRK,CUP,CYP,CZK,DKK,DJF,DOP,EGP,SVC,ERN,EEK,ETB,FKP,FJD,GMD,GEL,GHS,GIP,GTQ,GNF,GWP,GYD,HTG,HNL,HKD,HUF,ISK,INR,IDR,XDR,IRR,IQD,ILS,JMD,JPY,JOD,KZT,KES,KPW,KRW,KWD,KGS,LAK,LVL,LBP,LSL,LRD,LYD,LTL,MOP,MKD,MGA,MWK,MYR,MVR,MTL,MRO,MUR,MXN,MXV,MDL,MNT,MAD,MZN,MMK,NAD,NPR,ANG,XPF,NZD,NIO,NGN,NOK,OMR,PKR,PAB,PGK,PYG,PEN,PHP,PLN,QAR,RON,RUB,RWF,SHP,WST,STD,SAR,RSD,SCR,SLL,SGD,SKK,SBD,SOS,ZAR,LKR,SDG,SRD,SZL,SEK,CHF,CHW,CHE,SYP,TWD,TJS,TZS,THB,TOP,TTD,TND,TRY,TMM,UGX,UAH,AED,GBP,USS,USN,UYU,UYI,UZS,VUV,VEF,VND,YER,ZMK,ZWD,XBA,XBB,XBC,XBD,XPD,XPT,XAG,XAU]-->
        $merchantTxnDataDefaults->CurrencyCode = 'USD';
        //  <!--type: CustomerPresent - enumeration: [NotSet,Present,Suspicious,BillPayment,Transponder,MOTO,VisaOpenNetworkTransaction,VisaCardPresentStripeUnreadable,MailFax,Ecommerce,TelARU,MOTOCC,VoiceResponse]-->
        $merchantTxnDataDefaults->CustomerPresent = Settings::CustomerPresent;
        // <!--type: RequestACI - enumeration: [NotSet,NotCPSMeritCapable,IsCPSMeritCapable,CPSMeritCapableIncAuth,PremierCustomer,RecurringInstallment]-->
        $merchantTxnDataDefaults->RequestACI = Settings::RequestACI;
        // <!--type : EntryMode - enumeration: [Keyed, TrackDataFromMSR] -->
        $merchantTxnDataDefaults->EntryMode = Settings::TxnData_EntryMode;
        // <!--type: RequestAdvice - enumeration: [NotSet,NotCapable,Capable]-->
        $merchantTxnDataDefaults->RequestAdvice = 'NotCapable';
        //
        // Merchant Profile Information Object
        //
        $merchantData = new \MerchantProfileMerchantData();
        // <!--type: string-->
        $merchantData->CustomerServiceInternet = 'customerservice@revopayments.com';
        // <!--type: string--> must be in the following format 111 2223333
        $merchantData->CustomerServicePhone = '305 2528297';
        // <!--type: TypeISOLanguageCodeA3 - enumeration: [NotSet,AAR,ABK,ACE,ACH,ADA,ADY,AFA,AFH,AFR,AIN,AKA,AKK,ALB,ALE,ALG,ALT,AMH,ANG,ANP,APA,ARA,ARC,ARG,ARM,ARN,ARP,ARW,ASM,AST,ATH,AUS,AVA,AVE,AWA,AYM,AZE,BAD,BAI,BAK,BAL,BAM,BAN,BAQ,BAS,BAT,BEJ,BEL,BEM,BEN,BER,BHO,BIH,BIK,BIN,BIS,BLA,BNT,BOD,BOS,BRA,BRE,BTK,BUA,BUG,BUL,BUR,BYN,CAD,CAI,CAR,CAT,CAU,CEB,CEL,CES,CHA,CHB,CHE,CHG,CHI,CHK,CHM,CHN,CHO,CHP,CHR,CHU,CHV,CHY,CMC,COP,COR,COS,CPE,CPF,CPP,CRE,CRH,CRP,CSB,CUS,CYM,CZE,DAK,DAN,DAR,DAY,DEL,DEN,DEU,DGR,DIN,DIV,DOI,DRA,DSB,DUA,DUM,DUT,DYU,DZO,EFI,EGY,EKA,ELL,ELX,ENG,ENM,EPO,EST,EUS,EWE,EWO,FAN,FAO,FAS,FAT,FIJ,FIL,FIN,FIU,FON,FRA,FRE,FRM,FRO,FRR,FRS,FRY,FUL,FUR,GAA,GAY,GBA,GEM,GEO,GER,GEZ,GIL,GLA,GLE,GLG,GLV,GMH,GOH,GON,GOR,GOT,GRB,GRC,GRE,GRN,GSW,GUJ,GWI,HAI,HAT,HAU,HAW,HEB,HER,HIL,HIM,HIN,HIT,HMN,HMO,HRV,HSB,HUN,HUP,HYE,IBA,IBO,ICE,IDO,III,IJO,IKU,ILE,ILO,INA,INC,IND,INE,INH,IPK,IRA,IRO,ISL,ITA,JAV,JBO,JPN,JPR,JRB,KAA,KAB,KAC,KAL,KAM,KAN,KAR,KAS,KAT,KAU,KAW,KAZ,KBD,KHA,KHI,KHM,KHO,KIK,KIN,KIR,KMB,KOK,KOM,KON,KOR,KOS,KPE,KRC,KRL,KRO,KRU,KUA,KUM,KUR,KUT,LAD,LAH,LAM,LAO,LAT,LAV,LEZ,LIM,LIN,LIT,LOL,LOZ,LTZ,LUA,LUB,LUG,LUI,LUN,LUO,LUS,MAC,MAD,MAG,MAH,MAI,MAK,MAL,MAN,MAO,MAP,MAR,MAS,MAY,MDF,MDR,MEN,MGA,MIC,MIN,MKD,MKH,MLG,MLT,MNC,MNI,MNO,MOH,MOL,MON,MOS,MRI,MSA,MUN,MUS,MWL,MWR,MYA,MYN,MYV,NAH,NAI,NAP,NAU,NAV,NBL,NDE,NDO,NDS,NEP,NEW,NIA,NIC,NIU,NLD,NNO,NOB,NOG,NON,NOR,NQO,NSO,NUB,NWC,NYA,NYM,NYN,NYO,NZI,OCI,OJI,ORI,ORM,OSA,OSS,OTA,OTO,PAA,PAG,PAL,PAM,PAN,PAP,PAU,PEO,PER,PHI,PHN,PLI,POL,PON,POR,PRA,PRO,PUS,QUE,RAJ,RAP,RAR,ROA,ROH,ROM,RON,RUM,RUN,RUP,RUS,SAD,SAG,SAH,SAI,SAL,SAM,SAN,SAS,SAT,SCC,SCN,SCO,SCR,SEL,SEM,SGA,SGN,SHN,SID,SIN,SIO,SIT,SLA,SLK,SLO,SLV,SMA,SME,SMI,SMJ,SMN,SMO,SMS,SNA,SND,SNK,SOG,SOM,SON,SOT,SPA,SQI,SRD,SRN,SRP,SRR,SSA,SSW,SUK,SUN,SUS,SUX,SWA,SWE,SYR,TAH,TAI,TAM,TAT,TEL,TEM,TER,TET,TGK,TGL,THA,TIB,TIG,TIR,TIV,TKL,TLH,TLI,TMH,TOG,TON,TPI,TSI,TSN,TSO,TUK,TUM,TUP,TUR,TUT,TVL,TWI,TYV,UDM,UGA,UIG,UKR,UMB,URD,UZB,VAI,VEN,VIE,VOL,VOT,WAK,WAL,WAR,WAS,WEL,WEN,WLN,WOL,XAL,XHO,YAO,YAP,YID,YOR,YPK,ZAP,ZEN,ZHA,ZHO,ZND,ZUL,ZUN,ZZA]-->
        $merchantData->Language = 'ENG';
        // <!--type: string-->
        $merchantData->Address = $merchAddressInfo;
        // <!--type: string-->
        $merchantData->MerchantId = $data['mid'];
        // <!--type: string-->
        $merchantData->Name = $data['name'];
        // <!--type: string--> must be in the following format 111 2223333
        $merchantData->Phone = '305 2528297';
        $merchantData->BankcardMerchantData = $bankCardMerchData;
        // Merchant Profile Transaction Data Object
        $txnData = new \MerchantProfileTransactionData();
        $txnData->BankcardTransactionDataDefaults = $merchantTxnDataDefaults;
        // Create Merchant Profile object
        $merchProfile = new \MerchantProfile();
        // <!--type: string-->
        $merchProfile->ProfileId = substr('R'.date('His').'_'.substr($data['clientid'], -6), 0, 15);
        // <!--type: string-->
        $merchProfile->LastUpdated = date('Y-m-d');
        $merchProfile->MerchantData = $merchantData;
        $merchProfile->TransactionData = $txnData;
    
        return $merchProfile;
    }


    /*
     * Function to create BCP MerchantProfile XML
    */
    private function createMerchantProfileXML($merchProfileData)
    {
        $merchantProfileXML =
        '<MerchantProfile>'.
        '<ProfileId>'.$merchProfileData->ProfileId.'</ProfileId>'.
        '<LastUpdated>'.$merchProfileData->LastUpdated.'</LastUpdated>'.
        '<MerchantData>'.
        '<CustomerServiceInternet>'.$merchProfileData->MerchantData->CustomerServiceInternet.'</CustomerServiceInternet>'.
        '<CustomerServicePhone>'.$merchProfileData->MerchantData->CustomerServicePhone.'</CustomerServicePhone>'.
        '<Language>'.$merchProfileData->MerchantData->Language.'</Language>'.
        '<Address>'.
        '<Street1>'.$merchProfileData->MerchantData->Address->Street1.'</Street1>'.
        '<Street2>'.$merchProfileData->MerchantData->Address->Street2.'</Street2>'.
        '<City>'.$merchProfileData->MerchantData->Address->City.'</City>'.
        '<StateProvince>'.substr(strtoupper($merchProfileData->MerchantData->Address->StateProvince), 0, 2).'</StateProvince>'.
        '<PostalCode>'.$merchProfileData->MerchantData->Address->PostalCode.'</PostalCode>'.
        '<CountryCode>'.$merchProfileData->MerchantData->Address->CountryCode.'</CountryCode>'.
        '</Address>'.
        '<MerchantId>'.$merchProfileData->MerchantData->MerchantId.'</MerchantId>'.
        '<Name>'.substr($merchProfileData->MerchantData->Name, 0, 15).'</Name>'.
        '<Phone>'.$merchProfileData->MerchantData->Phone.'</Phone>'.
        '<TaxId>'.$merchProfileData->MerchantData->TaxId.'</TaxId>'.
        '<BankcardMerchantData>'.
        '<ABANumber>'.$merchProfileData->MerchantData->BankcardMerchantData->ABANumber.'</ABANumber>'.
        '<AcquirerBIN>'.$merchProfileData->MerchantData->BankcardMerchantData->AcquirerBIN.'</AcquirerBIN>'.
        '<AgentBank>'.$merchProfileData->MerchantData->BankcardMerchantData->AgentBank.'</AgentBank>'.
        '<AgentChain>'.$merchProfileData->MerchantData->BankcardMerchantData->AgentChain.'</AgentChain>'.
        '<Aggregator>'.$merchProfileData->MerchantData->BankcardMerchantData->Aggregator.'</Aggregator>'.
        '<ClientNumber>'.$merchProfileData->MerchantData->BankcardMerchantData->ClientNumber.'</ClientNumber>'.
        '<IndustryType>'.$merchProfileData->MerchantData->BankcardMerchantData->IndustryType.'</IndustryType>'.
        '<Location>'.$merchProfileData->MerchantData->BankcardMerchantData->Location.'</Location>'.
        '<PrintCustomerServicePhone>false</PrintCustomerServicePhone>'.
        '<ReimbursementAttribute>'.$merchProfileData->MerchantData->BankcardMerchantData->ReimbursementAttribute.'</ReimbursementAttribute>'.
        '<SIC>'.$merchProfileData->MerchantData->BankcardMerchantData->SIC.'</SIC>'.
        '<SecondaryTerminalId>'.$merchProfileData->MerchantData->BankcardMerchantData->SecondaryTerminalId.'</SecondaryTerminalId>'.
        '<SettlementAgent>'.$merchProfileData->MerchantData->BankcardMerchantData->SettlementAgent.'</SettlementAgent>'.
        '<SharingGroup>'.$merchProfileData->MerchantData->BankcardMerchantData->SharingGroup.'</SharingGroup>'.
        '<StoreId>'.$merchProfileData->MerchantData->BankcardMerchantData->StoreId.'</StoreId>'.
        '<TerminalId>'.$merchProfileData->MerchantData->BankcardMerchantData->TerminalId.'</TerminalId>'.
        '<TimeZoneDifferential>'.$merchProfileData->MerchantData->BankcardMerchantData->TimeZoneDifferential.'</TimeZoneDifferential>'.
        '</BankcardMerchantData>'.
        '<ElectronicCheckingMerchantData i:nil="true"/>'.
        '</MerchantData>'.
        '<TransactionData>'.
        '<BankcardTransactionDataDefaults>'.
        '<CurrencyCode>'.$merchProfileData->TransactionData->BankcardTransactionDataDefaults->CurrencyCode.'</CurrencyCode>'.
        '<CustomerPresent>'.$merchProfileData->TransactionData->BankcardTransactionDataDefaults->CustomerPresent.'</CustomerPresent>'.
        '<EntryMode>'.$merchProfileData->TransactionData->BankcardTransactionDataDefaults->EntryMode.'</EntryMode>'.
        '<RequestACI>'.$merchProfileData->TransactionData->BankcardTransactionDataDefaults->RequestACI.'</RequestACI>'.
        '<RequestAdvice>'.$merchProfileData->TransactionData->BankcardTransactionDataDefaults->RequestAdvice.'</RequestAdvice>'.
        '</BankcardTransactionDataDefaults>'.
        '</TransactionData>'.
        '</MerchantProfile>';
    
        return $merchantProfileXML;
    }
}
