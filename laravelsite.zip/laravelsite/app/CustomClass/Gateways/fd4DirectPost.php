<?php
namespace App\CustomClass;

//transaction_type = 00 -> run transaction
//transaction_type = 01 -> verify transaction
////transaction_type = 34 -> refund transaction
//transaction_type = 33 -> void transaction
 
require_once('fd4.class.php');

class fd4DirectPost extends fd4
{
    private $level3= array();
    private $items= array();
    
    
    private $amount=0;
    private $transaction_type;
    private $UMcard;
    private $UMexpir;
    private $UMname;
    private $UMstreet;
    private $UMzip;
    private $UMstate;
    private $UMcity;
    private $transarmor_token;
    private $UMcvv2;
    private $credit_card_type;
    private $trans_id;
    private $reference_no;
    private $total_tax_amount;
    private $ship_to_address;
    //item information
    private $description;
    private $discount;
    private $code;
    private $total;
    private $tax_rate;
    private $qty;
    private $price;
    private $tax;
    private $statesh= array("AL","AK","AZ","AR","CA","CO","CT","DE","DC","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","MA","ME","MD","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY","PR");
            
    
    
    /*
     * The $query_string property is a properly formatted name-value-pair string
     */
    private $query_string;

    /*
     * @param array $options
     * - fd4_url
     * - fd4_user
     * - fd4_password
     */
    public function __construct($options = array())
    {
        parent::__construct($options);
    }

    public function setAmount($amount)
    {
        $this->amount=$amount;
    }
    
    public function setCcNumber($cc_number)
    {
        $this->UMcard=$cc_number;
    }
    
    public function setExpireDate($cc_expiry)
    {
        $this->UMexpir=$cc_expiry;
    }
    
    public function setName($cardholder_name)
    {
        $this->UMname=$cardholder_name;
    }
    
    public function setAddress($address)
    {
        $this->UMstreet=$address;
    }

    public function setZip($zip_code)
    {
        $this->UMzip=$zip_code;
    }
    
    public function setCity($city)
    {
        $this->UMcity=$city;
    }
    
    public function setToken($text)
    {
        $this->transarmor_token=$text;
    }
    public function setState($state)
    {
        $this->UMstate=$state;
    }
    
    public function setCc_verification_str1($cc_verification_str1)
    {
        $this->cc_verification_str1=$cc_verification_str1;
    }
    
    public function setCvv2($cvv2)
    {
        $this->UMcvv2=$cvv2;
    }
    
    public function setCvd_presence_ind($cvd_presence_ind)
    {
        $this->cvd_presence_ind=$cvd_presence_ind;
    }
    
    public function setOrderId($customer_ref)
    {
        $this->trans_id=$customer_ref;
    }
    
    public function getReference_no()
    {
        return $this->reference_no;
    }
    
    public function setReference_no($reference_no)
    {
        $this->reference_no=$reference_no;
    }
    
    public function setEcommerce_flag($ecommerce_flag)
    {
        $this->ecommerce_flag=$ecommerce_flag;
    }
    
    public function setCredit_card_type($credit_card_type)
    {
        $this->credit_card_type=$credit_card_type;
    }
    
    public function setTax_range($tax_range)
    {
        $this->tax_rate=number_format($tax_range, 2);
    }
    
    function getTotal_tax_amount()
    {
        return $this->total_tax_amount;
    }

    function setTotal_tax_amount($total_tax_amount)
    {
        $this->total_tax_amount = $total_tax_amount;
    }

    public function getCalculateTax()
    {
        $this->tax=number_format(($this->qty*$this->price*$this->tax/100), 2);
        return number_format($this->tax, 2);
    }
    
    function getDescription()
    {
        return $this->description;
    }

    function getDiscount()
    {
        return $this->discount;
    }

    function getCode()
    {
        return $this->code;
    }

    function getQty()
    {
        return $this->qty;
    }

    function getPrice()
    {
        return $this->price;
    }
    
    function getTotal()
    {
        return $this->total;
    }

    function setTotal($total)
    {
        $this->total = number_format($total, 2, ".", "");
    }
        
    function setDescription($description)
    {
        if (empty($description)) {
            $description="General Services";
        }
        $this->description = $description;
    }

    function setDiscount($discount)
    {
        $this->discount = number_format($discount, 2);
    }

    function setCode($code)
    {
        $pdd=substr($code, 0, 12);
        if (!$pdd) {
            $pdd="empty";
        }
        $this->code = $pdd;
    }

    function setQty($qty)
    {
        $this->qty = $qty;
    }

    function setPrice($price)
    {
        $this->price = number_format($price, 2, '.', '');
    }

        
    public function addItem()
    {
        $this->items[]=array('commodity_code'=>'96101','description'=>$this->description,'discount_amount'=>  $this->discount,
                            'discount_indicator'=>0,'gross_net_indicator'=>0,'line_item_total'=>number_format($this->total, 2, '.', '')*1,
                            'product_code'=>$this->code,'quantity'=>$this->qty,'unit_cost'=> $this->price,'unit_of_measure'=>'ST',
                            'tax_rate'=>$this->tax_rate,'tax_type'=>'10','tax_amount'=>  $this->tax);
    }
    
    public function deleteItem($pos)
    {
        unset($this->items[$pos]);
    }
    
    public function getItemlist()
    {
        return $this->items;
    }
    
    public function getLevel3()
    {
        return $this->level3;
    }
    
    function getShip_to_address()
    {
        return $this->ship_to_address;
    }

    function setShip_to_address($name, $email_address)
    {
        $this->ship_to_address = array('address_1'=>$this->UMstreet,'city'=>strtoupper($this->UMcity),'state'=>$this->UMstate,'name'=>$name,'email'=>$email_address);
    }

        
    public function Sale()
    {
        $query_data=array();
        
        $query_data['gateway_id']=parent::getGatewayID();
        $query_data['password']=  parent::getPassword();
        $query_data['transaction_type']='00';
        $query_data['amount']=str_replace(",", "", sprintf("%0.2f", $this->amount));
        $query_data['cc_number']=trim($this->UMcard);
        $umexpira=trim(str_replace(array('/','-'), '', $this->UMexpir));
        if (trim($umexpira)<4) {
            $umexpira=str_pad($umexpira, 4, '0', STR_PAD_LEFT);
        }
        $query_data['cc_expiry']=$umexpira;
        $umname = str_replace(array('&','<','>','|',',',';','*','/','+','-','^',"`","'",'--'), '', $this->UMname);
        $umname = $this->avoidSpaceBug($umname);
        $query_data['cardholder_name']=substr($umname, 0, 30);
        $umaddress=substr(trim($this->UMstreet), 0, 50);
        $umaddress=str_replace(array('<','/','>','&'), '', $umaddress);
        if ($umaddress=='') {
            $umaddress='No Address';
        }
        $umzip=substr($this->UMzip, 0, 5);
        if (strlen($umzip)!=5) {
            $umzip='33130';
        }
        $umcity=trim($this->UMcity);
        if ($umcity=='') {
            $umcity='miami';
        }
        $umstate=trim($this->UMstate);
        if ($umstate=='') {
            $umstate='FL';
        }
        $query_data['cc_verification_str1']=substr($umaddress.'|'.$umzip.'|'.$umcity.'|'.$umstate, 0, 41);
        $query_data['cc_verification_str2']=trim($this->UMcvv2);
        $query_data['cvd_presence_ind']='1';
        $query_data['reference_no']=$this->reference_no;
        $query_data['zip_code']=$umzip;
        $query_data['customer_ref']=$this->trans_id;
        $query_data['ecommerce_flag']='7';
        $query_data['credit_card_type']=$this->credit_card_type;
        $query_data['tax1_amount']='0.00';
        
        //level3
        $this->level3['tax_amount']=0;
        if (!empty($this->total_tax_amount)) {
            $this->level3['tax_amount']=str_replace(',', '', $this->total_tax_amount);
        };
        
        $this->level3['discount_amount']='0.00';
        $this->level3['duty_amount']='0.00';
        $this->level3['freight_amount']='0.00';
        $this->level3['tax_rate']='0.00';
        
        $this->level3['line_items']=$this->getItemlist();
        $this->level3['ship_to_address']=$this->getShip_to_address();
        if (count($this->level3['line_items'])>0) {
            $query_data['level3']=  $this->level3;
            if (isset($this->level3['tax_amount'])) {
                $query_data['tax1_amount']=$this->level3['tax_amount'];
            }
        }
        $tosend_data=json_encode($query_data);
        $respond=$this->execute($tosend_data);
        $response=$this->parseResponse($respond);
        $result=array();
        $result['response']=$this->getResponse($response);
        $result['responsetext']=$this->getResponseText($response);
        if ($result['response']==1) {
            $result['authcode']=$response['authorization_num'];
        }
        if (isset($response['exact_message'])) {
            $result['exact_message']=$response['exact_message'];
        }
        if (isset($response['avs'])) {
            $result['avsresponse'] =$response['avs'];
        }
        if (isset($response['cvv2'])) {
            $result['cvvresponse']=$response['cvv2'];
        }
        
        if (isset($response['transaction_tag'])) {
            $result['reference']=$response['transaction_tag'];
        } else {
            $result['reference']='';
        }
        return $result;
    }
    
    public function AuthToken()
    {
        $query_data=array();
        $query_data['gateway_id']=parent::getGatewayID();
        $query_data['password']=parent::getPassword();
        list($token,$expdate)=explode(":|", $this->transarmor_token);
        $query_data['transaction_type']='00';
        $query_data['amount']=$this->amount;
        $query_data['cc_number']='';
        $query_data['cc_expiry']=$expdate;
       // error_log($this->UMname, 3, "/var/tmp/my-errors.log");
        $umname = str_replace(array('&','<','>','|',',',';','*','/','+','-','^',"`","'",'--'), '', $this->UMname);
        $query_data['cardholder_name']=substr($umname, 0, 30);
        $umaddress=substr(trim($this->UMstreet), 0, 50);
        $umaddress=str_replace(array('<','/','>','&'), '', $umaddress);
        if ($umaddress=='') {
            $umaddress='No Address';
        }
        $umzip=substr($this->UMzip, 0, 5);
        if (strlen($umzip)!=5) {
            $umzip='33130';
        }
        $umcity=trim($this->UMcity);
        if ($umcity=='') {
            $umcity='miami';
        }
        $umstate=trim($this->UMstate);
        if (!in_array($umstate, $this->statesh)) {
            $umstate='FL';
        }
        $query_data['reference_no']=$this->trans_id;
        $query_data['zip_code']=$umzip;
        $query_data['customer_ref']=$this->trans_id;
        $query_data['ecommerce_flag']='7';
        $query_data['credit_card_type']=$this->credit_card_type;
        $query_data['transarmor_token']=$token;
        $tosend_data=json_encode($query_data);
        $respond=$this->execute($tosend_data);
        $response=$this->parseResponse($respond);
       // error_log($response, 3, "/var/tmp/my-errors.log");
        $result=array();
        $result['response']=$this->getResponse($response);
        $result['responsetext']=$this->getResponseText($response);
        if ($result['response']==1) {
            $result['authcode']=$response['authorization_num'];
        }
        if (isset($response['exact_message'])) {
            $result['exact_message']=$response['exact_message'];
        }
        if (isset($response['avs'])) {
            $result['avsresponse'] =$response['avs'];
        }
        if (isset($response['cvv2'])) {
            $result['cvvresponse']=$response['cvv2'];
        }
        
        if (isset($response['transaction_tag'])) {
            $result['reference']=$response['transaction_tag'];
        } else {
            $result['reference']='';
        }
        return $result;
    }
    
    public function Verify()
    {
        $query_data=array();
        $query_data['gateway_id']=parent::getGatewayID();
        $query_data['password']=parent::getPassword();
        $query_data['transaction_type']='01';
        $query_data['amount']=0;
        $query_data['cc_number']=trim($this->UMcard);
        $umexpira=trim(str_replace(array('/','-'), '', $this->UMexpir));
        if (trim($umexpira)<4) {
            $umexpira=str_pad($umexpira, 4, '0', STR_PAD_LEFT);
        }
        $query_data['cc_expiry']=$umexpira;
        $umname = str_replace(array('&','<','>','|',',',';','*','/','+','-','^',"`","'",'--'), '', $this->UMname);
        $umname = $this->avoidSpaceBug($umname);
        $query_data['cardholder_name']=substr($umname, 0, 30);
        $umaddress=substr(trim($this->UMstreet), 0, 50);
        $umaddress=str_replace(array('<','/','>','&'), '', $umaddress);
        if ($umaddress=='') {
            $umaddress='No Address';
        }
        $umzip=substr($this->UMzip, 0, 5);
        if (strlen($umzip)!=5) {
            $umzip='33130';
        }
        $umcity=trim($this->UMcity);
        if ($umcity=='') {
            $umcity='miami';
        }
        $umstate=trim($this->UMstate);
        if ($umstate=='') {
            $umstate='FL';
        }
        $query_data['cc_verification_str1']=substr($umaddress.'|'.$umzip.'|'.$umcity.'|'.$umstate, 0, 41);
        $query_data['cc_verification_str2']=trim($this->UMcvv2);
        $query_data['cvd_presence_ind']='1';
        $query_data['reference_no']=$this->trans_id;
        $query_data['zip_code']=$umzip;
        $query_data['customer_ref']=$this->trans_id;
        $query_data['ecommerce_flag']='7';
        $query_data['credit_card_type']=$this->credit_card_type;
        $tosend_data=json_encode($query_data);
        $respond=$this->execute($tosend_data);
        $response=$this->parseResponse($respond);
        $result=array();
        $result['response']=$this->getResponse($response);
        $result['responsetext']=$this->getResponseText($response);
        $result['token']='';
        if (!isset($response['transarmor_token'])) {
            $result['response']=3;
            $result['responsetext']='TransArmor feature need be activated';
        } else {
            $result['token']=$response['transarmor_token'].':|'.$umexpira;
        }
        return $result;
    }
    
    public function Refund($transid, $amount)
    {
        $query_data=array();
        $query_data['gateway_id']=parent::getGatewayID();
        $query_data['password']=parent::getPassword();
        if (!empty($transid)) {
            list($tag,$auth)=explode('--', $transid);
            $query_data['transaction_type']='34';
            $query_data['amount']=str_replace(",", "", sprintf("%0.2f", $amount));
            $query_data['transaction_tag']=$tag;
            $query_data['authorization_num']=$auth;
            $tosend_data=json_encode($query_data);
            $respond=$this->execute($tosend_data);
            $response=$this->parseResponse($respond);
            $result=array();
            $result['response']=$this->getResponse($response);
            $result['responsetext']=$this->getResponseText($response);
        } else {
            $result=array();
            $result['response']=3;
            $result['responsetext']='Invalid Transaction ID';
        }
        return $result;
    }
    
    public function Void($transid, $amount)
    {
        $query_data=array();
        $query_data['gateway_id']=parent::getGatewayID();
        $query_data['password']=parent::getPassword();
        if (!empty($transid)) {
            list($tag,$auth)=explode('--', $transid);
            $query_data['transaction_type']='33';
            $query_data['amount']=str_replace(",", "", sprintf("%0.2f", $amount));
            $query_data['transaction_tag']=$tag;
            $query_data['authorization_num']=$auth;
            $tosend_data=json_encode($query_data);
            $respond=$this->execute($tosend_data);
            $response=$this->parseResponse($respond);
            $result=array();
            $result['response']=$this->getResponse($response);
            $result['responsetext']=$this->getResponseText($response);
        } else {
            $result=array();
            $result['response']=3;
            $result['responsetext']='Invalid Transaction ID';
        }
        return $result;
    }
    
    private function getResponse($response)
    {
        $resultCode =0;
        if (isset($response['transaction_approved'])) {
            $resultCode = $response['transaction_approved'];
        }
        if ($resultCode == 1) { //approved transaction
               return 1;
        } else { //declined transaction
               return 3;
        }
    }
    
    private function getResponseText($response)
    {
        $msg=null;
        if (isset($response['bank_message'])) {
            $msg= $response['bank_message'];
        }
        if (empty($msg)) {
            if (isset($response['exact_message'])) {
                $msg=$response['exact_message'];
            } else {
                $msg='Possible Communication Error!';
            }
        }
        return $msg;
    }
    
    private function parseResponse($response_string)
    {
        $return_array = array();
        if (empty($response_string)) {
            return $return_array;
        }
        $r_pos=strpos($response_string, '{');
        if ($r_pos===false) {
            return $return_array;
        }
        $r_string=substr($response_string, $r_pos);
        $return_array=  json_decode($r_string, true);
        return $return_array;
    }
    
    private function avoidSpaceBug($umname)
    {
        $umname= str_replace(" ", "", $umname);
        return $umname;
    }
}
