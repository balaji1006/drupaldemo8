<?php
namespace App\CustomClass;

class tandem610
{
    private $url; //connection url
    private $authorization; //base64 encoded user:passwd
    private $host; //target host
    private $bin='1340';
    private $terminal='001';
    private $nrcode='000000'; //network routing code
    private $mid; //merchant id
    
    //payment info
    private $amount='0.00';
    private $track;
    private $card;
    private $exp;
    private $cvv;
    private $token;
    private $orderid;
    private $zip;
    private $b2b=false;
    private $routing;
    private $account;
    private $name;
    private $reference;
    
    public function __construct($options = array())
    {
        if (isset($options['gw_mid'])) {
            $this->mid=trim($options['gw_mid']);
        }
    }
    
    public function Sale()
    {
        if (empty($this->zip)) {
            $request='I2.'.$this->nrcode.'020023004000';
            $amt=number_format($this->amount, 2);
            $amt=str_replace(array(',','.'), '', $amt);
            $amt=str_pad($amt, 9, '0', STR_PAD_LEFT);
            $request.=$amt.date('mdyHis').substr($this->orderid, -6).date('mdyHis');
            if (empty($this->track)) {
                $request.='012';
            } else {
                $request.='812';
            }
            $request.=$this->bin.$this->terminal.substr($this->mid, 0, 12).'001';
            if (!empty($this->track)) {
                $data=str_pad($this->track, 76, ' ', STR_PAD_LEFT);
            } elseif (!empty($this->token)) {
                $data=str_pad($this->token.'=0000', 76, ' ', STR_PAD_LEFT);
            } else {
                $tdata=$this->card;
                if (!empty($this->exp)) {
                    $tdata.='='.$this->exp;
                    if (!empty($this->cvv)) {
                        $tdata.=$this->cvv;
                    }
                }
                $data=str_pad($tdata, 76, ' ', STR_PAD_LEFT);
            }
            $request.=$data.'00000000000000000000000000000040';
            $request.=str_pad($this->orderid, 20, ' ');
            $request.='000000000'.str_pad($this->orderid, 16, '0', STR_PAD_LEFT);
        } else {
            $request='I2.'.$this->nrcode.'020025524000';
            $amt=number_format($this->amount, 2);
            $amt=str_replace(array(',','.'), '', $amt);
            $amt=str_pad($amt, 9, '0', STR_PAD_LEFT);
            $request.=$amt.date('mdyHis').substr($this->orderid, -6).date('mdyHis');
            if (empty($this->track)) {
                $request.='012';
            } else {
                $request.='812';
            }
            $request.=$this->bin.$this->terminal.substr($this->mid, 0, 12).'001';
            if (!empty($this->track)) {
                $data=str_pad($this->track, 76, ' ', STR_PAD_LEFT);
            } elseif (!empty($this->token)) {
                $data=str_pad($this->token.'=0000', 76, ' ', STR_PAD_LEFT);
            } else {
                $tdata=$this->card;
                if (!empty($this->exp)) {
                    $tdata.='='.$this->exp;
                    if (!empty($this->cvv)) {
                        $tdata.=$this->cvv;
                    }
                }
                $data=str_pad($tdata, 76, ' ', STR_PAD_LEFT);
            }
            $request.=$data.'00000000000000000000';
            $request.='                    ';
            $request.=str_pad($this->zip, 9, ' ');
            $request.='40';
            if ($this->b2b) {
                $request.='9';
            } else {
                $request.='1';
            }
            $request.='0000000000000000000000';
            $request.=str_pad($this->orderid, 20, ' ');
            $request.=str_pad($this->orderid, 16, '0', STR_PAD_LEFT);
            $request.='W2ECHO               ';
            $request.='4 ';
            $request.='                                     ';
            $request.=str_pad('T'.$this->routing.'A'.$this->account.'C', 63, ' ');
            $request.=str_pad(strtoupper(substr($this->name, 0, 35)), 35, ' ');
        }
        $result=$this->sendRequest($request);
        //parse response
        $response=$this->parseResponse($result);
    }
    
    public function Void()
    {
        $request='I2.'.$this->nrcode.'040001                   ';
        $request.=date('mdyHis').substr($this->orderid, -6).date('mdyHis');
        $request.=$this->bin.$this->terminal.substr($this->mid, 0, 12).'001';
        $request.='0000000000000000000';
        $request.=$this->reference;
        $request.='40'.str_pad($this->orderid, 16, '0', STR_PAD_LEFT);
        $result=$this->sendRequest($request);
        //parse response
        $response=$this->parseResponse($result);
    }
    
    public function VoidCheck()
    {
    }
    
    public function Credit()
    {
        $request='I2.'.$this->nrcode.'020022204000';
        $amt=number_format($this->amount, 2);
        $amt=str_replace(array(',','.'), '', $amt);
        $amt=str_pad($amt, 9, '0', STR_PAD_LEFT);
        $request.=$amt.date('mdyHis').substr($this->orderid, -6).date('mdyHis');
        if (empty($this->track)) {
            $request.='012';
        } else {
            $request.='812';
        }
        $request.=$this->bin.$this->terminal.substr($this->mid, 0, 12).'001';
        if (!empty($this->track)) {
            $data=str_pad($this->track, 76, ' ', STR_PAD_LEFT);
        } elseif (!empty($this->token)) {
            $data=str_pad($this->token.'=0000', 76, ' ', STR_PAD_LEFT);
        } else {
            $tdata=$this->card;
            if (!empty($this->exp)) {
                $tdata.='='.$this->exp;
                if (!empty($this->cvv)) {
                    $tdata.=$this->cvv;
                }
            }
            $data=str_pad($tdata, 76, ' ', STR_PAD_LEFT);
        }
        $request.=$data.'00000000000000000000000000000040';
        $request.=str_pad($this->orderid, 20, ' ');
        $request.='000000000'.str_pad($this->orderid, 16, '0', STR_PAD_LEFT);
    }
    
    public function CheckSale()
    {
        $request='I2.'.$this->nrcode.'020032004000';
        $amt=number_format($this->amount, 2);
        $amt=str_replace(array(',','.'), '', $amt);
        $amt=str_pad($amt, 9, '0', STR_PAD_LEFT);
        $request.=$amt.date('mdyHis').substr($this->orderid, -6).date('mdyHis');
        if (empty($this->track)) {
            $request.='012';
        } else {
            $request.='812';
        }
        $request.=$this->bin.$this->terminal.substr($this->mid, 0, 12).'001';
        $request.='0000000000000000000000000000';
        $request.='          '.str_pad($this->zip, 9, ' ');
        $request.='40';
        $request.=str_pad($this->orderid, 20, ' ');
        $request.='000000000'.str_pad($this->orderid, 16, '0', STR_PAD_LEFT);
    }
    
    public function getToken()
    {
        $request='I2.'.$this->nrcode.'010050800000';
        $request.=date('mdyHis').substr($this->orderid, -6).date('mdyHis');
        if (empty($this->track)) {
            $request.='012';
        } else {
            $request.='812';
        }
            $request.='0000000300';
            $request.=$this->bin.$this->terminal.substr($this->mid, 0, 12).'001';
        if (!empty($this->track)) {
            $data=str_pad($this->track, 76, ' ', STR_PAD_LEFT);
        } else {
            $tdata=$this->card;
            if (!empty($this->exp)) {
                $tdata.='='.$this->exp;
                if (!empty($this->cvv)) {
                    $tdata.=$this->cvv;
                }
            }
            $data=str_pad($tdata, 76, ' ', STR_PAD_LEFT);
        }
            $request.=$data.'0000000000040'.str_pad($this->orderid, 16, '0', STR_PAD_LEFT).'99999999999999';
    }
    
    private function sendRequest($str)
    {
        $tpheader='BT';
        $slen=strlen($str);
        $slenh=str_pad($slen, 4, '0', STR_PAD_LEFT);
        $content='REQUEST='.$tpheader.$slenh.'000000000000000'.$str;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                'Host: '.$this->host,
                                'Connection: close',
                                'Authorization: Basic '.$this->authorization,
                                'Content-length: '.  strlen($content),
                                'Content-Type: application/x-www-form-urlencoded'
        ));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
        curl_setopt($ch, CURLOPT_TIMEOUT, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    
    private function parseResponse($text)
    {
        $data=array();
        $data['rcode']=substr($text, 0, 3);
        if ($data['rcode']=='000') {
            $message=substr($text, 26);
            $data['message_type']=substr($message, 0, 4);
            $data['type']=substr($message, 4, 2);
            if ($data['type']=='91') {
                //cc approval
                $data['pcode']=substr($message, 6, 6);
                $data['tdate']=substr($message, 12, 10);
                $data['stan']=substr($message, 22, 6);
                $data['reference']=substr($message, 28, 8);
                $data['authcode']=substr($message, 36, 6);
                $data['cavs']=substr($message, 42, 2);
                $data['psi']=substr($message, 44, 1);
                $data['transid']=substr($message, 45, 15);
                $data['visacode']=substr($message, 60, 4);
                $data['trace']=substr($message, 64, 16);
                $data['batch']=substr($message, 80, 6);
                $data['demo']=substr($message, 86, 1);
                $data['cardtype']=substr($message, 87, 4);
                $data['workingkey']=substr($message, 91, 16);
            } elseif ($data['type']=='99') {
                $data['stan']=substr($message, 6, 6);
                $data['cavs']=substr($message, 12, 2);
                $data['psi']=substr($message, 14, 1);
                $data['transid']=substr($message, 15, 15);
                $data['visacode']=substr($message, 30, 4);
                $data['trace']=substr($message, 34, 16);
                $data['text']=substr($message, 50, 20);
                $data['response']=substr($message, 70, 3);
                $data['workingkey']=substr($message, 73, 16);
            } elseif ($data['type']=='70') {
                //ec approval
                $data['pcode']=substr($message, 6, 6);
                $data['tdate']=substr($message, 12, 10);
                $data['stan']=substr($message, 22, 6);
                $data['reference']=substr($message, 28, 8);
                $data['authcode']=substr($message, 36, 6);
                $data['accountid']=substr($message, 42, 28);
                $data['checktype']=substr($message, 70, 1);
                $data['manager']=substr($message, 71, 8);
                $data['checknumber']=substr($message, 79, 6);
                $data['bdate']=substr($message, 85, 8);
                $data['trace']=substr($message, 93, 16);
                $data['batch']=substr($message, 109, 6);
                $data['demo']=substr($message, 115, 1);
                $data['cardtype']=substr($message, 116, 4);
                $data['response']=substr($message, 120, 3);
            } elseif ($data['type']=='71') {
                $data['stan']=substr($message, 6, 6);
                $data['trace']=substr($message, 12, 16);
                $data['text']=substr($message, 28, 20);
                $data['response']=substr($message, 48, 3);
            } elseif ($data['type']=='53') {
                $data['pcode']=substr($message, 6, 6);
                $data['tdate']=substr($message, 12, 10);
                $data['stan']=substr($message, 22, 6);
                $data['trace']=substr($message, 28, 16);
                $data['batch']=substr($message, 44, 6);
                $data['demo']=substr($message, 50, 1);
            }
        }
        return $data;
    }
}
