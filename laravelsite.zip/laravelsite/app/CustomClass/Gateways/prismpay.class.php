<?php

namespace App\CustomClass;

class prismpay
{

    private $Url = 'https://trans.myprismpay.com/cgi-bin/ProcessXML.cgi';
    private $TransactionName = ''; //Transaction Name
    private $AccountID = 'PYXG1'; //Merchant AccountID for prismpay
    private $Subid = 'COL99'; // Merchant Sub ID.
    private $Merchantpin = ''; //The 32 character Merchant PIN code generated from the Online Merchant Center.
    private $TransactionAmount; //Amount to pay
    /*
     * Credit Card
     */
    private $CardholderName; //Name on card
    private $CardNumber; //Card Number
    private $ExpirationMonth; //Expiry month for card
    private $ExpirationYear; //Expiry year for card
    private $HistoryId; //History Id
    private $OrderId; //Order Id
//Swipe
    private $Track2Data; //Swipe track2data
    /*
     * ACH
     */
    private $NameOnCheck; // First and Last Name
    private $CheckNumber;
    private $CheckType; //  SEC code for transaction (WEB, POP, ARC, PPD, ICL, RCK, BOC, TEL
    private $RoutingNumber;
    private $AccountNumber;
    /*
     * Profile
     */
    private $UserProfileID;
    private $Last4Digits; // Last 4 digit of account number
    /*
     * Settlement Report
     */
    private $EncryptionKey = '59345A76516D4272644851584E5A79577A56414D71744352';
    private $ReportingKey = 'B118FE1A55930EDC';

    private function CreditCardSale()
    {
//Function to make a Credit Card Sale

        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>2</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<ccname>' . $this->CardholderName . '</ccname>'
                . '<ccnum>' . $this->CardNumber . '</ccnum>'
                . '<expmon>' . $this->ExpirationMonth . '</expmon>'
                . '<expyear>' . $this->ExpirationYear . '</expyear>'
                . '<memo></memo>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
            $result['reference'] = $resultx['orderid'];
            $result['authcode'] = $resultx['historyid'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function CreditCardAuth()
    {
//Function to make a Credit Card Authentication

        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>30</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<ccname>' . $this->CardholderName . '</ccname>'
                . '<ccnum>' . $this->CardNumber . '</ccnum>'
                . '<expmon>' . $this->ExpirationMonth . '</expmon>'
                . '<expyear>' . $this->ExpirationYear . '</expyear>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($result['responsetext'] == 'Approved') {
            $result = $this->CreditCardSale();
            return $result;
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
            return $result;
        }
    }

    function CreditCardVoid()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>5</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<orderkeyid>' . $this->OrderId . '</orderkeyid>'
                . '<historykeyid>' . $this->HistoryId . '</historykeyid>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function CreditCardRefund()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>4</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<orderkeyid>' . $this->OrderId . '</orderkeyid>'
                . '<historykeyid>' . $this->HistoryId . '</historykeyid>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;

    }

    function SwipeSale()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>2</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<swipedata>' . $this->Track2Data . '</swipedata>'
                . '<memo></memo>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $resultx['responsetext'] = $resultx['status'];
        $result=array();
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
            $result['reference'] = $resultx['orderid'];
            $result['authcode'] = $resultx['historyid'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ACHSale()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>2</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<ckname>' . $this->NameOnCheck . '</ckname>'
                . '<ckaba>' . $this->RoutingNumber . '</ckaba>'
                . '<ckacct>' . $this->AccountNumber . '</ckacct>'
                . '<cktype>' . $this->CheckType . '</cktype>'
                . '<ckno>' . $this->CheckNumber . '</ckno>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
            $result['reference'] = $resultx['orderid'];
            $result['authcode'] = $resultx['historyid'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ACHVoid()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>5</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<orderkeyid>' . $this->OrderId . '</orderkeyid>'
                . '<historykeyid>' . $this->HistoryId . '</historykeyid>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ACHCreditRefund()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>4</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<orderkeyid>' . $this->OrderId . '</orderkeyid>'
                . '<historykeyid>' . $this->HistoryId . '</historykeyid>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ACHProfileAdd()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>7</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<ckname>' . $this->NameOnCheck . '</ckname>'
                . '<ckaba>' . $this->RoutingNumber . '</ckaba>'
                . '<ckacct>' . $this->AccountNumber . '</ckacct>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ACHProfileSale()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>8</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '<userprofileid>' . $this->UserProfileID . '</userprofileid>'
                . '<last4digits>' . $this->Last4Digits . '</last4digits>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
            $result['reference'] = $resultx['orderid'];
            $result['authcode'] = $resultx['historyid'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ProfileAddCreditCard()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>7</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<ccname>' . $this->CardholderName . '</ccname>'
                . '<ccnum>' . $this->CardNumber . '</ccnum>'
                . '<expmon>' . $this->ExpirationMonth . '</expmon>'
                . '<expyear>' . $this->ExpirationYear . '</expyear>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ProfileSaleCredit()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>8</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<userprofileid>' . $this->UserProfileID . '</userprofileid>'
                . '<last4digits>' . $this->Last4Digits . '</last4digits>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
            $result['reference'] = $resultx['orderid'];
            $result['authcode'] = $resultx['historyid'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function DeleteProfileCredit()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>10</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<userprofileid>' . $this->UserProfileID . '</userprofileid>'
                . '<last4digits>' . $this->Last4Digits . '</last4digits>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function UpdateProfile()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>9</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<userprofileid>' . $this->UserProfileID . '</userprofileid>'
                . '<last4digits>' . $this->Last4Digits . '</last4digits>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ProfileCredit()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>13</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<userprofileid>' . $this->UserProfileID . '</userprofileid>'
                . '<last4digits>' . $this->Last4Digits . '</last4digits>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<amount>' . $this->TransactionAmount . '</amount>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    function ProfileRetrive()
    {
        $request = '<?xml version="1.0"?>'
                . '<interface_driver>'
                . '<trans_catalog>'
                . '<transaction name="' . $this->TransactionName . '">'
                . '<inputs>'
                . '<service>12</service>'
                . '<acctid>' . $this->AccountID . '</acctid>'
                . '<subid>' . $this->Subid . '</subid>'
                . '<userprofileid>' . $this->UserProfileID . '</userprofileid>'
                . '<last4digits>' . $this->Last4Digits . '</last4digits>'
                . '<merchantpin>' . $this->Merchantpin . '</merchantpin>'
                . '<server_host>TestHost</server_host>'
                . '</inputs>'
                . '</transaction>'
                . '</trans_catalog>'
                . '</interface_driver>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        $result=array();
        $result['responsetext'] = $resultx['status'];
        if ($resultx['status'] == 'Approved') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['status'];
        } else {
            $result['response'] = 3;
            $error = str_replace(":", "-", $resultx['result']);
            $result['responsetext'] = $error;
        }
        return $result;
    }

    private function sendRequest($request)
    {
//function to send Requests to Vantiv
        $url = $this->Url;

        $header = array(
            "Content-type: application/xml",
            "Cache-Control: no-cache",
        );
        $ch = curl_init();

// set the target url
        curl_setopt($ch, CURLOPT_URL, $url);
// howmany parameter to post
        curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
//curl_setopt($ch, CURLOPT_VERBOSE, true);

        $result = curl_exec($ch);

        curl_close($ch);
        return $result;
    }

    private function parseResponse($str)
    {

        $xml = simplexml_load_string($str); // where $xml_string is the XML data you'd like to use (a well-formatted XML string). If retrieving from an external source, you can use file_get_contents to retrieve the data and populate this variable.
        $json = json_encode($xml); // convert the XML string to JSON
        $array = json_decode($json, TRUE);
        $result = $array['trans_catalog']['transaction']['outputs'];
        return $result;
    }

    /*
     * Getter Methods
     */

    function getUrl()
    {
        return $this->Url;
    }

    function getTransactionName()
    {
        return $this->TransactionName;
    }

    function getAccountID()
    {
        return $this->AccountID;
    }

    function getSubid()
    {
        return $this->Subid;
    }

    function getMerchantpin()
    {
        return $this->Merchantpin;
    }

    function getTransactionAmount()
    {
        return $this->TransactionAmount;
    }

    function getCardholderName()
    {
        return $this->CardholderName;
    }

    function getCardNumber()
    {
        return $this->CardNumber;
    }

    function getExpirationMonth()
    {
        return $this->ExpirationMonth;
    }

    function getExpirationYear()
    {
        return $this->ExpirationYear;
    }

    function getHistoryId()
    {
        return $this->HistoryId;
    }

    function getOrderId()
    {
        return $this->OrderId;
    }

    function getTrack2Data()
    {
        return $this->Track2Data;
    }

    function getNameOnCheck()
    {
        return $this->NameOnCheck;
    }

    function getCheckNumber()
    {
        return $this->CheckNumber;
    }

    function getCheckType()
    {
        return $this->CheckType;
    }

    function getRoutingNumber()
    {
        return $this->RoutingNumber;
    }

    function getAccountNumber()
    {
        return $this->AccountNumber;
    }

    function getUserProfileID()
    {
        return $this->UserProfileID;
    }

    function getLast4Digits()
    {
        return $this->Last4Digits;
    }

    function getEncryptionKey()
    {
        return $this->EncryptionKey;
    }

    function getReportingKey()
    {
        return $this->ReportingKey;
    }

    /*
     * Setter Methods
     */

    function setUrl($url)
    {
        $this->Url = $url;
    }

    function setTransactionName($TransactionName)
    {
        $this->TransactionName = $TransactionName;
    }

    function setAccountID($AccountID)
    {
        $this->AccountID = $AccountID;
    }

    function setSubid($Subid)
    {
        $this->Subid = $Subid;
    }

    function setMerchantpin($Merchantpin)
    {
        $this->Merchantpin = $Merchantpin;
    }

    function setTransactionAmount($TransactionAmount)
    {
        $this->TransactionAmount = $TransactionAmount;
    }

    function setCardholderName($CardholderName)
    {
        $this->CardholderName = $CardholderName;
    }

    function setCardNumber($CardNumber)
    {
        $this->CardNumber = $CardNumber;
    }

    function setExpirationMonth($ExpirationMonth)
    {
        $this->ExpirationMonth = $ExpirationMonth;
    }

    function setExpirationYear($ExpirationYear)
    {
        $this->ExpirationYear = '20' . $ExpirationYear;
    }

    function setHistoryId($HistoryId)
    {
        $this->HistoryId = $HistoryId;
    }

    function setOrderId($OrderId)
    {
        $this->OrderId = $OrderId;
    }

    function setNameOnCheck($NameOnCheck)
    {
        $this->NameOnCheck = $NameOnCheck;
    }

    function setCheckNumber($CheckNumber)
    {
        $this->CheckNumber = $CheckNumber;
    }

    function setCheckType($CheckType)
    {
        $this->CheckType = $CheckType;
    }

    function setRoutingNumber($RoutingNumber)
    {
        $this->RoutingNumber = $RoutingNumber;
    }

    function setAccountNumber($AccountNumber)
    {
        $this->AccountNumber = $AccountNumber;
    }

    function setUserProfileID($UserProfileID)
    {
        $this->UserProfileID = $UserProfileID;
    }

    function setLast4Digits($Last4Digits)
    {
        $this->Last4Digits = $Last4Digits;
    }

    function setTrack2Data($Track2Data)
    {
        $this->Track2Data = $Track2Data;
    }

    function setEncryptionKey($EncryptionKey)
    {
        $this->EncryptionKey = $EncryptionKey;
    }

    function setReportingKey($ReportingKey)
    {
        $this->ReportingKey = $ReportingKey;
    }

    function setExpirationDate($exp)
    {
        $exp = str_pad($exp, 4, "0", STR_PAD_LEFT);
        $expMonth = substr($exp, 0, 2);
        $expYear = substr($exp, 2, 2);
        $this->setExpirationMonth($expMonth);
        $this->setExpirationYear($expYear);
    }

}
