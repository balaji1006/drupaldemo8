<?php
namespace App\CustomClass;

require_once realpath(dirname(__FILE__)) . '/litle/UrlMapper.php';
require_once realpath(dirname(__FILE__)) . '/litle/LitleOnlineRequest.php';


/*
 *  Lifespan of a Payment Authorization
 *      American Express => 7 days
 *      Discover => 10 days
 *      MasterCard => 7 days
 *      Visa =>  7 days
 *      Bill Me Later => 30 days by default; for more information about Bill Me Later authorizations, see the Vantiv Bill Me Later Integration Guide.
 *      PayPal => 29 days total; Vantiv recommends three days. For more information about PayPal authorizations, see the Vantiv PayPal Integration Guide.
 */

/*
 *  orderSource
 *      3dsAttempted => Use this value only if you attempted to authenticate the cardholder via an
                            approved 3DS system such as Visa VerifiedByVisa and MasterCard SecureCode,
                            but either the Issuer or cardholder is not participating in the 3DS program. This
                            value applies to Visa and MasterCard transactions only. If this is a MasterCard
                            transaction, you must include the authenticationValue returned by
                            MasterCard.
                            NOTE: Your Merchant Profile must be configured to process 3DS type payments and accept this value.    
 *      3dsAuthenticated => Use this value only if you authenticated the cardholder via an approved 3DS
                            system such as Visa Verified By Visa and MasterCard SecureCode. This value
                            applies to Visa and MasterCard transactions only.
                            NOTE: Your Merchant Profile must be configured to process 3DS type payments and accept this value.
 *      echeckppd => (eCheck only) Use this value for eCheck PPD transactions (Prearranged
                     Payment and Deposit Entries). This type of transaction occurs when a merchants
                     receives a written authorization, including a voided paper check, from a consumer
                     so that the merchant can debit the consumer account. These transactions can be
                     single entry or recurring debits to a consumer's account.
 *      ecommerce => The transaction is an Internet or electronic commerce transaction.
 *      installment => The transaction in an installment payment.
 *      mailorder => The transaction is for a single mail order transaction.
 *      recurring => The transaction is a recurring transaction. For Visa transactions, you can use this
                     value for all transactions in a recurring stream including the initial transaction.
 *      retail => The transaction is a Swiped or Keyed Entered retail purchase transaction.
 *      telephone => The transaction is for a single telephone order.
 *      recurringtel => (eCheck only) The transaction is a recurring eCheck transaction initiated via telephone
 *      applepay => The transaction uses the Apple Pay service.
 * 
 *  */

class litle
{

//credentials attributes
    private $username;
    private $password;
    private $currency_merchant_map;
    private $url;
    private $proxy;
    private $batch_request_path;
    private $litle_request_path;
    private $sftp_username;
    private $sftp_password;
    private $batch_url;
    private $tcp_port;
    private $tcp_timeout;
    private $tcp_ssl;
    private $print_xml;
    private $timeout;
    private $reportGroup;
    
    
//attributes
    private $litleTxnId; // ref_number
    private $orderId; //trans_id
    private $amount; // amount to pay
    private $id; //A unique identifier assigned by the presenter and mirrored back in the response. minLength = N/A maxLength = 25
    private $orderSource; // type of payment "ecommerce"
    private $name; // card holder name
    private $firstName;
    private $lastName;
    private $addressLine1; // billing address
    private $city; // billing city
    private $state; // billing state
    private $zip; // billing zip
    private $country; // billing country
    private $number; // card number
    private $expDate; // card expiration date
    private $cardValidationNum; // card cvv
    private $partial; // Boolean
    private $type; // Type of Card {VISA: "VI" , DISCOVER: "DI", MASTERCARD: "MC", AMERICAN EXPRESS: "AX"}
    private $accountNumber; //
    private $litleToken; // token
    private $secondaryAmount; // convenience fee
    private $accNum; // bank account number
    private $routingNum; // bank routing number
    private $checkNum; // check number
    private $ccdPaymentInformation; // payment Description
    private $accType; // type of account (Checking, Savings, Corporate, or Corp +Savings)
    
    function __construct($option = "")
    {
        $this->orderSource="ecommerce";
        $obj_url = new \litle\UrlMapper();
        if (isset($option['key']) && !empty($option['key'])) {
        } elseif (!empty($option)) {
            if (isset($options['username'])) {
                $this->username=trim($options['username']);
            } else {
                $this->username="";
            }
            if (isset($options['password'])) {
                $this->password=trim($options['password']);
            } else {
                $this->password="";
            }
            if (isset($options['currency_merchant_map'])) {
                $this->currency_merchant_map=trim($options['currency_merchant_map']);
            } else {
                $this->currency_merchant_map="";
            }
            if (isset($options['url'])) {
                $this->url=$options['url'];
            } else {
                $this->url=$obj_url->getUrl("production");
            }
            if (isset($options['proxy'])) {
                $this->proxy=trim($options['proxy']);
            } else {
                $this->proxy="";
            }
            if (isset($options['batch_request_path'])) {
                $this->batch_request_path=trim($options['batch_request_path']);
            } else {
                $this->sftp_username="";
            }
            if (isset($options['litle_request_path'])) {
                $this->litle_request_path=trim($options['litle_request_path']);
            } else {
                $this->sftp_username="";
            }
            if (isset($options['sftp_username'])) {
                $this->sftp_username=trim($options['sftp_username']);
            } else {
                $this->sftp_username="";
            }
            if (isset($options['sftp_password'])) {
                $this->sftp_password=trim($options['sftp_password']);
            } else {
                $this->sftp_password="";
            }
            if (isset($options['batch_url'])) {
                $this->batch_url=trim($options['batch_url']);
            } else {
                $this->batch_url="";
            }
            if (isset($options['tcp_port'])) {
                $this->tcp_port=trim($options['tcp_port']);
            } else {
                $this->tcp_port="";
            }
            if (isset($options['tcp_timeout'])) {
                $this->tcp_timeout=trim($options['tcp_timeout']);
            } else {
                $this->tcp_timeout="";
            }
            if (isset($options['tcp_ssl'])) {
                $this->tcp_ssl=trim($options['tcp_ssl']);
            } else {
                $this->print_xml=1;
            }
            if (isset($options['print_xml'])) {
                $this->print_xml=trim($options['print_xml']);
            } else {
                $this->print_xml=0;
            }
            if (isset($options['timeout'])) {
                $this->timeout=trim($options['timeout']);
            } else {
                $this->timeout= 500;
            }
            if (isset($options['reportGroup'])) {
                $this->reportGroup=trim($options['reportGroup']);
            } else {
                $this->reportGroup="Default Report Group";
            }
        } else {
            //sandbox configuration
            $this->username="revopay";
            $this->password="password";
            $this->currency_merchant_map="";
            $this->url=$obj_url->getUrl("sandbox");
            $this->proxy="";
            $this->sftp_username="";
            $this->sftp_username="";
            $this->sftp_username="";
            $this->sftp_password="";
            $this->batch_url="";
            $this->tcp_port="";
            $this->tcp_timeout="";
            $this->print_xml=1;
            $this->print_xml=0;
            $this->timeout= 500;
            $this->reportGroup="Default Report Group";
        }
    }

    
    //functions CC
    function sale()
    {
        $hash_in = array (
            'amount' => $this->amount,
            'orderId' => $this->orderId,
            'id' => $this->id,
            'orderSource' => $this->orderSource,
            'billToAddress' => array(
                'name' => $this->name,
                'addressLine1' => $this->addressLine1,
                'city' => $this->city,
                'state' => $this->state,
                'zip' => $this->zip,
                'country' => $this->country),
            'card'=> array (
                'number' => $this->number,
                'expDate' =>  $this->expDate,
                'cardValidationNum' => $this->cardValidationNum,
                'type' => $this->type ),
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $saleResponse = $initilaize->saleRequest($hash_in);
        
        $status = \litle\XmlParser::getNode($saleResponse, 'response');
        $avsResult = \litle\XmlParser::getNode($saleResponse, 'avsResult');
        $cardValidationResult = \litle\XmlParser::getNode($saleResponse, 'cardValidationResult');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($saleResponse, 'message');
        $result['authcode']= \litle\XmlParser::getNode($saleResponse, 'authCode');
        $result['reference']= \litle\XmlParser::getNode($saleResponse, 'litleTxnId');
        $result['avsresponse'] = $initilaize->getAddressResponse($avsResult);
        $result['cvvresponse']=$initilaize->getCardResponse($cardValidationResult);
        
        return $result;
    }
    function auth()
    {
        $hash_in = array (
            'orderId' => $this->orderId,
            'amount' => $this->amount,
            
            'id' => $this->id,
            'orderSource' => $this->orderSource,
            'billToAddress' => array(
                'name' => $this->name,
                'addressLine1' => $this->addressLine1,
                'city' => $this->city,
                'state' => $this->state,
                'zip' => $this->zip,
                'country' => $this->country),
            'card'=> array (
                'number' => $this->number,
                'expDate' =>  $this->expDate,
                'cardValidationNum' => $this->cardValidationNum,
                'type' => $this->type ),
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $authResponse = $initilaize->authorizationRequest($hash_in);
        
        $status = \litle\XmlParser::getNode($authResponse, 'response');
        $avsResult = \litle\XmlParser::getNode($authResponse, 'avsResult');
        $cardValidationResult = \litle\XmlParser::getNode($authResponse, 'cardValidationResult');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($authResponse, 'message');
        $result['authcode']= \litle\XmlParser::getNode($authResponse, 'authCode');
        $result['reference']= \litle\XmlParser::getNode($authResponse, 'litleTxnId');
        $result['avsresponse'] = $initilaize->getAddressResponse($avsResult);
        $result['cvvresponse']=$initilaize->getCardResponse($cardValidationResult);
        
        return $result;
    }
    function verify()
    {
        $hash_in = array (
            'orderId' => $this->orderId,
            'id'=> $this->id,
            'accountNumber' => $this->accountNumber,
            'cardValidationNum' => $this->cardValidationNum
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $tokenResponse = $initilaize->registerTokenRequest($hash_in);
        $status = \litle\XmlParser::getNode($tokenResponse, 'response');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($tokenResponse, 'message');
        $result['token']=\litle\XmlParser::getNode($tokenResponse, 'litleToken');
        
        return $result;
    }
    function runToken()
    {
        $hash_in = array (
            'orderId' => $this->orderId,
            'id' => $this->id,
            'amount' => $this->amount,
            'orderSource' => $this->orderSource,
            'billToAddress' => array(
                'name' => $this->name,
                'addressLine1' => $this->addressLine1,
                'city' => $this->city,
                'state' => $this->state,
                'zip' => $this->zip,
                'country' => $this->country),
            'token'=> array (
                'litleToken' => $this->litleToken,
                'expDate' =>  $this->expDate,
                'cardValidationNum' => $this->cardValidationNum,
                'type' => $this->type ),
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $saleResponse = $initilaize->saleRequest($hash_in);
        
        $status = \litle\XmlParser::getNode($saleResponse, 'response');
        $avsResult = \litle\XmlParser::getNode($saleResponse, 'avsResult');
        $cardValidationResult = \litle\XmlParser::getNode($saleResponse, 'cardValidationResult');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($saleResponse, 'message');
        $result['authcode']= \litle\XmlParser::getNode($saleResponse, 'authCode');
        $result['reference']= \litle\XmlParser::getNode($saleResponse, 'litleTxnId');
        $result['avsresponse'] = $initilaize->getAddressResponse($avsResult);
        $result['cvvresponse']=$initilaize->getCardResponse($cardValidationResult);
        
        return $result;
    }
    function refund()
    {
        $hash_in = array (
            'litleTxnId' => $this->litleTxnId
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $creditRequest = $initilaize->creditRequest($hash_in);
        $status = \litle\XmlParser::getNode($creditRequest, 'response');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($creditRequest, 'message');
        $result['orderId']= \litle\XmlParser::getNode($creditRequest, 'orderId');
        
        return $result;
    }
    function partialRefund()
    {
        $hash_in = array (
            'litleTxnId' => $this->litleTxnId,
            'id' => $this->id,
            'amount' => $this->amount
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $creditRequest = $initilaize->creditRequest($hash_in);
        $status = \litle\XmlParser::getNode($creditRequest, 'response');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($creditRequest, 'message');
        $result['orderId']= \litle\XmlParser::getNode($creditRequest, 'orderId');
        
        return $result;
    }
    function credit()
    {
        $hash_in = array (
            'amount' => $this->amount,
            'orderId' => $this->orderId,
            'id' => $this->id,
            'orderSource' => $this->orderSource,
            'billToAddress' => array(
                'name' => $this->name,
                'addressLine1' => $this->addressLine1,
                'city' => $this->city,
                'state' => $this->state,
                'zip' => $this->zip,
                'country' => $this->country),
            'card'=> array (
                'number' => $this->number,
                'expDate' =>  $this->expDate,
                'cardValidationNum' => $this->cardValidationNum,
                'type' => $this->type ),
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $creditRequest = $initilaize->creditRequest($hash_in);
        
        $status = \litle\XmlParser::getNode($creditRequest, 'response');
        $avsResult = \litle\XmlParser::getNode($creditRequest, 'avsResult');
        $cardValidationResult = \litle\XmlParser::getNode($creditRequest, 'cardValidationResult');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($creditRequest, 'message');
        $result['authcode']= \litle\XmlParser::getNode($creditRequest, 'authCode');
        $result['reference']= \litle\XmlParser::getNode($creditRequest, 'litleTxnId');
        $result['avsresponse'] = $initilaize->getAddressResponse($avsResult);
        $result['cvvresponse']=$initilaize->getCardResponse($cardValidationResult);
        
        return $result;
    }
    function void()
    {
        $hash_in = array (
            'litleTxnId' => $this->litleTxnId,
            'id'=> $this->id
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $voidRequest = $initilaize->voidRequest($hash_in);
        $status = \litle\XmlParser::getNode($voidRequest, 'response');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($voidRequest, 'message');
        $result['orderId']= \litle\XmlParser::getNode($voidRequest, 'orderId');
        
        return $result;
    }
    
    //functions EC
    function echeckSale()
    {
        $hash_in = array (
            'id' => $this->id,
            'orderId' => $this->orderId,
            'amount' => $this->amount,
            'orderSource' => $this->orderSource,
            'billToAddress' => array(
                'name' => $this->name),
            'echeck'=> array (
                'accType' => $this->accType,
                'accNum' => $this->accNum,
                'routingNum' =>  $this->routingNum),
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $echeckSaleRequest = $initilaize->echeckSaleRequest($hash_in);
        
        $status = \litle\XmlParser::getNode($echeckSaleRequest, 'response');
        $avsResult = \litle\XmlParser::getNode($echeckSaleRequest, 'avsResult');
        $cardValidationResult = \litle\XmlParser::getNode($echeckSaleRequest, 'cardValidationResult');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($echeckSaleRequest, 'message');
        $result['authcode']= \litle\XmlParser::getNode($echeckSaleRequest, 'authCode');
        $result['reference']= \litle\XmlParser::getNode($echeckSaleRequest, 'litleTxnId');
        
        return $result;
    }
    function echeckVerify()
    {
        $hash_in = array (
            'orderId' => $this->orderId,
            'echeckForToken'=> array (
                'accType' => $this->accType,
                'accNum' => $this->accNum,
                'routingNum' =>  $this->routingNum)
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $tokenResponse = $initilaize->registerTokenRequest($hash_in);
        $status = \litle\XmlParser::getNode($tokenResponse, 'response');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($tokenResponse, 'message');
        $result['token']=\litle\XmlParser::getNode($tokenResponse, 'litleToken');
        
        return $result;
    }
    function echeckVoid()
    {
        $hash_in = array (
            'litleTxnId' => $this->litleTxnId,
            'id' => $this->id
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $echeckVoidRequest = $initilaize->echeckVoidRequest($hash_in);
        $status = \litle\XmlParser::getNode($echeckVoidRequest, 'response');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($echeckVoidRequest, 'message');
        $result['orderId']= \litle\XmlParser::getNode($echeckVoidRequest, 'orderId');
        
        return $result;
    }
    function echeckRunToken()
    {
        $hash_in = array (
            'orderId' => $this->orderId,
            'id' => $this->id,
            'amount' => $this->amount,
            'orderSource' => $this->orderSource,
            'billToAddress' => array(
                'name' => $this->name,
                'addressLine1' => $this->addressLine1,
                'city' => $this->city,
                'state' => $this->state,
                'zip' => $this->zip,
                'country' => $this->country),
            'token'=> array (
                'litleToken' => $this->litleToken
                ),
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $echeckSaleRequest = $initilaize->echeckSaleRequest($hash_in);
        
        $status = \litle\XmlParser::getNode($echeckSaleRequest, 'response');
        $avsResult = \litle\XmlParser::getNode($echeckSaleRequest, 'avsResult');
        $cardValidationResult = \litle\XmlParser::getNode($echeckSaleRequest, 'cardValidationResult');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($echeckSaleRequest, 'message');
        $result['authcode']= \litle\XmlParser::getNode($echeckSaleRequest, 'authCode');
        $result['reference']= \litle\XmlParser::getNode($echeckSaleRequest, 'litleTxnId');
        
        return $result;
    }
    function echeckCreditRunToken()
    {
        $hash_in = array (
            'orderId' => $this->orderId,
            'id' => $this->id,
            'amount' => $this->amount,
            'orderSource' => $this->orderSource,
            'billToAddress' => array(
                'name' => $this->name,
                'addressLine1' => $this->addressLine1,
                'city' => $this->city,
                'state' => $this->state,
                'zip' => $this->zip,
                'country' => $this->country),
            'token'=> array (
                'litleToken' => $this->litleToken
                ),
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $echeckCreditRequest = $initilaize->echeckCreditRequest($hash_in);
        
        $status = \litle\XmlParser::getNode($echeckCreditRequest, 'response');
        $avsResult = \litle\XmlParser::getNode($echeckCreditRequest, 'avsResult');
        $cardValidationResult = \litle\XmlParser::getNode($echeckCreditRequest, 'cardValidationResult');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($echeckCreditRequest, 'message');
        $result['authcode']= \litle\XmlParser::getNode($echeckCreditRequest, 'authCode');
        $result['reference']= \litle\XmlParser::getNode($echeckCreditRequest, 'litleTxnId');
        
        return $result;
    }
    function echeckCredit()
    {
        $hash_in = array (
            'id' => $this->id,
            'orderId' => $this->orderId,
            'amount' => $this->amount,
            'orderSource' => $this->orderSource,
            'billToAddress' => array(
                'name' => $this->name,
                'addressLine1' => $this->addressLine1,
                'city' => $this->city,
                'state' => $this->state,
                'zip' => $this->zip,
                'country' => $this->country),
            'echeck'=> array (
                'accType' => $this->accType,
                'accNum' => $this->accNum,
                'routingNum' =>  $this->routingNum),
        );
        
        $initilaize = new \litle\LitleOnlineRequest();
        $echeckCreditRequest = $initilaize->echeckCreditRequest($hash_in);
        
        $status = \litle\XmlParser::getNode($echeckCreditRequest, 'response');
        $avsResult = \litle\XmlParser::getNode($echeckCreditRequest, 'avsResult');
        $cardValidationResult = \litle\XmlParser::getNode($echeckCreditRequest, 'cardValidationResult');
        
        $result=array();
        $result['response']=$this->getResultCode($status);
        $result['responsetext']= \litle\XmlParser::getNode($echeckCreditRequest, 'message');
        $result['authcode']= \litle\XmlParser::getNode($echeckCreditRequest, 'authCode');
        $result['reference']= \litle\XmlParser::getNode($echeckCreditRequest, 'litleTxnId');
        
        return $result;
    }
    
    private function getResultCode($response)
    {
        /*
         *  Approved Transaction Response Codes
         *  000 -> Approved
         *  010 -> Partially Approved | The authorized amount is less than the requested amount.
         *  801 -> The card number was successfully registered and a token number was returned.
         *  802 -> The card number was previously registered for tokenization.
         *  805 -> The stored value for CVV2/CVC2/CID has been successfully updated.
         *  
         */
        $resultCode = $response;
        if ($resultCode == "000"||$resultCode == "010" || $resultCode == "801"||$resultCode == "802" || $resultCode == "805") { //approved transaction
               return 1;
        } else { //declined transaction
               return 3;
        }
    }
    function getProfileKey()
    {
    }




























    //Getter and Setter
    function getLitleTxnId()
    {
        return $this->litleTxnId;
    }

    function getOrderId()
    {
        return $this->orderId;
    }

    function getUsername()
    {
        return $this->username;
    }

    function getPassword()
    {
        return $this->password;
    }

    function getCurrency_merchant_map()
    {
        return $this->currency_merchant_map;
    }

    function getUrl()
    {
        return $this->url;
    }

    function getProxy()
    {
        return $this->proxy;
    }

    function getBatch_request_path()
    {
        return $this->batch_request_path;
    }

    function getLitle_request_path()
    {
        return $this->litle_request_path;
    }

    function getSftp_username()
    {
        return $this->sftp_username;
    }

    function getSftp_password()
    {
        return $this->sftp_password;
    }

    function getBatch_url()
    {
        return $this->batch_url;
    }

    function getTcp_port()
    {
        return $this->tcp_port;
    }

    function getTcp_timeout()
    {
        return $this->tcp_timeout;
    }

    function getTcp_ssl()
    {
        return $this->tcp_ssl;
    }

    function getPrint_xml()
    {
        return $this->print_xml;
    }

    function getTimeout()
    {
        return $this->timeout;
    }

    function getReportGroup()
    {
        return $this->reportGroup;
    }

    function getAccountNumber()
    {
        return $this->accountNumber;
    }

    function getLitleToken()
    {
        return $this->litleToken;
    }

    function getSecondaryAmount()
    {
        return $this->secondaryAmount;
    }

    function getAccNum()
    {
        return $this->accNum;
    }

    function getRoutingNum()
    {
        return $this->routingNum;
    }

    function getCheckNum()
    {
        return $this->checkNum;
    }

    function getCcdPaymentInformation()
    {
        return $this->ccdPaymentInformation;
    }

    function getAccType()
    {
        return $this->accType;
    }

    function setUsername($username)
    {
        $this->username = $username;
    }

    function setPassword($password)
    {
        $this->password = $password;
    }

    function setCurrency_merchant_map($currency_merchant_map)
    {
        $this->currency_merchant_map = $currency_merchant_map;
    }

    function setUrl($url)
    {
        $this->url = $url;
    }

    function setProxy($proxy)
    {
        $this->proxy = $proxy;
    }

    function setBatch_request_path($batch_request_path)
    {
        $this->batch_request_path = $batch_request_path;
    }

    function setLitle_request_path($litle_request_path)
    {
        $this->litle_request_path = $litle_request_path;
    }

    function setSftp_username($sftp_username)
    {
        $this->sftp_username = $sftp_username;
    }

    function setSftp_password($sftp_password)
    {
        $this->sftp_password = $sftp_password;
    }

    function setBatch_url($batch_url)
    {
        $this->batch_url = $batch_url;
    }

    function setTcp_port($tcp_port)
    {
        $this->tcp_port = $tcp_port;
    }

    function setTcp_timeout($tcp_timeout)
    {
        $this->tcp_timeout = $tcp_timeout;
    }

    function setTcp_ssl($tcp_ssl)
    {
        $this->tcp_ssl = $tcp_ssl;
    }

    function setPrint_xml($print_xml)
    {
        $this->print_xml = $print_xml;
    }

    function setTimeout($timeout)
    {
        $this->timeout = $timeout;
    }

    function setReportGroup($reportGroup)
    {
        $this->reportGroup = $reportGroup;
    }

    function setAccountNumber($accountNumber)
    {
        $this->accountNumber = $accountNumber;
    }

    function setLitleToken($litleToken)
    {
        $this->litleToken = $litleToken;
    }

    function setSecondaryAmount($secondaryAmount)
    {
        $this->secondaryAmount = $secondaryAmount;
    }

    function setAccNum($accNum)
    {
        $this->accNum = $accNum;
    }

    function setRoutingNum($routingNum)
    {
        $this->routingNum = $routingNum;
    }

    function setCheckNum($checkNum)
    {
        $this->checkNum = $checkNum;
    }

    function setCcdPaymentInformation($ccdPaymentInformation)
    {
        $this->ccdPaymentInformation = $ccdPaymentInformation;
    }

    function setAccType($accType)
    {
        $this->accType = $accType;
    }

        
    function getAmount()
    {
        return $this->amount;
    }

    function getId()
    {
        return $this->id;
    }

    function getOrderSource()
    {
        return $this->orderSource;
    }

    function getName()
    {
        return $this->name;
    }

    function getAddressLine1()
    {
        return $this->addressLine1;
    }

    function getCity()
    {
        return $this->city;
    }

    function getState()
    {
        return $this->state;
    }

    function getZip()
    {
        return $this->zip;
    }

    function getCountry()
    {
        return $this->country;
    }

    function getNumber()
    {
        return $this->number;
    }

    function getExpDate()
    {
        return $this->expDate;
    }

    function getCardValidationNum()
    {
        return $this->cardValidationNum;
    }

    function getPartial()
    {
        return $this->partial;
    }

    function getBillToAddress()
    {
        return $this->billToAddress;
    }

    function getCard()
    {
        return $this->card;
    }

    function getType()
    {
        return $this->type;
    }

    function setLitleTxnId($litleTxnId)
    {
        $this->litleTxnId = $litleTxnId;
    }

    function setOrderId($orderId)
    {
        $this->orderId = $orderId;
    }

    function setAmount($amount)
    {
        $this->amount = $amount;
    }

    function setId($id)
    {
        $this->id = $id;
    }

    function setOrderSource($orderSource)
    {
        $this->orderSource = $orderSource;
    }

    function setName($name)
    {
        $this->name = $name;
    }

    function setAddressLine1($addressLine1)
    {
        $this->addressLine1 = $addressLine1;
    }

    function setCity($city)
    {
        $this->city = $city;
    }

    function setState($state)
    {
        $this->state = $state;
    }

    function setZip($zip)
    {
        $this->zip = $zip;
    }

    function setCountry($country)
    {
        $this->country = $country;
    }

    function setNumber($number)
    {
        $this->number = $number;
    }

    function setExpDate($expDate)
    {
        $this->expDate = $expDate;
    }

    function setCardValidationNum($cardValidationNum)
    {
        $this->cardValidationNum = $cardValidationNum;
    }

    function setPartial($partial)
    {
        $this->partial = $partial;
    }

    function setBillToAddress($billToAddress)
    {
        $this->billToAddress = $billToAddress;
    }

    function setCard($card)
    {
        $this->card = $card;
    }
    
    function getFirstName()
    {
        return $this->firstName;
    }

    function getLastName()
    {
        return $this->lastName;
    }

    function setFirstName($firstName)
    {
        $this->firstName = $firstName;
    }

    function setLastName($lastName)
    {
        $this->lastName = $lastName;
    }
    
    // change OrderSource
    function setOrderSource_3dsAuthenticated()
    {
        $this->orderSource="3dsAuthenticated";
    }
    
    function setOrderSource_3dsAttempted()
    {
        $this->orderSource="3dsAttempted";
    }
    
    function setOrderSource_echeckppd()
    {
        $this->orderSource="echeckppd";
    }
    
    function setOrderSource_installment()
    {
        $this->orderSource="installment";
    }
    
    function setOrderSource_mailorder()
    {
        $this->orderSource="mailorder";
    }
    
    function setOrderSource_recurring()
    {
        $this->orderSource="recurring";
    }
    
    function setOrderSource_retail()
    {
        $this->orderSource="retail";
    }
    
    function setOrderSource_telephone()
    {
        $this->orderSource="telephone";
    }
    
    function setOrderSource_recurringtel()
    {
        $this->orderSource="recurringtel";
    }
    
    function setOrderSource_applepay()
    {
        $this->orderSource="applepay";
    }

    function setB2B()
    {
        if ($this->accType=="Checking") {
            $this->accType= "Corporate";
        } elseif ($this->accType=="Savings") {
            $this->accType = "Corp Savings";
        }
    }
    
    function setType($type)
    {
        $ttype = "VI";
        switch (strtolower(substr($type, 0, 2))) {
            case 'ma':
                $ttype = "MC";
                break;
            case 'di':
                $ttype = "DI";
                break;
            case 'am':
                $ttype = "AX";
                break;
            default:
                $ttype = "VI";
                break;
        }
        $this->type = $ttype;
    }
}
