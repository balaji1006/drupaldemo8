<?php
namespace App\CustomClass;

class pstars
{
    private $gw_url = 'https://ssl.selectpayment.com/PV/TransactionReporting.asmx';

    private $gw_mid = '43461';
    private $gw_lid ='127225';
    private $gw_sid ="128492";
    private $gw_key="S5cCiJ1Y7oqjFitU2ZcYi6CDIKMR";
    
    private $porigin='Internet';
    private $b2b='0';
    private $account_type='Checking';
    private $memo='';
    private $amount=0;
    private $trans_id;
    private $routing_number;
    private $account_number;
    private $name;
    
    /*
     * @param array $options
     * - gw_url
     * - gw_mid
     * - gw_lid
     * - gw_sid
     * - gw_key
     */
    public function __construct($options = array())
    {
        if (isset($options['gw_url'])) {
            $this->gw_url=trim($options['gw_url']);
        }
        if (isset($options['gw_mid'])) {
            $this->gw_mid=trim($options['gw_mid']);
        }
        if (isset($options['gw_lid'])) {
            $this->gw_lid=trim($options['gw_lid']);
        }
        if (isset($options['gw_sid'])) {
            $this->gw_sid=trim($options['gw_sid']);
        }
        if (isset($options['gw_key'])) {
            $this->gw_key=trim($options['gw_key']);
        }
    }
    
    private function sendRequest($request, $action)
    {
        $url=$this->gw_url;
        $header = array(
                    "Content-type: text/xml;charset=\"utf-8\"",
                    "Accept: text/xml",
                    "Cache-Control: no-cache",
                    "Pragma: no-cache",
                    "SOAPAction: \"https://ssl.selectpayment.com/PV/".$action."\"",
                    "Content-length: ".strlen($request),
                    );
        $ch = curl_init();
    // set the target url
        curl_setopt($ch, CURLOPT_URL, $url);
    // howmany parameter to post
        curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    //curl_setopt($ch, CURLOPT_VERBOSE, true);

        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }


    function ReturnedEvents()
    {
        $result=array();
        if (empty($this->gw_key) || empty($this->gw_lid) || empty($this->gw_mid) || empty($this->gw_sid) || empty($this->gw_url)) {
            $result['response']=4;
            $result['responsetext']='Error with credentials';
            return $result;
        }
        $request='<?xml version="1.0" encoding="utf-8"?>
                            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                              <soap:Body>
                                <HistoricalEventReport xmlns="https://ssl.selectpayment.com/PV">
                                  <storeId>'.$this->gw_sid.'</storeId>
                                  <storeKey>'.$this->gw_key.'</storeKey>
                                  <entityId>'.$this->gw_mid.'</entityId>    
                                   <wsdisplayFields>   
                                        <WSDisplayFields>Transaction_Number</WSDisplayFields>
                                        <WSDisplayFields>Reference_Number</WSDisplayFields>
                                        <WSDisplayFields>ReturnCode</WSDisplayFields>
                                   </wsdisplayFields>  
                                  <locationIds><int>'.$this->gw_lid.'</int></locationIds>
                                  <wstransEvent>
                                    <WSTransactionEvent>Sent_To_Collection</WSTransactionEvent>
                                    <WSTransactionEvent>Disputed</WSTransactionEvent>
                                    <WSTransactionEvent>Returned_NSF</WSTransactionEvent>
                                    <WSTransactionEvent>Returned_Bad_Account</WSTransactionEvent>
                                  </wstransEvent>
                                  <wstransStatus>
                                    <WSTransactionStatus>In_Collection</WSTransactionStatus>
                                    <WSTransactionStatus>Disputed</WSTransactionStatus>
                                    <WSTransactionStatus>Uncollected_NSF</WSTransactionStatus>
                                    <WSTransactionStatus>Invalid__Closed_Account</WSTransactionStatus>
                                  </wstransStatus>
                                  <wssettlementType>
                                    <WSSettlementType>ACH</WSSettlementType>
                                  </wssettlementType>
                                  <wspaymentType>
                                    <WSPaymentType>Checking</WSPaymentType>
                                    <WSPaymentType>Savings</WSPaymentType>
                                  </wspaymentType>
                                  <wspaymentOrigin></wspaymentOrigin>
                                  <wssettlementStatus></wssettlementStatus>
                                  <wsopType>Sale</wsopType>
                                  <beginTransDate>'.date('Y-m-d', strtotime('-2 day')).'</beginTransDate>
                                  <endTransDate>'.date('Y-m-d').'</endTransDate>
                                  <fromAmount></fromAmount>
                                  <toAmount></toAmount>
                                </HistoricalEventReport>
                              </soap:Body>
                            </soap:Envelope>';
        $response=$this->sendRequest($request, 'HistoricalEventReport');
        $resultx=$this->parseResponse($response);
        if (isset($resultx['Fault'])) {
            $result['response']=3;
            $result['responsetext']=$resultx['Fault']['faultcode'].' '.$resultx['Fault']['faultstring'];
            return $result;
        }
        return $result;
    }
    
    private function parseResponse($str)
    {
        $xml = simplexml_load_string(str_replace("soap:", "", $str));
        $json = json_encode($xml);
        $array = json_decode($json, true);
        $result=$array['Body'];
        return $result;
    }
}
