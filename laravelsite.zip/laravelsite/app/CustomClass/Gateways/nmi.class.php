<?php

namespace App\CustomClass;

/**
*/
class nmi
{
   
    private $nmi_url = 'https://secure.nmi.com/api/transact.php';
    private $nmi_user = '';
    private $nmi_password = '';

    /*
     * @param array $options
     * - nmi_url
     * - nmi_user
     * - nmi_password
     */
    public function __construct($options = array())
    {
//        if (isset($options['nmi_url'])) $this->setNmiUrl($options['nmi_url']);
        if (isset($options['nmi_user'])) {
            $this->setNmiUser(trim($options['nmi_user']));
        }
        if (isset($options['nmi_password'])) {
            $this->setNmiPassword(trim($options['nmi_password']));
        }
    }

   
    private function setNmiUrl($nmi_url)
    {
        $this->nmi_url = $nmi_url;
    }

    
    private function setNmiUser($nmi_user)
    {
        $this->nmi_user = $nmi_user;
    }

    
    private function setNmiPassword($nmi_password)
    {
        $this->nmi_password = $nmi_password;
    }

    
    protected function getNmiUrl()
    {
        return $this->nmi_url;
    }

    
    protected function getNmiUser()
    {
        return $this->nmi_user;
    }

    
    protected function getNmiPassword()
    {
        return $this->nmi_password;
    }

    protected function getCodeText($code)
    {
        $table=array(
            100=>'Transaction was approved.',
            200=>'Transaction was declined by processor.',
            201=>'Do not honor.',
            202=>'Insufficient funds.',
            203=>'Over limit.',
            204=>'Transaction not allowed.',
            220=>'Incorrect payment information.',
            221=>'No such card issuer.',
            222=>'No card number on file with issuer.',
            223=>'Expired card.',
            224=>'Invalid expiration date.',
            225=>'Invalid card security code.',
            240=>'Call issuer for further information.',
            250=>'Pick up card.',
            251=>'Lost card.',
            252=>'Stolen card.',
            253=>'Fraudulent card.',
            260=>'Declined with further instructions available. (See response text)',
            261=>'Declined-Stop all recurring payments.',
            262=>'Declined-Stop this recurring program.',
            263=>'Declined-Update cardholder data available.',
            264=>'Declined-Retry in a few days.',
            300=>'Transaction was rejected by gateway.',
            400=>'Transaction error returned by processor.',
            410=>'Invalid merchant configuration.',
            411=>'Merchant account is inactive.',
            420=>'Communication error.',
            421=>'Communication error with issuer.',
            430=>'Duplicate transaction at processor.',
            440=>'Processor format error.',
            441=>'Invalid transaction information.',
            460=>'Processor feature not available.',
            461=>'Unsupported card type.'
        );
        if (isset($table[$code])) {
            return $table[$code];
        } else {
            return '';
        }
    }
    /*
     * @param string $query_string
     *  Properly formatted name-value-pair query string
     *
     * $return array[string] $result
     *  array containing response code, message and other fail or pass codes
     */
    protected function execute($query_string)
    {
        if (in_array("curl", get_loaded_extensions())) {
            $ch = curl_init($this->getNmiUrl());
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
            curl_setopt($ch, CURLOPT_REFERER, "");
            $response = curl_exec($ch);
            curl_close($ch);

            $result = array();
            $result['query_string'] = $query_string;

            // TO DO, PARSE RESULT AND PROCESS AVS RETURN CODES
            if (!$response) {
                $result['response'] = 2;
                $result['responsetext'] ='There was an error communicating with the NMI gateway';
            } else {
                parse_str($response, $result);
                if (isset($result['response_code'])) {
                    $result['responsetext']=$this->getCodeText($result['response_code']);
                }
            }

            return $result;
        } else {
            throw new Exception('Could not load cURL libraries. Make sure PHP is compiled with cURL');
        }
    }
}

/*
 * Class for Debugging and Simple Formatting
 */
class globalFormat
{
    public static function phone($input)
    {
        return preg_replace('/[^\d]/', '', $input);
    }

    public static function debug($data)
    {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}
