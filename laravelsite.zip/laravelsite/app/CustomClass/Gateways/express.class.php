<?php

namespace App\CustomClass;

/*
  MarketCode (MarketCode specifies the industry type of the merchant.
  Set this to a value of Default if you would like to use the MarketCode from the merchant profile)

 * 0 => Default
 * 1 => AutoRental
 * 2 => DirectMarketing
 * 3 => ECommerce
 * 4 => FoodRestaurant
 * 5 => HotelLoding
 * 6 => Petroleum
 * 7 => Retail
 * 8 => QSR
 *
 *  */

/*
  CVVPresenceCode (CVVPresenceCode specifies the status of the CVV code from the consumer card as it
  pertains to the transaction. If the CVV code from the card is not inlcuded in the transaction, it is
  recommended that his code be set to the reason why.)

 * 0 => Use Default
 * 1 => Not Provided
 * 2 => Provided
 * 3 => Illegible
 * 4 => Customer Illegible
 *
 *  */

/*
  MotoECICode (MotoECICode is used on MOTO and E-Commerce transactions to identify the type of transaction,
  and the means in which it was obtained)

 * 0 => Default
 * 1 => NotUsed
 * 2 => Single
 * 3 => Recurring
 * 4 => Installment
 * 5 => SecureElectronicCommerce
 * 6 => NonAuthenticatedSecureTransaction
 * 7 => NonAuthenticatedSecureECommerceTransaction
 * 8 => NonSecureECommerceTransaction
 *
 *  */

/*
  CardPresentCode (CardPresentCode specifies the location of the card at the time of the transaction)

 * 0 => Default
 * 1 => Unknown
 * 2 => Present
 * 3 => NotPresent
 *
 *  */

/*
  TerminalEnvironmentCode (TerminalEnvironmentCode specifies what type of conditions the Terminal is operated in.
  For example: a card reader at a fuel pump would be considered LocalUnattended)

 *  0 => Default
 *  1 => NoTerminal
 *  2 => LocalAttended
 *  3 => LocalUnattended
 *  4 => RemoteAttended
 *  5 => RemoteUnattended
 *  6 => ECommerce
 *
 *  */

/*
  TerminalCapabilityCode (TerminalCapabilityCode specifies what the capabilities of the Terminal are.
  For example: an E-Commerce website would be considered KeyEntered.)

 *  0 => Default
 *  1 => Unknown
 *  2 => NoTerminal
 *  3 => MagstripeReader
 *  4 => ContactlessMagstripeReader
 *  5 => KeyEntered
 *
 *  */

/*
  CardInputCode (CardInputCode specifies the means in which the Card Number or Track Data was acquired.)

 *  0 => Default
 *  1 => Unknown
 *  2 => MagstripeRead
 *  3 => ContactlessMagstripeRead
 *  4 => ManualKeyed
 *  5 => ManualKeyedMagstripeFailure
 *
 *  */

/*
  CardholderPresentCode (CaldholderPresentCode specifies the location of the cardholder at the time of the transaction)

 *  0 => Default
 *  1 => Unknown
 *  2 => Present
 *  3 => NotPresent
 *  4 => MailOrder
 *  5 => PhoneOrder
 *  6 => StandingAuth
 *  7 => ECommerce
 *
 *  */

/*
  ConsetCode (ConsetCode specifies the way the consumers consent for the transaction was received)

 *  0 => NotSpecified
 *  1 => FaceToFace
 *  2 => Phone
 *  3 => Internet
 *
 *  */

/*
  TerminalType specifies what type of Terminal is used to send the transaction in.

 * 0 => Unknown
 * 1 => PointOfSale
 * 2 => Ecommerce
 * 3 => MOTO
 * 4 => FuelPump
 * 5 => ATM
 * 6 => Voice
 *
 */

/*
  ReversalType specifies the type reversal that is being performed.

 *  0 => System
 *  1 => Full
 *  2 => Partial
 *
 */

/*
  ConsentCode specifies the way the consumers consent for the transaction was received

 *  0 => NotSpecified
 *  1 => FaceToFace (PPD or CCD) -> PPD when CheckType = 0 and CCD when CheckType = 1
 *  2 => Phone (TEL)
 *  3 => Internet (WEB)
 *
 */

class express
{

// Express Url
    private $Url = 'https://transaction.elementexpress.com';
    //private $Url = 'https://certtransaction.elementexpress.com';
//Application to live
    private $ApplicationID = '6390'; //Unique application identifier
    private $ApplicationName = "RevoExpress"; //Name of application
//Credential to live
    private $AccountID = '1027635'; // AccountID provider for Vantiv Express
    private $AccountToken = '89CBD8505FC0D6D6CD5ADE9AD75C3E0DEF4D16CFB41C6EC87BAE214D3A1C2D08BF9BF601'; // Account Token provider for Vantiv Express
    private $AcceptorID = '017473181'; //Merchant ID "link with the merchat"
    //Application
    /* private $ApplicationID = '8245'; //Unique application identifier
      private $ApplicationName ="RevoExpress"; //Name of application

      //Credential
      private $AccountID = '1044159'; // AccountID provider for Vantiv Express
      private $AccountToken ='721B2EF5BF6E033997F17B75E9AF88E35E5C6A159A23E0C36323E2214E5FFD8443F53A01'; // Account Token provider for Vantiv Express
      private $AcceptorID= '3928907'; //Merchant ID "link with the merchat" */
    //
//Terminal
    private $TerminalID; //Unique terminal identifier
    private $CardPresentCode; //Card Present Code
    private $CardholderPresentCode; //Cardholder Present Code
    private $CardInputCode; //Card Input Code
    private $CVVPresenceCode; // Card Verification Value Presence Code
    private $TerminalCapabilityCode; //Terminal Capability Code
    private $TerminalEnvironmentCode; //Terminal Environment Code
    private $MotoECICode; //Mail Order Telephone Order Electronic Indicatior Code
    private $ConsentCode; // ConsentCode specifies the way the consumers consent for the transaction was received
    private $TerminalType; // Type of Terminal
    private $ReversalType; // ReversalType specifies the type reversal that is being performed.
//Address
    private $BillingName;  //The name used for billing purpose. Recommend submitting for Level II processing.
    private $BillingAddress1; //The street address used for billing purposes (Needed for AVS)
    private $BillingCity; //The city name used for billing purposes
    private $BillingState; //The state name used for billing purposes
    private $BillingZipcode; //The zip code used for billing purposes
    private $BillingAddress2; //The zip code used for billing purposes
    private $BillingPhone; //The zip code used for billing purposes
//Transaction
    private $TransactionAmount; //Amount of Transaction
    private $ConvenienceFeeAmount; //Convenience fee amount (Vantiv only)
    private $ReferenceNumber; //Unique value assigned by the transaction sender
    private $MarketCode; // Market Code
    private $TicketNumber; //Used for Direct Marketing, MOTO, and E-Commerce transactions. Required when card number is manually keyed.
    private $TransactionID; //TransactionID returned in original transaction
    private $PartialApprovedFlag; //Boolean Indicates whether software supports partial approvals
//DemandDepositAccount
    private $AccountNumber; //The Account Number
    private $RoutingNumber; //The Routing Number
    private $CheckNumber; //Check Number
    private $CheckType; //Type of check. Business/ Personal, etc.
    private $DDAAccountType; //DDAAccountType specifies the type of DDA Account being used in the transaction ("Checking => 0";"Savings => 1")
//Card
    private $CardNumber; //Numeric number displayed on front of card (Max 30)
    private $ExpirationMonth; //Two digit expiration month displayed on front of card e.g. 02
    private $ExpirationYear; //Two digit expiration year displayed on front of card e.g. 08
    private $CardholderName; //The name of the Card holder as printer on the front of the card.
    private $Cvv; //The Card Verification Value found on the card: Visa CVV2, MasterCard CVC2, Discover CID
    private $CardLogo; //Payment brand ("Visa"; "Mastercard"; "Discover"; "Amex"; "Diners Club"; "JCB"; "Carte Blanche"; "Other")
//PaymentAccount
    private $PaymentAccountType; //Payment Account Type (0 => CreditCard, 1 => Checking, 2 => Savings, 3 => ACH, 4 => Other)
    private $PaymentAccountReferenceNumber; //Payment Account Reference Number
    private $PaymentAccountID; //Token to make a payment
//Swipe
    private $Track1Data;
    private $Track2Data;
    private $MagneprintData;
    private $EncryptedFormat;
    private $CardDataKeySerialNumber;
    private $EncryptedTrack1Data;
    private $EncryptedTrack2Data;
    private $EncryptedCardData;

    function __construct($option = array())
    {
        $this->ValuesDefault();
    }

    function ValuesDefault()
    {
        $this->TerminalID = "I1263000201"; // Default Terminal ID provider for Vantiv Express
        $this->CardPresentCode = "3"; //NotPresent
        $this->CardholderPresentCode = "7"; //ECommerce
        $this->CardInputCode = "4"; //ManualKeyed
        $this->CVVPresenceCode = "1"; //Not Present
        $this->TerminalCapabilityCode = "5"; //KeyEntered (E-Commerce website)
        $this->TerminalEnvironmentCode = "6"; //ECommerce
        $this->MotoECICode = "7"; //NonAuthenticatedSecureECommerceTransaction
        $this->ConsentCode = "3"; //Internet (WEB)
        $this->MarketCode = "3"; //ECommerce
        $this->PaymentAccountType = "0"; //CreditCard;
        $this->ConvenienceFeeAmount = 0;
        $this->TicketNumber = "REVO" . uniqid();
        $this->TerminalType = "2"; //ECommerce
        $this->PartialApprovedFlag = "0"; //Not Accept Partial Approve
        $this->ReversalType = "0"; //System
        $this->CheckType = "0"; //Personal Account
    }

    /* function ValuesDefaultSwipe(){
      $this->TerminalID = "0001"; // Default Terminal ID provider for Vantiv Express
      $this->CardPresentCode = "2"; //NotPresent
      $this->CardholderPresentCode ="2"; //ECommerce
      $this->CardInputCode = "2"; //ManualKeyed
      $this->CVVPresenceCode = "0"; //Not Present
      $this->TerminalCapabilityCode ="3"; //KeyEntered (E-Commerce website)
      $this->TerminalEnvironmentCode = "2"; //ECommerce
      $this->MotoECICode = "1"; //NonAuthenticatedSecureECommerceTransaction
      $this->ConsentCode = "3"; //Internet (WEB)
      $this->MarketCode = "7"; //ECommerce
      $this->PaymentAccountType = "0"; //CreditCard;
      $this->ConvenienceFeeAmount=0;
      $this->TicketNumber="REVO".uniqid();
      $this->TerminalType="1"; //ECommerce
      $this->PartialApprovedFlag ="1"; //Not Accept Partial Approve
      $this->ReversalType="0"; //System
      $this->CheckType ="0"; //Personal Account
      } */

    function Sale()
    {
        //Function to make a Credit Card Sale
        $request = '<?xml version="1.0"?>
            <CreditCardSale xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <TerminalType>' . $this->TerminalType . '</TerminalType>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>
                </Terminal>
                <Card>
                    <CardholderName>' . $this->CardholderName . '</CardholderName>
                    <CardNumber>' . $this->CardNumber . '</CardNumber>
                    <ExpirationMonth>' . $this->ExpirationMonth . '</ExpirationMonth>
                    <ExpirationYear>' . $this->ExpirationYear . '</ExpirationYear>
                    <CVV>' . $this->Cvv . '</CVV>
                </Card>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <ConvenienceFeeAmount>' . $this->ConvenienceFeeAmount . '</ConvenienceFeeAmount>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                    <PartialApprovedFlag>' . $this->PartialApprovedFlag . '</PartialApprovedFlag>
                </Transaction>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>';
        if (!empty($this->BillingZipcode)) {
            $request.='<BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>';
        }
        $request.='</Address></CreditCardSale>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['ApprovalNumber'];
            if (isset($resultx['Batch'])) {
                $result['batch'] = $resultx['Batch'];
            }
            if (isset($resultx['Card'])) {
                $result['card'] = $resultx['Card'];
            }
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    //Function to make a Credit Card Sale
    //can no go the conveniencefee field
    function  RunSwipe()
    {

        $request = '<?xml version="1.0"?>
            <CreditCardSale xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <TerminalType>1</TerminalType>
                    <CardholderPresentCode>2</CardholderPresentCode>
                    <CardInputCode>2</CardInputCode>
                    <TerminalCapabilityCode>3</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>2</TerminalEnvironmentCode>
                    <CardPresentCode>2</CardPresentCode>
                    <MotoECICode>1</MotoECICode>
                    <CVVPresenceCode>0</CVVPresenceCode>
                </Terminal>
                <Card>';
        if (!empty($this->MagneprintData)) {
            $request .='<MagneprintData>' . $this->MagneprintData . '</MagneprintData>';
        }
        if (!empty($this->EncryptedTrack1Data)) {
            $request .='<EncryptedTrack1Data>' . $this->EncryptedTrack1Data . '</EncryptedTrack1Data>';
        }
        if (!empty($this->EncryptedTrack2Data)) {
            $request .='<EncryptedTrack2Data>' . $this->EncryptedTrack2Data . '</EncryptedTrack2Data>';
        }
        if (!empty($this->EncryptedFormat)) {
            $request .='<EncryptedFormat>' . $this->EncryptedFormat . '</EncryptedFormat>';
        }
        if (!empty($this->EncryptedCardData)) {
            $request .='<EncryptedCardData>' . $this->EncryptedCardData . '</EncryptedCardData>';
        }
        if (!empty($this->CardDataKeySerialNumber)) {
            $request .='<CardDataKeySerialNumber>' . $this->CardDataKeySerialNumber . '</CardDataKeySerialNumber>';
        }
        if (!empty($this->Track1Data)) {
            $request .='<Track1Data>' . $this->Track1Data . '</Track1Data>';
        }
        if (!empty($this->Track2Data)) {
            $request .='<Track2Data>' . $this->Track2Data . '</Track2Data>';
        }

        $request .='</Card>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <TicketNumber>' . $this->TicketNumber . '</TicketNumber>
                    <MarketCode>7</MarketCode>
                    <PartialApprovedFlag>' . $this->PartialApprovedFlag . '</PartialApprovedFlag>
                </Transaction>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                </Address>
            </CreditCardSale>';

        $response = $this->sendRequest($request);

        $resultx = $this->parseResponse($response);
//        error_log('request'.print_r($request,true).'result'.print_r($resultx,true), 3, '/var/tmp/1swipesale.log');
        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['ApprovalNumber'];
            if (isset($resultx['Batch'])) {
                $result['batch'] = $resultx['Batch'];
            }
            if (isset($resultx['Card'])) {
                $result['card'] = $resultx['Card'];
            }
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function CreditCardAVSOnly()
    {
        //Function to make a Credit Card Sale
        $request = '<?xml version="1.0"?>
            <CreditCardAVSOnly xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <TerminalType>' . $this->TerminalType . '</TerminalType>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>
                </Terminal>
                <Card>
                    <CardholderName>' . $this->CardholderName . '</CardholderName>
                    <CardNumber>' . $this->CardNumber . '</CardNumber>
                    <ExpirationMonth>' . $this->ExpirationMonth . '</ExpirationMonth>
                    <ExpirationYear>' . $this->ExpirationYear . '</ExpirationYear>
                </Card>
                <Transaction>
                    <TransactionAmount>0.00</TransactionAmount>
                    <TicketNumber>' . $this->TicketNumber . '</TicketNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                    <PartialApprovedFlag>' . $this->PartialApprovedFlag . '</PartialApprovedFlag>
                </Transaction>
                <Address>
                    <BillingAddress1>' . $this->BillingAddress1 . '</BillingAddress1>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                </Address>
            </CreditCardAVSOnly>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['ApprovalNumber'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function CreditCardAVSOnlyToken()
    {
        //Function to make a Credit Card Sale
        $request = '<?xml version="1.0"?>
            <CreditCardAVSOnly xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <TerminalType>' . $this->TerminalType . '</TerminalType>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>
                </Terminal>
                <PaymentAccount>
                    <PaymentAccountID>' . $this->PaymentAccountID . '</PaymentAccountID>
                </PaymentAccount>
                <Transaction>
                    <TransactionAmount>0.00</TransactionAmount>
                    <TicketNumber>' . $this->TicketNumber . '</TicketNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                    <PartialApprovedFlag>' . $this->PartialApprovedFlag . '</PartialApprovedFlag>
                </Transaction>
                <Address>
                    <BillingAddress1>' . $this->BillingAddress1 . '</BillingAddress1>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                </Address>
            </CreditCardAVSOnly>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['ApprovalNumber'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function Authorization()
    {
        //Function to make a Credit Card Authorization (An Authorization transaction is used to verify funds when the total amount of the purchase is unknown)
        //TransactionAmount is required but is Depending on the merchant setup, a $0.00 account verification may be used when address verification is performed.
        $request = '<?xml version="1.0"?>
            <CreditCardAuthorization xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>
                </Terminal>
                <Card>
                    <CardNumber>' . $this->CardNumber . '</CardNumber>
                    <ExpirationMonth>' . $this->ExpirationMonth . '</ExpirationMonth>
                    <ExpirationYear>' . $this->ExpirationYear . '</ExpirationYear>
                    <CVV>' . $this->Cvv . '</CVV>
                </Card>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <ConvenienceFeeAmount>' . $this->ConvenienceFeeAmount . '</ConvenienceFeeAmount>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>7</MarketCode>
                </Transaction>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                </Address>
            </CreditCardAuthorization>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);
        /*
          if($this->AcceptorID=="024089144")
          {
          error_log(print_r($request),3,"/var/tmp/1vativdeclined.log");
          error_log(print_r($resultx),3,"/var/tmp/2vativdeclined.log");
          }
         *
         */
        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['ApprovalNumber'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function Void()
    {
        //Function to make a Credit Card Void (A Void Transaction is used to completely back out a previous Sale transaction.
        //This applies to all transactions that were entered into the current batch, and only for the full dollar amount of the original transaction)

        $request = '<?xml version="1.0"?>
            <CreditCardVoid xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>
                </Terminal>
                <Transaction>
                    <TransactionID>' . $this->TransactionID . '</TransactionID>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <TicketNumber>' . $this->TicketNumber . '</TicketNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                </Transaction>
            </CreditCardVoid>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function Refund()
    {
        //Function to make a Credit Card Return (The CreditCardReturn transaction requires a TransactionID for the previous dependent transaction.
        //Note That the CreditCardReturn method can be used only for transactions thet are no greater than 120 days old.)

        $request = '<?xml version="1.0"?>
            <CreditCardReturn xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>
                </Terminal>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <TransactionID>' . $this->TransactionID . '</TransactionID>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <TicketNumber>' . $this->TicketNumber . '</TicketNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>

                </Transaction>
            </CreditCardReturn>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);



        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['transactionid'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['ApprovalNumber'];
            if (isset($resultx['Batch'])) {
                $result['batch'] = $resultx['Batch'];
            }
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function Reversal()
    {
        //Function to make a Credit Card Reversal

        $request = '<?xml version="1.0"?>
            <CreditCardReversal xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>

                </Terminal>
                <Card>
                    <CardholderName>' . $this->CardholderName . '</CardholderName>
                    <CardNumber>' . $this->CardNumber . '</CardNumber>
                    <ExpirationMonth>' . $this->ExpirationMonth . '</ExpirationMonth>
                    <ExpirationYear>' . $this->ExpirationYear . '</ExpirationYear>
                </Card>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <TicketNumber>' . $this->TicketNumber . '</TicketNumber>
                    <ReversalType>' . $this->ReversalType . '</ReversalType>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                </Transaction>
            </CreditCardReversal>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function ReversalSwipe()
    {
        //Function to make a Credit Card Reversal

        $request = '<?xml version="1.0"?>
            <CreditCardReversal xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>

                </Terminal>
               <Card>';
        if (!empty($this->MagneprintData)) {
            $request .='<MagneprintData>' . $this->MagneprintData . '</MagneprintData>';
        }
        if (!empty($this->EncryptedTrack1Data)) {
            $request .='<EncryptedTrack1Data>' . $this->EncryptedTrack1Data . '</EncryptedTrack1Data>';
        }
        if (!empty($this->EncryptedTrack2Data)) {
            $request .='<EncryptedTrack2Data>' . $this->EncryptedTrack2Data . '</EncryptedTrack2Data>';
        }
        if (!empty($this->EncryptedFormat)) {
            $request .='<EncryptedFormat>' . $this->EncryptedFormat . '</EncryptedFormat>';
        }
        if (!empty($this->EncryptedCardData)) {
            $request .='<EncryptedCardData>' . $this->EncryptedCardData . '</EncryptedCardData>';
        }
        if (!empty($this->CardDataKeySerialNumber)) {
            $request .='<CardDataKeySerialNumber>' . $this->CardDataKeySerialNumber . '</CardDataKeySerialNumber>';
        }
        if (!empty($this->Track1Data)) {
            $request .='<Track1Data>' . $this->Track1Data . '</Track1Data>';
        }
        if (!empty($this->Track2Data)) {
            $request .='<Track2Data>' . $this->Track2Data . '</Track2Data>';
        }

        $request .='</Card>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <TicketNumber>' . $this->TicketNumber . '</TicketNumber>
                    <ReversalType>' . $this->ReversalType . '</ReversalType>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                </Transaction>
            </CreditCardReversal>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function ReversalToken()
    {
        //Function to make a Credit Card Reversal using PaymentID

        $request = '<?xml version="1.0"?>
            <CreditCardReversal xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>

                </Terminal>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <TicketNumber>' . $this->TicketNumber . '</TicketNumber>
                    <ReversalType>' . $this->ReversalType . '</ReversalType>
                </Transaction>
                <PaymentAccount>
                    <PaymentAccountID>' . $this->PaymentAccountID . '</PaymentAccountID>
                </PaymentAccount>
            </CreditCardReversal>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function GetToken()
    {
        //Function to get a Token
        $request = '<?xml version="1.0"?>
            <PaymentAccountCreate xmlns="https://services.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <PaymentAccount>
                    <PaymentAccountType>' . $this->PaymentAccountType . '</PaymentAccountType>
                    <PaymentAccountReferenceNumber>' . $this->PaymentAccountReferenceNumber . '</PaymentAccountReferenceNumber>
                </PaymentAccount>
                <Card>
                    <CardholderName>' . $this->CardholderName . '</CardholderName>
                    <CardNumber>' . $this->CardNumber . '</CardNumber>
                    <ExpirationMonth>' . $this->ExpirationMonth . '</ExpirationMonth>
                    <ExpirationYear>' . $this->ExpirationYear . '</ExpirationYear>
                    <CVV>' . $this->Cvv . '</CVV>
                </Card>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                </Address>
            </PaymentAccountCreate>';
        $this->setUrl("https://services.elementexpress.com");
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['token'] = $resultx['PaymentAccount']['PaymentAccountID'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function GetTokenTrandID()
    {
        //Function to get a Token
        $request = '<?xml version="1.0"?>
            <PaymentAccountCreateWithTransID xmlns="https://services.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <PaymentAccount>
                    <PaymentAccountType>' . $this->PaymentAccountType . '</PaymentAccountType>
                    <PaymentAccountReferenceNumber>' . $this->PaymentAccountReferenceNumber . '</PaymentAccountReferenceNumber>
                </PaymentAccount>
                <Transaction>
                    <TransactionID>' . $this->TransactionID . '</TransactionID>
                </Transaction>
            </PaymentAccountCreateWithTransID>';
        $this->setUrl("https://services.elementexpress.com");
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['token'] = $resultx['PaymentAccount']['PaymentAccountID'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function UpdateToken()
    {
        //Function to get a Token
        $request = '<?xml version="1.0"?>
            <PaymentAccountUpdate xmlns="https://services.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <PaymentAccount>
                    <PaymentAccountID>' . $this->PaymentAccountID . '</PaymentAccountID>
                    <PaymentAccountType>' . $this->PaymentAccountType . '</PaymentAccountType>
                    <PaymentAccountReferenceNumber>' . $this->PaymentAccountReferenceNumber . '</PaymentAccountReferenceNumber>
                </PaymentAccount>
                <Card>
                    <CardholderName>' . $this->CardholderName . '</CardholderName>
                    <CardNumber>' . $this->CardNumber . '</CardNumber>
                    <ExpirationMonth>' . $this->ExpirationMonth . '</ExpirationMonth>
                    <ExpirationYear>' . $this->ExpirationYear . '</ExpirationYear>
                    <CVV>' . $this->Cvv . '</CVV>
                </Card>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>
                    <BillingAddress1>' . $this->BillingAddress1 . '</BillingAddress1>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                </Address>
            </PaymentAccountUpdate>';
        $this->setUrl("https://services.elementexpress.com");
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['token'] = $resultx['PaymentAccount']['PaymentAccountID'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function DeleteToken()
    {
        //Function to get a Token
        $request = '<?xml version="1.0"?>
            <PaymentAccountDelete xmlns="https://services.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <PaymentAccount>
                    <PaymentAccountID>' . $this->PaymentAccountID . '</PaymentAccountID>
                </PaymentAccount>
            </PaymentAccountDelete>';
        $this->setUrl("https://services.elementexpress.com");
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['token'] = $resultx['PaymentAccount']['PaymentAccountID'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function RunToken()
    {
        //Function to make a Credit Card Sale with Token
        $request = '<?xml version="1.0"?>
            <CreditCardSale xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <TerminalType>' . $this->TerminalType . '</TerminalType>
                    <CardholderPresentCode>' . $this->CardholderPresentCode . '</CardholderPresentCode>
                    <CardInputCode>' . $this->CardInputCode . '</CardInputCode>
                    <TerminalCapabilityCode>' . $this->TerminalCapabilityCode . '</TerminalCapabilityCode>
                    <TerminalEnvironmentCode>' . $this->TerminalEnvironmentCode . '</TerminalEnvironmentCode>
                    <CardPresentCode>' . $this->CardPresentCode . '</CardPresentCode>
                    <MotoECICode>' . $this->MotoECICode . '</MotoECICode>
                    <CVVPresenceCode>' . $this->CVVPresenceCode . '</CVVPresenceCode>
                </Terminal>
                <PaymentAccount>
                    <PaymentAccountID>' . $this->PaymentAccountID . '</PaymentAccountID>
                </PaymentAccount>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <PartialApprovedFlag>' . $this->PartialApprovedFlag . '</PartialApprovedFlag>
                    <ConvenienceFeeAmount>' . $this->ConvenienceFeeAmount . '</ConvenienceFeeAmount>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                </Transaction>
                <Address>
                    <BillingAddress1>' . $this->BillingAddress1 . '</BillingAddress1>';
        if (!empty($this->BillingZipcode)) {
            $request.='<BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>';
        }
        $request.='</Address></CreditCardSale>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['ApprovalNumber'];
            if (isset($resultx['Batch'])) {
                $result['batch'] = $resultx['Batch'];
            }
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function eCheckRunToken()
    {
        //Function to make a eCheck Sale
        $request = '<?xml version="1.0"?>
            <CheckSale xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <ConsentCode>' . $this->ConsentCode . '</ConsentCode>
                </Terminal>
                <PaymentAccount>
                    <PaymentAccountID>' . $this->PaymentAccountID . '</PaymentAccountID>
                </PaymentAccount>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                </Transaction>
                <DemandDepositAccount>
                    <DDAAccountType>' . $this->DDAAccountType . '</DDAAccountType>
                </DemandDepositAccount>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                </Address>
            </CheckSale>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['TransactionID'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function eCheckGetToken()
    {
        //Function to get a Token
        $request = '<?xml version="1.0"?>
            <PaymentAccountCreate xmlns="https://services.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <PaymentAccount>
                    <PaymentAccountType>' . $this->PaymentAccountType . '</PaymentAccountType>
                    <PaymentAccountReferenceNumber>' . $this->PaymentAccountReferenceNumber . '</PaymentAccountReferenceNumber>
                </PaymentAccount>
                <DemandDepositAccount>
                    <AccountNumber>' . $this->AccountNumber . '</AccountNumber>
                    <RoutingNumber>' . $this->RoutingNumber . '</RoutingNumber>
                </DemandDepositAccount>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                </Address>
            </PaymentAccountCreate>';

        $this->setUrl("https://services.elementexpress.com");
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
            $result['token'] = $resultx['PaymentAccount']['PaymentAccountID'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function eCheckSale()
    {
        //Function to make a eCheck Sale
        $request = '<?xml version="1.0"?>
            <CheckSale xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <ConsentCode>' . $this->ConsentCode . '</ConsentCode>
                </Terminal>
                <DemandDepositAccount>
                    <AccountNumber>' . $this->AccountNumber . '</AccountNumber>
                    <RoutingNumber>' . $this->RoutingNumber . '</RoutingNumber>
                    <DDAAccountType>' . $this->DDAAccountType . '</DDAAccountType>
                    <CheckType>' . $this->CheckType . '</CheckType>
                </DemandDepositAccount>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>7</MarketCode>
                </Transaction>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>
                    <BillingAddress1>' . $this->BillingAddress1 . '</BillingAddress1>
                    <BillingAddress2>' . $this->BillingAddress2 . '</BillingAddress2>
                    <BillingCity>' . $this->BillingCity . '</BillingCity>
                    <BillingState>' . $this->BillingState . '</BillingState>
                    <BillingZipcode>' . $this->BillingZipcode . '</BillingZipcode>
                    <BillingPhone>' . $this->BillingPhone . '</BillingPhone>
                </Address>
            </CheckSale>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = "Approved"; // $resultx['ExpressResponseMessage']; (Success)
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['TransactionID'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function eCheckCredit()
    {
        //Function to make a eCheck Credit
        $request = '<?xml version="1.0"?>
            <CheckCredit xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                    <ConsentCode>' . $this->ConsentCode . '</ConsentCode>
                </Terminal>
                <DemandDepositAccount>
                    <AccountNumber>' . $this->AccountNumber . '</AccountNumber>
                    <RoutingNumber>' . $this->RoutingNumber . '</RoutingNumber>
                    <DDAAccountType>' . $this->DDAAccountType . '</DDAAccountType>
                    <CheckType>' . $this->CheckType . '</CheckType>
                </DemandDepositAccount>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                </Transaction>
                <Address>
                    <BillingName>' . $this->BillingName . '</BillingName>
                </Address>
            </CheckCredit>';

        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = "Approved"; // $resultx['ExpressResponseMessage']; (Success)
            $result['reference'] = $resultx['Transaction']['TransactionID'];
            $result['authcode'] = $resultx['Transaction']['TransactionID'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function eCheckVoid()
    {
        //Function to make a eCheck Void
        $request = '<?xml version="1.0"?>
            <CheckVoid xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                </Terminal>
                <Transaction>
                    <TransactionID>' . $this->TransactionID . '</TransactionID>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                </Transaction>
            </CheckVoid>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function eCheckReturn()
    {
        //Function to make a eCheck Return
        $request = '<?xml version="1.0"?>
            <CheckReturn xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                </Terminal>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <TransactionID>' . $this->TransactionID . '</TransactionID>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <MarketCode>' . $this->MarketCode . '</MarketCode>
                </Transaction>
            </CheckReturn>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    function eCheckReversal()
    {
        //Function to make a Credit Card Reversal

        $request = '<?xml version="1.0"?>
            <CheckReversal xmlns="https://transaction.elementexpress.com">
               <Credentials>
                    <AccountID>' . $this->AccountID . '</AccountID>
                    <AccountToken>' . $this->AccountToken . '</AccountToken>
                    <AcceptorID>' . $this->AcceptorID . '</AcceptorID>
                </Credentials>
                <Application>
                    <ApplicationID>' . $this->ApplicationID . '</ApplicationID>
                    <ApplicationName>' . $this->ApplicationName . '</ApplicationName>
                    <ApplicationVersion>1.0.0</ApplicationVersion>
                </Application>
                <Terminal>
                    <TerminalID>' . $this->TerminalID . '</TerminalID>
                </Terminal>
                <Transaction>
                    <TransactionAmount>' . $this->TransactionAmount . '</TransactionAmount>
                    <TransactionID>' . $this->TransactionID . '</TransactionID>
                    <ReferenceNumber>' . $this->ReferenceNumber . '</ReferenceNumber>
                    <ReversalType>' . $this->ReversalType . '</ReversalType>
                </Transaction>
            </CheckReversal>';
        $response = $this->sendRequest($request);
        $resultx = $this->parseResponse($response);

        if ($resultx['ExpressResponseCode'] == '0' || $resultx['ExpressResponseCode'] == '5') {
            $result['response'] = 1;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        } else {
            $result['response'] = 3;
            $result['responsetext'] = $resultx['ExpressResponseMessage'];
        }
        return $result;
    }

    private function sendRequest($request)
    {
        //function to send Requests to Vantiv
        $url = $this->Url;

        $header = array(
            "Content-type: text/xml;charset=\"utf-8\"",
            "Accept: text/xml",
            "Cache-Control: no-cache",
            "Pragma: no-cache",
        );
        $ch = curl_init();

        // set the target url
        curl_setopt($ch, CURLOPT_URL, $url);
        // howmany parameter to post
        curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        //curl_setopt($ch, CURLOPT_VERBOSE, true);

        $result = curl_exec($ch);

        curl_close($ch);
        return $result;
    }

    private function parseResponse($str)
    {
        $xml = simplexml_load_string(str_replace("soap:", "", $str));
        $json = json_encode($xml);
        $array = json_decode($json, true);
        $result = $array['Response'];
        return $result;
    }

    //Getter and Setter
    function getTrack1Data()
    {
        return $this->Track1Data;
    }

    function getTrack2Data()
    {
        return $this->Track2Data;
    }

    function getMagneprintData()
    {
        return $this->MagneprintData;
    }

    function getEncryptedFormat()
    {
        return $this->EncryptedFormat;
    }

    function getCardDataKeySerialNumber()
    {
        return $this->CardDataKeySerialNumber;
    }

    function getEncryptedTrack1Data()
    {
        return $this->EncryptedTrack1Data;
    }

    function getEncryptedTrack2Data()
    {
        return $this->EncryptedTrack2Data;
    }

    function getEncryptedCardData()
    {
        return $this->EncryptedCardData;
    }

    function getUrl()
    {
        return $this->Url;
    }

    function getAccountID()
    {
        return $this->AccountID;
    }

    function getAccountToken()
    {
        return $this->AccountToken;
    }

    function getApplicationID()
    {
        return $this->ApplicationID;
    }

    function getAcceptorID()
    {
        return $this->AcceptorID;
    }

    function getTransactionAmount()
    {
        return $this->TransactionAmount;
    }

    function getClerkNumber()
    {
        return $this->ClerkNumber;
    }

    function getShiftID()
    {
        return $this->ShiftID;
    }

    function getSalesTaxesAmount()
    {
        return $this->SalesTaxesAmount;
    }

    function getConvenienceFeeAmount()
    {
        return $this->ConvenienceFeeAmount;
    }

    function getReferenceNumber()
    {
        return $this->ReferenceNumber;
    }

    function getMarketCode()
    {
        return $this->MarketCode;
    }

    function getTerminalID()
    {
        return $this->TerminalID;
    }

    function getCardPresentCode()
    {
        return $this->CardPresentCode;
    }

    function getCardholderPresentCode()
    {
        return $this->CardholderPresentCode;
    }

    function getCardInputCode()
    {
        return $this->CardInputCode;
    }

    function getCVVPresenceCode()
    {
        return $this->CVVPresenceCode;
    }

    function getTerminalCapabilityCode()
    {
        return $this->TerminalCapabilityCode;
    }

    function getTerminalEnvironmentCode()
    {
        return $this->TerminalEnvironmentCode;
    }

    function getMotoECICode()
    {
        return $this->MotoECICode;
    }

    function getBillingName()
    {
        return $this->BillingName;
    }

    function getBillingAddress1()
    {
        return $this->BillingAddress1;
    }

    function getBillingCity()
    {
        return $this->BillingCity;
    }

    function getBillingState()
    {
        return $this->BillingState;
    }

    function getBillingZipcode()
    {
        return $this->BillingZipcode;
    }

    function getAccountNumber()
    {
        return $this->AccountNumber;
    }

    function getRoutingNumber()
    {
        return $this->RoutingNumber;
    }

    function getCheckNumber()
    {
        return $this->CheckNumber;
    }

    function getCheckType()
    {
        return $this->CheckType;
    }

    function getCardNumber()
    {
        return $this->CardNumber;
    }

    function getExpirationMonth()
    {
        return $this->ExpirationMonth;
    }

    function getExpirationYear()
    {
        return $this->ExpirationYear;
    }

    function getCardholderName()
    {
        return $this->CardholderName;
    }

    function getCvv()
    {
        return $this->Cvv;
    }

    function getCardLogo()
    {
        return $this->CardLogo;
    }

    function getApplicationName()
    {
        return $this->ApplicationName;
    }

    function getTransactionID()
    {
        return $this->TransactionID;
    }

    function getDDAAccountType()
    {
        return $this->DDAAccountType;
    }

    function getConsetCode()
    {
        return $this->ConsentCode;
    }

    function getConsentCode()
    {
        return $this->ConsentCode;
    }

    function getPaymentAccountType()
    {
        return $this->PaymentAccountType;
    }

    function getPaymentAccountReferenceNumber()
    {
        return $this->PaymentAccountReferenceNumber;
    }

    function getPaymentAccountID()
    {
        return $this->PaymentAccountID;
    }

    function setTrack1Data($Track1Data)
    {
        $this->Track1Data = $Track1Data;
    }

    function setTrack2Data($Track2Data)
    {

        $this->Track2Data = $Track2Data;
    }

    function setMagneprintData($MagneprintData)
    {
        $this->MagneprintData = $MagneprintData;
    }

    function setEncryptedFormat($EncryptedFormat)
    {
        $this->EncryptedFormat = $EncryptedFormat;
    }

    function setCardDataKeySerialNumber($CardDataKeySerialNumber)
    {
        $this->CardDataKeySerialNumber = $CardDataKeySerialNumber;
    }

    function setEncryptedTrack1Data($EncryptedTrack1Data)
    {
        $this->EncryptedTrack1Data = $EncryptedTrack1Data;
    }

    function setEncryptedTrack2Data($EncryptedTrack2Data)
    {
        $this->EncryptedTrack2Data = $EncryptedTrack2Data;
    }

    function setEncryptedCardData($EncryptedCardData)
    {
        $this->EncryptedCardData = $EncryptedCardData;
    }

    function setConsentCode($ConsentCode)
    {
        $this->ConsentCode = $ConsentCode;
    }

    function setPaymentAccountType($PaymentAccountType)
    {
        $this->PaymentAccountType = $PaymentAccountType;
    }

    function setPaymentAccountReferenceNumber($PaymentAccountReferenceNumber)
    {
        $this->PaymentAccountReferenceNumber = $PaymentAccountReferenceNumber;
    }

    function setPaymentAccountID($PaymentAccountID)
    {
        $this->PaymentAccountID = $PaymentAccountID;
    }

    function setConsetCode($ConsetCode)
    {
        $this->ConsentCode = $ConsetCode;
    }

    function setDDAAccountType($DDAAccountType)
    {
        if ($DDAAccountType == "Checking") {
            $this->DDAAccountType = 0;
            $this->PaymentAccountType = 1;
        } elseif ($DDAAccountType == "Savings") {
            $this->DDAAccountType = 1;
            $this->PaymentAccountType = 2;
        }
    }

    function setTransactionID($TransactionID)
    {
        $this->TransactionID = $TransactionID;
    }

    function setApplicationName($ApplicationName)
    {
        $this->ApplicationName = $ApplicationName;
    }

    function setCardLogo($CardLogo)
    {
        $this->CardLogo = $CardLogo;
    }

    function setUrl($Url)
    {
        $this->Url = $Url;
    }

    function setAccountID($AccountID)
    {
        $this->AccountID = $AccountID;
    }

    function setAccountToken($AccountToken)
    {
        $this->AccountToken = $AccountToken;
    }

    function setApplicationID($ApplicationID)
    {
        $this->ApplicationID = $ApplicationID;
    }

    function setAcceptorID($AcceptorID)
    {
        $this->AcceptorID = $AcceptorID;
    }

    function setTransactionAmount($TransactionAmount)
    {

        $this->TransactionAmount = number_format($TransactionAmount, 2, '.', '');
    }

    function setClerkNumber($ClerkNumber)
    {
        $this->ClerkNumber = $ClerkNumber;
    }

    function setShiftID($ShiftID)
    {
        $this->ShiftID = $ShiftID;
    }

    function setSalesTaxesAmount($SalesTaxesAmount)
    {
        $this->SalesTaxesAmount = $SalesTaxesAmount;
    }

    function setConvenienceFeeAmount($ConvenienceFeeAmount)
    {
        $this->ConvenienceFeeAmount = number_format($ConvenienceFeeAmount, 2, '.', '');
    }

    function setReferenceNumber($ReferenceNumber)
    {
        $this->ReferenceNumber = $ReferenceNumber;
    }

    function setMarketCode($MarketCode)
    {
        $this->MarketCode = $MarketCode;
    }

    function setTerminalID($TerminalID)
    {
        $this->TerminalID = $TerminalID;
    }

    function setCardPresentCode($CardPresentCode)
    {
        $this->CardPresentCode = $CardPresentCode;
    }

    function setCardholderPresentCode($CardholderPresentCode)
    {
        $this->CardholderPresentCode = $CardholderPresentCode;
    }

    function setCardInputCode($CardInputCode)
    {
        $this->CardInputCode = $CardInputCode;
    }

    function setCVVPresenceCode($CVVPresenceCode)
    {
        $this->CVVPresenceCode = $CVVPresenceCode;
    }

    function setTerminalCapabilityCode($TerminalCapabilityCode)
    {
        $this->TerminalCapabilityCode = $TerminalCapabilityCode;
    }

    function setTerminalEnvironmentCode($TerminalEnvironmentCode)
    {
        $this->TerminalEnvironmentCode = $TerminalEnvironmentCode;
    }

    function setMotoECICode($MotoECICode)
    {
        $this->MotoECICode = $MotoECICode;
    }

    function setBillingName($BillingName)
    {
        $this->BillingName = $BillingName;
    }

    function setBillingAddress1($BillingAddress1)
    {
        $this->BillingAddress1 = $BillingAddress1;
    }

    function setBillingCity($BillingCity)
    {
        $this->BillingCity = $BillingCity;
    }

    function setBillingState($BillingState)
    {
        $this->BillingState = $BillingState;
    }

    function setBillingZipcode($BillingZipcode)
    {
        $this->BillingZipcode = $BillingZipcode;
    }

    function setAccountNumber($AccountNumber)
    {
        $this->AccountNumber = $AccountNumber;
    }

    function setRoutingNumber($RoutingNumber)
    {
        $this->RoutingNumber = $RoutingNumber;
    }

    function setCheckNumber($CheckNumber)
    {
        $this->CheckNumber = $CheckNumber;
    }

    function setCheckType($CheckType)
    {
        $this->CheckType = $CheckType;
    }

    function setCardNumber($CardNumber)
    {
        $this->CardNumber = $CardNumber;
    }

    function setExpirationMonth($ExpirationMonth)
    {
        $this->ExpirationMonth = $ExpirationMonth;
    }

    function setExpirationYear($ExpirationYear)
    {
        $this->ExpirationYear = $ExpirationYear;
    }

    function setCardholderName($CardholderName)
    {
        $this->CardholderName = $CardholderName;
    }

    function setCvv($Cvv)
    {
        $this->CVVPresenceCode = 2;
        $this->Cvv = $Cvv;
    }

    //optional function

    function is_eCheckIvr()
    {
        $this->ConsentCode = 2;
    }

    function is_eCheckInternet()
    {
        $this->ConsentCode = 3;
    }

    function is_eCheckFaceToFace()
    {
        $this->ConsentCode = 1;
    }

    function is_eCheckB2B()
    {
        $this->CheckType = 1;
    }

    function getTerminalType()
    {
        return $this->TerminalType;
    }

    function getTicketNumber()
    {
        return $this->TicketNumber;
    }

    function getPartialApprovedFlag()
    {
        return $this->PartialApprovedFlag;
    }

    function setTerminalType($TerminalType)
    {
        $this->TerminalType = $TerminalType;
    }

    function setTicketNumber($TicketNumber)
    {
        $this->TicketNumber = $TicketNumber;
    }

    function setPartialApprovedFlag($PartialApprovedFlag)
    {
        $this->PartialApprovedFlag = $PartialApprovedFlag;
    }

    function getReversalType()
    {
        return $this->ReversalType;
    }

    function setReversalType($ReversalType)
    {
        $this->ReversalType = $ReversalType;
    }

    function isCCD()
    {
        $this->CheckType = 1;
        $this->ConsentCode = 1;
    }

    function isPPD()
    {
        $this->CheckType = 0;
        $this->ConsentCode = 1;
    }

    function isTEL()
    {
        $this->ConsentCode = 2;
    }

    function setExpirationDate($exp)
    {
        $exp = str_pad($exp, 4, "0", STR_PAD_LEFT);
        $expMonth = substr($exp, 0, 2);
        $expYear = substr($exp, 2, 2);
        $this->setExpirationMonth($expMonth);
        $this->setExpirationYear($expYear);
    }
}
