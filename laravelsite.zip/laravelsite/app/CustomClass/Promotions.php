<?php

namespace App\CustomClass;

use App\Model\PromotionsModel;
use App\Model\User;

/*
 * Promotions Type:
 * 1- Visa
 * 2- Grubhub
 * 3- Lift
 *
 */

class Promotions
{

    private $web_user_id;
    private $property_id;
    private $obj_user;
    private $obj_promo;
    private $type; // id_promo
    private $clasifytopromo; // clasify to promotion or NOT
    private $name;

    function __construct($web_user_id, $property_id)
    {
        $this->web_user_id = $web_user_id;
        $this->property_id = $property_id;
        $this->obj_user = new User();
        $this->obj_promo = new PromotionsModel();
        $this->type = $this->getPromotionType();
        if ($this->type > 0) {//exist promotion ?
            $this->name = $this->obj_user->getPromotionName($this->type);
            $this->clasifytopromo = $this->getActiveUsrPromotions();
        }
    }

    //get what promotion applied to this property... return 0 is there are none
    function getPromotionType()
    {
        return $this->obj_user->getPromotions($this->property_id);
    }

    //user clasify to promotion
    function getActiveUsrPromotions()
    {
 //promo_done
        return $this->obj_user->gethasUsrActivePromotion($this->web_user_id, $this->property_id, $this->type);
    }

    function getPromotionImage()
    {
        return $this->obj_promo->getPromoContent($this->type);
    }

    function getPromotionLink()
    {
        return $this->obj_promo->getPromoLink($this->type);
    }

    function getSetCodeAvailable($trans_id)
    {
        $code = "";
        if ($this->getActiveUsrPromotions()) {
            //has already this promotion
            return false;
        }
        switch ($this->type) {
            case 1:
            case 4:
            case 5:
            case 6:
            case 8:
                if ($this->obj_user->isValidVisaPromotion($trans_id, $this->property_id, $this->web_user_id)) {
                    $code = "VISA";
                }
                break;
            case 2:
            case 3:
                $code = $this->obj_user->getNextAvailablePromo($this->type);
                break;
            case 10:
                if ($this->obj_user->isValidMCPromotion($trans_id, $this->property_id, $this->web_user_id)) {
                    $code = "Mastercard";
                }
                break;
            case 99:
                $code = "Lyft";
                break;
            default:
                break;
        }
        if (!empty($code)) {
            $this->appliedPromo($trans_id, $code);
        }
    }

    function appliedPromo($trans_id, $code)
    {
        $this->obj_user->insertPromoDone($this->type, $this->web_user_id, $this->property_id, $trans_id, $code);
    }

    function getCodeApplied($trans_id)
    {
        $code = "";
        switch ($this->type) {
            case 1:
            case 4:
            case 5:
            case 6:
            case 8:
                $value = $this->obj_user->getPromoApplied($trans_id);
                if (!empty($value)) {
                    $code = "Congratulations! You have qualified for a $10 Amazon.com reward for scheduling your payments! You'll receive your eGift card via email within 24 hours.";
                }
                break;
            case 3:
            case 2:
                $value = $this->obj_user->getPromoApplied($trans_id);
                if (!empty($value)) {
                    $code = "Congratulations! You earned a GrubHub reward for making your payment! Go to GrubHub.com to redeem your unique $6 coupon towards lunch or dinner: " . $value;
                }
                break;
            case 10:
                $value = $this->obj_user->getPromoApplied($trans_id);
                if (!empty($value)) {
                    $code = "Congratulations! You have qualified for a $20 prepaid Mastercard reward for scheduling your payments! You'll receive your card via mail.";
                }
                break;
            case 99:
                $code = "Lyft: Promo Code RevoPay";
                break;
            default:
                break;
        }
        return $code;
    }

    //get
    function getClasifyToPromo()
    {
        return $this->clasifytopromo;
    }

    function getType()
    {
        return $this->type;
    }

    function getName()
    {
        return $this->name;
    }

    function getPromoByTransId($trans_id)
    {
        $promoInfo = $this->obj_user->getPromoDoneInfo($trans_id, $this->web_user_id, $this->property_id);
        if (empty($promoInfo)) {
            return "";
        }
        $code = "";
        switch ($this->type) {
            case 1:
            case 4:
            case 5:
            case 6:
            case 8:
                $value = $this->obj_user->getPromoApplied($trans_id);
                if (!empty($value)) {
                    $code = "VISA: You will receive soon the Amazon give card";
                }
                break;
            case 2:
            case 3:
                $value = $this->obj_user->getPromoApplied($trans_id);
                if (!empty($value)) {
                    $code = "GRUBHUB: Promo Code " . $value;
                }
                break;
            case 10:
                $value = $this->obj_user->getPromoApplied($trans_id);
                if (!empty($value)) {
                    $code = "Mastercard: You will receive soon the MC prepaid card";
                }
                break;
            case 99:
                $code = "Lyft: Promo Code RevoPay";
                break;
            default:
                break;
        }
        return $code;
    }
}
