<?php
namespace App\CustomClass;
/**
 * Class to connect to TOPS API
 *
 * @author lnorat
 */
class TOPSconnection {
    protected $ckey; //sandbox CFC21A74-7AA2-4948-B658-49E4480CF30C
    //sandbox
    /*
    protected $api_key= 'NDY2MTdDNzktQzAwQS00MDY5LUFFRjEtNkFGMzczQTJENjQxOjYxQUYyMzA0LTg5N0YtNEY5Ri1BNjVCLTRBQUI3NzdBOEJEMg==';
    protected $api_url='https://topsconnectapi.azure-api.net/sandbox/api/';
    protected $suscription_key='7a422168e3924088823f999b8a3f1c3e';
     */
     
     
    //production
    protected $api_key= 'NTMwNzRGMkYtQkZGMS00QzAyLUI4RUEtOUM5NTVEQzMyMDQ0OjRGREQzNjNDLUQ2RTMtNDJFQy04OTk1LUI1MEY2NDFDOUU4Mg==';
    //protected $api_url='https://topsconnectapi.azure-api.net/broad/api/'; old URL
    protected $api_url='https://topsconnectapi.azure-api.net/v2/broad/api/';// V2 URL
    protected $suscription_key='b485574a3886456f98b6f72c68985d30';
    
    
    function __construct($community_key=""){
       $this->ckey=$community_key;
    }
    
    function setCommunityKey($community_key){
        $this->ckey=$community_key;
    }
    
    function getCommunityList(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('community');
        $result=json_decode($data,true);
        return $result;
    }
    
    function getCommunityData($key){
        /*
         * json for community
         * {
    "Address1": "C/O TOPS Management",
    "Address2": "2495 Enterprise Rd, Ste 201",
    "City": "Clearwater",
    "CommunityKey": 6,
    "CommunityID": "CEH",
    "DefaultCity": "Safety Harbor",
    "DefaultState": "FL",
    "DefaultZip4": "",
    "DefaultZip": "34695",
    "Email": "",
    "Fax": "",
    "LastSyncTime": "2015-05-27T12:23:31",
    "Name": "Country Estates HOA",
    "Phone1": "800-760-9966",
    "Phone2": "",
    "State": "FL",
    "Zip4": "",
    "Zip": "33763",
    "Links": [
      {
        "rel": "self",
        "href": "community/6"
      }
    ],
    "Metadata": {
      "ModifiedDate": null
    }
  }
         */
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('community','/'.$key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function getPropertyList(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('property');
        $result=json_decode($data,true);
        return $result;
    }
    
    function getPropertyData($key){
        /*
         * property structure
         * {
            "Account_Number": "111",
            "Address_Number": "111",
            "Apt_Number": "",
            "City": "Odessa",
            "CmtyKey": 5,
            "Lot_Unit_Number": "1A",
            "PropKey": 1,
            "State": "FL",
            "Street": "Magnolia Way",
            "Zip": "33726",
            "Links": [
                {
                    "rel": "parent",
                    "href": "community/5"
                },
                {
                    "rel": "self",
                    "href": "property/1"
                }
            ],
            "Metadata": { }
            }
         */
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('property','/'.$key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function putPropertyDataByKey($key,$data){
        if(empty($this->ckey))return false;
        $result=$this->send2TAPI('property','/'.$key,'PUT',json_encode($data));
        return $result;
    }

    function getAllOwnerList(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('owner');
        $result=json_decode($data,true);
        return $result;
    }

    function getOwnerDataByProperty($prop_key,$cmt_key){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('owner','','GET','propertykey='.$prop_key.'&communitykey='.$cmt_key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function getOwnerDataByKey($key){
        /*
        {
  "AltMailing1AddressLine1": "",
  "AltMailing1AddressLine2": "",
  "AltMailing1City": "",
  "AltMailing1State": "",
  "AltMailing1Zip": "",
  "AltMailing2AddressLine1": "",
  "AltMailing2AddressLine2": "",
  "AltMailing2City": "",
  "AltMailing2State": "",
  "AltMailing2Zip": "",
  "CommunityKey": 6,
  "LegalName": "Rose Hall",
  "AlternateName": "",
  "MoveOutDate": null,
  "OwnerKey": 1,
  "ResidentType": "Owner",
  "PhoneAlt": "",
  "PhoneFax": "",
  "PhoneHome": "727-555-4587",
  "PhoneWork": "",
  "PropertyKey": 1,
  "SettlementDate": null,
  "Links": [
    {
      "rel": "parent",
      "href": "property/1"
    },
    {
      "rel": "self",
      "href": "owner/1"
    },
    {
      "rel": "child",
      "href": "balance/1"
    },
    {
      "rel": "child",
      "href": "charge/1"
    },
    {
      "rel": "child",
      "href": "email?ContactType=Owner&ContactKey=1"
    }
  ],
  "Metadata": {}
}
        */
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('owner','/'.$key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function putOwnerDataByKey($key,$data){
        if(empty($this->ckey))return false;
        $result=$this->send2TAPI('owner','/'.$key,'PUT',json_encode($data));
        return $result;
    }
    
    function getOwnerBalanceByKey($key){
        /*
        {
  "Links": [
    {
      "rel": "parent",
      "href": "owner/1"
    },
    {
      "rel": "self",
      "href": "balance/1"
    }
  ],
  "BalanceDetails": [
    {
      "CashApplicationOrder": 1,
      "ChargeCode": "A1",
      "Year": "",
      "Balance": 0,
      "Description": "Fees"
    }
  ],
  "BalanceTotal": 0,
  "OwnerKey": 1,
  "Prepaid": 0,
  "Metadata": {
    "UsesYearlyAccounting": false,
    "UsesRentalAccounting": true
  }
}
        */
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('balance','/'.$key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function getAccountingList(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('account');
        $result=json_decode($data,true);
        return $result;
    }
    
    function getAccountingByKey($key){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('account','/'.$key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function getBankList(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('bank');
        $result=json_decode($data,true);
        return $result;
    }
    
    function getInvoiceList(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('invoice');
        $result=json_decode($data,true);
        return $result;
    }
    
    function getInvoiceByKey($key){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('invoice','/'.$key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function getVendorList(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('vendor');
        $result=json_decode($data,true);
        return $result;
    }

    function getChargeCodeList(){
        /*
        * charge code structure
        {
    "ChargeCodeKey": 1,
    "Code": "A1",
    "CommunityKey": 6,
    "Description": "Fees",
    "Links": [
      {
        "rel": "parent",
        "href": "community/6"
      },
      {
        "rel": "self",
        "href": "chargecode/1"
      }
    ],
    "Metadata": {
      "ModifiedDate": "2015-09-02T15:00:23"
    }
  }
        */
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('chargecode');
        $result=json_decode($data,true);
        return $result;
    }
    
    function getChargeCodeByKey($key){
       if(empty($this->ckey))return false;
        $data=$this->send2TAPI('chargecode','/'.$key);
        $result=json_decode($data,true);
        return $result; 
    }
    
    function getVendorByKey($key){
        /*
         * vendor structure
         * 
         * {
            "AccountKey": 152,
            "Address1": "100 Main Street",
            "Address2": "Gaithersburg, MD 20879",
            "Address3": "",
            "CommunityKey": 6,
            "Contact": "Bill Jones",
            "Contact2": "",
            "FederalTaxID": "52-1123563",
            "LiabilityCompany": "Any State Insurance",
            "LiabilityExpirationDate": "2018-01-01T00:00:00",
            "LiabilityPolicyNumber": "12763CA124",
            "Name": "ABC MAINTENANCE",
            "Number": "ABC",
            "Phone": "301 555 1215",
            "Phone2": "",
            "VendorKey": 1,
            "WorkersCompCompany": "aa",
            "WorkersCompExpirationDate": "1999-12-31T00:00:00",
            "WorkersCompPolicyNumber": "aswda",
            "Links": [
              {
                "rel": "parent",
                "href": "community/6"
              },
              {
                "rel": "self",
                "href": "vendor/1"
              },
              {
                "rel": "child",
                "href": "email?ContactType=Vendor&ContactKey=1"
              },
              {
                "rel": "sibling",
                "href": "account152"
              }
            ],
            "Metadata": {
              "ModifiedDate": "2015-05-27T16:23:31"
            }
          },
         */
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('vendor','/'.$key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function sendVendor($key,$mode,$data){
        if(empty($this->ckey))return false;
        $result=$this->send2TAPI('vendor','/'.$key,$mode,json_encode($data));
        return $result;
    }
    
    function sendEmail($key,$mode,$data){
        if(empty($this->ckey))return false;
        $result=$this->send2TAPI('email','/'.$key,$mode,json_encode($data));
        return $result;
    }
    
    function getGeneralInfo(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('general');
        $result=json_decode($data,true);
        return $result;
    }
    
    function getCapability(){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('company');
        $result=json_decode($data,true);
        return $result;
    }
    
    function getOwnerEmail($key,$type='Owner'){
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('email','','GET','contactkey='.$key.'&contacttype='.$type);
        $result=json_decode($data,true);
        return $result;
    }
    
    function getBankByKey($key){
        /*
         * sample structure for bank record
         * 
         * {
            "BankAddress1":"123 Easy Street",
            "BankAddress2":"Clearwater FL 33456",
            "BankAddress3":null,
            "BankKey":1,
            "BankName":"Testing Bank",
            "CommunityKey":5,
            "AccountKey":12,
            "LastCheckNumber":123456
            "Links":[
               {
                  "rel":"parent",
                  "href":"community/5"
               },
               {
                  "rel":"self",
                  "href":"bank/1"
               },
               {
                  "rel":"sibling",
                  "href":"account/12"
               }
            ],
            "Metadata":{
               "ModifiedDate":"2015-05-26T00:00:00"
            }
         }
         */
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('bank','/'.$key);
        $result=json_decode($data,true);
        return $result;
    }
    
    function postReceiptBatch($data){
        /*
         * sample structure for a receipt by owner
         * 
         * {
                "CommunityKey": 5,
                "BankKey":1,
                "ReceiptDate":"2015-08-06T00:00:00",
                "ReceiptItems":[
                   {
                      "OwnerKey":52,
                      "ReceivedDate":"2015-08-01T00:00:00",
                      "CheckNumber":"123T",
                      "Amount":30.00
                   },
                   {
                      "OwnerKey":55,
                      "ReceivedDate":"2015-07-22T00:00:00",
                      "CheckNumber":"124T",
                      "Amount":100.00
                   }
                ]
            }
         */
        if(empty($this->ckey))return false;
        $result=$this->send2TAPI('receiptbatch','','POST',json_encode($data));
        return $result; 
        /*
        response from postreceiptbatch
        {
  "ReceiptBatchKey": 4,
  "CommunityKey": 6,
  "BankKey": 7,
  "ReceiptDate": "2015-09-06T00:00:00",
  "Links": [
    {
      "rel": "parent",
      "href": "community/6"
    },
    {
      "rel": "self",
      "href": "receiptbatch/4"
    }
  ],
  "ReceiptItems": [
    {
      "ReceiptItemKey": 3,
      "ReceiptBatchKey": 4,
      "CommunityKey": 0,
      "OwnerKey": 1,
      "ReceivedDate": "2015-09-01T00:00:00",
      "Amount": 30,
      "CheckNumber": "1213T"
    }
  ]
}
        */
    }
    
    function postChargeBatch($data){
    /*JSOn structure for chargebatch
    {
        "CommunityKey": 6,
        "EffectivetDate":"2015-08-06T00:00:00",
    "ChargeItems": [
        {
            "OwnerKey": 1,
            "ChargeCodeKey": 3, (chargecode/3 = NSF Fee)
            "Amount": 35.0,
        },
        {
            "OwnerKey":1,
            "ChargeCodeKey": 1, (chargecode/1 = Fees)
            "Amount": 25.0,
        },
        {
            "OwnerKey":1,
            "ChargeCodeKey": 14, (chargecode/14 = CCR Fine)
            "Amount": 100.0,
        }
    ],
    "CommunityKey": 6,
    "EffectiveDate": "2015-09-03T00:00:00"
}
    */    
        if(empty($this->ckey))return false;
        $result=$this->send2TAPI('chargebatch','','POST',json_encode($data));
        return $result; 
        /*
        response for chargebatch
        {
  "ChargeBatchKey": 4,
  "CommunityKey": 6,
  "EffectiveDate": "2015-08-06T00:00:00",
  "Links": [
    {
      "rel": "parent",
      "href": "community/6"
    },
    {
      "rel": "self",
      "href": "chargebatch/4"
    }
  ],
  "ChargeItems": [
    {
      "Amount": 35,
      "ChargeBatchKey": 4,
      "ChargeCodeKey": 3,
      "ChargeItemKey": 4,
      "OwnerKey": 1
    }
  ]
}
*/
    }
    
    //get companies
    //Danieyis Santiago
    
    function getCompanies()
    {
        if(empty($this->ckey))return false;
        $data=$this->send2TAPI('company');
        $result=json_decode($data,true);
        return $result;
    }
    
    private function send2TAPI($endpoint,$parameters=null,$mode='GET',$data=null){
        $url=$this->api_url.$endpoint.$parameters.'?';
        if(!empty($this->suscription_key))$url.='subscription-key='.$this->suscription_key.'&';
        if($mode=='GET' && !empty($data))$url.=$data;
        
        $ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $mode);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                'api-version: 1',
                                'authorization: Basic '.$this->api_key,
                                'community-api-key: '.$this->ckey,
                                'Content-Type: application/json'
        ));
	if($mode!='GET'){
            $todata=$data;
            curl_setopt($ch, CURLOPT_POSTFIELDS, $todata);
        }    
	curl_setopt($ch, CURLOPT_TIMEOUT, 600);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	$result = curl_exec($ch);
        $rcode=curl_getinfo($ch,CURLINFO_HTTP_CODE);
	curl_close($ch);
        if($mode=='PUT')return $rcode;
	return $result;
    }
    
    
}