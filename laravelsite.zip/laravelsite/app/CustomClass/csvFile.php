<?php
namespace App\CustomClass;
use Illuminate\Support\Facades\DB;
/*
 * CSV file format
 * User account,First name,Last name,Property ID,Amount,Routing number,Bank Account number,User email address
 */
class csvFile {
    private $file;
    private $tid;
    
    function __construct($content,$tid=0)
    {
        $this->file=$content;
        $this->tid=$tid;
        DB::table('import_batch_file')->where('idimport_batch_file',$tid)->update(['records'=>count($this->file)]);
    }
    
    function updatePayments($level,$idlevel,$data){
        $data2p=$this->file;
        $objusr=new \App\Model\WebUsers();
        $objtx=new \App\Model\Transations();
        $objprop=new \App\Model\Properties();
        $objbatch=new \App\Model\ImportBatchFile();
        $currentline=0;
        foreach($data2p as $p2data){
            $currentline++;
            $line=str_getcsv($p2data);
            if(!empty($line)){
                if(count($line)<8){
                    $objbatch->insertSummaryLine($this->tid, $currentline, 'invalid number of columns');
                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                    continue;
                }
                else {
                    $account_number=trim($line[0]);
                    $aname=trim($line[1]);
                    $atype=trim($line[2]);
                    $pid=trim($line[3]);
                    $amount=trim(str_replace(',','',$line[4]))*1;
                    $routing=trim($line[5]);
                    $bank=trim($line[6]);
                    $email=trim($line[7]);
                    if($account_number==''){
                        //error
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'empty Account number');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                        continue;
                    }
                    if($level=='P'){
                        if($pid!=''){
                            $result= DB::table('properties')->where('id_partners',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                            if(empty($result)){
                                //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $propertyid=$result->id;
                        }
                        else {
                            //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            continue;
                        }
                    }
                    elseif($level=='G'){
                        if($pid!=''){
                            $result= DB::table('properties')->where('id_companies',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                            if(empty($result)){
                                //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $propertyid=$result->id;
                        }
                        else {
                            //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            continue;
                        }
                    }
                    elseif($level=='M'){
                        $propertyid=$idlevel;
                    }
                    $usr=$objusr->searchWebUserAcc($account_number, $propertyid);
                    if(empty($usr)){
                        //no user
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'Payor not found: '.$account_number);
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                        continue;
                    }
                    $web_user_id=$usr->web_user_id;
                    if($amount<0){
                        //cancel autopayment
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'Canceled autopayment for '.$account_number);
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('completed');                                
                        $objtx->cancelRTxByUser($web_user_id);
                    }
                    else {
                        $credentials=$objprop->getCredentialtype_isrecurring('ec', $propertyid, 1);
                        $toupdate=array();
                        $toupdate['trans_recurring_net_amount']=$amount;
                        $cfee=$objtx->getFee($credentials, $amount);
                        if(!isset($cfee['CFEE'])){
                            //error
                            $objbatch->insertSummaryLine($this->tid, $currentline, 'Error calculating Fee');
                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            continue;
                        }
                        $toupdate['trans_recurring_convenience_fee']=$cfee['CFEE'];
                        $toupdate['trans_descr']='Payment: '.$amount;
                        if($routing!=''){
                            if(!$objtx->getRoutingNumber($routing)){
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Invalid Routing Number: '.$routing);
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $toupdate['echeck_routing_number']=$routing;
                        }
                        if($bank!=''){
                            $toupdate['trans_card_type']='Checking('.substr($bank,-4).')';
                            $toupdate['echeck_account_number']=$bank;
                            $toupdate['profile_id']=0;
                        }
                        if($aname!=''){
                            $toupdate['echeck_account_holder']=$aname;
                        }
                        if($atype!=''){
                            if(substr($atype,0,1)=='S'){
                                $toupdate['echeck_account_type']='Savings';
                                if(isset($toupdate['trans_card_type'])){
                                    $toupdate['trans_card_type']='Savings('.substr($bank,-4).')';
                                }
                            }
                            else {
                                $toupdate['echeck_account_type']='Checking';
                            }
                        }
                        if($data['fq']!='now'){
                            $toupdate['trans_schedule']=$data['fq'];
                            $stdate=$data['sy'].'-'.$data['sm'].'-'.$data['sd'];
                            if(strtotime($stdate)<=strtotime(date('Y-m-d'))){
                                //error today
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Error in start date');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $toupdate['trans_next_post_date']=date('Y-m-d',strtotime($stdate));
                            switch($data['fq']){
                                case 'onetime':
                                    $toupdate['trans_numleft']=1;
                                    break;
                                case 'monthly':
                                    $toupdate['trans_numleft']=1200;
                                    break;
                                case 'quarterly':
                                    $toupdate['trans_numleft']=400;
                                    break;
                                case 'annually':
                                    $toupdate['trans_numleft']=100;
                                    break;
                                default:
                                    $objbatch->insertSummaryLine($this->tid, $currentline, 'Invalid frequency. Ignored');
                                    break;
                            }
                        }
                        $toupdate['last_updated']=date('Y-m-d H:i:s');
                        $toupdate['last_updated_by']='batch import tool';
                        $objtx->updateRTxByUserDynamic($web_user_id, $toupdate, 'ec');
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'Updated Autopayment for '.$account_number);
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('completed');                                
                    }
                }
            }                                            
         }
    }
    
    function createPayments($level,$idlevel,$data){
        $data2p=$this->file;
        $objusr=new \App\Model\WebUsers();
        $objtx=new \App\Model\Transations();
        $objprop=new \App\Model\Properties();
        $objapi=new \App\CustomClass\RevoAPI();
        $objbatch=new \App\Model\ImportBatchFile();
        $currentline=0;
        foreach($data2p as $p2data){
            $currentline++;
            $line=str_getcsv($p2data);
            if(!empty($line)){
                if(count($line)<8){
                    //error
                    $objbatch->insertSummaryLine($this->tid, $currentline, 'invalid number of columns');
                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                    continue;
                }
                else {
                    $account_number=trim($line[0]);
                    $aname=trim($line[1]);
                    $atype=trim($line[2]);
                    $pid=trim($line[3]);
                    $amount=trim(str_replace(',','',$line[4]))*1;
                    $routing=trim($line[5]);
                    $bank=trim($line[6]);
                    $email=trim($line[7]);
                    if($aname==''){
                        //empty payor
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'empty Account number');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                        continue;
                    }
                    if($routing==''){
                        //empty routing
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'empty Routing number');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                        continue;
                    }
                    if($bank==''){
                        //empty bank
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'empty Bank Account number');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                        continue;
                    }
                    if($level=='P'){
                        if($pid!=''){
                            $result= DB::table('properties')->where('id_partners',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                            if(empty($result)){
                                //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $propertyid=$result->id;
                        }
                        else {
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            continue;
                        }
                    }
                    elseif($level=='G'){
                        if($pid!=''){
                            $result= DB::table('properties')->where('id_companies',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                            if(empty($result)){
                                //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $propertyid=$result->id;
                        }
                        else {
                            //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            continue;
                        }
                    }
                    elseif($level=='M'){
                        $propertyid=$idlevel;
                    }
                    
                    if($amount<=0){
                        //no valid
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'Amount zero or negative. Skipped payment for '.$account_number);
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('completed');                                
                        continue;
                    }
                    else {
                        if(!$objtx->getRoutingNumber($routing)){
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Invalid Routing Number: '.$routing);
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                        $toupdate=array();
                        $payor=array();
                        if($account_number!=''){
                                $payor['account_number']=$account_number;
                        }
                        if($aname!=''){
                                $payor['first_name']=$aname;
                        }
                        $payment=array();
                        $payment['TransactionAmount']=$amount;
                        $payment['Source']='batchImport';
                        $stdate=$data['sy'].'-'.$data['sm'].'-'.$data['sd'];
                        if(strtotime($stdate)<=strtotime(date('Y-m-d'))){
                            //error before today
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Error in start date');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            continue;
                        }
                        $payment['StartDate']=date('Y-m-d',strtotime($stdate));
						if($data['dynamic']!=''){
							$payment['Dynamic']=1;
						}
                        switch($data['fq']){
                            case 'onetime':
                                $payment['Frequency']=0;
                                $payment['RunCycle']=1;
                                break;
                            case 'quarterly':
                                $payment['Frequency']=4;
                                $payment['RunCycle']=400;
                                break;
                            case 'annually':
                                $payment['Frequency']=6;
                                $payment['RunCycle']=100;
                                break;
                            case 'monthly':
                            default:    
                                $payment['Frequency']=3;
                                $payment['RunCycle']=1200;
                                break;
                        }

                        $categories=array();
                        $categories[]=array('name'=>'Payment','amount'=>$amount);
                        $method=array();
                        $method['AccountHolder']=$aname;
                        $method['BankAccount']=$bank;
                        $method['BankRouting']=$routing;
                        $method['BankType']=0;
                        if($atype!=''){
                            if(substr($atype,0,1)=='S'){
                                    $method['BankType']=1;	                                
                            }
                        }
                        $toupdate['payor']=$payor;
                        $toupdate['payment']=$payment;
                        $toupdate['categories']=$categories;
                        $toupdate['paymentMethod']=$method;
                        $response=$objapi->sendPayment($toupdate,$propertyid);
                        if(isset($response['response'])){
                            if($response['response']==1){
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Approved payment for '.$account_number);
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            }
                            else {
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Error in payment for '.$account_number.' -> '.json_encode($response));
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            }
                        }
                        else {
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Error sending Payment');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                        }
                    }
                }
            }                                            
         }
    }
    
    function processPayments($level,$idlevel,$data){
        $data2p=$this->file;
        $objusr=new \App\Model\WebUsers();
        $objtx=new \App\Model\Transations();
        $objprop=new \App\Model\Properties();
        $objapi=new \App\CustomClass\RevoAPI();
        $objbatch=new \App\Model\ImportBatchFile();
        $currentline=0;
        foreach($data2p as $p2data){
            $currentline++;
            $line=str_getcsv($p2data);

            if(!empty($line)){
                if(count($line)<8){
                    //error
                    $objbatch->insertSummaryLine($this->tid, $currentline, 'invalid number of columns');
                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                    continue;
                }
                else {
                    $account_number=trim($line[0]);
                    $aname=trim($line[1]);
                    $atype=trim($line[2]);
                    $pid=trim($line[3]);
                    $amount=trim(str_replace(',','',$line[4]))*1;
                    $routing=trim($line[5]);
                    $bank=trim($line[6]);
                    $email=trim($line[7]);
                    if($aname==''){
						//empty payor
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'empty Account number');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                            continue;
                    }
                    if($routing==''){
                        //empty routing
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'empty Routing number');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                        continue;
                    }
                    if($bank==''){
                        //empty bank
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'empty Bank Account number');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                        continue;
                    }
                    
                    if($level=='P'){
                        if($pid!=''){
                            $result= DB::table('properties')->where('id_partners',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                            if(empty($result)){
                                //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $propertyid=$result->id;
                        }
                        else {
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            continue;
                        }
                    }
                    elseif($level=='G'){
                        if($pid!=''){
                            $result= DB::table('properties')->where('id_companies',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                            if(empty($result)){
                                //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $propertyid=$result->id;
                        }
                        else {
                            //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            continue;
                        }
                    }
                    elseif($level=='M'){
                        $propertyid=$idlevel;
                    }
                    if($amount<=0){
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'Amount zero or negative. Skipped payment for '.$account_number);
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('completed');                                
                        continue;
                    }
                    else {
                        if(!$objtx->getRoutingNumber($routing)){
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Invalid Routing Number: '.$routing);
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                        $toupdate=array();
                        $payor=array();
                        if($account_number!=''){
                                $payor['account_number']=$account_number;
                        }
                        if($aname!=''){
                                $payor['first_name']=$aname;
                        }
                        $payment=array();
                        $payment['TransactionAmount']=$amount;
                        $payment['Source']='batchImport';
                        $categories=array();
                        $categories[]=array('name'=>'Payment','amount'=>$amount);
                        $method=array();
                        $method['AccountHolder']=$aname;
                        $method['BankAccount']=$bank;
                        $method['BankRouting']=$routing;
                        $method['BankType']=0;
                        if($atype!=''){
                            if(substr($atype,0,1)=='S'){
                                $method['BankType']=1;	                                
                            }
                        }
                        $toupdate['payor']=$payor;
                        $toupdate['payment']=$payment;
                        $toupdate['categories']=$categories;
                        $toupdate['paymentMethod']=$method;
                        $response=$objapi->sendPayment($toupdate,$propertyid);
                        if(isset($response['response'])){
                            if($response['response']==1){
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Approved payment for '.$account_number);
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            }
                            else {
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Error in payment for '.$account_number.' -> '.json_encode($response));
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            }
                        }
                        else {
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Error sending Payment');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                        }
                    }
                }
            }                                            
         }
        
    }
    
}