<?php
namespace App\CustomClass;
use Illuminate\Support\Facades\DB;
/*
 * CSV file format
 * User account,First name,Last name,Property ID,Amount,Routing number,Bank Account number,User email address
 */
class nachaFile {
    private $file;
    private $tid;
    
    function __construct($content,$tid=0)
    {
        $this->file=$content;
        $this->tid=$tid;
        DB::table('import_batch_file')->where('idimport_batch_file',$tid)->update(['records'=>count($this->file)]);
    }

	private function CleanString ($string){
        $string = str_replace("#", "", $string);
        $string = str_replace("/", "", $string);
        $string = str_replace("$", "", $string);
        $string = str_replace("\\", "", $string);
        $string = str_replace("%", "", $string);
        $string = preg_replace( '/[^[:print:]]/', ' ',$string);
        return $string;
    }

	function processPayments($level,$idlevel,$data){
		$data2p=$this->file;
        $objusr=new \App\Model\WebUsers();
        $objtx=new \App\Model\Transations();
        $objproperty=new \App\Model\Properties();
        $objapi=new \App\CustomClass\RevoAPI();
        $objbatch=new \App\Model\ImportBatchFile();
		$identifier=0;
                $currentline=0;
		foreach($data2p as $p2data){
                    $currentline++;
                $p2data=$this->CleanString($p2data);
                $ltype=substr($p2data,0,1);
                if($ltype=='5'){
                    //start property
                    if($level=='M') {
                            $current_p=$idlevel;
                            continue;
                    }
                    else {
                        $current_p=0;
                        $pid=trim(substr($p2data,40,10));
                        $pname=trim(substr($p2data,4,16));
                        if($level=='P'){
                            if($pid!=''){
                                    $result= DB::table('properties')->where('id_partners',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                                    if(empty($result)){
                                            //error
                                             $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                                            continue;
                                    }
                                    $current_p=$result->id;
                            }
                            else {
                                    //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                                continue;
                            }
                        }
                        else {
                            if($pid!=''){
                                    $result= DB::table('properties')->where('id_companies',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                                    if(empty($result)){
                                            //error
                                         $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                                            continue;
                                    }
                                    $current_p=$result->id;
                            }
                            else {
                                    //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                                    continue;
                            }
                        }
                        if(empty($current_p)){
							//merchant does not exists
                            $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                            continue;
                        }
                    }
                }
                elseif(substr($p2data,0,3)=='627' || substr($p2data,0,3)=='637'){
                    if(empty($current_p)){
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'Skipped payment because Paypoint does not found');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                        continue;
                    }
                        if(substr($p2data,0,3)=='627')$pmethod='Checking';
                        else $pmethod='Savings';
                        $routing=trim(substr($p2data,3,9));
                        $account=trim(substr($p2data,12,17));
                        $amount=(trim(substr($p2data,29,8)).".".trim(substr($p2data,37,2)))*1;
                        $user_num=trim(substr($p2data,39,15));
                        $user_name=str_replace("'","",trim(substr($p2data,54,22)));
                        $user_name=str_replace("/","",$user_name);
                        $user_name=str_replace('"',"",$user_name);
                        $user_name=str_replace('$',"",$user_name);
                        $user_name=str_replace('&'," ",$user_name);
                        $user_name=str_replace('\\',"",$user_name);
                        $user_name=str_replace("\r","",$user_name);
                        $user_name=str_replace("\n","",$user_name);
                        $user_name=str_replace("#"," ",$user_name);
                        $user_name=  strip_tags($user_name);
                        $user_name.=",";
                        list($last_name,$first_name)=explode(',',$user_name);
                        if(empty($first_name)){
                            $first_name=$last_name;
                            $last_name='';
                        }
                        
                        if($amount>0){
                            if(!$objtx->getRoutingNumber($routing)){
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Invalid Routing Number: '.$routing);
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $toupdate=array();
                            $payor=array();
                            if($user_num!=''){
                                    $payor['account_number']=$user_num;
                            }
                            if($first_name!=''){
                                    $payor['first_name']=$first_name;
                                    $payor['last_name']=$last_name;
                            }
                            $payment=array();
                            $payment['TransactionAmount']=$amount;
                            $payment['Source']='NACHA';
                            $categories=array();
                            $categories[]=array('name'=>'Payment','amount'=>$amount);
                            $method=array();
                            $method['AccountHolder']=trim($first_name.' '.$last_name);
                            $method['BankAccount']=$account;
                            $method['BankRouting']=$routing;
                            $method['BankType']=0;
                            if($pmethod!=''){
                                    if(substr($pmethod,0,1)=='S'){
                                            $method['BankType']=1;	                                
                                    }
                            }
                            $toupdate['payor']=$payor;
                            $toupdate['payment']=$payment;
                            $toupdate['categories']=$categories;
                            $toupdate['paymentMethod']=$method;
                            $response=$objapi->sendPayment($toupdate,$current_p);
                            if(isset($response['response'])){
                                if($response['response']==1){
                                    $objbatch->insertSummaryLine($this->tid, $currentline, 'Approved payment for '.$account_number);
                                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                }
                                else {
                                    $objbatch->insertSummaryLine($this->tid, $currentline, 'Error in payment for '.$account_number.' -> '.json_encode($response));
                                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                }
                            }
                            else {
                                    $objbatch->insertSummaryLine($this->tid, $currentline, 'Error sending Payment');
                                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            }
                        }
                        else {
                            $objbatch->insertSummaryLine($this->tid, $currentline, 'Amount zero or negative. Skipped payment for '.$account_number);
                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('completed');
                        }
                    }
            }
	}

	function createPayments($level,$idlevel,$data){
		$data2p=$this->file;
        $objusr=new \App\Model\WebUsers();
        $objtx=new \App\Model\Transations();
        $objproperty=new \App\Model\Properties();
        $objapi=new \App\CustomClass\RevoAPI();
        $objbatch=new \App\Model\ImportBatchFile();
		$identifier=0;
                $currentline=0;
		foreach($data2p as $p2data){
                    $currentline++;
                $p2data=$this->CleanString($p2data);
                $ltype=substr($p2data,0,1);
                if($ltype=='5'){
                    //start property
                    if($level=='M') {
                            $current_p=$idlevel;
                            continue;
                    }
                    else {
                        $current_p=0;
                        $pid=trim(substr($p2data,40,10));
                        $pname=trim(substr($p2data,4,16));
                        if($level=='P'){
                            if($pid!=''){
                                    $result= DB::table('properties')->where('id_partners',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                                    if(empty($result)){
                                            //error
                                             $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                                            continue;
                                    }
                                    $current_p=$result->id;
                            }
                            else {
                                    //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                                continue;
                            }
                        }
                        else {
                            if($pid!=''){
                                    $result= DB::table('properties')->where('id_companies',$idlevel)->where('compositeID_clients',$pid)->where('status_clients',1)->select('id')->first();
                                    if(empty($result)){
                                            //error
                                         $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                                            continue;
                                    }
                                    $current_p=$result->id;
                            }
                            else {
                                    //error
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Empty paypointID');
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                                    continue;
                            }
                        }
                        if(empty($current_p)){
							//merchant does not exists
                            $objbatch->insertSummaryLine($this->tid, $currentline, 'Paypoint '.$pid.' not found');
                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                            continue;
                        }
                    }
                }
                elseif(substr($p2data,0,3)=='627' || substr($p2data,0,3)=='637'){
                    if(empty($current_p)){
                        $objbatch->insertSummaryLine($this->tid, $currentline, 'Skipped payment because Paypoint does not found');
                        DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');
                        continue;
                    }
                        if(substr($p2data,0,3)=='627')$pmethod='Checking';
                        else $pmethod='Savings';
                        $routing=trim(substr($p2data,3,9));
                        $account=trim(substr($p2data,12,17));
                        $amount=(trim(substr($p2data,29,8)).".".trim(substr($p2data,37,2)))*1;
                        $user_num=trim(substr($p2data,39,15));
                        $user_name=str_replace("'","",trim(substr($p2data,54,22)));
                        $user_name=str_replace("/","",$user_name);
                        $user_name=str_replace('"',"",$user_name);
                        $user_name=str_replace('$',"",$user_name);
                        $user_name=str_replace('&'," ",$user_name);
                        $user_name=str_replace('\\',"",$user_name);
                        $user_name=str_replace("\r","",$user_name);
                        $user_name=str_replace("\n","",$user_name);
                        $user_name=str_replace("#"," ",$user_name);
                        $user_name=  strip_tags($user_name);
                        $user_name.=",";
                        list($last_name,$first_name)=explode(',',$user_name);
                        if(empty($first_name)){
                            $first_name=$last_name;
                            $last_name='';
                        }
                        if($amount>0){
                            if(!$objtx->getRoutingNumber($routing)){
                                $objbatch->insertSummaryLine($this->tid, $currentline, 'Invalid Routing Number: '.$routing);
                                DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                continue;
                            }
                            $toupdate=array();
                            $payor=array();
                            if($user_num!=''){
                                    $payor['account_number']=$user_num;
                            }
                            if($first_name!=''){
                                    $payor['first_name']=$first_name;
                                    $payor['last_name']=$last_name;
                            }
                            $payment=array();
                            $payment['TransactionAmount']=$amount;
                            $payment['Source']='NACHA';
                            $stdate=$data['sy'].'-'.$data['sm'].'-'.$data['sd'];
                            if(strtotime($stdate)<=strtotime(date('Y-m-d'))){
                                    //error before today
                                    continue;
                            }
                            $payment['StartDate']=date('Y-m-d',strtotime($stdate));
                            if($data['dynamic']!=''){
                                    $payment['Dynamic']=1;
                            }
                            switch($data['fq']){
                                    case 'onetime':
                                            $payment['Frequency']=0;
                                            $payment['RunCycle']=1;
                                            break;
                                    case 'monthly':
                                            $payment['Frequency']=3;
                                            $payment['RunCycle']=1200;
                                            break;
                                    case 'quarterly':
                                            $payment['Frequency']=4;
                                            $payment['RunCycle']=400;
                                            break;
                                    case 'annually':
                                            $payment['Frequency']=6;
                                            $payment['RunCycle']=100;
                                            break;
                            }
                            $categories=array();
                            $categories[]=array('name'=>'Payment','amount'=>$amount);
                            $method=array();
                            $method['AccountHolder']=trim($first_name.' '.$last_name);
                            $method['BankAccount']=$account;
                            $method['BankRouting']=$routing;
                            $method['BankType']=0;
                            if($pmethod!=''){
                                    if(substr($pmethod,0,1)=='S'){
                                            $method['BankType']=1;	                                
                                    }
                            }
                            $toupdate['payor']=$payor;
                            $toupdate['payment']=$payment;
                            $toupdate['categories']=$categories;
                            $toupdate['paymentMethod']=$method;
                            $response=$objapi->sendPayment($toupdate,$current_p);
                            if(isset($response['response'])){
                                if($response['response']==1){
                                    $objbatch->insertSummaryLine($this->tid, $currentline, 'Created payment for '.$account_number);
                                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                }
                                else {
                                    $objbatch->insertSummaryLine($this->tid, $currentline, 'Error creating payment for '.$account_number.' -> '.json_encode($response));
                                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                                }
                            }
                            else {
                                    $objbatch->insertSummaryLine($this->tid, $currentline, 'Error sending Payment');
                                    DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('errors');                                
                            }
                        }
                        else {
                            $objbatch->insertSummaryLine($this->tid, $currentline, 'Amount zero or negative. Skipped payment for '.$account_number);
                            DB::table('import_batch_file')->where('idimport_batch_file',$this->tid)->increment('completed');
                        }
                    }
            }
	}
    
}