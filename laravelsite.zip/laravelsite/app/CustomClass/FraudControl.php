<?php

namespace App\CustomClass;

/*
 * property_id
 * cc_number
 * user_id
 * net_amount
 */

use App\Model\Transations;
use App\Model\Properties;
use App\CustomClass\Email;

class FraudControl
{

    private $property_id;
    private $web_user_id;
    private $cc_number;
    private $net_amount;
    private $fraud_rules;
    private $maxTransProperty;
//objects
    private $obj_properties;
    private $obj_transactions;
    private $obj_email;

    function __construct($property_id, $web_user_id, $cc_number, $net_amount)
    {
        $this->property_id = $property_id;
        $this->web_user_id = $web_user_id;
        $this->cc_number = $cc_number;
        $this->net_amount = $net_amount;
        $this->maxTransProperty = 30;
        $this->obj_properties = new Properties();
        $this->obj_transactions = new Transations();
        $this->obj_email = new Email();
        $this->getFraudControl();
    }

    // read from database fraud rules
    function getFraudControl()
    {
        $fraudC = $this->obj_properties->getFraudControlrules($this->property_id);
        $this->fraud_rules = $fraudC;
    }

    // main function
    function isFraud()
    {
        $this->send_alert();
        if ($this->maxAuthRequest1day()) {
            $fraudText = $this->fraud_rules['fraud1'] . "% of Unit Count is Max # of Authorization Requests allowed in 1 day";
            $this->obj_email->FraudControlmail($this->web_user_id, $this->property_id, $fraudText);
            return true;
        } elseif ($this->minTransAmount()) {
            $fraudText = "Alert for any transaction below this minimun transaction amount: $" . $this->fraud_rules['fraud9'];
            $this->obj_email->FraudControlmail($this->web_user_id, $this->property_id, $fraudText);
            return true;
        } elseif ($this->authRequestCardholderAcc()) {
            $fraudText = "Max # of repeated Authorization Requests within 1 min for the same Cardholder Account " . $this->fraud_rules['fraud2'];
            $this->obj_email->FraudControlmail($this->web_user_id, $this->property_id, $fraudText);
            return true;
        } elseif ($this->maxTrans1hour()) {
            $fraudText = "Max # of payments a web user can submit within an hour: " . $this->fraud_rules['fraud11'];
            $this->obj_email->FraudControlmail($this->web_user_id, $this->property_id, $fraudText);
            return true;
        } elseif ($this->maxTrans1day()) {
            $fraudText = "Max # of payments a web user can submit within a day: " . $this->fraud_rules['fraud12'];
            $this->obj_email->FraudControlmail($this->web_user_id, $this->property_id, $fraudText);
            return true;
        } elseif ($this->maxTransNOapproved1day()) {
            $fraudText = "Max # of declined a property can submit within an hour :" . $this->maxTransProperty;
            $this->obj_email->FraudControlmail($this->web_user_id, $this->property_id, $fraudText);
            return true;
        }
        return false;
    }

    //function to send alert but not stop the payment
    function send_alert()
    {
        if ($this->maxTransDeclinedbyProp()) {
            $fraudText = "Max # of declined a property can submit within an hour :" . $this->fraud_rules['fraud13'];
            $this->obj_email->FraudControlmailtoMerchant($this->web_user_id, $this->property_id, $fraudText);
        }
    }

    // % of Unit Count is Max # of Authorization Requests allowed in 1 day (fraud1)
    function maxAuthRequest1day()
    {
        if (isset($this->fraud_rules['fraud1a']) && ($this->fraud_rules['fraud1a'] == 'on' || $this->fraud_rules['fraud1a'] == 'checked')) {
            $unit = $this->obj_properties->get1PropertyInfo($this->property_id, 'units');
            if ($unit == 0 && (isset($this->fraud_rules['fraud10a']) && ($this->fraud_rules['fraud10a'] == 'on' || $this->fraud_rules['fraud10a'] == 'checked'))) {
                $unit = $this->fraud_rules['fraud10'];
            }
            $value = $this->fraud_rules['fraud1'];
            $value = $unit * $value / 100;
            $value = round($value);
            $max = $this->obj_transactions->getFraudControlUnitCount($this->property_id);
            if ($max > $value) {
                return true;
            }
        }
        return false;
    }

    // Max # of repeated Authorization Requests within 1 min for the same Cardholder Account (fraud2)
    function authRequestCardholderAcc()
    {
        if (isset($this->fraud_rules['fraud2a']) && ($this->fraud_rules['fraud2a'] == 'on' || $this->fraud_rules['fraud2a'] == 'checked')) {
            $hash = md5($this->cc_number);
            $count = $this->obj_transactions->getFraudControlHash($hash, $this->property_id);
            if ($this->fraud_rules['fraud2'] < $count) {
                return true;
            } else {
                $this->obj_transactions->insertFraudHash($hash, $this->property_id);
            }
        }
        return false;
    }

    // % increase in Max Authorization Requests allowed over highest historical month (#3)
    function maxAuthRequestHistorical()
    {

        return false;
    }

    // % increase in Max Merchant Monthly Deposit Volume allowed over highest historical month (#4)
    function maxMonDepositVolHistorical()
    {

        return false;
    }

    //% increase in Merchants Historical Average Ticket Size (#5)
    function merchHistoricalAve()
    {

        return false;
    }

    //  Create Alert for the first transaction of in an inactive Merchant with 90 days of inactivity (#6)
    function inactiveMerch90days()
    {

        return false;
    }

    // Max # of permitted transactions per month: Nro % of Unit Count (#7)
    function maxTransofUnitCount()
    {

        return false;
    }

    // Max # of permitted transactions per Deposit (Batch)  (#8)
    function maxTransxDeposit()
    {

        return false;
    }

    // Create Alert for any transaction below this minimun transaction amount: $Nro  (fraud9)
    function minTransAmount()
    {
        if (isset($this->fraud_rules['fraud9a']) && ($this->fraud_rules['fraud9a'] == 'on' || $this->fraud_rules['fraud9a'] == 'checked')) {
            if ($this->fraud_rules['fraud9'] > $this->net_amount) {
                return true;
            }
        }
        return false;
    }

    // Max # of payments a web user can submit within an hour (fraud11)
    function maxTrans1hour()
    {
        if (isset($this->fraud_rules['fraud11a']) && ($this->fraud_rules['fraud11a'] == 'on' || $this->fraud_rules['fraud11a'] == 'checked')) {
            $count = $this->obj_transactions->getFraudMaxTrans1hour($this->web_user_id);
            if ($count > $this->fraud_rules['fraud11']) {
                return true;
            }
        }
        return false;
    }

    //Max # of payments a web user can submit within a day (fraud12)
    function maxTrans1day()
    {
        if (isset($this->fraud_rules['fraud12a']) && ($this->fraud_rules['fraud12a'] == 'on' || $this->fraud_rules['fraud12a'] == 'checked')) {
            $count = $this->obj_transactions->getFraudMaxTrans1day($this->web_user_id);
            if ($count > $this->fraud_rules['fraud12']) {
                return true;
            }
        }
        return false;
    }

    //Max # of transactions distinct of Approved within an hour
    function maxTransNOapproved1day()
    {
        $count = $this->obj_transactions->getFraudMaxTrans1hourXProperty($this->property_id);
        if ($count > $this->maxTransProperty) {
            return true;
        }
        return false;
    }

    //Max # of transactions declined by Property in an hour
    function maxTransDeclinedbyProp()
    {
        if (isset($this->fraud_rules['fraud13a']) && ($this->fraud_rules['fraud13a'] == 'on' || $this->fraud_rules['fraud13a'] == 'checked')) {
            $count = $this->obj_transactions->getFraudMaxTransDeclined1hourbyProperty($this->property_id);
            if ($count > $this->fraud_rules['fraud13']) {
                return true;
            }
        }
        return false;
    }
}
