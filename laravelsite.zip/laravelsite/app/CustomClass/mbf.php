<?php

namespace App\CustomClass;

class mbf {

    public $data;
    protected $merchantclass = array('21', '19', '23', '24', '21', '25', '24', '26', '18');

    public function headerRecord() {
        $str = 'HDRMBF';
        if (isset($this->data['iso'])) {
            $str.=str_pad($this->data['iso'], 6, ' ');
        } else {
            $str.='53    ';
        }
        $str.=date('Ymd') . date('Ymd') . date('His');
        $str.='REVO' . 'PAYFAC    ' . 'CHAIN     ' . 'VANTIV';
        $str = str_pad($str, 600, ' ') . chr(13) . chr(10);
        return $str;
    }

    public function chainRecord() {
        $str = 'CHN' . str_pad(' ', 42, ' ');
        $str .= '0M0314';
        $str = str_pad($str, 600, ' ') . chr(13) . chr(10);
        return $str;
    }

    public function divRecord() {
        $dt = $this->data;
        $str = 'DIV10';
        $str.=str_pad($dt['id_partner'], 3, '0', STR_PAD_LEFT);
        $str.=str_pad(substr($dt['partner_name'], 0, 30), 30, ' ');
        $str = str_pad($str, 600, ' ') . chr(13) . chr(10);
        return $str;
    }

    public function storeRecord() {
        $dt = $this->data;
        $str = 'STR ';
//        $revoid=str_pad($dt['id_partner'],2,'0',STR_PAD_LEFT).str_pad($dt['id_company'],3,'0',STR_PAD_LEFT).str_pad($dt['id_property'],4,'0',STR_PAD_LEFT);
        $revoid = $dt['appid'];
        $str.=str_pad($revoid, 9, '0', STR_PAD_LEFT);
        $dba = strtoupper(substr($dt['dba'], 0, 40));
        $str.=str_pad($dba, 40, ' '); //dba
        $adr = str_replace(array("\t", "\n", "\r"), "", strtoupper(substr($dt['adr1'], 0, 80)));
        $str.=str_pad($adr, 80, ' ');
        $cty = strtoupper(substr($dt['cty1'], 0, 28));
        $str.=str_pad($cty, 28, ' ');
        $str.=$dt['state1'];
        $str.=str_pad($dt['zip1'], 9, ' ');
        $fti = str_replace(array("\t", "\n", "\r", "-"), '', $dt['fti']);
        if ($fti == '') {
            $fti = '320095365';
        }
        $str.=$fti;
        $str.='M     ';
        $str.='M     ';
        $pn = strtoupper(substr($dt['pname'], 0, 40));
        $str.=str_pad($pn, 40, ' '); //primary name
        $phone = substr(str_replace(array('-', '(', ')', ' ', '.'), '', $dt['pphone']), 0, 10);
        $str.=str_pad($phone, 10, ' ');
        $str.='08';
        $str = str_pad($str, 600, ' ') . chr(13) . chr(10);
        return $str;
    }

    public function merchantRecord() {
        $dt = $this->data;
        $str = 'MCH                ';
        $str.='00000';
        $str.='10';
        $str.=date('Ymd');
        $str.='        ';
        $str.=str_pad($dt['sic'], 6, ' ');
        $avol = number_format(round($dt['avticket'], 0, PHP_ROUND_HALF_UP), 2);
        $avol = str_replace(array(',', '.'), '', $avol);
        $str.=str_pad($avol, 8, '0', STR_PAD_LEFT); //average ticket
        $banknm = 'REVO*' . strtoupper(substr($dt['dba'], 0, 20));
        $str.=str_pad($banknm, 30, ' '); //dba name
        $str.=str_pad(str_replace(array("\t", "\n", "\r", "-"), "", $dt['banknumber']), 17, ' ');
        $str.=str_pad(str_replace(array("\t", "\n", "\r", "-"), "", $dt['bankrouting']), 9, ' ');
        $str.='                         ';
        $str.='295                                         1407         ';
        $str.=str_repeat(' ', 169);
        $str.='99' . str_pad($dt['id_property'], 10, '0', STR_PAD_LEFT);
        $str.='3052528297';
        $str = str_pad($str, 600, ' ') . chr(13) . chr(10);
        return $str;
    }

    public function rateRecord() {
        $dt = $this->data;
        $str = 'RTE';
        $avol = ceil(round($dt['avticket'], 0, PHP_ROUND_HALF_UP));
        $avdaily = ceil($dt['mticket']);
        //visa
        $str.=str_pad('VISA', 6, ' ');
        $str.=str_pad('', 21, ' ');
        $str.=str_pad($avdaily, 9, '0', STR_PAD_LEFT);
        $str.=str_pad($avol, 7, '0', STR_PAD_LEFT);
        $str.='09';
        $str.=str_pad('', 9, '0');
        //mastercard
        $str.=str_pad('MASTER', 6, ' ');
        $str.=str_pad('', 21, ' ');
        $str.=str_pad($avdaily, 9, '0', STR_PAD_LEFT);
        $str.=str_pad($avol, 7, '0', STR_PAD_LEFT);
        $str.='09';
        $str.=str_pad('', 9, '0');
        //discover
        $str.=str_pad('DISCOV', 6, ' ');
        $str.=str_pad('NEW', 21, ' ');
        $str.=str_pad($avdaily, 9, '0', STR_PAD_LEFT);
        $str.=str_pad($avol, 7, '0', STR_PAD_LEFT);
        $str.='09';
        $str.=str_pad('', 9, '0');
        if (!empty($dt['amex'])) {
            //american express
            $str.=str_pad('AMEX', 6, ' ');
            $str.=str_pad('', 21, ' ');
            $str.=str_pad($avdaily, 9, '0', STR_PAD_LEFT);
            $str.=str_pad($avol, 7, '0', STR_PAD_LEFT);
            $str.='09';
            $str.=str_pad('', 9, '0');
        } else {
            $str.=str_pad('', 6, ' ');
            $str.=str_pad('', 21, ' ');
            $str.=str_pad('', 9, '0');
            $str.=str_pad('', 7, '0');
            $str.='09';
            $str.=str_pad('', 9, '0');
        }
        if (!empty($dt['jcb'])) {
            //jcb
            $str.=str_pad('JCB', 6, ' ');
            $str.=str_pad('', 21, ' ');
            $str.=str_pad($avdaily, 9, '0', STR_PAD_LEFT);
            $str.=str_pad($avol, 7, '0', STR_PAD_LEFT);
            $str.='09';
            $str.=str_pad('', 9, '0');
        } else {
            $str.=str_pad('', 6, ' ');
            $str.=str_pad('', 21, ' ');
            $str.=str_pad('', 9, '0');
            $str.=str_pad('', 7, '0');
            $str.='09';
            $str.=str_pad('', 9, '0');
        }
        if (!empty($dt['diners'])) {
            //diners club
            $str.=str_pad('DINERS', 6, ' ');
            $str.=str_pad('', 21, ' ');
            $str.=str_pad($avdaily, 9, '0', STR_PAD_LEFT);
            $str.=str_pad('', 7, '0', STR_PAD_LEFT);
            $str.='09';
            $str.=str_pad($avol, 9, '0');
        } else {
            $str.=str_pad('', 6, ' ');
            $str.=str_pad('', 21, ' ');
            $str.=str_pad('', 9, '0');
            $str.=str_pad('', 7, '0');
            $str.='09';
            $str.=str_pad('', 9, '0');
        }
        //rest
        $str.=str_pad('', 6, ' ');
        $str.=str_pad('', 21, ' ');
        $str.=str_pad('', 9, '0');
        $str.=str_pad('', 7, '0');
        $str.='09';
        $str.=str_pad('', 9, '0');
        $str.=str_pad('', 6, ' ');
        $str.=str_pad('', 21, ' ');
        $str.=str_pad('', 9, '0');
        $str.=str_pad('', 7, '0');
        $str.='09';
        $str.=str_pad('', 9, '0');
        $str.=str_pad('', 6, ' ');
        $str.=str_pad('', 21, ' ');
        $str.=str_pad('', 9, '0');
        $str.=str_pad('', 7, '0');
        $str.='09';
        $str.=str_pad('', 9, '0');
        $str.=str_pad('', 6, ' ');
        $str.=str_pad('', 21, ' ');
        $str.=str_pad('', 9, '0');
        $str.=str_pad('', 7, '0');
        $str.='09';
        $str.=str_pad('', 9, '0');
        $str = str_pad($str, 600, ' ') . chr(13) . chr(10);
        return $str;
    }

    public function eqpRecord() {
        $dt = $this->data;
        $str = 'EQP293ECOM';
        //visa
        $str.=str_pad('VISA', 6, ' ');
        //mastercard
        $str.=str_pad('MASTER', 6, ' ');
        //discover
        $str.=str_pad('DISCOV', 6, ' ');
        if (!empty($dt['amex'])) {
            //american express
            $str.=str_pad('AMEX', 6, ' ');
        } else {
            $str.=str_pad('', 6, ' ');
        }
        if (!empty($dt['jcb'])) {
            //jcb
            $str.=str_pad('JCB', 6, ' ');
        } else {
            $str.=str_pad('', 6, ' ');
        }
        if (!empty($dt['diners'])) {
            //diners club
            $str.=str_pad('DINERS', 6, ' ');
        } else {
            $str.=str_pad('', 6, ' ');
        }
        //rest
        $str.=str_pad('', 6, ' ');
        $str.=str_pad('', 6, ' ');
        $str.=str_pad('', 6, ' ');
        $str.=str_pad('', 6, ' ');
        $str.='H2359';
        $str = str_pad($str, 600, ' ') . chr(13) . chr(10);
        return $str;
    }

    public function cntRecord() {
        $dt = $this->data;
        $str = 'CNT';
        $str.=str_pad(' ', 5, ' ');
        $str.=str_pad($dt['pname'], 40, ' ');
        $name = explode(" ", $dt['pname']);
        if (isset($name[0])) {
            $str.=str_pad($name[0], 15, ' ');
        } else {
            $str.=str_pad(' ', 15, ' ');
        }
        $str.=' ';
        if (isset($name[1])) {
            $str.=str_pad($name[1], 25, ' ');
        } else {
            $str.=str_pad(' ', 25, ' ');
        }
        $str.=str_pad($dt['title'], 30, ' ');
        $str.=str_pad($dt['adr1'], 40, ' ');
        if (isset($dt['adr2'])) {
            $str.=str_pad($dt['adr2'], 40, ' ');
        } else {
            $str.=str_pad(' ', 40, ' ');
        }
        $str.=str_pad($dt['cty1'], 28, ' ');
        $str.=str_pad($dt['state1'], 2, ' ');
        $str.=str_pad($dt['zip1'], 5, ' ');
        $str.=str_pad(' ', 4, ' ');
        $str.=str_pad($dt['phone1'], 10, ' ');
        $str.=str_pad(' ', 10, ' ');
        $str.=str_pad($dt['email'], 60, ' ');
        $str.=str_pad($dt['ssn'], 9, ' ');
        $str.=str_pad(' ', 3, ' ');
        if (isset($dt['bdate'])) {
            $birthdate = date('Ymd', strtotime($dt['bdate']));
            $str.=str_pad($birthdate, 10, ' ');
        } else {
            $str.=str_pad(' ', 10, ' ');
        }

        $str.=str_pad(' ', 2, ' ');
        $str.=str_pad(' ', 1657, ' ');


        $str = str_pad($str, 2000, ' ') . chr(13) . chr(10);
        return $str;
    }

    public function trailerRecord($nr = '7') {
        $str = 'TLRMBF0000100000' . $nr;
        $str = str_pad($str, 600, ' ') . chr(13) . chr(10);
        return $str;
    }

}
