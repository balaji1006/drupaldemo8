<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Model;

class permission
{

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $route_name = Route::currentRouteName();
        $user_permission = Model\UsersPermissions::where(['users_admin_id' => Auth::id()])->
                join('permissions_new', 'users_permissions.permissions_id', '=', 'permissions_new.permissions_id')
                ->get();

        $route_collection = [];
        foreach ($user_permission as $item) {
            $route_collection[] = $item->permissions_route_name;
        }
        if (in_array($route_name, $route_collection)) {
            return $next($request);
        } else {
            return redirect(route('accessdenied'));
        }
    }
}
