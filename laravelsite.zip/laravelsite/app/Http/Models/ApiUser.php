<?php

namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class ApiUser extends Model {
     
    protected $table = 'api_user';
    protected $softDelete = false;
    public $timestamps = false;
    
    function validateUser($usr,$pass){
        $result=$this->where('apiusername','=',$usr)->where('apipasswd','=',sha1($pass))->where('ustatus','=',1)->first();
        if(!$result){
            $result=$this->where('apiusername','=',$usr)->where('apipasswd','=',$pass)->where('ustatus','=',1)->first();
        }
        return $result;
    }

    function getUserUsername($username){
        $result=DB::table('api_user')->where('apiusername','=',$username)->first();
        return $result;
    }

    function getFirstUser($level,$id_level){
        if($level=='P'){
            $result=DB::table('api_user')->where('id_partner','=',$id_level)->first();
            return $result;
        }
        elseif ($level=='G'){
            $result=DB::table('api_user')->where('id_company','=',$id_level)->first();
            return $result;
        }
        elseif ($level=='M'){
            $result=DB::table('api_user')->where('id_property','=',$id_level)->first();
            return $result;
        }
    }
    
    function existsUsername($usr){
        $result=DB::table($this->table)->where('apiusername','=',$usr)->count();
        if($result>0) return true;
        else return false;
    }
    
    function getByLevel($id_level,$level){
        if($level=='P'){
            $result=DB::table('api_user')->where('id_partner','=',$id_level)->where('lvkey',0);
            return $result;
        }
        elseif ($level=='G'){
            $result=DB::table('api_user')->where('id_company','=',$id_level)->where('lvkey',0);
            return $result;
        }
        elseif ($level=='M'){
            $result=DB::table('api_user')->where('id_property','=',$id_level)->where('lvkey',0);
            return $result;
        }
        return null;
    }
    
}