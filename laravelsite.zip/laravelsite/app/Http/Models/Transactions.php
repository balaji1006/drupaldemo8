<?php

namespace App\Http\Models;

use DB;

//functions related to Transactions

class Transactions {

    /**
     * Get an array with volume and transactions per period and scope
     * $period = 'months','days','years'
     * $scope a positive number
     * $idlevel is an array
     * $level '','M','G','P','B'
     * return array with total, count and array of records
     */
    function getSummaryByPeriod($level, $idlevel, $period, $scope) {
        $last_period = 'days';
        $last_scope = 30;
        $query = DB::table('accounting_transactions')->where('trans_status', 1)->where('trans_type', '<', 2)->where('is_convenience_fee_trans', 0);
        if ($scope > 0) {
            $last_scope = $scope * 1;
        }
        if ($this->_isValidPeriod($period)) {
            $last_period = \strtolower($period);
        }
        $scope_string = $this->_getScopeStr($last_period);
        $query->where('trans_first_post_date', '>=', date('Y-m-d 00:00:00', strtotime('-' . $last_scope . ' ' . $last_period)));
        if ($level == 'M') {
            $query->whereIn('property_id', $idlevel);
        } elseif ($level == 'G') {
            $query->whereIn('property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_companies', $idlevel);
            });
        } elseif ($level == 'P') {
            $query->whereIn('property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $idlevel);
            });
        } elseif ($level == 'B') {
            $partnersA = DB::table('branch_partner')->whereIn('branch_id', $idlevel)->select('id_partners')->get();
            $partners = array();
            foreach ($partnersA as $pa) {
                $partners[] = $pa->id_partners;
            }
            $query->whereIn('property_id', function ($query) use ($partners) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $partners);
            });
        }
        $query2 = DB::table('accounting_transactions')->where('trans_status', 1)->where('trans_type', '<', 2)->where('is_convenience_fee_trans', 0);
        if ($scope > 0) {
            $last_scope = $scope * 1;
        }
        if ($this->_isValidPeriod($period)) {
            $last_period = \strtolower($period);
        }
        $scope_string = $this->_getScopeStr($last_period);
        $query2->where('trans_first_post_date', '>=', date('Y-m-d 00:00:00', strtotime('-' . $last_scope . ' ' . $last_period)));
        if ($level == 'M') {
            $query2->whereIn('property_id', $idlevel);
        } elseif ($level == 'G') {
            $query2->whereIn('property_id', function ($query2) use ($idlevel) {
                $query2->from('properties');
                $query2->select('id as property_id');
                $query2->whereIn('id_companies', $idlevel);
            });
        } elseif ($level == 'P') {
            $query2->whereIn('property_id', function ($query2) use ($idlevel) {
                $query2->from('properties');
                $query2->select('id as property_id');
                $query2->whereIn('id_partners', $idlevel);
            });
        } elseif ($level == 'B') {
            $partnersA = DB::table('branch_partner')->whereIn('branch_id', $idlevel)->select('id_partners')->get();
            $partners = array();
            foreach ($partnersA as $pa) {
                $partners[] = $pa->id_partners;
            }
            $query->whereIn('property_id', function ($query) use ($partners) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $partners);
            });
        }
        $last_day = '';
        $df = $query2->select('trans_first_post_date')->orderBy('trans_first_post_date', 'DESC')->first();
        if (!empty($df)) {
            $last_day = $df->trans_first_post_date;
        }
        $query->select(DB::raw($scope_string . ' as tx_date'), DB::raw('SUM(trans_net_amount) as net_amount'), DB::raw('COUNT(trans_id) as tx_count'));
        $result['total'] = $query->sum('trans_net_amount');
        $result['count'] = $query->count('trans_id');
        $result['last_date'] = $last_day;
        $query->groupBy('tx_date')->orderBy('tx_date');
        $result['records'] = $query->get();

        return $result;
    }

    private function _isValidPeriod($period) {
        $validperiods = array('days', 'months', 'years');
        return (in_array(\strtolower($period), $validperiods));
    }

    private function _getScopeStr($period) {
        $str = '';
        if ($period == 'days') {
            $str = "DATE_FORMAT(trans_first_post_date,'%m-%d')";
        } elseif ($period == 'months') {
            $str = "DATE_FORMAT(trans_first_post_date,'%Y-%m')";
        } else {
            $str = "YEAR(trans_first_post_date)";
        }
        return $str;
    }

    function getRecentActivity($level, $idlevel, $lines = 5) {
        if ($lines > 20) {
            $lines = 20;
        }
        $query = DB::table('accounting_transactions')->where('trans_status', 1)->where('is_convenience_fee_trans', 0);
        if ($level == 'M') {
            $query->whereIn('property_id', $idlevel);
        } elseif ($level == 'G') {
            $query->whereIn('property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_companies', $idlevel);
            });
        } elseif ($level == 'P') {
            $query->whereIn('property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $idlevel);
            });
        } elseif ($level == 'B') {
            $partnersA = DB::table('branch_partner')->whereIn('branch_id', $idlevel)->select('id_partners')->get();
            $partners = array();
            foreach ($partnersA as $pa) {
                $partners[] = $pa->id_partners;
            }
            $query->whereIn('property_id', function ($query) use ($partners) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $partners);
            });
        }
        $query->select('trans_first_post_date', 'trans_account_number', 'trans_user_name', 'trans_card_type', 'trans_net_amount', 'trans_status', 'trans_type');
        $result = $query->take($lines)->orderBy('trans_first_post_date', 'DESC')->get();
        return $result;
    }

    function getTransactionSettled($trans_id) {
        $query = DB::table('settlement_report')
                ->where('trans_id', $trans_id)
                ->first();
        return $query;
    }

    function getXFields($level, $idlevel=0,$export = false) {
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $nfields = [
            "trans_payment_type" => "Method",
            "trans_first_post_date" => "Date",
            "trans_id" => "Trans ID",
            "trans_account_number" => $obj_layout->extractLayoutValue('label_acc_number',$layouts),
            "trans_user_name" => $obj_layout->extractLayoutValue('label_user',$layouts)." Name",
            "trans_net_amount" => "Amount",
            "trans_convenience_fee" => "Fee",
            "trans_total_amount" => "Total"
        ];
        if ($level != 'M' || $export) {
            $nfields['properties.name_clients'] = $obj_layout->extractLayoutValue('label_merchant',$layouts);
            $nfields['properties.compositeID_clients'] = 'PaypointID';
        }
        if ($level != 'G' && $level != 'M') {
            $nfields['companies.company_name'] = $obj_layout->extractLayoutValue('label_group',$layouts);
            $nfields['companies.compositeID_companies'] = 'CompanyID';
        }
        if ($level == 'B' || $level == 'A') {
            $nfields['partners.partner_title'] = $obj_layout->extractLayoutValue('label_partner',$layouts);
        }
        return $nfields;
    }

    function getByFilter($idlevel, $level, $filter) {
        return $this->getTransactionsByFilter($level, $idlevel, $filter);
    }

    function getTransactionsByFilter($level, $idlevel, $filter = null) {

        $query = DB::table('accounting_transactions')
                ->where('is_convenience_fee_trans', 0)
                ->join('properties', 'properties.id', 'accounting_transactions.property_id');
        if ($level == 'M') {
            $query->where('accounting_transactions.property_id', $idlevel);
            $query->select('trans_id', 'properties.name_clients', 'trans_account_number', 'invoice_number', 'trans_first_post_date', 'trans_user_name', 'trans_payment_type', 'trans_card_type', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'source', 'trans_result_auth_code', 'trans_status', 'trans_type','properties.compositeID_clients');
        } elseif ($level == 'G') {
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->where('properties.id_companies', $idlevel);
            $query->select('trans_id', 'properties.name_clients', 'trans_account_number', 'invoice_number', 'trans_first_post_date', 'trans_user_name', 'trans_payment_type', 'trans_card_type', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'source', 'trans_result_auth_code', 'trans_status', 'trans_type','properties.compositeID_clients');
        } elseif ($level == 'P') {
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->where('properties.id_partners', $idlevel);
            $query->select('trans_id', 'properties.name_clients', 'trans_account_number', 'invoice_number', 'trans_first_post_date', 'trans_user_name', 'trans_payment_type', 'trans_card_type', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'source', 'trans_result_auth_code', 'trans_status', 'trans_type','companies.company_name','properties.compositeID_clients');
        }elseif ($level == 'B') {
            $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->join('partners', 'properties.id_partners', 'partners.id');
            $query->whereIn('properties.id_partners', $partners);
            $query->select('trans_id', 'properties.name_clients', 'trans_account_number', 'invoice_number', 'trans_first_post_date', 'trans_user_name', 'trans_payment_type', 'trans_card_type', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'source', 'trans_result_auth_code', 'trans_status', 'trans_type','companies.company_name','partners.partner_title','properties.compositeID_clients');
        }elseif($level=='A'){
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->join('partners', 'properties.id_partners', 'partners.id');
            $query->select('trans_id', 'properties.name_clients', 'trans_account_number', 'invoice_number', 'trans_first_post_date', 'trans_user_name', 'trans_payment_type', 'trans_card_type', 'trans_net_amount', 'trans_convenience_fee', 'trans_total_amount', 'source', 'trans_result_auth_code', 'trans_status', 'trans_type','companies.company_name','partners.partner_title','properties.compositeID_clients');
        }
        if (!empty($filter) && isset($filter['rules'])) {
            $filter = $filter['rules'];
            foreach ($filter as $rule) {
                if (!isset($rule['data']) || !isset($rule['op']) || !isset($rule['field'])) {
                    continue;
                }
                $tofind = $rule['data'];
                if ($tofind == '') {
                    continue;
                }
                $tocmp = $rule['op'];
                $field = "";
                switch ($rule['field']) {
                    case 'partner':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('partners.partner_title', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('partners.partner_title', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('partners.partner_title', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('partners.partner_title', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('partners.partner_title', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('partners.partner_title', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('companies.company_name', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('companies.company_name', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('companies.company_name', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('companies.company_name', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('companies.company_name', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('companies.company_name', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'merchant':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('properties.name_clients', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('properties.name_clients', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('properties.name_clients', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('properties.name_clients', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('properties.name_clients', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('properties.name_clients', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'webname':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('trans_user_name', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('trans_user_name', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('trans_user_name', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('trans_user_name', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('trans_user_name', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('trans_user_name', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'webuser':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('trans_account_number', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('trans_account_number', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('trans_account_number', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('trans_account_number', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('trans_account_number', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('trans_account_number', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'invoice':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('invoice_number', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('invoice_number', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('invoice_number', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('invoice_number', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('invoice_number', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('invoice_number', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'trans_id':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('accounting_transactions.trans_id', 'like', '%' . $tofind . '%');
                                break;
                            case 'eq':
                                $query->where('accounting_transactions.trans_id', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('accounting_transactions.trans_id', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('accounting_transactions.trans_id', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('accounting_transactions.trans_id', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('accounting_transactions.trans_id', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('accounting_transactions.trans_id', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'pay_method':
                        $query->where('accounting_transactions.trans_payment_type', '=', $tofind);
                        break;
                    case 'pay_type':
                        if ($tocmp == 'cn') {
                            $query->where('accounting_transactions.trans_card_type', 'like', '%' . $tofind . '%');
                        } else {
                            $query->where('accounting_transactions.trans_card_type', 'not like', '%' . $tofind . '%');
                        }
                        break;
                    case 'net_amount':
                        switch ($tocmp) {
                            case 'eq':
                                $query->where('accounting_transactions.trans_net_amount', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('accounting_transactions.trans_net_amount', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('accounting_transactions.trans_net_amount', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('accounting_transactions.trans_net_amount', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('accounting_transactions.trans_net_amount', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('accounting_transactions.trans_net_amount', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'net_fee':
                        switch ($tocmp) {
                            case 'eq':
                                $query->where('accounting_transactions.trans_convenience_fee', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('accounting_transactions.trans_convenience_fee', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('accounting_transactions.trans_convenience_fee', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('accounting_transactions.trans_convenience_fee', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('accounting_transactions.trans_convenience_fee', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('accounting_transactions.trans_convenience_fee', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'net_charge':
                        switch ($tocmp) {
                            case 'eq':
                                $query->where('accounting_transactions.trans_total_amount', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('accounting_transactions.trans_total_amount', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('accounting_transactions.trans_total_amount', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('accounting_transactions.trans_total_amount', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('accounting_transactions.trans_total_amount', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('accounting_transactions.trans_total_amount', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'auth_code':
                        if ($tocmp == 'cn') {
                            $query->where('trans_result_auth_code', 'like', '%' . $tofind . '%');
                        } else {
                            $query->where('trans_result_auth_code', 'not like', '%' . $tofind . '%');
                        }
                        break;
                    case 'source':
                        $query->where('source', 'like', $tofind);
                        break;
                    case 'status':
                        if ($tofind <= 1) {
                            $query->where('trans_status', '=', $tofind)->where('trans_type', '<=', 1);
                        } else {
                            if ($tofind == 2) {
                                $query->where('trans_status', '>=', 2)->where('trans_status', '<=', 3);
                            } elseif ($tofind == 4) {
                                $query->where('trans_status', '=', 1)->where('trans_type', '=', 2);
                            } else {
                                $query->where('trans_status', '=', $tofind);
                            }
                        }
                        break;
                    case 'stype':
                        $query->where('trans_type', '=', $tofind);
                        break;
                    case 'trans_date':
                        switch ($tocmp) {
                            case 'eq':
                                $query->whereRaw('DATE(accounting_transactions.trans_first_post_date)= ?', [$tofind]);
                                break;
                            case 'ne':
                                $query->whereRaw('DATE(accounting_transactions.trans_first_post_date)!= ?', [$tofind]);
                                break;
                            case 'lt':
                                $query->whereRaw('DATE(accounting_transactions.trans_first_post_date)< ?', [$tofind]);
                                break;
                            case 'le':
                                $query->whereRaw('DATE(accounting_transactions.trans_first_post_date)<= ?', [$tofind]);
                                break;
                            case 'gt':
                                $query->whereRaw('DATE(accounting_transactions.trans_first_post_date)> ?', [$tofind]);
                                break;
                            case 'ge':
                                $query->whereRaw('DATE(accounting_transactions.trans_first_post_date)>= ?', [$tofind]);
                                break;
                        }
                        break;
                }
            }
        }
        return $query;
    }

    function getActivityPeriod($level, $idlevel, $from, $to) {
        $query = DB::table('accounting_transactions')->where('trans_status', 1)->where('is_convenience_fee_trans', 0)->where('trans_type', '<', 2);
        if ($level == 'M') {
            $query->whereIn('property_id', $idlevel);
        } elseif ($level == 'G') {
            $query->whereIn('property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_companies', $idlevel);
            });
        } elseif ($level == 'P') {
            $query->whereIn('property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $idlevel);
            });
        } elseif ($level == 'B') {
            $partnersA = DB::table('branch_partner')->whereIn('branch_id', $idlevel)->select('id_partners')->get();
            $partners = array();
            foreach ($partnersA as $pa) {
                $partners[] = $pa->id_partners;
            }
            $query->whereIn('property_id', function ($query) use ($partners) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $partners);
            });
        }
        $query->where('trans_first_post_date', '>=', date('Y-m-d H:i:s', $from));
        $query->where('trans_first_post_date', '<=', date('Y-m-d H:i:s', $to));
        $query->select('trans_payment_type as method', DB::raw('SUM(trans_net_amount) as volume'), DB::raw('count(trans_id) as qty'))->groupBy('trans_payment_type');
        return $query->get();
    }

    function getDetails($txid, $with_events = false) {
        $result = DB::table('accounting_transactions')->where('trans_id', $txid)->first();
        if (!empty($result) && $with_events) {
            $events = DB::table('transaction_events')->where('trans_id', 'like', $txid)->get();
            $result['events'] = $events;
        }
        return $result;
    }

    function get1TransInfo($trans_id, $key) {
        $info = DB::table('accounting_transactions')->select($key)->where('trans_id', $trans_id)->first();
        return $info->$key;
    }

    /*
     * get amount refunded to that transaction
     * @param int $trans_id
     * @return bool
     * @author dsantiago@revopay.com
     */

    function getRefundAmount($trans_id, $property_id) {
        //Sum net amount to transactions with trans_type=5 and trans_parent_id=$trans_id
        $amount = DB::table('accounting_transactions')
                ->where('property_id', $property_id)
                ->where('parent_trans_id', $trans_id)
                ->where('trans_type', 5)
                ->sum('trans_net_amount');

        return $amount;
    }

    function getAdvancedFilters($level,$idlevel=0) {
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);

        $advFilter = [
            ['text' => 'transaction date',
                'itemval' => 'trans_date',
                'ops' => [
                    ['op' => "eq", 'text' => "is equal to"],
                    ['op' => "ne", 'text' => "is not equal to"],
                    ['op' => "lt", 'text' => "is less than"],
                    ['op' => "le", 'text' => "is less or equal to"],
                    ['op' => "gt", 'text' => "is greater than"],
                    ['op' => "ge", 'text' => "is greater or equal to"]
                ],
                'dateType' => true
            ],
            ['text' => 'transID',
                'itemval' => 'trans_id',
                'ops' => [
                    ['op' => "eq", 'text' => "is equal to"],
                    ['op' => "ne", 'text' => "is not equal to"],
                    ['op' => "lt", 'text' => "is less than"],
                    ['op' => "le", 'text' => "is less or equal to"],
                    ['op' => "gt", 'text' => "is greater than"],
                    ['op' => "ge", 'text' => "is greater or equal to"]
                ],
            ],
            ['text' => $obj_layout->extractLayoutValue('label_acc_number',$layouts),
                'itemval' => 'webuser',
                'ops' => [
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"],
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ],
            ['text'=>'Invoice #',
                'itemval'=>'invoice',
                'ops'=>[
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ],
            ['text' => $obj_layout->extractLayoutValue('label_user',$layouts).' Name',
                'itemval' => 'webname',
                'ops' => [
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"],
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ],
            ['text' => 'Method',
                'itemval' => 'pay_method',
                'ops' => [
                    ['op' => "eq", 'text' => "is equal to"],
                ],
                'dataValues' => [
                    ['value' => 'ec', 'text' => 'E-Check'],
                    ['value' => 'cc', 'text' => 'Credit Card'],
                    ['value' => 'CASH', 'text' => 'CASH']
                ]
            ],
            ['text' => 'Payment Type',
                'itemval' => 'pay_type',
                'ops' => [
                    ['op' => "cn", 'text' => "contains"],
                ],
                'dataValues' => [
                    ['value' => 'Visa', 'text' => 'Visa'],
                    ['value' => 'MasterCard', 'text' => 'MasterCard'],
                    ['value' => 'American', 'text' => 'AmericanExpress'],
                    ['value' => 'Discover', 'text' => 'Discover'],
                    ['value' => 'Checking', 'text' => 'Checking'],
                    ['value' => 'Savings', 'text' => 'Savings'],
                ]
            ],
            ['text' => 'Amount',
                'itemval' => 'net_amount',
                'ops' => [
                    ['op' => "eq", 'text' => "is equal to"],
                    ['op' => "ne", 'text' => "is not equal to"],
                    ['op' => "lt", 'text' => "is less than"],
                    ['op' => "le", 'text' => "is less or equal to"],
                    ['op' => "gt", 'text' => "is greater than"],
                    ['op' => "ge", 'text' => "is greater or equal to"]
                ],
            ],
            ['text' => 'Fee',
                'itemval' => 'net_fee',
                'ops' => [
                    ['op' => "eq", 'text' => "is equal to"],
                    ['op' => "ne", 'text' => "is not equal to"],
                    ['op' => "lt", 'text' => "is less than"],
                    ['op' => "le", 'text' => "is less or equal to"],
                    ['op' => "gt", 'text' => "is greater than"],
                    ['op' => "ge", 'text' => "is greater or equal to"]
                ],
            ],
            ['text' => 'AuthCode',
                'itemval' => 'auth_code',
                'ops' => [
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ],
            ['text' => 'Source',
                'itemval' => 'source',
                'ops' => [
                    ['op' => "eq", 'text' => "is equal to"],
                ],
            ],
            ['text' => 'Status',
                'itemval' => 'status',
                'ops' => [
                    ['op' => "eq", 'text' => "is equal to"],
                ],
                'dataValues' => [
                    ['value' => 0, 'text' => 'Errored'],
                    ['value' => 1, 'text' => 'Approved'],
                    ['value' => 2, 'text' => 'Declined'],
                    ['value' => 4, 'text' => 'Returned'],
                    ['value' => 5, 'text' => 'Refunded'],
                    ['value' => 9, 'text' => 'Voided'],
                ]
            ],
            ['text' => 'Cycle',
                'itemval' => 'stype',
                'ops' => [
                    ['op' => "eq", 'text' => "is equal to"],
                ],
                'dataValues' => [
                    ['value' => 0, 'text' => 'One Time'],
                    ['value' => 1, 'text' => 'Recurring']
                ]
            ]
        ];
        if ($level == 'G') {
            $advFilter[] = ['text' => $obj_layout->extractLayoutValue('label_merchant',$layouts),
                'itemval' => 'merchant',
                'ops' => [
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"],
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ];
        } elseif ($level == 'P') {
            $advFilter[] = ['text' => $obj_layout->extractLayoutValue('label_group',$layouts),
                'itemval' => 'group',
                'ops' => [
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"],
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ];
            $advFilter[] = ['text' => $obj_layout->extractLayoutValue('label_merchant',$layouts),
                'itemval' => 'merchant',
                'ops' => [
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"],
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ];
        } elseif ($level == 'B' || $level == 'A') {
            $advFilter[] = ['text' => $obj_layout->extractLayoutValue('label_partner',$layouts),
                'itemval' => 'partner',
                'ops' => [
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"],
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ];
            $advFilter[] = ['text' => $obj_layout->extractLayoutValue('label_group',$layouts),
                'itemval' => 'group',
                'ops' => [
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"],
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ];
            $advFilter[] = ['text' => $obj_layout->extractLayoutValue('label_merchant',$layouts),
                'itemval' => 'merchant',
                'ops' => [
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"],
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"]
                ],
            ];
        }
        return $advFilter;
    }

    function getTransactionsCustomField($transid, $idproperty) {
        $result = DB::table('custom_fields_transaction')
                        ->join('custom_fields', 'custom_fields_transaction.custom_field_id', 'custom_fields.id')
                        ->where('trans_id', $transid)
                        ->where('is_active', 1)
                        ->where('custom_fields.in_txreport', 1)
                        ->where('custom_fields_transaction.property_id', $idproperty)
                        ->select('custom_fields.field_description as field_description', 'field_value')->get();

        return $result;
    }

}
