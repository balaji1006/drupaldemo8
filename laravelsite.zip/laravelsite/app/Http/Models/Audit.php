<?php
namespace App\Http\Models;
use DB;

class Audit {
    function  getByFilter($level,$idlevel,$filterdata){
        if($level!='A'){
            $query= \Illuminate\Support\Facades\DB::table('audit')->where('level',$level)->where('idlevel',$idlevel);
            if($level=='P'){
                $query->orWhere(function ($query) use ($idlevel) {
                    $query->where('level', 'G')
                          ->WhereIn('idlevel',function ($query) use ($idlevel) {
                                $query->from('companies');
                                $query->select('id as idlevel');
                                $query->where('id_partners', $idlevel);
                            });
                });
                $query->orWhere(function ($query) use ($idlevel) {
                    $query->where('level', 'M')
                          ->WhereIn('idlevel',function ($query) use ($idlevel) {
                                $query->from('properties');
                                $query->select('id as idlevel');
                                $query->where('id_partners', $idlevel);
                            });
                });
            }
            elseif($level=='G'){
                $query->orWhere(function ($query) use ($idlevel) {
                    $query->where('level', 'M')
                          ->WhereIn('idlevel',function ($query) use ($idlevel) {
                                $query->from('properties');
                                $query->select('id as idlevel');
                                $query->where('id_partners', $idlevel);
                            });
                });
            }
            elseif($level=='B'){
                $partnersA=DB::table('branch_partner')->whereIn('branch_id',$idlevel)->select('id_partners')->get();
                $partners=array();
                foreach($partnersA as $pa){
                    $partners[]=$pa->id_partners;
                }
                $query->orWhere(function ($query) use ($partners) {
                    $query->where('level', 'P')
                          ->WhereIn('idlevel',$partners);
                });
                $query->orWhere(function ($query) use ($partners) {
                    $query->where('level', 'G')
                          ->WhereIn('idlevel',function ($query) use ($partners) {
                                $query->from('companies');
                                $query->select('id as idlevel');
                                $query->whereIn('id_partners', $partners);
                            });
                });
                $query->orWhere(function ($query) use ($partners) {
                    $query->where('level', 'M')
                          ->WhereIn('idlevel',function ($query) use ($partners) {
                                $query->from('properties');
                                $query->select('id as idlevel');
                                $query->whereIn('id_partners', $partners);
                            });
                });
            }
        }
        else {
            $query= \Illuminate\Support\Facades\DB::table('audit');
        }
        return $query;
    }
}