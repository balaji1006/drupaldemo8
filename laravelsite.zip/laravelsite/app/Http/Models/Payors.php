<?php

namespace App\Http\Models;

use DB;
use App\Model\WebUsers;

//functions related to Payors

class Payors
{
    
    function getByFilter($idlevel,$level,$filter){
        $webusers = new WebUsers();
        return $webusers->getWebUserList($idlevel, $level);
    }
    
    function getXFields($level,$idlevel=0,$export=false){
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $nfields=[
          "account_number"=>$obj_layout->extractLayoutValue('label_acc_number',$layouts),
          "first_name"=>"First Name",
          "last_name"=>"Last Name",
          "balance"=>"balance",
          "username"=>"Login Name",
          "email_address"=>"Email",
          "phone_number"=>"Phone",
          "address"=>"Address",
          "city"=>"City",
          "state"=>"State",
          "zip"=>"Zip",
          "web_status"=>"Status",
          "last_updated"=>"Updated at"  
        ];
        if($level!='M'){
            $nfields['properties.name_clients']=$obj_layout->extractLayoutValue('label_merchant',$layouts);
            $nfields['properties.compositeID_clients']='PaypointID';
        }
        if($level!='G' && $level!='M'){
            $nfields['companies.company_name']=$obj_layout->extractLayoutValue('label_group',$layouts);
            $nfields['companies.compositeID_companies']=$obj_layout->extractLayoutValue('label_group',$layouts).' ID';
        }
        if($level=='B' || $level=='A'){
            $nfields['partners.partner_title']=$obj_layout->extractLayoutValue('label_partner',$layouts);
        }
        return $nfields;
    }

    function getAdoptionRate($level, $idlevel)
    {
        $query = DB::table('web_users')->where('web_status', '<', 1000);
        if ($level == 'M') {
            $query->where('web_users.property_id', $idlevel);
        } elseif ($level == 'G') {
            $query->whereIn('web_users.property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->where('id_companies', $idlevel);
            });
        } elseif ($level == 'P') {
            $query->whereIn('web_users.property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->where('id_partners', $idlevel);
            });
        }elseif($level=='B'){
            $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
            $query->whereIn('web_users.property_id', function ($query) use ($partners) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $partners);
            });
        }
        $total = $query->count();
        $active = $query->whereIn('web_users.web_status',[1,46])->count();
        //calculate rate
        //units
        $units=0;
        if ($level == 'M') {
            $result= \Illuminate\Support\Facades\DB::table('properties')->where('id', $idlevel)->select('units')->first();
            $units=$result->units;
            $payments= \Illuminate\Support\Facades\DB::table('accounting_transactions')->whereIn('accounting_transactions.trans_payment_type', ['cc', 'ec', 'amex'])->where('accounting_transactions.trans_first_post_date', date('Y-m-d H:i:s', strtotime('-12 months')))->where('trans_status',1)->where('trans_type','<',2)->where('property_id',$idlevel)->count();
        } elseif ($level == 'G') {
            $units= \Illuminate\Support\Facades\DB::table('properties')->where('id_companies', $idlevel)->where('status_clients', 1)->sum('units');
            $query= \Illuminate\Support\Facades\DB::table('accounting_transactions')->whereIn('accounting_transactions.trans_payment_type', ['cc', 'ec', 'amex'])->where('accounting_transactions.trans_first_post_date', date('Y-m-d H:i:s', strtotime('-12 months')))->where('trans_status',1)->where('trans_type','<',2);
            $query->whereIn('property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->where('id_companies', $idlevel);
            });
            $payments=$query->count();
        } elseif ($level == 'P') {
            $units= \Illuminate\Support\Facades\DB::table('properties')->where('id_partners', $idlevel)->where('status_clients', 1)->sum('units');
            $query= \Illuminate\Support\Facades\DB::table('accounting_transactions')->whereIn('accounting_transactions.trans_payment_type', ['cc', 'ec', 'amex'])->where('accounting_transactions.trans_first_post_date', date('Y-m-d H:i:s', strtotime('-12 months')))->where('trans_status',1)->where('trans_type','<',2);
            $query->whereIn('property_id', function ($query) use ($idlevel) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->where('id_partners', $idlevel);
            });
            $payments=$query->count();
        }elseif($level=='B'){
            $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
            $units= \Illuminate\Support\Facades\DB::table('properties')->whereIn('id_partners', $partners)->where('status_clients', 1)->sum('units');
            $query= \Illuminate\Support\Facades\DB::table('accounting_transactions')->whereIn('accounting_transactions.trans_payment_type', ['cc', 'ec', 'amex'])->where('accounting_transactions.trans_first_post_date', date('Y-m-d H:i:s', strtotime('-12 months')))->where('trans_status',1)->where('trans_type','<',2);
            $query->whereIn('property_id', function ($query) use ($partners) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->whereIn('id_partners', $partners);
            });
            $payments=$query->count();
        }
        else {
            $units= \Illuminate\Support\Facades\DB::table('properties')->where('status_clients', 1)->sum('units');
            $query= \Illuminate\Support\Facades\DB::table('accounting_transactions')->whereIn('accounting_transactions.trans_payment_type', ['cc', 'ec', 'amex'])->where('accounting_transactions.trans_first_post_date', date('Y-m-d H:i:s', strtotime('-12 months')))->where('trans_status',1)->where('trans_type','<',2);
            $payments=$query->count();
        }
        if($units>0){
            $rate = number_format(($payments / ($units*12)) * 100, 2);
        }
        else $rate=0;
        return array('total' => $total, 'active' => $active, 'rate' => $rate);
    }
}
