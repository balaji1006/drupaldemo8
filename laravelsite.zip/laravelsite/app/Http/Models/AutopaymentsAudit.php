<?php

namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

//functions related to Autopayments

class AutopaymentsAudit extends Model {
    
    protected $table = 'accounting_recurring_transactions_audit';
    public $timestamps = false;
    public $incrementing = false;
    
        function getTransactionsByFilter($level, $idlevel, $filter = null) {
            $query = DB::table('accounting_recurring_transactions_audit')->join('web_users', 'accounting_recurring_transactions_audit.trans_web_user_id', 'web_users.web_user_id')
                    ->join('properties', 'properties.id', 'accounting_recurring_transactions_audit.property_id');
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->join('partners', 'properties.id_partners', 'partners.id');
            $query->select('trans_id as id', 'companies.company_name', 'properties.name_clients', 'trans_next_post_date', 'web_users.account_number', DB::raw("CONCAT (web_users.first_name, ' ', web_users.last_name) as name"), 'trans_payment_type', 'trans_recurring_net_amount', 'trans_recurring_convenience_fee','audit_action','audit_timestamp', 'dynamic', 'tag','trans_schedule');
        return $query;
        }

}
