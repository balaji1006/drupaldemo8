<?php
namespace App\Http\Models;
use DB;

class Emaf {


    function getCreditReportDetail(){

        $query =  DB::table('credit_report_detail')
            ->select('partner_title','company_name','name_clients','fdate','tx_date','type','amount','cfee_amount','card_type','inter_fee_amount','mid')
            ->join('properties', 'credit_report_detail.id_property', '=', 'properties.id')
            ->join('partners', 'properties.id_partners', '=', 'partners.id')
            ->join('companies', 'properties.id_companies', '=', 'companies.id');
        return $query;
    }

    function getTransactionsByFilter($level,$filter = null){
        if($level=='A'){
            $query =  DB::table('credit_report_detail')
            ->select('credit_report_detail.id','partner_title','company_name','name_clients','fdate','tx_date','type','amount','cfee_amount','card_type','inter_fee_amount','mid')
            ->join('properties', 'credit_report_detail.id_property', '=', 'properties.id')
            ->join('partners', 'properties.id_partners', '=', 'partners.id')
            ->join('companies', 'properties.id_companies', '=', 'companies.id');
            if (!empty($filter)) {
                foreach ($filters as $rule) {
                if (!isset($rule['data']) || !isset($rule['op']) || !isset($rule['field'])) {
                    continue;
                }
                $tofind = $rule['data'];
                if ($tofind == '') {
                    continue;
                }
                $tocmp = $rule['op'];
                $field = "";
                switch ($rule['field']) {
                     case 'partner':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('partners.partner_title', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('partners.partner_title', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('partners.partner_title', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('partners.partner_title', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('partners.partner_title', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('partners.partner_title', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('companies.company_name', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('companies.company_name', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('companies.company_name', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('companies.company_name', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('companies.company_name', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('companies.company_name', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'merchant':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('properties.name_clients', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('properties.name_clients', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('properties.name_clients', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('properties.name_clients', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('properties.name_clients', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('properties.name_clients', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'mid':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('mid', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('mid', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('mid', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('mid', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('mid', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('mid', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                     case 'tx_date':
                            switch($tocmp){
                                case 'eq':
                                    $query->whereRaw("STR_TO_DATE(tx_date,'%m%d%Y')='".$tofind."'");
                                    break;
                                case 'ne':
                                    $query->whereRaw("STR_TO_DATE(tx_date,'%m%d%Y')!='".$tofind."'");
                                    break;
                                case 'lt':
                                    $query->whereRaw("STR_TO_DATE(tx_date,'%m%d%Y')<'".$tofind."'");
                                    break;
                                case 'le':
                                    $query->whereRaw("STR_TO_DATE(tx_date,'%m%d%Y')<='".$tofind."'");
                                    break;
                                case 'gt':
                                    $query->whereRaw("STR_TO_DATE(tx_date,'%m%d%Y')>'".$tofind."'");
                                    break;
                                case 'ge':
                                    $query->whereRaw("STR_TO_DATE(tx_date,'%m%d%Y')>='".$tofind."'");
                                    break;
                            }
                            break;
                        case 'fdate':
                            switch($tocmp){
                                case 'eq':
                                    $query->whereRaw("fdate='".str_replace("-",'',$tofind)."'");
                                    break;
                                case 'ne':
                                    $query->whereRaw("fdate!='".str_replace("-",'',$tofind)."'");
                                    break;
                                case 'lt':
                                    $query->whereRaw("fdate<'".str_replace("-",'',$tofind)."'");
                                    break;
                                case 'le':
                                    $query->whereRaw("fdate<='".str_replace("-",'',$tofind)."'");
                                    break;
                                case 'gt':
                                    $query->whereRaw("fdate>'".str_replace("-",'',$tofind)."'");
                                    break;
                                case 'ge':
                                    $query->whereRaw("fdate>='".str_replace("-",'',$tofind)."'");
                                    break;
                            }
                            break;
                        case 'approval':
                            switch($tocmp){
                                case 'cn':
                                $query->where('approval_code', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('approval_code', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('approval_code', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('approval_code', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('approval_code', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('approval_code', 'not like', '%' . $tofind);
                                break;            
                            }
                            break;
                        case 'card_type':
                            switch($tocmp){
                                case 'cn':
                                $query->where('card_type', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('card_type', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('card_type', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('card_type', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('card_type', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('card_type', 'not like', '%' . $tofind);
                                break;            
                            }
                            break;            
                }
            }
        }
            return $query;
        }
        else return NULL;
    }
}