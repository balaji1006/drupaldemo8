<?php
namespace App\Http\Models;

use DB;

//functions related to Evendorpayments

class Outboundpayments
{
    
    function getByFilter($level, $idlevel, $filter){
        return $this->getTransactionsByFilter($level, $idlevel, $filter);
    }
    
    function getXFields($level,$idlevel=0,$export=false){
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $nfields=[
            "trans_unique_id"=>"Trans ID",
            "vendor.eid"=>"Vendor ID",
            "vendor.vname"=>"Vendor Name",
            "trans_net_amount"=>"Amount",
            "trans_convenience_fee"=>"Fee",
            "invoice_num"=>"Bill #",
            "trans_last_post_date"=>"Transaction Date"
        ];
        if($level!='M' || $export){
            $nfields['properties.name_clients']=$obj_layout->extractLayoutValue('label_merchant',$layouts);
            $nfields['properties.compositeID_clients']='PaypointID';
        }
        if($level!='G'){
            $nfields['companies.company_name']=$obj_layout->extractLayoutValue('label_group',$layouts);
            $nfields['companies.compositeID_companies']=$obj_layout->extractLayoutValue('label_group',$layouts).' ID';
        }
        if($level!='P'){
            $nfields['partners.partner_title']=$obj_layout->extractLayoutValue('label_partner',$layouts);
        }
        return $nfields;
    }
    
    function getTransactionsByFilter($level, $idlevel, $filter = null)
    {
        $query= DB::table('evendorpay_transactions')
                    ->where('is_fee_transaction', 0)
                    ->join('vendor', 'evendorpay_transactions.vendor_id', 'vendor.id')
                    ->join('properties', 'properties.id', 'evendorpay_transactions.property_id');
        if ($level=='M') {
            $query->whereIn('evendorpay_transactions.property_id', $idlevel);
            $query->select('trans_id as id', 'trans_unique_id as trans_id', 'trans_descr as description', 'properties.name_clients as merchant', 'vendor.eid as web_user', 'trans_last_post_date as trans_date', 'vendor.vname as webname', 'trans_payment_type as pay_method', 'trans_net_amount as net_amount', 'trans_convenience_fee as net_fee', 'trans_total_amount as net_charge', 'trans_result_auth_code as auth_code', 'trans_status as status', 'trans_type as stype', 'invoice_num','properties.compositeID_clients');
        } elseif ($level=='G') {
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->whereIn('properties.id_companies', $idlevel);
            $query->select('trans_id as id', 'trans_unique_id as trans_id', 'trans_descr as description', 'properties.name_clients as merchant', 'companies.company_name', 'vendor.eid as web_user', 'trans_last_post_date as trans_date', 'vendor.vname as webname', 'trans_payment_type as pay_method', 'trans_net_amount as net_amount', 'trans_convenience_fee as net_fee', 'trans_total_amount as net_charge', 'trans_result_auth_code as auth_code', 'trans_status as status', 'trans_type as stype', 'invoice_num','properties.compositeID_clients');
        } elseif ($level=='P') {
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->join('partners', 'properties.id_partners', 'partners.id');
            $query->whereIn('properties.id_partners', $idlevel);
            $query->select('trans_id as id', 'trans_unique_id as trans_id', 'trans_descr as description', 'properties.name_clients as merchant', 'partners.partner_title', 'companies.company_name', 'vendor.eid as web_user', 'trans_last_post_date as trans_date', 'vendor.vname as webname', 'trans_payment_type as pay_method', 'trans_net_amount as net_amount', 'trans_convenience_fee as net_fee', 'trans_total_amount as net_charge', 'trans_result_auth_code as auth_code', 'trans_status as status', 'trans_type as stype', 'invoice_num','properties.compositeID_clients');
        } elseif ($level=='B') {
            $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->join('partners', 'properties.id_partners', 'partners.id');
            $query->whereIn('properties.id_partners', $partners);
            $query->select('trans_id as id', 'trans_unique_id as trans_id', 'trans_descr as description', 'properties.name_clients as merchant', 'partners.partner_title', 'companies.company_name', 'vendor.eid as web_user', 'trans_last_post_date as trans_date', 'vendor.vname as webname', 'trans_payment_type as pay_method', 'trans_net_amount as net_amount', 'trans_convenience_fee as net_fee', 'trans_total_amount as net_charge', 'trans_result_auth_code as auth_code', 'trans_status as status', 'trans_type as stype', 'invoice_num','properties.compositeID_clients');
        } else {
            $query->join('companies', 'properties.id_companies', 'companies.id');
            $query->join('partners', 'properties.id_partners', 'partners.id');
            $query->select('trans_id as id', 'trans_unique_id as trans_id', 'trans_descr as description', 'properties.name_clients as merchant', 'partners.partner_title', 'companies.company_name', 'vendor.eid as web_user', 'trans_last_post_date as trans_date', 'vendor.vname as webname', 'trans_payment_type as pay_method', 'trans_net_amount as net_amount', 'trans_convenience_fee as net_fee', 'trans_total_amount as net_charge', 'trans_result_auth_code as auth_code', 'trans_status as status', 'trans_type as stype', 'invoice_num','properties.compositeID_clients');
        }
        
        if (!empty($filter) && isset($filter['rules'])) {
            $filters=$filter['rules'];
            foreach ($filters as $rule) {
                if (!isset($rule['data']) || !isset($rule['op']) || !isset($rule['field'])) {
                    continue;
                }
                $tofind=$rule['data'];
                if ($tofind=='') {
                    continue;
                }
                $tocmp=$rule['op'];
                $field="";
                switch ($rule['field']) {
                    case 'partner':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('partners.partner_title', 'like', '%'.$tofind.'%');
                                break;
                            case 'nc':
                                $query->where('partners.partner_title', 'not like', '%'.$tofind.'%');
                                break;
                            case 'bw':
                                $query->where('partners.partner_title', 'like', $tofind.'%');
                                break;
                            case 'bn':
                                $query->where('partners.partner_title', 'not like', $tofind.'%');
                                break;
                            case 'ew':
                                $query->where('partners.partner_title', 'like', '%'.$tofind);
                                break;
                            case 'en':
                                $query->where('partners.partner_title', 'not like', '%'.$tofind);
                                break;
                        }
                        break;
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('companies.company_name', 'like', '%'.$tofind.'%');
                                break;
                            case 'nc':
                                $query->where('companies.company_name', 'not like', '%'.$tofind.'%');
                                break;
                            case 'bw':
                                $query->where('companies.company_name', 'like', $tofind.'%');
                                break;
                            case 'bn':
                                $query->where('companies.company_name', 'not like', $tofind.'%');
                                break;
                            case 'ew':
                                $query->where('companies.company_name', 'like', '%'.$tofind);
                                break;
                            case 'en':
                                $query->where('companies.company_name', 'not like', '%'.$tofind);
                                break;
                        }
                        break;
                    case 'merchant':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('properties.name_clients', 'like', '%'.$tofind.'%');
                                break;
                            case 'nc':
                                $query->where('properties.name_clients', 'not like', '%'.$tofind.'%');
                                break;
                            case 'bw':
                                $query->where('properties.name_clients', 'like', $tofind.'%');
                                break;
                            case 'bn':
                                $query->where('properties.name_clients', 'not like', $tofind.'%');
                                break;
                            case 'ew':
                                $query->where('properties.name_clients', 'like', '%'.$tofind);
                                break;
                            case 'en':
                                $query->where('properties.name_clients', 'not like', '%'.$tofind);
                                break;
                        }
                        break;
                    case 'webname':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('vendor.vname', 'like', '%'.$tofind.'%');
                                break;
                            case 'nc':
                                $query->where('vendor.vname', 'not like', '%'.$tofind.'%');
                                break;
                            case 'bw':
                                $query->where('vendor.vname', 'like', $tofind.'%');
                                break;
                            case 'bn':
                                $query->where('vendor.vname', 'not like', $tofind.'%');
                                break;
                            case 'ew':
                                $query->where('vendor.vname', 'like', '%'.$tofind);
                                break;
                            case 'en':
                                $query->where('vendor.vname', 'not like', '%'.$tofind);
                                break;
                        }
                        break;
                    case 'webuser':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('vendor.eid', 'like', '%'.$tofind.'%');
                                break;
                            case 'nc':
                                $query->where('vendor.eid', 'not like', '%'.$tofind.'%');
                                break;
                            case 'bw':
                                $query->where('vendor.eid', 'like', $tofind.'%');
                                break;
                            case 'bn':
                                $query->where('vendor.eid', 'not like', $tofind.'%');
                                break;
                            case 'ew':
                                $query->where('vendor.eid', 'like', '%'.$tofind);
                                break;
                            case 'en':
                                $query->where('vendor.eid', 'not like', '%'.$tofind);
                                break;
                        }
                        break;
                    case 'trans_id':
                        switch ($tocmp) {
                            case 'eq':
                                $query->where('evendorpay_transactions.trans_unique_id', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('evendorpay_transactions.trans_unique_id', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('evendorpay_transactions.trans_unique_id', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('evendorpay_transactions.trans_unique_id', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('evendorpay_transactions.trans_unique_id', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('evendorpay_transactions.trans_unique_id', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'pay_method':
                        $query->where('evendorpay_transactions.trans_payment_type', '=', $tofind);
                        break;
                    case 'net_amount':
                        switch ($tocmp) {
                            case 'eq':
                                $query->where('evendorpay_transactions.trans_net_amount', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('evendorpay_transactions.trans_net_amount', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('evendorpay_transactions.trans_net_amount', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('evendorpay_transactions.trans_net_amount', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('evendorpay_transactions.trans_net_amount', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('evendorpay_transactions.trans_net_amount', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'net_fee':
                        switch ($tocmp) {
                            case 'eq':
                                $query->where('evendorpay_transactions.trans_convenience_fee', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('evendorpay_transactions.trans_convenience_fee', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('evendorpay_transactions.trans_convenience_fee', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('evendorpay_transactions.trans_convenience_fee', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('evendorpay_transactions.trans_convenience_fee', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('evendorpay_transactions.trans_convenience_fee', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'net_charge':
                        switch ($tocmp) {
                            case 'eq':
                                $query->where('evendorpay_transactions.trans_total_amount', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('evendorpay_transactions.trans_total_amount', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('evendorpay_transactions.trans_total_amount', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('evendorpay_transactions.trans_total_amount', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('evendorpay_transactions.trans_total_amount', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('evendorpay_transactions.trans_total_amount', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'auth_code':
                        if ($tocmp=='cn') {
                            $query->where('trans_result_auth_code', 'like', '%'.$tofind.'%');
                        } else {
                            $query->where('trans_result_auth_code', 'not like', '%'.$tofind.'%');
                        }
                        break;
                    case 'status':
                        if ($tofind <= 1) {
                            $query->where('trans_status', '=', $tofind)->where('trans_type', '<=', 1);
                        } else {
                            if ($tofind==2) {
                                $query->where('trans_status', '>=', 2)->where('trans_status', '<=', 3);
                            } elseif ($tofind==4) {
                                $query->where('trans_status', '=', 1)->where('trans_type', '=', 2);
                            } else {
                                $query->where('trans_status', '=', $tofind);
                            }
                        }
                        break;
                    case 'stype':
                        $query->where('trans_type', '=', $tofind);
                        break;
                    case 'trans_date':
                        switch ($tocmp) {
                            case 'eq':
                                $query->whereRaw('DATE(evendorpay_transactions.trans_last_post_date)= ?', [$tofind]);
                                break;
                            case 'ne':
                                $query->whereRaw('DATE(evendorpay_transactions.trans_last_post_date)!= ?', [$tofind]);
                                break;
                            case 'lt':
                                $query->whereRaw('DATE(evendorpay_transactions.trans_last_post_date)< ?', [$tofind]);
                                break;
                            case 'le':
                                $query->whereRaw('DATE(evendorpay_transactions.trans_last_post_date)<= ?', [$tofind]);
                                break;
                            case 'gt':
                                $query->whereRaw('DATE(evendorpay_transactions.trans_last_post_date)> ?', [$tofind]);
                                break;
                            case 'ge':
                                $query->whereRaw('DATE(evendorpay_transactions.trans_last_post_date)>= ?', [$tofind]);
                                break;
                        }
                        break;
                }
            }
        }
        return $query;
    }

    function getAdvancedFilters($level,$idlevel=0){
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $advFilter= [
            ['text'=> 'transaction date', 
             'itemval'=>'trans_date',
             'ops'=>[
                 ['op'=> "eq", 'text'=> "is equal to"],
                 ['op'=> "ne", 'text'=> "is not equal to"],
                 ['op'=> "lt", 'text'=> "is less than"],
                 ['op'=> "le", 'text'=> "is less or equal to"],
                 ['op'=> "gt", 'text'=> "is greater than"],
                 ['op'=> "ge", 'text'=> "is greater or equal to"]
             ],
             'dateType'=>true   
            ],
            ['text'=>'transID',
             'itemval'=>'trans_id',
             'ops'=>[
                 ['op'=> "eq", 'text'=> "is equal to"],
                 ['op'=> "ne", 'text'=> "is not equal to"],
                 ['op'=> "lt", 'text'=> "is less than"],
                 ['op'=> "le", 'text'=> "is less or equal to"],
                 ['op'=> "gt", 'text'=> "is greater than"],
                 ['op'=> "ge", 'text'=> "is greater or equal to"]
             ],
            ],
            ['text'=>'Vendor #',
             'itemval'=>'webuser',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ],
            ['text'=>'Vendor Name',
             'itemval'=>'webname',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ],
            ['text'=>'Amount',
             'itemval'=>'net_amount',
             'ops'=>[
                 ['op'=> "eq", 'text'=> "is equal to"],
                 ['op'=> "ne", 'text'=> "is not equal to"],
                 ['op'=> "lt", 'text'=> "is less than"],
                 ['op'=> "le", 'text'=> "is less or equal to"],
                 ['op'=> "gt", 'text'=> "is greater than"],
                 ['op'=> "ge", 'text'=> "is greater or equal to"]
             ],
            ],
            ['text'=>'Fee',
             'itemval'=>'net_fee',
             'ops'=>[
                 ['op'=> "eq", 'text'=> "is equal to"],
                 ['op'=> "ne", 'text'=> "is not equal to"],
                 ['op'=> "lt", 'text'=> "is less than"],
                 ['op'=> "le", 'text'=> "is less or equal to"],
                 ['op'=> "gt", 'text'=> "is greater than"],
                 ['op'=> "ge", 'text'=> "is greater or equal to"]
             ],
            ],
            ['text'=>'AuthCode',
             'itemval'=>'auth_code',
             'ops'=>[
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],
            ],
            ['text'=>'Status',
             'itemval'=>'status',
             'ops'=>[
                 ['op'=> "eq", 'text'=> "is equal to"],
             ],
             'dataValues'=>[
                 ['value'=>0,'text'=>'Errored'],
                 ['value'=>1,'text'=>'Approved'],
                 ['value'=>2,'text'=>'Declined'],
                 ['value'=>4,'text'=>'Returned'],
                 ['value'=>5,'text'=>'Refunded'],
                 ['value'=>9,'text'=>'Voided'],
             ]   
            ],
            ['text'=>'Cycle',
             'itemval'=>'stype',
             'ops'=>[
                 ['op'=> "eq", 'text'=> "is equal to"],
             ],
             'dataValues'=>[
                 ['value'=>0,'text'=>'One Time'],
                 ['value'=>1,'text'=>'Recurring']
             ]   
            ]
        ];
        if($level=='G'){
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_merchant',$layouts),
             'itemval'=>'merchant',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
        }
        elseif($level=='P'){
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_group',$layouts),
             'itemval'=>'group',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_merchant',$layouts),
             'itemval'=>'merchant',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
        }
        elseif($level=='B' || $level=='A'){
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_partner',$layouts),
             'itemval'=>'partner',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_group',$layouts),
             'itemval'=>'group',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_merchant',$layouts),
             'itemval'=>'merchant',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
        }
        return $advFilter;
    }
    
    function getDetails($txid, $with_events = false)
    {
        $result=DB::table('evendorpay_transactions')->where('trans_id', $txid)->first();
        if (!empty($result)) {
            $vendor=DB::table('vendor')->where('id', $result['vendor_id'])->first();
            $result['vendor']=$vendor;
            if ($with_events) {
                $events=DB::table('transaction_events')->where('trans_id', 'like', $result['trans_unique_id'])->get();
                $result['events']=$events;
            }
        }
        return $result;
    }
}
