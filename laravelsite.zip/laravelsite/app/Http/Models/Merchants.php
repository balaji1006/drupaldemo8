<?php

namespace App\Http\Models;

use DB;

//functions related to Payors

class Merchants
{
    function getByFilter($idlevel,$level,$filter){
        $merchants = new \App\Model\Properties();
        return $merchants->getMerchantByFilter($level, $idlevel, $filter);
    }
    
    function getXFields($level,$idlevel=0,$export=false){
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $nfields=[
            "id"=>"IVR ID",
            "name_clients"=>"DBA Name",
            "compositeID_clients"=>"PaypointID",
            "units"=>"Units",
            "email_address_clients"=>"Email Address",
            "accounting_email_address"=>"Accounting Email",
            "subdomain_clients"=>"Subdomain",
            "address_clients"=>"Address",
            "city_clients"=>"City",
            "state_clients"=>"State",
            "zip_clients"=>"Zip",
            "phone_clients"=>"Phone",
            "contact_name_clients"=>"Contact Name",
            "date_new"=>"Created at",
            "last_updated"=>"Updated at"
            
        ];
        if($level!='G' && $level!='M'){
            $nfields['companies.company_name']=$obj_layout->extractLayoutValue('label_group',$layouts);
            $nfields['companies.compositeID_companies']=$obj_layout->extractLayoutValue('label_group',$layouts).' ID';
        }
        if($level=='B' || $level=='A'){
            $nfields['partners.partner_title']=$obj_layout->extractLayoutValue('label_partner',$layouts);
        }
        return $nfields;
    }
}