<?php
namespace App\Http\Models;

use DB;

//functions related to Admins

class Admins
{

    function isMaster($id_user){
        $master=DB::table('users_access_master')->where('users_admin_id',$id_user)->count();
        if(empty($master))return false;
        return true;
    }
    
    function getAdminName($id)
    {
        $result=DB::table('users_admin')->where('id', $id)->select('name')->first();
        if (!empty($result)) {
            return $result['name'];
        }
        return $result;
    }
}
