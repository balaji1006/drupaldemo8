<?php
namespace App\Http\Models;

use DB;

//functions related to Groups

class Groups
{
    function getXFields($level,$idlevel=0,$export=false){
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $nfields=[
            "company_name"=>$obj_layout->extractLayoutValue('label_group',$layouts)." Name",
            "subdomain_companies"=>"subdomain",
            "compositeID_companies"=>"ID",
            "contact_name"=>"Contact Name",
            "contact_email"=>"Email",
            "address"=>"Address",
            "city"=>"City",
            "state"=>"State",
            "zip"=>"Zip",
            "phone_number"=>"Phone"
        ];
        if($level!='G'){
            $nfields['partners.partner_title']=$obj_layout->extractLayoutValue('label_partner',$layouts);
        }
        return $nfields;
    }

    function getByFilter($idlevel, $level='P', $filter = null)
    {
        $query= DB::table('companies')->where('status', 1)->join('partners', 'partners.id', 'companies.id_partners');
        $query->select('companies.id as id', 'partners.partner_title as partner', 'companies.company_name as group', 'subdomain_companies', 'contact_name', 'contact_email', 'address', 'city', 'state', 'zip', 'phone_number', 'clayout_id as layout', 'logo_group as logo');
        if (!empty($idlevel)) {
            $query->whereIn('id', $idlevel);
        }
        if (!empty($filter)) {
            foreach ($filters as $rule) {
                if (!isset($rule['data']) || !isset($rule['op']) || !isset($rule['field'])) {
                    continue;
                }
                $tofind=$rule['data'];
                if ($tofind=='') {
                    continue;
                }
                $tocmp=$rule['op'];
                $field="";
                switch ($rule['field']) {
                    case 'partner':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('partners.partner_title', 'like', '%'.$tofind.'%');
                                break;
                            case 'nc':
                                $query->where('partners.partner_title', 'not like', '%'.$tofind.'%');
                                break;
                            case 'bw':
                                $query->where('partners.partner_title', 'like', $tofind.'%');
                                break;
                            case 'bn':
                                $query->where('partners.partner_title', 'not like', $tofind.'%');
                                break;
                            case 'ew':
                                $query->where('partners.partner_title', 'like', '%'.$tofind);
                                break;
                            case 'en':
                                $query->where('partners.partner_title', 'not like', '%'.$tofind);
                                break;
                        }
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('companies.company_name', 'like', '%'.$tofind.'%');
                                break;
                            case 'nc':
                                $query->where('companies.company_name', 'not like', '%'.$tofind.'%');
                                break;
                            case 'bw':
                                $query->where('companies.company_name', 'like', $tofind.'%');
                                break;
                            case 'bn':
                                $query->where('companies.company_name', 'not like', $tofind.'%');
                                break;
                            case 'ew':
                                $query->where('companies.company_name', 'like', '%'.$tofind);
                                break;
                            case 'en':
                                $query->where('companies.company_name', 'not like', '%'.$tofind);
                                break;
                        }
                    case 'group_id':
                        $query->where('companies.compositeID_companies', 'like', '%'.$tofind.'%');
                        break;
                    case 'contact_name':
                        $query->where('companies.contact_name', 'like', '%'.$tofind.'%');
                        break;
                    case 'address':
                        $query->where('companies.address', 'like', '%'.$tofind.'%');
                        break;
                    case 'city':
                        $query->where('companies.city', 'like', '%'.$tofind.'%');
                        break;
                    case 'state':
                        $query->where('companies.state', $tofind);
                        break;
                    case 'layout':
                        $query->where('companies.clayout_id', $tofind);
                        break;
                }
            }
        }
        return $query;
    }

    function add($data)
    {
        if (!isset($data['company_name'])) {
            return false;
        }
        $company=trim($data['company_name']);
        if ($company=='') {
            return false;
        }
        if (!isset($data['admin'])) {
            return false;
        }
        if (($data['admin']*1)<=0) {
            return false;
        }
        if (!isset($data['id_partner'])) {
            return false;
        }
        if (($data['id_partner']*1)<=0) {
            return false;
        }
        $company_subdomain=$this->cleanString($company);
        $df=DB::table('companies')->where('subdomain_companies', $company_subdomain)->count();
        if ($df>0) {
            $company_subdomain.=time();
        }
        $newcompany=array();
        $newcompany['company_name']=$company;
        $newcompany['subdomain_companies']=$company_subdomain;
        $newcompany['id_partners']=$data['id_partner'];
        if (isset($data['company_id'])) {
            $newcompany['compositeID_companies']=trim($data['company_id']);
        }
        if (isset($data['logo'])) {
            $newcompany['logo_group']=trim($data['logo']);
        }
        if (isset($data['contact_name'])) {
            $newcompany['contact_name']=trim($data['contact_name']);
        }
        if (isset($data['contact_email'])) {
            $newcompany['contact_email']=trim($data['contact_email']);
        }
        if (isset($data['address'])) {
            $newcompany['address']=trim($data['address']);
        }
        if (isset($data['city'])) {
            $newcompany['city']=trim($data['city']);
        }
        if (isset($data['state'])) {
            $newcompany['state']=trim($data['state']);
        }
        if (isset($data['zip'])) {
            $newcompany['zip']=trim($data['zip']);
        }
        if (isset($data['phone_number'])) {
            $newcompany['phone_number']=trim($data['phone_number']);
        }
        if (isset($data['status'])) {
            $newcompany['status']=trim($data['status'])*1;
        }
        if (isset($data['layout'])) {
            $newcompany['clayout_id']=trim($data['layout'])*1;
        }
        $newcompany['last_updated']=date('Y-m-d H:i:s');
        $newcompany['last_updated_by']=Admins::getAdminName($data['admin']);
        return DB::table('companies')->insertGetId($newcompany);
    }

    function update($id, $data)
    {
        if (!isset($data['admin'])) {
            return false;
        }
        if (($data['admin']*1)<=0) {
            return false;
        }
        $newcompany=array();
        if (isset($data['company_name'])) {
            $newcompany['company_name']=trim($data['company_name']);
        }
        if (isset($data['subdomain'])) {
            $newcompany['subdomain_companies']=trim($data['subdomain']);
        }
        if (isset($data['company_id'])) {
            $newcompany['compositeID_companies']=trim($data['company_id']);
        }
        if (isset($data['logo'])) {
            $newcompany['logo_group']=trim($data['logo']);
        }
        if (isset($data['contact_name'])) {
            $newcompany['contact_name']=trim($data['contact_name']);
        }
        if (isset($data['contact_email'])) {
            $newcompany['contact_email']=trim($data['contact_email']);
        }
        if (isset($data['address'])) {
            $newcompany['address']=trim($data['address']);
        }
        if (isset($data['city'])) {
            $newcompany['city']=trim($data['city']);
        }
        if (isset($data['state'])) {
            $newcompany['state']=trim($data['state']);
        }
        if (isset($data['zip'])) {
            $newcompany['zip']=trim($data['zip']);
        }
        if (isset($data['phone_number'])) {
            $newcompany['phone_number']=trim($data['phone_number']);
        }
        if (isset($data['status'])) {
            $newcompany['status']=trim($data['status'])*1;
        }
        if (isset($data['layout'])) {
            $newcompany['clayout_id']=trim($data['layout'])*1;
        }
        $newcompany['last_updated']=date('Y-m-d H:i:s');
        $newcompany['last_updated_by']=Admins::getAdminName($data['admin']);
        DB::table('companies')->where('id', $id)->update($newcompany);
        return true;
    }

    function get($id)
    {
        $result=DB::table('companies')->where('id', $id)->first();
        return $result;
    }

    function delete($id, $id_admin, $cascade = true)
    {
        if (($id_admin*1)<=0) {
            return false;
        }
        $admin_name=Admins::getAdminName($data['admin']);
        $last_updated=date('Y-m-d H:i:s');
        DB::table('companies')->where('id', $id)->update(['status'=>0,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
        if ($cascade) {
            DB::table('properties')->where('id_companies', $id)->update(['status_clients'=>0,'status_pp'=>0,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
            DB::table('accounting_recurring_transactions')->where('trans_status', 1)->whereIn('property_id', function ($query) use ($id) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->where('id_companies', $id);
            })->update(['trans_status'=>5,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
            DB::table('web_users')->where('web_status', '<', 1000)->whereIn('property_id', function ($query) use ($id) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->where('id_companies', $id);
            })->update(['web_status'=>9999,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
            DB::table('profiles')->where('id_company', $id)->delete();
            DB::table('api_user')->where('id_company', $id)->delete();
        }
        return true;
    }

    public function cleanString($string)
    {
        $string = strtolower($string);
        $string = str_replace(' ', '', $string);
        $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string);
        return preg_replace('/-+/', '_', $string);
    }
}
