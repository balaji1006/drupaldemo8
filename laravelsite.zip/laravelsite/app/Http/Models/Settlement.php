<?php

namespace App\Http\Models;

use DB;

//functions related to Settlements

class Settlement
{

    function getSettlementToday($level, $idlevel)
    {
        if ($level == 'P') {
            $query = DB::table('settlement_report')->where('id_partner', $idlevel);
        } elseif ($level == 'G') {
            $query = DB::table('settlement_report')->where('id_company', $idlevel);
        } elseif ($level == 'M') {
            $query = DB::table('settlement_report')->where('id_property', $idlevel);
        } elseif ($level == 'B') {
            $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
            $query = DB::table('settlement_report')->whereIn('id_partner', $partners);
        } else {
            $query = DB::table('settlement_report');
        }
        $query->where('date_formatted', date('m/d/Y'));
        $debits = $query->sum('debit');
        $credits = $query->sum('credit');
        return ($credits - $debits);
    }

    function getBatches($level, $idlevel, $from, $to)
    {
        if ($level == 'P') {
            $query = DB::table('settlement_report')->where('id_partner', $idlevel);
        } elseif ($level == 'G') {
            $query = DB::table('settlement_report')->where('id_company', $idlevel);
        } elseif ($level == 'M') {
            $query = DB::table('settlement_report')->where('id_property', $idlevel);
        }elseif ($level == 'B') {
            $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
            $query = DB::table('settlement_report')->whereIn('id_partner', $partners);
        } else {
            $query = DB::table('settlement_report');
        }
        $_from = strtotime($from);
        $_to = strtotime($to);
        $tdates = array();
        $mtime = $_from;
        while ($mtime <= $_to) {
            $tdates[] = date('m/d/Y', $mtime);
            $mtime = strtotime('+1 days', $mtime);
        }
        $query->where('date', $tdates);
        $query->select('batch', 'date', 'company_name', 'company_id', 'property_name', 'property_id', 'transaction_type', DB::raw('SUM(credit-debit) as total'));
        $query->groupBy('batch')->groupBy('date')->groupBy('transaction_type')->groupBy('company_name')->groupBy('property_name');
        $query->orderBy('id', 'DESC');
        return $query;
    }
    
    function getXFields($level,$idlevel=0,$export=false){
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $nfields=[
            "batch"=>"Batch ID",
            "property_name"=>$obj_layout->extractLayoutValue('label_merchant',$layouts),
            "property_id"=>"PaypointID",
            "company_name"=>$obj_layout->extractLayoutValue('label_group',$layouts),
            "company_id"=>$obj_layout->extractLayoutValue('label_group',$layouts)." ID",
            "customer_name"=>$obj_layout->extractLayoutValue('label_user',$layouts)." Name",
            "customer_id"=>$obj_layout->extractLayoutValue('label_acc_number',$layouts),
            "trans_id"=>"Transaction ID",
            "debit"=>"Debit",
            "credit"=>"Credit",
            "date_formatted"=>"Settlement Date",
            "trans_date"=>"Transaction Date"
        ];
        return $nfields;
    }

    function getByFilter($level, $idlevel, $filter){
        return $this->getSettledTransactions($level, $idlevel, $filter);
    }
    
    function getSettledTransactions($level, $idlevel, $filter = null)
    {
        if ($level == 'P') {
            $query = DB::table('settlement_report')->where('id_partner', $idlevel);
        } elseif ($level == 'G') {
            $query = DB::table('settlement_report')->where('id_company', $idlevel);
        } elseif ($level == 'M') {
            $query = DB::table('settlement_report')->where('id_property', $idlevel);
        }elseif ($level == 'B') {
            $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
            $query = DB::table('settlement_report')->whereIn('id_partner', $partners);
        } else {
            $query = DB::table('settlement_report');
        }
        $query->select('id','batch', 'date_formatted', 'company_name', 'company_id', 'property_name', 'property_id', 'transaction_type', 'credit', 'debit', DB::raw('(credit - debit) as total'), 'customer_name', 'customer_id', 'trans_id', 'trans_date', 'trans_recurring');
        if (isset($filter['rules'])) {
            $filter=$filter['rules'];
            foreach ($filter as $rule) {
                if (!isset($rule['data']) || !isset($rule['op']) || !isset($rule['field'])) {
                    continue;
                }
                $tofind = $rule['data'];
                if ($tofind == '') {
                    continue;
                }
                $tocmp = $rule['op'];
                $field = "";
                switch ($rule['field']) {
                    case 'partner':
                        $query->where('id_partner', function ($query) use ($tofind) {
                            $query->from('partners');
                            $query->select('id as id_partner');
                            $query->where('partner_title', 'like', '%' . $tofind . '%');
                        });
                        break;
                    case 'group':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('company_name', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('company_name', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('company_name', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('company_name', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('company_name', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('company_name', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'merchant':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('property_name', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('property_name', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('property_name', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('property_name', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('property_name', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('property_name', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'webname':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('customer_name', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('customer_name', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('customer_name', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('customer_name', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('customer_name', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('customer_name', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'webuser':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('customer_id', 'like', '%' . $tofind . '%');
                                break;
                            case 'nc':
                                $query->where('customer_id', 'not like', '%' . $tofind . '%');
                                break;
                            case 'bw':
                                $query->where('customer_id', 'like', $tofind . '%');
                                break;
                            case 'bn':
                                $query->where('customer_id', 'not like', $tofind . '%');
                                break;
                            case 'ew':
                                $query->where('customer_id', 'like', '%' . $tofind);
                                break;
                            case 'en':
                                $query->where('customer_id', 'not like', '%' . $tofind);
                                break;
                        }
                        break;
                    case 'trans_id':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('trans_id', 'like', '%' . $tofind . '%');
                                break;
                            case 'eq':
                                $query->where('trans_id', '=', $tofind);
                                break;
                            case 'ne':
                                $query->where('trans_id', '!=', $tofind);
                                break;
                            case 'lt':
                                $query->where('trans_id', '<', $tofind);
                                break;
                            case 'le':
                                $query->where('trans_id', '<=', $tofind);
                                break;
                            case 'gt':
                                $query->where('trans_id', '>', $tofind);
                                break;
                            case 'ge':
                                $query->where('trans_id', '>=', $tofind);
                                break;
                        }
                        break;
                    case 'date_formatted':
                        switch ($tocmp) {
                            case 'eq':
                                $query->whereRaw('date_formatted = ?', date('m/d/Y',strtotime($tofind)));
                                break;
                            case 'ne':
                                $query->whereRaw('date_formatted != ?', date('m/d/Y',strtotime($tofind)));
                                break;
                            case 'lt':
                                $query->whereRaw('date_formatted < ?', date('m/d/Y',strtotime($tofind)));
                                break;
                            case 'le':
                                $query->whereRaw('date_formatted <= ?', date('m/d/Y',strtotime($tofind)));
                                break;
                            case 'gt':
                                $query->whereRaw('date_formatted > ?', date('m/d/Y',strtotime($tofind)));
                                break;
                            case 'ge':
                                $query->whereRaw('date_formatted >= ?', date('m/d/Y',strtotime($tofind)));
                                break;
                        }
                    break;
                    case 'pay_method':
                        $query->where('transaction_type', 'like', $tofind);
                        break;
                    case 'group_id':
                        $query->where('company_id', 'like', $tofind);
                        break;
                    case 'merchant_id':
                        $query->where('property_id', 'like', $tofind);
                        break;
                    case 'batch_id':
                        $query->where('batch', 'like', $tofind);
                        break;
                }
            }
        }
        $query->groupBy('batch')->groupBy('date')->groupBy('property_id');
        return $query;
    }
    
        function getAdvancedFilters($level,$idlevel=0){
            $obj_layout = new \App\Model\Layout();
            $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $advFilter= [
            ['text'=> 'batch date', 
             'itemval'=>'date_formatted',
             'ops'=>[
                 ['op'=> "eq", 'text'=> "is equal to"],
                 ['op'=> "ne", 'text'=> "is not equal to"],
                 ['op'=> "lt", 'text'=> "is less than"],
                 ['op'=> "le", 'text'=> "is less or equal to"],
                 ['op'=> "gt", 'text'=> "is greater than"],
                 ['op'=> "ge", 'text'=> "is greater or equal to"],
             ],
             'dateType'=>true   
            ],
            ['text'=>'transID',
             'itemval'=>'trans_id',
             'ops'=>[
                 ['op'=> "cn", 'text'=> "contains"],
             ],
            ],
            ['text'=>$obj_layout->extractLayoutValue('label_acc_number',$layouts),
             'itemval'=>'webuser',
                'ops'=>[
                    ['op' => "cn", 'text' => "contains"],
                    ['op' => "nc", 'text' => "does not contain"],
                    ['op' => "bw", 'text' => "begins with"],
                    ['op' => "bn", 'text' => "does not begin with"],
                    ['op' => "ew", 'text' => "ends with"],
                    ['op' => "en", 'text' => "does not end with"]
             ],   
            ],
            ['text'=>$obj_layout->extractLayoutValue('label_user',$layouts).' Name',
             'itemval'=>'webname',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ],
            ['text'=>'Method',
             'itemval'=>'pay_method',
             'ops'=>[
                 ['op'=> "eq", 'text'=> "is equal to"],
             ],
             'dataValues'=>[
                 ['value'=>'eCheck','text'=>'E-Check'],
                 ['value'=>'Credit Card','text'=>'Credit Card'],
             ]   
            ],
            ['text'=>$obj_layout->extractLayoutValue('label_group',$layouts).' ID',
             'itemval'=>'group_id',
             'ops'=>[
                 ['op'=> "cn", 'text'=> "contains"],
             ],
            ],
            ['text'=>'Paypoint ID',
             'itemval'=>'merchant_id',
             'ops'=>[
                 ['op'=> "cn", 'text'=> "contains"],
             ],
            ],
            ['text'=>'Batch ID',
             'itemval'=>'batch_id',
             'ops'=>[
                 ['op'=> "cn", 'text'=> "contains"],
             ],
            ],
        ];
        if($level=='G'){
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_merchant',$layouts),
             'itemval'=>'merchant',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
        }
        elseif($level=='P'){
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_group',$layouts),
             'itemval'=>'group',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_merchant',$layouts),
             'itemval'=>'merchant',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
        }
        elseif($level=='B' || $level=='A'){
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_group',$layouts),
             'itemval'=>'group',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
            $advFilter[]=['text'=>$obj_layout->extractLayoutValue('label_merchant',$layouts),
             'itemval'=>'merchant',
             'ops'=>[
                 ['op'=> "bw", 'text'=> "begins with"],
                 ['op'=> "bn", 'text'=> "does not begin with"],
                 ['op'=> "ew", 'text'=> "ends with"],
                 ['op'=> "en", 'text'=> "does not end with"],
                 ['op'=> "cn", 'text'=> "contains"],
                 ['op'=> "nc", 'text'=> "does not contain"]
             ],   
            ];
        }
        return $advFilter;
    }

     function getSettledTransactionsBatch($level, $idlevel, $batch)
    {
        if ($level == 'P') {
            $query = DB::table('settlement_report')->where('id_partner', $idlevel);
        } elseif ($level == 'G') {
            $query = DB::table('settlement_report')->where('id_company', $idlevel);
        } elseif ($level == 'M') {
            $query = DB::table('settlement_report')->where('id_property', $idlevel);
        }elseif ($level == 'B') {
            $partnersA=DB::table('branch_partner')->where('branch_id',$idlevel)->select('id_partners')->get();
            $partners=array();
            foreach($partnersA as $pa){
                $partners[]=$pa->id_partners;
            }
            $query = DB::table('settlement_report')->whereIn('id_partner', $partners);
        } else {
            $query = DB::table('settlement_report');
        }
        $query->select('batch', 'date_formatted', 'company_name', 'company_id', 'property_name', 'property_id', 'transaction_type', 'credit', 'debit', DB::raw('(credit-debit) as total'), 'customer_name', 'customer_id', 'trans_id', 'trans_date', 'trans_recurring');
        $query->where('batch',$batch);
        return $query;
    }
}
