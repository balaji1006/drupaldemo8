<?php
namespace App\Http\Models;

use DB;

//functions related to Partners

class Partners
{

    function getXFields($level,$idlevel=0,$export=false){
        $nfields=[
            "partner_title"=>"Partner Title",
            "partner_name"=>"subdomain",
            "partner_composite_id"=>"PartnerID"
        ];
        return $nfields;
    }
    
    function getByFilter($idlevel, $level, $filter = null)
    {
        $query= DB::table('partners')->where('status', 1);
        if (!empty($idlevel)) {
            $query->whereIn('id', $idlevel);
        }
        if (!empty($filter)) {
            foreach ($filters as $rule) {
                if (!isset($rule['data']) || !isset($rule['op']) || !isset($rule['field'])) {
                    continue;
                }
                $tofind=$rule['data'];
                if ($tofind=='') {
                    continue;
                }
                $tocmp=$rule['op'];
                $field="";
                switch ($rule['field']) {
                    case 'partner':
                        switch ($tocmp) {
                            case 'cn':
                                $query->where('partners.partner_title', 'like', '%'.$tofind.'%');
                                break;
                            case 'nc':
                                $query->where('partners.partner_title', 'not like', '%'.$tofind.'%');
                                break;
                            case 'bw':
                                $query->where('partners.partner_title', 'like', $tofind.'%');
                                break;
                            case 'bn':
                                $query->where('partners.partner_title', 'not like', $tofind.'%');
                                break;
                            case 'ew':
                                $query->where('partners.partner_title', 'like', '%'.$tofind);
                                break;
                            case 'en':
                                $query->where('partners.partner_title', 'not like', '%'.$tofind);
                                break;
                        }
                    case 'partner_id':
                        $query->where('partners.partner_composite_id', 'like', '%'.$tofind.'%');
                        break;
                    case 'layout':
                        $query->where('partners.layout_id', $tofind);
                        break;
                }
            }
        }
        return $query;
    }

    function add($data)
    {
        if (!isset($data['partner_title'])) {
            return false;
        }
        $partner_title=trim($data['partner_title']);
        if ($partner_title=='') {
            return false;
        }
        if (!isset($data['admin'])) {
            return false;
        }
        if (($data['admin']*1)<=0) {
            return false;
        }
        $partner_subdomain=$this->cleanString($partner_title);
        $df=DB::table('partners')->where('partner_name', $partner_subdomain)->count();
        if ($df>0) {
            $partner_subdomain.=time();
        }
        $newpartner=array();
        $newpartner['partner_name']=$partner_subdomain;
        $newpartner['partner_title']=$partner_title;
        if (isset($data['partner_id'])) {
            $newpartner['partner_composite_id']=trim($data['partner_id']);
        }
        if (isset($data['logo'])) {
            $newpartner['logo']=trim($data['logo']);
        }
        if (isset($data['status'])) {
            $newpartner['status']=trim($data['status'])*1;
        }
        if (isset($data['layout'])) {
            $newpartner['layout_id']=trim($data['layout'])*1;
        }
        $newpartner['last_updated']=date('Y-m-d H:i:s');
        $newpartner['last_updated_by']=Admins::getAdminName($data['admin']);
        return DB::table('partners')->insertGetId($newpartner);
    }

    function update($id, $data)
    {
        if (!isset($data['admin'])) {
            return false;
        }
        if (($data['admin']*1)<=0) {
            return false;
        }
        $newpartner=array();
        if (isset($data['partner_name'])) {
            $newpartner['partner_name']=trim($data['partner_name']);
        }
        if (isset($data['partner_title'])) {
            $newpartner['partner_title']=trim($data['partner_title']);
        }
        if (isset($data['partner_id'])) {
            $newpartner['partner_composite_id']=trim($data['partner_id']);
        }
        if (isset($data['logo'])) {
            $newpartner['logo']=trim($data['logo']);
        }
        if (isset($data['status'])) {
            $newpartner['status']=trim($data['status'])*1;
        }
        if (isset($data['layout'])) {
            $newpartner['layout_id']=trim($data['layout'])*1;
        }
        $newpartner['last_updated']=date('Y-m-d H:i:s');
        $newpartner['last_updated_by']=Admins::getAdminName($data['admin']);
        DB::table('partners')->where('id', $id)->update($newpartner);
        return true;
    }

    function get($id)
    {
        $result=DB::table('partners')->where('id', $id)->first();
        return $result;
    }

    function delete($id, $id_admin, $cascade = true)
    {
        if (($id_admin*1)<=0) {
            return false;
        }
        $admin_name=Admins::getAdminName($data['admin']);
        $last_updated=date('Y-m-d H:i:s');
        DB::table('partners')->where('id', $id)->update(['status'=>0,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
        if ($cascade) {
            DB::table('companies')->where('id_partners', $id)->update(['status'=>0,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
            DB::table('properties')->where('id_partners', $id)->update(['status_clients'=>0,'status_pp'=>0,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
            DB::table('accounting_recurring_transactions')->where('trans_status', 1)->whereIn('property_id', function ($query) use ($id) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->where('id_partners', $id);
            })->update(['trans_status'=>5,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
            DB::table('web_users')->where('web_status', '<', 1000)->whereIn('property_id', function ($query) use ($id) {
                $query->from('properties');
                $query->select('id as property_id');
                $query->where('id_partners', $id);
            })->update(['web_status'=>9999,'last_updated'=>$last_updated,'last_updated_by'=>$admin_name]);
            DB::table('profiles')->where('id_partner', $id)->delete();
            DB::table('api_user')->where('id_partner', $id)->delete();
        }
        return true;
    }

    public function cleanString($string)
    {
        $string = strtolower($string);
        $string = str_replace(' ', '', $string);
        $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string);
        return preg_replace('/-+/', '_', $string);
    }
}
