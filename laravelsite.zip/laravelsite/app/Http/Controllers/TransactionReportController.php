<?php

namespace App\Http\Controllers;

use App\Model\AccountingTransactions;
use App\CustomClass\PaymentProcessor;
use App\CustomClass\Email;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class TransactionReportController extends Controller
{

    function __construct()
    {
        $this->middleware('auth');
        $this->middleware('permission')->only('accountingtransactions');
    }

    public function accountingtransactions($token = null, Request $request)
    {
        if (!validateToken($token)) {
            return redirect(route('accessdenied'));
        }

        $accountingtransactions = new AccountingTransactions();

        $filter = \DataFilter::source($accountingtransactions->getAccountingTransactions());

        $filter->attributes(array("id" => "transactionRdatafilter"));
//        $filter->add('accounting_transactions.trans_first_post_date', 'Date', 'daterange')->format('m/d/Y', 'en');
        $filter->add('accounting_transactions.trans_id', 'Transaction Id', 'text');

//        switch (strtoupper($level)) {
//            case 'B':
//                $filter->add('partners.partner_title', 'Partner', 'text');
//                $filter->add('companies.company_name', 'Group', 'text');
//                $filter->add('properties.name_clients', 'Merchant', 'text');
//                break;
//            case 'P':
//                $filter->add('partners.partner_title', 'Partner', 'text');
//                $filter->add('companies.company_name', 'Group', 'text');
//                $filter->add('properties.name_clients', 'Merchant', 'text');
//                break;
//            case 'G':
//                $filter->add('companies.company_name', 'Group', 'text');
//                $filter->add('properties.name_clients', 'Merchant', 'text');
//                break;
//            case 'M':
//                $filter->add('properties.name_clients', 'Merchant', 'text');
//                break;
//        }

        $filter->add('trans_payment_type', 'Pay Method', 'select')->options(array('' => '--Pay Method--', 'cc' => 'Credit Card', 'ec' => 'E-Check'));
        $filter->add('web_users.first_name', 'First Name', 'text')->scope(function ($query, $value) {
            return $query->where('accounting_transactions.trans_card_type', 'like', '%' . $value . '%');
        });
        $filter->add('web_users.last_name', 'Last Name', 'text');
        $filter->add('accounting_transactions.trans_net_amount', 'Amount', 'text');
        $filter->add('accounting_transactions.trans_convenience_fee', 'Fee', 'text');
        $filter->add('accounting_transactions.trans_total_amount', 'Net Charge', 'text');
        $filter->add('source', 'Source', 'select')->options(array('' => '--Source--', 'web' => 'Web', 'qpay' => 'Quick Pay', 'eterm' => 'E-Terminal', 'ivr' => 'IVR', 'api' => 'API', 'lox' => 'Lockbox', 'rdc' => 'RDC', 'HAX' => 'HAX', 'CDO' => 'CDO', 'NACHA' => 'NACHA', 'AUTO' => 'AUTO'));
        $filter->add('accounting_transactions.trans_type', 'Type', 'select')->options(array('' => '--Type--', '0' => 'One Time', '1' => 'AutoPayment', '9' => 'Void', '5' => 'Discover', '2' => 'Saving'));
        $filter->add('accounting_transactions.trans_card_type', 'Pay Type', 'select')->options(array('' => '--Pay Type--', 'Visa' => 'Visa', 'Checking' => 'Checking', 'MasterCard' => 'MasterCard', '10' => 'Refunded'))->scope(function ($query, $value) {
            return $query->where('accounting_transactions.trans_card_type', 'like', '%' . $value . '%');
        });
        $filter->add('accounting_transactions.trans_status', 'Status', 'select')->options(array('' => '--Status--', '0' => 'Errored', '1' => 'Approved', '2' => 'Declined', '3' => 'Returned', '4' => 'Voided'));
        //$filter->add('publication_date','publication date','daterange')->format('m/d/Y', 'en');
        $filter->submit('search', 'BL', array('class' => 'btn btn-md btn-primary'));
        $filter->reset('reset', 'BL', array('class' => 'btn btn-md btn-primary'));
        $filter->build();
        //echo '<pre>';
        //print_r($filter); die;
        $grid = \DataGrid::source($filter);
        //echo '<pre>';
        //print_r($filter); die;
        // die;
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));
        //$grid->attributes(array("class"=>"table"));
        //print_r($grid); die;
//                $grid->add($token, 'token')->style("display:none;");
        //$grid->add('status','Status1')->style("display:none;");

        $grid->add('status', 'Status')->cell(function ($value) {

            if ($value == '0') {
                return '<img src="/images/red_alert.png" alt="Errored" data-original-title="Errored transaction." title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif ($value == '1') {
                return '<img src="/images/check.png" alt="Approved" data-original-title="Approved transaction." title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif ($value == '2') {
                return '<img src="/images/declined.png" alt="Declined" data-original-title="Declined transaction." title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif ($value == '3') {
                return '<img src="/images/returned.png" alt="Returned" data-original-title="Returned transaction." title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif ($value == '4') {
                return '<img src="/images/void.png" alt="Voided" data-original-title="Voided transaction." title="" class="tooltip_hover" data-toggle="tooltip"  />';
            }
        })->attributes(array("class" => "trans-column"));
        $grid->add('trans_date', 'Date', true)->attributes(array("class" => "trans-column"));
        $grid->add('trans_id', 'Trans. Id', true)->attributes(array("class" => "trans-column"));
//        $grid->add('status', 'Status', true)->attributes(array("class" => "trans-column"));
//                    if ($level == 'B') {
        $grid->add('partner', 'Partner', true)->attributes(array("class" => "trans-column"));
        $grid->add('group', 'Group', true)->attributes(array("class" => "trans-column"));
        $grid->add('merchant', 'Property', true)->attributes(array("class" => "trans-column"));
        $grid->add('account_number', 'AN', true)->attributes(array("class" => "trans-column"));
//                    }
//                    if ($level == 'P') {
//                        $grid->add('partner', 'Partner', true)->attributes(array("class" => "trans-column"));
//                        $grid->add('group', 'Group', true)->attributes(array("class" => "trans-column"));
//                        $grid->add('merchant', 'Property', true)->attributes(array("class" => "trans-column"));
//                        $grid->add('account_number', 'AN', true)->attributes(array("class" => "trans-column"));
//                    }
//                    if ($level == 'M') {
//                        $grid->add('address_unit', 'Unit', true)->attributes(array("class" => "trans-column"));
//                    }
        //$grid->add('trans_date','Date');
        $grid->add('web_user_name', 'Name', true)->attributes(array("class" => "trans-column"));
        //$grid->add('last_name','Last Name');
        /* $grid->add('pay_method','Pay Method', true)->cell( function($value){
          if($value == 'ec'){
          return '<img src="/img/echeck.png" alt="E-Check" data-original-title="E-Check" title="" class="tooltip_hover" data-toggle="tooltip"  />';
          }else if($value == 'cc'){
          return '<img src="/img/credit-cards.png" alt="Credit Cards" data-original-title="Credit Cards" title="" class="tooltip_hover" data-toggle="tooltip"  />';
          }else if($value == 'CASH'){
          return '<img src="/img/cash.png" alt="Cash" data-original-title="Cash" title="" class="tooltip_hover" data-toggle="tooltip"  />';
          }else if($value == 'MISC'){
          return '<img src="/img/misc.png" alt="Misc" data-original-title="Miscellaneous" title="" class="tooltip_hover" data-toggle="tooltip"  />';
          }
          }); */
        //$grid->add('pay_type','Pay Type');
        $grid->add('pay_type', 'Pay Type', true)->cell(function ($value) {
            $valueArray = explode(" ", $value);
            if (isset($valueArray[0]) && ($valueArray[0] == 'Visa')) {
                return '<img src="/images/visa.png" alt="Visa" data-original-title="' . $value . '" title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif (isset($valueArray[0]) && (rtrim($valueArray[0], '(') == 'Checking')) {
                return '<img src="/images/echeck.png" alt="Checking" data-original-title="' . $value . '" title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif (isset($valueArray[0]) && ($valueArray[0] == 'MasterCard')) {
                return '<img src="/images/mastercard.png" alt="Master Card" data-original-title="' . $value . '" title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif (isset($valueArray[0]) && ($valueArray[0] == 'Discover')) {
                return '<img src="/images/discover.png" alt="Discover" data-original-title="' . $value . '" title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif (isset($valueArray[0]) && ($valueArray[0] == 'Saving')) {
                return '<img src="/images/saving.png" alt="Saving" data-original-title="' . $value . '" title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif (isset($valueArray[0]) && ($valueArray[0] == 'Swipe')) {
                return '<img src="/images/swipe.png" alt="Saving" data-original-title="' . $value . '" title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } else {
                return $value;
            }
        })->attributes(array("class" => "trans-column"));

        $grid->add('net_amount', 'Amount', true)->attributes(array("class" => "trans-column"));
        $grid->add('net_fee', 'Fee', true)->attributes(array("class" => "trans-column"));
        $grid->add('net_charge', 'Net Charge', true)->attributes(array("class" => "trans-column"));
        $grid->add('stype', 'Type')->cell(function ($value) {
            if ($value == '0') {
                return 'One Time';
            } elseif ($value == '1') {
                return 'Auto Payment';
            } elseif ($value == '9') {
                return 'Void';
            } elseif ($value == '10') {
                return 'Refunded';
            }
        })->attributes(array("class" => "trans-column"));
        $grid->add('trans_source', 'Source')->attributes(array("class" => "trans-column"));
        //$grid->add('auth_code','Auth Code');
        $grid->add('actionvalue', 'Action');
        $grid->row(function ($row) {
            $id = $row->cell('trans_id')->value;
            $token = $row->cells[0]->value;
            $status = $row->cell('status')->value;
            $statusArray = explode(" ", $status);
            $statusValueArray[1] = "";
            if (isset($statusArray[2])) {
                $statusValueArray = explode("=", $statusArray[2]);
            }


            $view_link = '';
//            foreach (Session::get('user_permissions') as $p) {
//                if ($p['route'] == 'viewtransaction') {
            $view_link = '<li><a href="#" onclick="showTransdetail(\'' . $id . '\');" >View</a></li>';
//                    break;
//                }
//            }

            $void_link = '';
//            foreach (Session::get('user_permissions') as $p) {
//                if ($p['route'] == 'void') {
            $void_link = '<li><a href="#" onclick="voidpr(\'' . $id . '\')" >Void</a></li>';
//                    break;
//                }
//            }

            $email_link = '';
//            foreach (Session::get('user_permissions') as $p) {
//                if ($p['route'] == 'emailreceipt') {
            $email_link = '<li><a href="#" onclick="sendpr(\'' . $id . '\')" >Email Receipt</a></li>';
//                    break;
//                }
//            }

            if (trim($statusValueArray[1], '"') == "Approved") {
                $row->cell('actionvalue')->value = ' <div class="dropdown">
													  <button class="btn btn-xs btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><span style="color:#fff">Actions</span>
													  <span class="caret white-font-color"></span></button>
													  <ul class="dropdown-menu">
														' . $view_link . '
														' . $void_link . '
														' . $email_link . '
													  </ul>
													</div>';
            } else {
                $row->cell('actionvalue')->value = '<div class="dropdown">
												  <button class="btn btn-xs btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><span style="color:#fff">Actions</span>
												  <span class="caret white-font-color"></span></button>
												  <ul class="dropdown-menu">
													' . $view_link . '
												  </ul>
												</div>';
            }
            // $row->cell('trans_id')->style("display:none;");
            // $row->cell('status')->style("display:none;");
//            $row->cells[0]->style("display:none;");
            //$row->cells[1]->style("display:none;");
        });
        //style data grid
        //$grid->edit('/transactionReport/'.$token.'/edit', 'Action','show', 'trans_id');
//        $grid->link('/transactionReport/report', 'Export', "TR", array('id' => 'exportCSV', 'class' => 'btn btn-md btn-success'));
        $grid->orderBy('trans_date', 'desc');
        $recordperpage = 10;
        $ord = 'trans_date';
        $page = 1;
        if ($request->get("ord") != null) {
            $ord = $request->get("ord");
        }
        if ($request->get("page") != null) {
            $page = $request->get("page");
        }
        if ($request->get("recordperpage") != null) {
            $grid->paginate($request->get("recordperpage"));
            $recordperpage = $request->get("recordperpage");
        } else {
            $grid->paginate(10);
        }

        $sql = $filter->query->toSql();

        $pagetitle = 'Transaction Report';
        $grid->getGrid('rapyd::datagrid');
        return view('dashboard.transaction', array('sql' => $sql, 'pageTitle' => 'Transaction Report', 'filter' => $filter, 'grid' => $grid, 'recordperpage' => $recordperpage, 'page' => $page, 'ord' => $ord, 'token' => $token));
    }

    public function transdetail($trans_id, Request $request)
    {
#ajax
// dashboard/toekn
        // tranRport/details/id?toekn=ajsdhasjk
        //security
//       $objAdminAuth = new AuthAdminController();
//        $objAdminAuth->checkAuthPermissions($array_token['iduser']);
        $accountingtransactions = new AccountingTransactions();
        $accutransactiondetail = $accountingtransactions->getTransactionDetail($trans_id);

        $accountingdetailHtml = view('dashboard.accountingtransactiondetail', array('pageTitle' => 'Transaction Detail', 'accutransactiondetail' => $accutransactiondetail))->render();
        return response()->json(array('errcode' => 0, 'msg' => $accountingdetailHtml));
    }

    public function voidtransaction(Request $request, $id, $sts)
    {
        //security
//        $objAdminAuth = new AuthAdminController();
//        $objAdminAuth->checkAuthPermissions(Session::get('user_logged')['id']);

        $paymentprocessor = new PaymentProcessor();
        if ($sts == 1) {
            $result = $paymentprocessor->runVoidTransaction($id);
        }
        echo json_encode($result);
        die;
    }

    public function createReceiptMessageUndo($property_id, $trans_id, $status, $update = false)
    {

        $accountingtransactions = new AccountingTransactions();
        $transactiondetail = $accountingtransactions->getTransactionDetailWithPartner($trans_id);
        $user_info = $accountingtransactions->getWebUserDetail($transactiondetail[0]->trans_web_user_id);
        $message = "";
        $disclaimer = "";
        $subject = "Payment Transaction was Voided or Refunded";
        $properties = new \App\Model\Properties();
        $org_url = $properties->getPropertyUrlById($property_id);
        $org_name = $properties->getPropertyNameById($property_id);
        $adminemail = '';
        $message = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
				<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
				<head>
				<style> td {font-family: arial,helvetica,sans-serif; font-size: 10pt; color: #000;} </style>
				</head>
				<body><table border=\"0\" cellpadding=\"1\" cellspacing=\"2\" width=\"90%\">
					<tr>
						<td><img src=\"" . public_path() . $org_url[0]->url_clients . "/media/images/logo.jpg\" alt=\"Revo Payments\" title=\"Revo Payments\"/></td>
						<td><h3>" . $subject . "</h3></td>
					</tr>
					<tr><td colspan=\"2\"><br />For customer service please <a href=\"" . public_path() . $org_url[0]->url_clients . "/newhelp.php\">contact us</a><br /></td></tr>
					<tr><td bgcolor=\"#C4C7D4\" colspan=\"2\"><b>Transaction Result</b></td></tr>
					<tr><td><b>Date:</b></td><td>" . date('Y-m-d H:i:s') . "</td></tr>
					<tr><td><b>Reference #:</b></td><td>" . $trans_id . "</td></tr>
					<tr><td bgcolor=\"#C4C7D4\" colspan=\"2\"><b>Transaction Details</b></td></tr>
					<tr><td><b>Paid in:</b></td><td>" . $org_name[0]->name_clients . "</td></tr>
					<tr><td><b>Type:</b></td><td>" . $status . "</td></tr>
					<tr><td><b>Source:</b></td><td>WEB</td></tr>
					<tr><td><b>Account #:</b></td><td>" . $user_info[0]->account_number . "/" . $user_info[0]->first_name . " " . $user_info[0]->last_name . "</td></tr>
					<tr><td><b>Net Payment:</b></td><td>" . number_format($transactiondetail[0]->trans_net_amount, 2, ".", ",") . "</td></tr>
					<tr><td><b>Convenience Fee:</b></td><td>" . number_format($transactiondetail[0]->trans_convenience_fee, 2, ".", ",") . "</td></tr>
					<tr><td><b>Total Payment Amount:</b></td><td>" . number_format($transactiondetail[0]->trans_total_amount, 2, ".", ",") . "</td></tr>
					<tr><td valign=\"top\"><b>Payment Details:</b></td><td><pre>" . $transactiondetail[0]->trans_descr . "</pre></td></tr>";
        if ($transactiondetail[0]->trans_payment_type == 'ec') {
            $message .= "<tr><td><b>Account Type:</b></td><td>" . $transactiondetail[0]->trans_card_type . "</td></tr>";
        } else {
            $message .= "<tr><td><b>Card Number:</b></td><td>" . $transactiondetail[0]->trans_card_type . "</td></tr>";
        }

        $message .= "<tr><td colspan=\"2\">" . $disclaimer . "</td></tr>
						<tr><td colspan=\"2\"><p>" . $org_name[0]->name_clients . "</p></td></tr>
						</table>
						</body>
						</html>";
        $propertyemail = $properties->getPropertyEmailById($property_id);
        if (!empty($propertyemail)) {
            $tmpemail = explode(";", $propertyemail[0]->accounting_email_address_clients);
            $adminemail = trim($tmpemail[0]);
            if ($adminemail == "") {
                $adminemail = "info@revopayments.com";
            }
        } else {
            $adminemail = "info@revopayments.com"; //end else
        }
        if (!empty($user_info[0]->email_address)) {
            if (strpos($user_info[0]->email_address, 'yahoo') > 0 && strpos($adminemail, 'yahoo') > 0) {
                $adminemail = 'info@revopayments.com';
            }
            if (strpos($user_info[0]->email_address, 'aol.com') > 0 && strpos($adminemail, 'aol.com') > 0) {
                $adminemail = 'info@revopayments.com';
            }
            //$eml=new Easy_Email($user_info[0]['email_address'],$adminemail);
            //$eml->sendEmail($subject,$message);
            //sending mail
            $info['from'] = $adminemail;
            $info['to'] = $user_info[0]->email_address;
            //$info['to'] = 'pankaj.pandey.jec@gmail.com';
            $info['subject'] = $subject;
            $receiptcontentarray = array('receiptcontent' => $message);
            Mail::send('mail.receipttransactionemail', $receiptcontentarray, function ($messageinfo) use ($info) {
                $messageinfo->from($info['from']);
                $messageinfo->to($info['to'])->subject($info['subject']);
            });

            $accountingtransactions->saveReceipt($property_id, $user_info[0]->web_user_id, $trans_id, $message, $adminemail, $user_info[0]->email_address, $update);
        }// end if statement
        $propertyemail = $properties->getPropertyEmailById($property_id);
        $notificationsystem = new NotificationSystem();
        if (!empty($propertyemail)) {
            $tmpemail = explode(";", $propertyemail[0]->accounting_email_address_clients);
            foreach ($tmpemail as $pemail) {
                $spemail = $pemail;
                if ($spemail != "") {
                    if (strpos($spemail, 'yahoo') > 0) {
                        $spemail = 'info@revopayments.com';
                    }
                    if (strpos($spemail, 'aol.com') > 0) {
                        $spemail = 'info@revopayments.com';
                    }
                    //$receipt_sender = new Easy_Email($pemail, $spemail);
                    $info['from'] = $spemail;
                    $info['to'] = $tmpemail;
                    //$info['to'] = 'pankaj.pandey.jec@gmail.com';
                    $info['subject'] = $subject;
                    $receiptcontentarray = array('receiptcontent' => $message);
                    Mail::send('mail.receipttransactionemail', $receiptcontentarray, function ($messageinfo) use ($info) {
                        $messageinfo->from($info['from']);
                        $messageinfo->to($info['to'])->subject($info['subject']);
                    });
                    //if($isMailSend === false){
                    $notificationsystem->saveNotificationSystem("error", "Error sending email", "ID_PROPERTY: " . $property_id . "   DESTINATION: " . $pemail . "  FROM: " . $spemail, "Transactions");
                    //}
                } else {
                    $notificationsystem->saveNotificationSystem("error", "Missing account email address", "ID_PROPERTY: " . $property_id, "Transactions");
                }
            }
        }// end if statements
    }

    public function emailreceipt(Request $request)
    {

        //security
//        $objAdminAuth = new AuthAdminController();
//        $objAdminAuth->checkAuthPermissions(Session::get('user_logged')['id']);
        //echo $request->get("id").' == '.$request->get("eml");
        $email = new Email();
        $result = $email->transactionreceipt($request->get("id"), $request->get("eml"));
        echo json_encode($result);
        die;
    }
}
