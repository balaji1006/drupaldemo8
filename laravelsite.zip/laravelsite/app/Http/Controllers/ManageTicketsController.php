<?php
namespace App\Http\Controllers;

use App\Model\Tickets;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;

class ManageTicketsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function tickets($token, Request $request){

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $catdb = new Tickets();
        $filter = \DataFilter::source($catdb->getTickets($idlevel,$level));

        switch (strtolower($level)){
            case 'b':
            case 'a':    
                $filter->add('partners.partner_title','Partner','text');
                $filter->add('companies.company_name','Group','text');
                $filter->add('properties.name_clients','Merchant','text');
                break;
            case 'p':
                $filter->add('companies.company_name','Group','text');
                $filter->add('properties.name_clients','Merchant','text');
                break;
            case 'g':
                $filter->add('properties.name_clients','Merchant','text');
                break;
        }

        $filter->add('ticket_name','Name','text')->scope(
            function ($query, $value){
                return $query->where('ticket_name', 'like', '%' . $value . '%');
            }
        );
        $filter->add('ticket_email','Email','text')->scope(
            function ($query, $value){
                return $query->where('ticket_email', 'like', '%' . $value . '%');
            }
        );
        $filter->add('ticket_phone','Phone','number')->scope(
            function ($query, $value){
                return $query->where('ticket_phone', 'like', '%' . $value . '%');
            }
        );
        $filter->add('ticket_date_submitted','Date','date')->format('m/d/Y')->scope(
            function ($query, $value){
                return $query->where('ticket_date_submitted', 'like', '%' . $value . '%');
            }
        );
        $filter->add('ticket_type','Type','select')->options(array(
            '' => 'Type',
            '1' => 'Registration issue',
            '2' => 'Log in issue',
            '3' => 'One time payment issue',
            '4' => 'Auto pay issue',
            '5' => 'Question about already made payment',
            '6' => 'Balance due question',
            '101' => 'Increase payment limits',
            '100' => 'Bank account change',
            '99' => 'Cancel Merchant Account',
            '-1' => 'Other'
        ))->scope(
            function ($query, $value){

                if($value == '-1')
                return $query->whereNotIn('ticket_type', ["1","2","3","4","5","6","101","100","99"]);
                elseif($value != '' || $value != null){
                    return $query->whereIn('ticket_type', [$value]);
                }
                else{
                    return $query;
                }
            }
        );

        $filter->add('ticket_status','Status', 'select')->options(array(
            2 => 'Open',
            1 => 'Closed',
            0 => 'New'
        ));
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();	

        $grid = \DataGrid::source($filter);		
        $grid->attributes(array("class"=>"table table-striped table-hover"));
        $grid->add($token, $token)->style("display:none;");
        $grid->add('ticket_id', 'Ticketid')->style("display:none;");
        $grid->add('ticket_user_id', 'uid')->style("display:none;");
        $grid->add('id', 'merchantid')->style("display:none;");
        $grid->add('ticket_date_submitted','Date',true)->cell(function ($value){
            return date('m/d/Y, g:i a',strtotime($value));
        });
        switch (strtolower($level)){
            case 'b':
            case 'a':    
                $grid->add('partner_title','Partner', true);
                $grid->add('company_name','Group', true);
                $grid->add('name_clients','Merchant', true);
                $grid->row(function ($row) use ($level, $idlevel, $token) {
                    $id = $row->cell('id')->value;
                    $merchant = $row->cell('name_clients')->value;
                    $token_m = \Illuminate\Support\Facades\Crypt::encrypt(['level' => "M", 'level_id' => $id]);
                    $row->cell('name_clients')->value = ' <a href="#" onclick="openg(\''.$token_m.'\');" >'.$merchant.'</a></li>';

                    $row->cell('id')->style("display:none;");
            });
                break;
            case 'p':
                $grid->add('company_name','Group', true);
                $grid->add('name_clients','Merchant', true);
                $grid->row(function ($row) use ($level, $idlevel, $token) {
                    $id = $row->cell('id')->value;
                    $merchant = $row->cell('name_clients')->value;
                    $token_m = \Illuminate\Support\Facades\Crypt::encrypt(['level' => "M", 'level_id' => $id]);
                    $row->cell('name_clients')->value = ' <a href="#" onclick="openg(\''.$token_m.'\');" >'.$merchant.'</a></li>';

                    $row->cell('id')->style("display:none;");
                });
                break; 
            case 'g':
                $grid->add('name_clients','Merchant', true);
                $grid->row(function ($row) use ($level, $idlevel, $token) {
                    $id = $row->cell('id')->value;
                    $merchant = $row->cell('name_clients')->value;
                    $token_m = \Illuminate\Support\Facades\Crypt::encrypt(['level' => "M", 'level_id' => $id]);
                    $row->cell('name_clients')->value = ' <a href="#" onclick="openg(\''.$token_m.'\');" >'.$merchant.'</a></li>';

                    $row->cell('id')->style("display:none;");
                });
                break;
        }
        $grid->add('ticket_name','Name',true);
        $grid->add('ticket_email','Email');
        $grid->add('ticket_phone','Phone');
        
        $grid->add('ticket_type','Type',  true)->cell(function($value){
            switch ($value){
                case 1:
                    return "Registration issue";
                    break;
                case 2:
                    return "Log in issue";
                    break;
                case 3:
                    return "One time payment issue";
                    break;
                case 4:
                    return "Auto pay issue";
                    break;
                case 5:
                    return "Question about already made payment";
                    break;
                case 6:
                    return "Balance due question";
                    break;
                case 101:
                    return "Increase payment limits";
                    break;
                case 100:
                    return "Bank account change";
                    break;
                case 99:
                    return "Cancel Merchant Account";
                    break;
                default:
                    return "Other";
                    break;
            }
        });
        $grid->add('ticket_user_type','Request by', true)->cell(function ($value){
            if($value==0){
                    return "User";
            }
            else {
                    return "Admin";
            }
        });
        $grid->add('ticket_status','Status',  true);
	$grid->add('actionvalue', 'Action')->style('text-align:right;');

        $grid->row(
                function ($row) {
            $id = $row->cell('ticket_id')->value;
            $token = $row->cells[0]->name;
            $idu = $row->cell('ticket_user_id')->value;
            $usr=$row->cell('ticket_name')->value;
            
            $view_link = '<li><a data-toggle="modal" data-target="#myModal" data-url-reply="'.route('ticketreply', array('$token'=>$token, 'id'=>$id)).'" data-url="' . route('ticketdetails', array('token' => $token, 'id' => $id)) . '" >Details</a></li>';
            $reply_link = '<li><a href="'.route('ticketreply', ['token'=>$token,'id'=>$id]).'" target="_blank_">Reply</a></li>';
            $close_link = '<li><a onclick="closeticket(' . $id . ')" >Close</a></li>';
            $teml=$row->cell('ticket_email')->value;
            if(trim($teml)=='' || $idu==0)$reply_link='';
            else {
                $row->cell('ticket_name')->value='<a class="text-bold" href="'.route('edituser',['token'=>$token,'id'=>$idu]).'" >'.$usr.'</a>';
            }
             $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret white-font-color" ></span></button>
								<ul class="dropdown-menu">
							' . $view_link . '
							' . $reply_link . '
							' . $close_link . '
														  </ul>
	 													</div>';
           
           
            $sts=$row->cell('ticket_status')->value; 
            
            
            if($sts == '0'){$row->cell('ticket_status')->value = '<span class = "label label-warning pull-left"> New </span>';}
            else if ($sts == '1'){$row->cell('ticket_status')->value = '<span class = "label label-success pull-left"> Closed </span>';$row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret white-font-color" ></span></button>
								<ul class="dropdown-menu">
							' . $view_link . '
							' . $reply_link . '
							
														  </ul>
	 													</div>'; }
            else if ($sts == '2'){$row->cell('ticket_status')->value = '<span class = "label label-warning2 pull-left"> Open </span>';}
            
            //if($sts!='closed'){
                
                 //$close_link = '<li><a href="/ticketclose/' . $token . '/' . $id . '" >Close</a></li>';
           // }
            //else $edit_link='';
            
            
            
             
             //->cell(function($value){
           
        //})
            
            
            
            $row->cell('ticket_id')->style("display:none;");
            $row->cell('ticket_user_id')->style("display:none;");
            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
                }
                );
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('ticket_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));
        return view('reports.tickets', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    
    }

    function ticketdetails($token,$id,Request $request){
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $catdb=new Tickets();
        $ticket=$catdb->getTicketByID($id);
        $ticketdetailhtml = view('reports.ticketdetails', array('ticket' => $ticket, 'token' => $token))->render();
        return response($ticketdetailhtml);
    }
    
    function ticketclose($token,$id,Request $request){
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $catdb=new Tickets();
        $iduser=Auth::id();
        $catdb->closeTicket($id, $iduser);

        return redirect()->route('tickets',['token'=>$token])->with('success', 'Ticket closed successfully.');;
    }
    
    function ticketreply($token,$id,Request $request){
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $catdb=new Tickets();
        $ticket=$catdb->getTicketByID($id);
        return redirect()->to('mailto:'.$ticket->ticket_email.'?subject=Reply%20to%20Ticket&body='.$this->fullescape($ticket->ticket_notes));
    }
    
    function fullescape($in) 
    { 
      $out = ''; 
      for ($i=0;$i<strlen($in);$i++) 
      { 
        $hex = dechex(ord($in[$i])); 
        if ($hex=='') 
           $out = $out.urlencode($in[$i]); 
        else 
           $out = $out .'%'.((strlen($hex)==1) ? ('0'.strtoupper($hex)):(strtoupper($hex))); 
      } 
      $out = str_replace('+','%20',$out); 
      $out = str_replace('_','%5F',$out); 
      $out = str_replace('.','%2E',$out); 
      $out = str_replace('-','%2D',$out); 
      return $out; 
} 
    
}
