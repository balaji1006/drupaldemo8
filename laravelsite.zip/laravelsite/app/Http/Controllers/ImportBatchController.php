<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Mail;

class ImportBatchController extends Controller
{

    function __construct() {
        $this->middleware('auth');
    }

    function importBatch($token,Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level=='A' || $level=='B'){
            return redirect(route('accessdenied'));
        }
        $objbatch=new \App\Model\ImportBatchFile();
        return view('importbatch.importbatch',['token'=>$token]);
    }
    
    function processBatch($token,Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        
        $post = $request->all();
        $inputMode = $post['inputMode'];
        $fileMode = $post['fileMode'];
        $fileType = $post['fileType'];
        $inputFq = $post['inputFq'];
        $inputSd = $post['inputSd'];
        $inputSy = $post['inputSy'];
        $inputSm = $post['inputSm'];
        $inputDynamic='';
        if(isset($post['inputDynamic'])){
            $inputDynamic= $post['inputDynamic'];
        }
        $file = $request->file('file');
        $newname='SBF7_'.md5($level.$idlevel.$file->getClientOriginalName()).time();
        $file->move('/var/tmp/batch',$newname);
        $objbatch=new \App\Model\ImportBatchFile();
        $data=array();
        $data['tmp_file']='/var/tmp/batch/'.$newname;
        $data['real_file']=$file->getClientOriginalName();
        $data['level']=$level;
        $data['idlevel']=$idlevel;
        $data['data']=json_encode(array('type'=>$fileType,'mode'=>$fileMode,'fq'=>$inputFq,'sd'=>$inputSd,'sm'=>$inputSm,'sy'=>$inputSy,'dynamic'=>$inputDynamic));
        switch ($inputMode){
            case 'loadpayments':
                $data['oper']='L';
                break;
            case 'updatepayments':
                $data['oper']='U';
                break;
            case 'loadevendorpayments':
                break;
        }
        $data['created_at']=date('Y-m-d H:i:s');
        $tid=$objbatch->createBatchTask($data);
        exec('php /var/scripts/batchconsume.php '.base64_encode($tid).' > /dev/null &');
        return redirect()->route('importbatchback',['token'=>$token]);
    }
    
    function importbatchback($token,Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level=='A' || $level=='B'){
            return redirect(route('accessdenied'));
        }
        $objbatch=new \App\Model\ImportBatchFile();
        $filter = \DataFilter::source($objbatch->getBackList($level,$idlevel));
        $filter->add('real_file','File','text');
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();
        $grid = \DataGrid::source($filter);	
        $grid->add($token, $token)->style("display:none;");
        $grid->add('idimport_batch_file', 'id')->style("display:none;");
        $grid->add('created_at','Uploaded on',true);
        $grid->add('real_file','File');
        $grid->add('oper','Op',true);
        $grid->add('records','Lines',true);
        $grid->add('completed','Processed',true);
        $grid->add('errors','Errors',true);
        $grid->add('updated_at','Last Update',  true);
        $grid->add('status','Status',true)->style("text-align:right;");
        $grid->row(
                function ($row) {
            $id = $row->cell('idimport_batch_file')->value;
            $token = $row->cells[0]->name;
            $sts=$row->cell('status')->value;
            switch ($sts) {
                case 0:
                    $sts= '<span class="label label-default">to Consume</span>';
                    break;
                case 1:
                    $ds= DB::table('importbatch_summary')->where('id_batch_file',$id)->count();
                    if($ds>0){
                        $sts='<a href="'.route('viewimportbatch',['token'=>$token,'id'=>$id]).'" class="label-info">Consuming...</a>';
                    }
                    else {
                        $sts= '<span class="label label-info">Consuming...</span>';
                    }
                    break;
                case 90:
                    $ds= DB::table('importbatch_summary')->where('id_batch_file',$id)->count();
                    if($ds>0){
                        $sts='<a href="'.route('viewimportbatch',['token'=>$token,'id'=>$id]).'" class="label-success">Completed</a>';
                    }
                    else {
                        $sts= '<span class="label label-success">Completed</span>';
                    }
                    break;
                case 99:
                    $sts= '<span class="label label-warning">Empty File</span>';
                    break;
                case 100:
                    $sts= '<span class="label label-danger">Missing data</span>';
                    break;
                case 101:
                    $sts= '<span class="label label-danger">Invalid Type</span>';
                    break;
                case 102:
                    $sts= '<span class="label label-danger">Invalid Operation</span>';
                    break;
            }
            $row->cell('status')->value=$sts;
            $row->cell('status')->style("text-align:right;");
            $oper=$row->cell('oper')->value;
            if($oper=='L'){
                $row->cell('oper')->value='Load';
            }
            elseif($oper=='U'){
                $row->cell('oper')->value='Update';
            }
            $row->cell('idimport_batch_file')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('idimport_batch_file', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('importbatch.importbatchback', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }
    
    function viewimportbatch($token,$id,Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level=='A' || $level=='B'){
            return redirect(route('accessdenied'));
        }
        $objbatch=new \App\Model\ImportBatchFile();
        $filter = \DataFilter::source($objbatch->getBackSummaryList($id));
        $filter->add('error','Message','text');
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();
        $grid = \DataGrid::source($filter);
        $grid->add('line','Line',true);
        $grid->add('error','Message');
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('line', 'ASC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('importbatch.importbatchsummary', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }
}
