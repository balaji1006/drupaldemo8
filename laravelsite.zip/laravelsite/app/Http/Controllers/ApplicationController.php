<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\CustomClass\mbf;
use App\Model\Application;
use App\Model\Companies;
use App\Model\Partners;
use App\Model\Properties;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

class ApplicationController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    public function adminAppList($token, Request $request) {

        Session::forget('openapp');
        $array_token = decrypt($token);

        $idlevel = $array_token['level_id'];
        $type = $array_token['level'];

        if ($type == 'M') {
            return redirect(route('accessdenied'));
        }
        $atoken = encrypt(['level_id' => $idlevel, 'level' => $type]);

        $application = new Application();
        $applications = $application->getApplications($type, [$idlevel]);
        $obj_layout = new \App\Model\Layout();
        $layout_labels = $obj_layout->getLayoutValues($idlevel, $type);

        $filter = \DataFilter::source($applications);
        switch ($type) {
            case 'A':
            case 'B':
                $filter->add('partners.partner_title', $obj_layout->extractLayoutValue('label_partner', $layout_labels), 'text');
                $filter->add('companies.company_name', $obj_layout->extractLayoutValue('label_group', $layout_labels), 'text');
                break;
            case 'P':
                $filter->add('companies.company_name', $obj_layout->extractLayoutValue('label_group', $layout_labels), 'text');
                break;
        }
        $filter->add('name_clients', $obj_layout->extractLayoutValue('label_merchant', $layout_labels), 'text');
        $filter->add('application.status', 'Status', 'select')->options(array(
            '0' => 'Status',
            '-2' => 'Canceled',
            '1' => 'Live',
            '2' => 'Incomplete',
            '3' => 'Unknown',
            '4' => 'Pending',
            '5' => 'Underwriting',
            '6' => 'Approved'
        ))->scope(function ($query, $value) {
            if ($value == '0') {
                return $query;
            } else {
                return $query->where('application.status', '=', $value);
            }
        });
        $filter->add('application.datenew', 'Submited on', 'text');
        $filter->submit('Search');
        $filter->reset('Reset');
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));
        $grid->add('id', 'ID')->style("display:none;");
        $grid->add('content', 'content')->style("display:none;");
        $grid->add('partner_name', 'partner_name')->style("display:none;");
        $grid->add('partner_title', $obj_layout->extractLayoutValue('label_partner', $layout_labels), true);
        $grid->add('company_name', $obj_layout->extractLayoutValue('label_group', $layout_labels), true);
        $grid->add('name_clients', $obj_layout->extractLayoutValue('label_merchant', $layout_labels), true);
        $grid->add('status', 'Status')->cell(function ($value) {

            $status = $value;
            $string = '';
            switch ($value) {
                case -2:
                    $string = '<span class = "label label-danger pull-left">Canceled</span>';
                    break;
                case -1:
                    $string = '<span class = "label label-danger pull-left">Deleted</span>';
                    break;
                case 1:
                    $string = '<span class = "label label-success pull-left">Live</span>';
                    break;
                case 2:
                    $string = '<span class = "label label-warning pull-left">Incomplete</span>';
                    break;
                case 3:
                    $string = '<span class = "label label-primary pull-left">Unknown</span>';
                    break;
                case 4:
                    $string = '<span class = "label label-danger pull-left">Pending</span>';
                    break;
                case 5:
                    $string = '<span class = "label label-info pull-left">Underwriting</span>';
                    break;
                case 6:
                    $string = '<span class = "label label-success pull-left">Approved</span>';
                    break;
            }
            return $string;
        });
        $grid->add('datenew', 'Submitted on', true);

        $grid->add('status_pp', 'Payment page')->cell(function ($value) {
            if ($value == 1) {
                return 'Yes';
            } else {
                return 'No';
            }
        });
        $grid->add('envelope', 'Contracts');
        $grid->add('actionvalue', 'Action')->style('text-align:right;');
        

        $grid->row(function ($row) use ($atoken) {
            $id = $row->cell('id')->value;
            $li_email = '<li><a href = "#" onclick = "showMailPopup(\'' . $id . '\');">Email</a></li>';
            $li_email = '';
            $li_sendmbf = '<li><a href = "#" onclick = "sendMBFApp(\'' . $id . '\');">Send MBF</a></li>';

            $application = new Application();
            $active_extoapp = $application->getEXTOAPPsetting($row->cell('partner_name')->value);

            if ($row->cell('status')->value != '<span class = "label label-warning pull-left">Incomplete</span>') {
                $li_email = '';
            } else {
                if ($active_extoapp != 1) {
                    $li_email = '';
                }
            }


            $nm = trim($row->cell('name_clients')->value);
            if ($nm == '') {
                $appdb_aux = (array) $app_db = DB::table('application')->where('id', $id)->first();

                $dapp = json_decode(base64_decode($appdb_aux['content']), 1);
                if (isset($dapp['dba'])) {
                    $row->cell('name_clients')->value = trim($dapp['dba']);
                }
            }


            if ($row->cell('status')->value == '<span class = "label label-primary pull-left">Unknown</span>' ||
                    $row->cell('status')->value == '<span class = "label label-warning pull-left">Incomplete</span>' ||
                    $row->cell('status')->value == '<span class = "label label-danger pull-left">Deleted</span>' ||
                    $row->cell('status')->value == '<span class = "label label-danger pull-left">Canceled</span>'
            ) {
                $li_sendmbf = '';
            }


            //<li><a href="#" onclick="exportApp(\''.$id.'\');" >Export</a></li>

            $row->cell('actionvalue')->value = ' <div class = "dropdown pull-right">
                    <button class = "btn btn-xs btn-default dropdown-toggle" type = "button" data-toggle = "dropdown"><span>Actions</span>
                    <span class = "caret"></span></button>
                    <ul class = "dropdown-menu">
                    <li><a href = "#" onclick = "openApp(\'' . $id . '\');">Open</a></li>

                    ' . $li_email . '
                    <li><a href = "#" onclick = "deleteApp(\'' . $id . '\');">Delete</a></li>
                    ' . $li_sendmbf . '
                    </ul>
                    </div>';
            $row->cell('id')->style("display:none;");
            $row->cell('content')->style("display:none;");
            $row->cell('partner_name')->style("display:none;");
            if ($row->cell('company_name')->value == 'company_name') {
                $row->cell('company_name')->value(' ');
            }
            if ($row->cell('envelope')->value && $row->cell('envelope')->value != 'envelope') {
                $row->cell('envelope')->value('<a href = "' . route('applicationadmincontracts', ['token' => $atoken, 'id_app' => $id]) . '">Views</a>');
            } else {
                $row->cell('envelope')->value('-');
            }
        });

        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $grid->orderBy('application.id', 'desc');
        $grid->paginate($itemsPerPage);
        return view('application.adminList', array('filter' => $filter, 'grid' => $grid, 'token' => $token, 'itemspage' => $itemsPerPage, 'sqlEncrypted' => $sql_ready));
    }

    public function adminContracts($token, $id_app) {


//            list($data) = explode('|', Crypt::decrypt($token));
//            $array_token = json_decode($data, 1);
        $array_token = decrypt($token);

//        $atoken = encrypt($array_token . '|' . time() . '|' . config('app.appAPIkey'));
        $atoken = encrypt($array_token);
        $docusign_conf = config('docusign.credentials');
        $email = $docusign_conf['email'];
        $password = $docusign_conf['password'];
        $integratorKey = $docusign_conf['integrator_key'];
        $enviroment = $docusign_conf['environment'];

        $app_db = DB::table('application')->where('id', $id_app)->first();
        $array_envelope = explode(';', $app_db->envelope);
        $array_envelope_status = array();
        $array_envelope_documents = array();

        foreach ($array_envelope as $envelope) {
            if ($envelope) {
                $envelopeId = $envelope;
                $header = "<DocuSignCredentials><Username>" . $email . "</Username><Password>" . $password . "</Password><IntegratorKey>" . $integratorKey . "</IntegratorKey></DocuSignCredentials>";
                $url = "https://" . $enviroment . ".docusign.net/restapi/v2/login_information";
                $curl = curl_init($url);
                curl_setopt($curl, CURLOPT_HEADER, false);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_HTTPHEADER, array("X-DocuSign-Authentication: $header"));
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                $json_response = curl_exec($curl);
                $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                if ($status != 200) {
                    echo "error calling webservice, status is:" . $status;
                    exit(-1);
                }


                $response = json_decode($json_response, true);

                $accountId = $response["loginAccounts"][0]["accountId"];
                $baseUrl = $response["loginAccounts"][0]["baseUrl"];
                curl_close($curl);

                //get envelopes
                $curl = curl_init($baseUrl . "/envelopes/" . $envelopeId);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                    "X-DocuSign-Authentication: $header"));
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                $json_response = curl_exec($curl);
                $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                if ($status != 200) {
                    echo "error calling webservice, status is:" . $status;
                    exit(-1);
                }
                $response = json_decode($json_response, true);
                $array_envelope_status[$envelopeId] = $response['status'];
                curl_close($curl);


                //get douments
                $curl = curl_init($baseUrl . "/envelopes/" . $envelopeId . "/documents");
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                    "X-DocuSign-Authentication: $header"));
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                $json_response = curl_exec($curl);
                $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                if ($status != 200) {
                    echo "error calling webservice, status is:" . $status;
                    exit(-1);
                }
                $response = json_decode($json_response, true);
                $array_envelope_documents[$envelopeId] = $response['envelopeDocuments'];

                curl_close($curl);
            }
        }
        return view('application.adminListDocs', array(
            'token' => $atoken,
            'env_status' => $array_envelope_status,
            'env_documents' => $array_envelope_documents,
            'envelopes' => $array_envelope,
            'pageTitle' => 'Contracts',
            'token' => $atoken
        ));
    }

    public function downloadDocumentDS($docUri, $name) {
        $docUri = base64_decode($docUri);
        $docusign_conf = Config('docusign.credentials');
        $email = $docusign_conf['email'];
        $password = $docusign_conf['password'];
        $integratorKey = $docusign_conf['integrator_key'];
        $enviroment = $docusign_conf['environment'];

        $header = "<DocuSignCredentials><Username>" . $email . "</Username><Password>" . $password . "</Password><IntegratorKey>" . $integratorKey . "</IntegratorKey></DocuSignCredentials>";
        $url = "https://" . $enviroment . ".docusign.net/restapi/v2/login_information";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array("X-DocuSign-Authentication: $header"));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $json_response = curl_exec($curl);
        $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if ($status != 200) {
            echo "error calling webservice, status is:" . $status;
            exit(-1);
        }
        $response = json_decode($json_response, true);
        $baseUrl = $response["loginAccounts"][0]["baseUrl"];

        $curl = curl_init($baseUrl . $docUri);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_BINARYTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            "X-DocuSign-Authentication: $header"));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $data = curl_exec($curl);
        $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if ($status != 200) {
            echo "error calling webservice, status is:" . $status;
            exit(-1);
        }

        curl_close($curl);

        header('Content-Type: application/octet-stream; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $name . '.' . 'pdf');

        echo $data;
        exit;
    }

    public function adminAppOpen($token, $id) {

        $atoken = decrypt($token);
        $type = $atoken['level'];
        $idlevel = [$atoken['level_id']];



        $application = new Application();
        $app_db = $application->getAppAll($id);
        if (!$app_db) {
            $app_db = $application->getAppAllAux($id);
        }

        $partner = $app_db->partner_name;
        $company = $app_db->subdomain_companies;
        $property = $app_db->id_property;

        $partners = null;
        $layout = null;

        switch (strtoupper($type)) {
            case 'B':
                if ($idlevel) {
                    $partnersA = DB::table('branch_partner')->where('branch_id', $idlevel)->select('id_partners')->get();
                    $partnersI = array();
                    foreach ($partnersA as $pa) {
                        $partnersI[] = $pa->id_partners;
                    }
                    $partners = DB::table('partners')->whereIn('id', $partnersI)->get();
                }
                break;
            case 'A':
                $partners = DB::table('partners')->get();
                break;
            case 'P':
                $partners = DB::table('partners')->where('id', $idlevel)->get();
                break;
        }



        if ($app_db->content) {
            $data = json_decode(base64_decode($app_db->content), 1);
        } else {
            $data = json_decode(base64_decode($app_db->content), 1);
        }


        $p = new Partners();
        if ($idlevel) {
            $id = null;
            switch ($type) {
                case 'P':
                    $id = $idlevel;
                    $layout = $p->getPartnerLayout($id);
                    break;
                case 'G':
                    $id = $idlevel;
                    $comp_db = DB::table('companies')->where('id', $id)->first();
                    if ($comp_db) {
                        $layout = $p->getPartnerLayout($comp_db->id_partners);
                    }
                    break;
            }
        }

        if (isset($data['pricing_code']) && $data['pricing_code']) {
            $ps = $application->getPricingByCode($data['pricing_code']);
        } else {
            $ps = $application->getPricingServices($partner, $company);
        }

        if ($app_db->status != 2 && $type == 'G') {
            return view('application.viewApplication', array(
                'partner' => $partner,
                'company' => $company,
                'ps' => $ps,
                'data' => $data,
                'layout' => $layout,
                'token' => $token
            ));
        }

        for ($x = 0; $x < count($ps); $x++) {
            if ($ps[$x]->select == 2) {
                $ps[$x]->nameinput = 'pricing_services_radio_' . $this->in_array_services($ps[$x]->service);
            }
        }

        if (isset($data['array_service']) && $data['array_service']) {
            if (!is_array($data['array_service'])) {
                $data['array_service'] = get_object_vars($data['array_service']);
            }
        }

        $obj_property = new Properties();
        $property = $obj_property->getPropertyInfo($app_db->id_property);

        if (!isset($property->id)) {
            $property = new \stdClass();
            $app_dbaux = $application->getAppAllAux($app_db->id);
            $property->id = 0;
            if ($app_dbaux) {
                $property->company_name = $app_dbaux->company_name;
                $property->partner_name = $app_dbaux->partner_title;
            }
        }

        $comp_db = DB::table('companies')->where('id', $app_db->id_company)->first();
        if ($comp_db) {
            Session::put('company', $comp_db->subdomain_companies);
        }



        return view('application.createApplication', array(
            'partner' => $partner,
            'company' => $company,
            'ps' => $ps,
            'data' => $data,
            'partners' => $partners,
            'edit' => true,
            'app' => $app_db,
            'layout' => $layout,
            'token' => $token,
            'app_property' => $property,
            'idappsession' => Session::get('openapp'),
            'title' => 'Edit Application'
        ));

        /* $atoken = decrypt($token);
          $type = $atoken['level'];
          $ids = $atoken['level_id'];
          $ids = [$ids];
          $application = new Application();

          $app_db = $application->getAppAll($id);


          if (!$app_db) {
          $app_db = $application->getAppAllAux($id);
          }

          var_dump($app_db); exit();


          Session::put('partner', $app_db->partner_name);
          Session::put('company', $app_db->subdomain_companies);
          Session::put('property', $app_db->id_property);


          if ($app_db) {
          if ($app_db->subdomain_companies == '') {
          $app_db->subdomain_companies = 0;
          }
          return redirect()->route('applicationedit', ['idapp'=>$id,'token' => $token, 'partner' => $app_db->partner_name, 'company' => $app_db->subdomain_companies]);
          } else {
          return redirect()->route('applicationedit', ['idapp'=>$id,'token' => $token, 'partner' => 0, 'company' => 0]);
          } */
    }

    public function editApplication($token, $partner, $company, $idapp) {

        $token1 = Session::get('token');
        $atoken = decrypt($token);



        $type = $atoken['level'];
        $ids = $atoken['level_id'];
        $ids = [$ids];

        $application = new Application();

        $eapp = $application->getExternalAppApplication($token1);
        Session::forget('token');


        if (!$eapp) {
            $eapp = new \stdClass();
            $eapp->idapp = $idapp;
            $eapp->content = '';
        }
        $partners = null;
        $layout = null;
        $p = new Partners();



        switch (strtoupper($type)) {
            case 'B':
                if ($ids) {
                    $partnersA = DB::table('branch_partner')->where('branch_id', $ids)->select('id_partners')->get();
                    $partnersI = array();
                    foreach ($partnersA as $pa) {
                        $partnersI[] = $pa->id_partners;
                    }
                    $partners = DB::table('partners')->whereIn('id', $partnersI)->get();
                }
                break;
            case 'A':
                $partners = DB::table('partners')->get();
                break;
            case 'P':
                $partners = DB::table('partners')->where('id', $ids)->get();
                break;
        }

        $app = $application->getAppAll($eapp->idapp);



        if (!$app && Session::get('openapp')) {
            $app = DB::table('application')->where('id', Session::get('openapp'))->first();
        }


        if (isset($app->content)) {
            $data = json_decode(base64_decode($app->content), 1);
        } else {
            $data = json_decode(base64_decode($eapp->content), 1);
        }

        if ($ids) {
            $id = null;
            switch ($type) {
                case 'P':
                    $id = $ids;
                    $layout = $p->getPartnerLayout($id);
                    break;
                case 'G':
                    $id = $ids;
                    $comp_db = DB::table('companies')->where('id', $id)->first();
                    if ($comp_db) {
                        $layout = $p->getPartnerLayout($comp_db->id_partners);
                    }
                    break;
            }
        }


        if (isset($data['pricing_code']) && $data['pricing_code']) {
            $ps = $application->getPricingByCode($data['pricing_code']);
        } else {
            $ps = $application->getPricingServices($partner, $company);
        }

        if ($app->status != 2 && $type == 'G') {
            return view('application.viewApplication', array(
                'partner' => $partner,
                'company' => $company,
                'ps' => $ps,
                'data' => $data,
                'layout' => $layout,
                'token' => $token
            ));
        }


        //if ($app->status == 4) {
        //    return redirect()->route('applicationcreateuser', ['token' => $token, 'partner' => $partner, 'company' => $company]);
        //}
//        $ps = $ps->get();
        for ($x = 0; $x < count($ps); $x++) {
            if ($ps[$x]->select == 2) {
                $ps[$x]->nameinput = 'pricing_services_radio_' . $this->in_array_services($ps[$x]->service);
            }
        }



        if (isset($data['array_service']) && $data['array_service']) {
            if (!is_array($data['array_service'])) {
                $data['array_service'] = get_object_vars($data['array_service']);
            }
        }

        $obj_property = new Properties();
        $property = $obj_property->getPropertyInfo($app->id_property);
        if (!isset($property->id)) {
            $property = new \stdClass();
            $app_dbaux = $application->getAppAllAux($app->id);
            $property->id = 0;
            if ($app_dbaux) {
                $property->company_name = $app_dbaux->company_name;
                $property->partner_name = $app_dbaux->partner_title;
            }
        }


        $comp_db = DB::table('companies')->where('id', $app->id_company)->first();
        if ($comp_db) {
            Session::put('company', $comp_db->subdomain_companies);
        }




        return view('application.createApplication', array(
            'partner' => $partner,
            'company' => $company,
            'ps' => $ps,
            'data' => $data,
            'partners' => $partners,
            'edit' => true,
            'app' => $app,
            'layout' => $layout,
            'token' => $token,
            'app_property' => $property,
            'idappsession' => Session::get('openapp'),
            'title' => 'Edit Application'
        ));
    }

    public function createUserPassword($token, $partner, $company) {
        $atoken = $token;
        $token = Session::get('token');

        $verify = $this->checkPlace($token, 'merchant');
        if (!$verify) {
            return view('application.notavailable');
        }
        $application = new Application();
        $external_app = $application->getExternalApp($token);
        return view('application.createUserPassword', array('token' => $atoken, 'partner' => $partner, 'company' => $company, 'email' => $external_app->email));
    }

    public function checkPlace($token, $type) {
        $application = new Application();
        $external_app = $application->getExternalApp($token);

        if ($external_app) {
            if ($external_app->type == $type) {
                return true;
            }
        }

        return false;
    }

    public function getImgPartner() {
        $partner_model = new Partners();
        $application = new Application();
//        $request = ;
//        $request = $this->getRouter()->current();
//        $partner = $request->getParameter('partner');
        $partner = \Illuminate\Support\Facades\Request::get('partner');
        $id_partner = $application->getIdPartner($partner);
        return $partner_model->getPartnerLogo($id_partner);
    }

    public function adminAppDelete($id_app) {

        $app_db = DB::table('application')->where('id', $id_app)->first();
        if ($app_db) {
            DB::table('application')->where('id', $id_app)->delete();
            DB::table('external_app')->where('idapp', $id_app)->delete();
            return Redirect::back()->with('success', 'The Application has been deleted successfully');
        } else {
            return Redirect::back()->with('error', 'Application not found');
        }
    }

    public function storeApplication($token, $partner, $company, $idapp = null, Request $request) {



        $atoken = $token;
        $datatoken = decrypt($token);
        $type = $datatoken['level'];
        $ids = $datatoken['level_id'];
        Session::put('operation', 'create');


        $application = new Application();
        $token = Session::get('token');

        $external_app = $application->getExternalAppApplication($token);



        $external_app = (array) $external_app;
        $data = $request->all();


        $data_save = $data;
        unset($data_save['_token']);
        unset($data_save['action']);

        $id_partner = $application->getIdPartner($partner);
        $id_companies = $application->getIdCompanies($company);
        $id_company = $application->getIdCompany($company);
        if ($external_app) {
            $data_db = json_decode(base64_decode($external_app['content']));
            if ($data_db) {
                $data_db = get_object_vars($data_db);
            }
        } else {
            $data_db = [];
        }

        switch (strtoupper($type)) {
            case 'P':
                break;
            case 'G':
                $obj_company = new Companies();
                $company_db = $obj_company->getCompanyById($ids);
                if ($company_db) {
                    $id_company = $ids;
                    $id_partner = $company_db->all()[0]->id_partners;
                }
                break;
            case 'M':
                break;
        }


        $data_services = array();
        $data_save['array_service'] = array();
        $pdf_generate = array();
        $data_save['partnerdb'] = $id_partner;
        $data_save['companydb'] = $id_company;
        if (isset($data['pricing_code']))
            $data_save['pricing_code'] = $data['pricing_code'];



        foreach ($data as $key => $item) {
            if (strrpos($key, "pricing_services_check") === 0) {
                $data_save['array_service']['check_service' . $item] = 'checked';
                $data_services[$item] = true;
                $pdf_generate[$this->in_array_services($item)] = 1;
            }
            if (strpos($key, 'pricing_services_radio_') === 0 || strpos($key, 'pricing_services_radio') === 0) {
                $data_save['array_service']['check_service' . $item] = 'checked';
                $data_services[$item] = true;
                $pdf_generate[$this->in_array_services($item)] = 1;
            }
        }





//        if (Session::get('place') == 'admin') {
        if (isset($data['select_partner'])) {
            $id_partner = $data['select_partner'];
        }
        if (isset($data['select_companies'])) {
            $id_company = $data['select_companies'];
        }
//        }

        $partner_complete = $application->getPartners($id_partner);
        $partner_obj = new Partners();


        $layout = $partner_obj->getPartnerLayout($id_partner);



        if (isset($data['action']) && $data['action'] == 'save' || ( isset($data['action']) && $data['action'] != "save" && !empty($data['appsaved']))) {



            $validator = Validator::make($data, $this->getRulesUploadFilesSave(), $this->getMessagesUploadFilesSave());
            if ($validator->fails()) {
                return Redirect::back()->withErrors($validator->errors())->withInput($data);
            }

            if (isset($data['vcheck'])) {
                $data_save['vcheck'] = $this->upload_file($request->file('vcheck'), $data_db, 'vcheck');
            } elseif (isset($data['vcheck_saved'])) {
                $data_save['vcheck'] = $data['vcheck_saved'];
            }

            if (isset($data['bstatement'])) {
                $data_save['bstatement'] = $this->upload_file($request->file('bstatement'), $data_db, 'bstatement');
            } elseif (isset($data['bstatement_saved'])) {
                $data_save['bstatement'] = $data['bstatement_saved'];
            }

            if (isset($data['bsheet'])) {
                $data_save['bsheet'] = $this->upload_file($request->file('bsheet'), $data_db, 'bsheet');
            } elseif (isset($data['bsheet_saved'])) {
                $data_save['bsheet'] = $data['bsheet_saved'];
            }

            if (isset($data['taxreturn'])) {
                $data_save['taxreturn'] = $this->upload_file($request->file('taxreturn'), $data_db, 'taxreturn');
            } elseif (isset($data['taxreturn_saved'])) {
                $data_save['taxreturn'] = $data['taxreturn_saved'];
            }

            if (isset($data['driver'])) {
                $data_save['driver'] = $this->upload_file($request->file('driver'), $data_db, 'driver');
            } elseif (isset($data['driver_saved'])) {
                $data_save['driver'] = $data['driver_saved'];
            }

            if (isset($data['ccstatement'])) {
                $data_save['ccstatement'] = $this->upload_file($request->file('ccstatement'), $data_db, 'ccstatement');
            } elseif (isset($data['ccstatement_saved'])) {
                $data_save['ccstatement'] = $data['ccstatement_saved'];
            }




            $external_app = $application->getAppAll($idapp);

//            if (Session::get('place') == 'admin') {
            if ($data['action'] != "save" && !empty($data['appsaved'])) {
                $email = $data_save['email'];
                if (isset($data['behalf_merchants'])) {
                    $email = $data['email_behalf'];
                }


                $ps = null;
                if (isset($data_save['select_partner']) && isset($data_save['select_companies'])) {
                    $ps = $this->appPricing($token, $data['appsaved'], $data_save['select_partner'], $data_save['select_companies'], 3);
                }

                if ($data_save['pricing_code']) {
                    $ps = $application->getPricingByCode($data_save['pricing_code']);
                } else {
                    $ps = $application->getPricingServices($partner, $company);
                }



                if ($data_save['pricing_code']) {
                    $ps = $application->getPricingByCode($data_save['pricing_code']);
                } else {
                    $partner_p = $partner;
                    $company_p = $company;
                    if ($request->input('select_partner')) {
                        $pdb_temp = $application->getPartners($request->input('select_partner'));
                        if (isset($pdb_temp[0]) && isset($pdb_temp[0]->partner_name)) {
                            $partner_p = $pdb_temp[0]->partner_name;
                        }
                    }
                    if ($request->input('select_companies')) {
                        $cdb_temp = $application->getCompany($request->input('select_companies'));
                        if (isset($cdb_temp) && isset($cdb_temp->subdomain_companies)) {
                            $company_p = $cdb_temp->subdomain_companies;
                        }
                    }
                    $ps = $application->getPricingServices($partner_p, $company_p);
                }



                $envelopes = $this->saveAndSignPDF($data_save, $partner, $company, $ps, null, $email, $pdf_generate, $layout);
                $string_env = null;
                foreach ($envelopes as $env) {
                    $string_env.=$env . ';';
                }

                DB::table('application')
                        ->where('id', $data['appsaved'])
                        ->update([
                            'status' => 4,
                            'envelope' => $string_env
                ]);


                $appinfodb = DB::table('application')->where('id', $data_save['appsaved'])->first();
                $dba_new = $this->cleanString($data_save['dba']);
                if ($appinfodb) {
                    if ($appinfodb->id_property == 0) {
                        $id_property = DB::table('properties')->insertGetId([
                            'id_partners' => $id_partner,
                            'id_companies' => $id_company,
                            'CompositeID_clients' => $data_save['ppid'],
                            'name_clients' => $data_save['dba'],
                            'subdomain_clients' => $dba_new,
                            'address_clients' => $data_save['adr1'],
                            'email_address_clients' => $data_save['email'],
                            'accounting_email_address_clients' => $data_save['email'],
                            'phone_clients' => $data_save['pphone'],
                            'url_clients' => '/master/' . $partner_complete[0]->partner_name . '/properties/' . $dba_new,
                            'status_clients' => 1,
                            'status_pp' => 0,
                            'date_new' => date('Y-m-d H:i:s'),
                            'units' => $data_save['donor'],
                            'city_clients' => $data_save['cty1'],
                            'state_clients' => $data_save['state1'],
                            'zip_clients' => $data_save['zip1'],
                            'contact_name_clients' => $data_save['pname'],
                        ]);
                        DB::table('application')
                                ->where('id', $data_save['appsaved'])
                                ->update([
                                    'content' => base64_encode(json_encode($data_save)),
                                    'id_property' => $id_property
                        ]);
                    } else {
                        DB::table('application')
                                ->where('id', $data_save['appsaved'])
                                ->update([
                                    'content' => base64_encode(json_encode($data_save)),
                        ]);
                    }
                }
            }




            if ($type == 'G') {
                $id_c = $ids;
                $company_db = $application->getCompany($id_c);
                if ($company_db) {
                    $id_partner = $company_db->id_partners;
                    $id_company = $company_db->id;
                }
            }



            $external_app = (array) $external_app;



            if (!isset($external_app['id'])) {
                if (!Session::get('openapp') && !isset($data['appsaved'])) {
                    $id_app = DB::table('application')->insertGetId([
                        'status' => '2',
                        'content' => base64_encode(json_encode($data_save)),
                        'id_partner' => $id_partner,
                        'id_company' => $id_company,
                        'id_pricing' => $application->getIdPricing($id_partner, $id_companies)
                    ]);

                    DB::table('external_app')
                            ->where('token', $token)
                            ->update([
                                'last_updated' => date('Y-m-d H:i:s'),
                                'ipaddr' => $request->getClientIp(),
                                'type' => 'merchant',
                                'idapp' => $id_app
                    ]);



                    $token_aux = encrypt(time() . '-' . $data['email']);
                    switch ($type) {
                        case 'P':
                            $partner_db = $application->getPartners($ids);
                            foreach ($partner_db as $p_db) {
                                DB::table('external_app')->insert([
                                    'id_partners' => $id_partner,
                                    'id_companies' => $id_company,
                                    'email' => $data['email'],
                                    'first_name' => $data['pname'],
                                    'last_name' => '',
                                    'token' => $token_aux,
                                    'ipaddr' => $request->getClientIp(),
                                    'type' => 'merchant',
                                    'idapp' => $id_app,
                                    'date_send' => date('Y-m-d H:i:s')
                                ]);
                            }
                            break;
                        case 'G':
                            DB::table('external_app')->insert([
                                'id_partners' => $id_partner,
                                'id_companies' => $id_company,
                                'email' => $data['email'],
                                'first_name' => $data['pname'],
                                'last_name' => '',
                                'token' => $token_aux,
                                'ipaddr' => $request->getClientIp(),
                                'type' => 'merchant',
                                'idapp' => $id_app,
                                'date_send' => date('Y-m-d H:i:s')
                            ]);
                            break;
                        case 'B':
                            DB::table('external_app')->insert([
                                'id_partners' => $id_partner,
                                'id_companies' => $id_company,
                                'email' => $data['email'],
                                'first_name' => $data['pname'],
                                'last_name' => '',
                                'token' => $token_aux,
                                'ipaddr' => $request->getClientIp(),
                                'type' => 'merchant',
                                'idapp' => $id_app,
                                'date_send' => date('Y-m-d H:i:s')
                            ]);
                            break;
                    }


                    Session::forget('token');

                    //$external_app_aux = $application->getSingleExternalApp($token_aux);*/
                    Session::forget('openapp');
                    return redirect()->route('application', ['token' => $atoken])->with('success', 'The Application has been saved successfully');

                    Session::forget('openapp');

                    return view('application.successAppSave', array('token' => $atoken));
                } else {
                    if(isset($data['appsaved']) && $data['appsaved']>0){
                        DB::table('application')
                                ->where('id', $data['appsaved'])
                                ->update([
                                    'content' => base64_encode(json_encode($data_save)),
                        ]);
                    }
                    elseif (isset($data_save['array_service']) && $data_save['array_service']) {
                        DB::table('application')
                                ->where('id', Session::get('openapp'))
                                ->update([
                                    'content' => base64_encode(json_encode($data_save)),
                        ]);
                    } else {
                        DB::table('application')
                                ->where('id', Session::get('openapp'))
                                ->update([
                                    'content' => base64_encode(json_encode($data_save)),
                                    'status' => 2
                        ]);
                    }


                    Session::forget('token');
                    Session::forget('openapp');

                    return redirect()->route('application', ['token' => $atoken])->with('success', 'The Application has been saved successfully');
                }
            } else {


                if (isset($data_save['array_service']) && $data_save['array_service']) {

                    DB::table('application')
                            ->where('id', $external_app['id'])
                            ->update([
                                'content' => base64_encode(json_encode($data_save)),
                                'id_partner' => $id_partner,
                                'id_company' => $id_company
                    ]);
                } else {
                    DB::table('application')
                            ->where('id', $external_app['id'])
                            ->update([
                                'content' => base64_encode(json_encode($data_save)),
                                'id_partner' => $id_partner,
                                'id_company' => $id_company,
                                'status' => 2
                    ]);
                }


                return redirect()->route('application', ['token' => $atoken])->with('success', 'The Application has been saved successfully');
//
            }
        } else {



            $validator = Validator::make($data, $this->getRulesApplication());
            if ($validator->fails()) {
                return Redirect::back()->withErrors($validator->errors())->withInput($data);
            }

            if (isset($data['vcheck'])) {
                $data_save['vcheck'] = $this->upload_file($request->file('vcheck'), $data_db, 'vcheck');
            } elseif (isset($data['vcheck_saved'])) {
                $data_save['vcheck'] = $data['vcheck_saved'];
            }

            if (isset($data['bstatement'])) {
                $data_save['bstatement'] = $this->upload_file($request->file('bstatement'), $data_db, 'bstatement');
            } elseif (isset($data['bstatement_saved'])) {
                $data_save['bstatement'] = $data['bstatement_saved'];
            }

            if (isset($data['bsheet'])) {
                $data_save['bsheet'] = $this->upload_file($request->file('bsheet'), $data_db, 'bsheet');
            } elseif (isset($data['bsheet_saved'])) {
                $data_save['bsheet'] = $data['bsheet_saved'];
            }

            if (isset($data['taxreturn'])) {
                $data_save['taxreturn'] = $this->upload_file($request->file('taxreturn'), $data_db, 'taxreturn');
            } elseif (isset($data['taxreturn_saved'])) {
                $data_save['taxreturn'] = $data['taxreturn_saved'];
            }

            if (isset($data['driver'])) {
                $data_save['driver'] = $this->upload_file($request->file('driver'), $data_db, 'driver');
            } elseif (isset($data['driver_saved'])) {
                $data_save['driver'] = $data['driver_saved'];
            }

            if (isset($data['ccstatement'])) {
                $data_save['ccstatement'] = $this->upload_file($request->file('ccstatement'), $data_db, 'ccstatement');
            } elseif (isset($data['ccstatement_saved'])) {
                $data_save['ccstatement'] = $data['ccstatement_saved'];
            }



            $data_save['partnerdb'] = $id_partner;
            $data_save['companydb'] = $id_company;

            $dba_new = $this->cleanString($data_save['dba']);
            $property_db = DB::table('properties')
                    ->where('subdomain_clients', $dba_new);
            $name_count = '';
            if ($property_db) {
                $count = 1;
                while ($property_db) {
                    $name_count = $dba_new . $count;
                    $property_db = DB::table('properties')
                            ->where('subdomain_clients', $name_count)
                            ->first();
                    $count++;
                }
                $dba_new = $name_count;
            }

            $id_app = null;


            if (!isset($external_app['idapp'])) {

                if (!Session::get('openapp')) {
                    if (!$dba_new) {
                        $dba_new = $id_partner . '_' . $id_company . '_' . time();
                    }


                    $partner_complete = $partner_complete->all();

                    $id_property = DB::table('properties')->insertGetId([
                        'id_partners' => $id_partner,
                        'id_companies' => $id_company,
                        'CompositeID_clients' => $data_save['ppid'],
                        'name_clients' => $data_save['dba'],
                        'subdomain_clients' => $dba_new,
                        'address_clients' => $data_save['adr1'],
                        'email_address_clients' => $data_save['email'],
                        'accounting_email_address_clients' => $data_save['email'],
                        'phone_clients' => $data_save['pphone'],
                        'url_clients' => '/master/' . $partner_complete[0]->partner_name . '/properties/' . $dba_new,
                        'status_clients' => 1,
                        'status_pp' => 0,
                        'date_new' => date('Y-m-d H:i:s'),
                        'units' => $data_save['donor'],
                        'city_clients' => $data_save['cty1'],
                        'state_clients' => $data_save['state1'],
                        'zip_clients' => $data_save['zip1'],
                        'contact_name_clients' => $data_save['pname'],
                    ]);


                    $id_app = DB::table('application')->insertGetId([
                        'status' => '4',
                        'content' => base64_encode(json_encode($data_save)),
                        'id_partner' => $id_partner,
                        'id_company' => $id_company,
                        'id_property' => $id_property,
                        'id_pricing' => $application->getIdPricing($id_partner, $id_companies)
                    ]);

                    DB::table('external_app')
                            ->where('token', $token)
                            ->update([
                                'last_updated' => date('Y-m-d H:i:s'),
                                'ipaddr' => $request->getClientIp(),
                                'idapp' => $id_app,
                                'type' => 'merchant'
                    ]);
                } else {

                    if (!$dba_new) {
                        $dba_new = $id_partner . '_' . $id_company . '_' . time();
                    }

                    $id_property = DB::table('properties')->insertGetId([
                        'id_partners' => $id_partner,
                        'id_companies' => $id_company,
                        'CompositeID_clients' => $data_save['ppid'],
                        'name_clients' => $data_save['dba'],
                        'subdomain_clients' => $dba_new,
                        'address_clients' => $data_save['adr1'],
                        'email_address_clients' => $data_save['email'],
                        'accounting_email_address_clients' => $data_save['email'],
                        'phone_clients' => $data_save['pphone'],
                        'url_clients' => '/master/' . $partner_complete[0]['partner_name'] . '/properties/' . $dba_new,
                        'status_clients' => 1,
                        'status_pp' => 0,
                        'date_new' => date('Y-m-d H:i:s'),
                        'units' => $data_save['donor'],
                        'city_clients' => $data_save['cty1'],
                        'state_clients' => $data_save['state1'],
                        'zip_clients' => $data_save['zip1'],
                        'contact_name_clients' => $data_save['pname'],
                    ]);

//                    if (Session::get('place') == 'admin') {
                    DB::table('application')
                            ->where('id', Session::get('openapp'))
                            ->update([
                                'content' => base64_encode(json_encode($data_save)),
                                'status' => '4',
                                'id_partner' => $id_partner,
                                'id_company' => $id_company,
                                'id_property' => $id_property
                    ]);
                    $id_app = Session::get('openapp');
//                    }
                }
            } else {
                $appinfo = DB::table('application')->where('id', $external_app['idapp'])->select('id_property')->first();
                if (empty($appinfo)) {
                    if (!$dba_new) {
                        $dba_new = $id_partner . '_' . $id_company . '_' . time();
                    }
                    $id_property = DB::table('properties')->insertGetId([
                        'id_partners' => $id_partner,
                        'id_companies' => $id_company,
                        'CompositeID_clients' => $data_save['ppid'],
                        'name_clients' => $data_save['dba'],
                        'subdomain_clients' => $dba_new,
                        'address_clients' => $data_save['adr1'],
                        'email_address_clients' => $data_save['email'],
                        'accounting_email_address_clients' => $data_save['email'],
                        'phone_clients' => $data_save['pphone'],
                        'url_clients' => '/master/' . $partner_complete[0]['partner_name'] . '/properties/' . $dba_new,
                        'status_clients' => 1,
                        'status_pp' => 0,
                        'date_new' => date('Y-m-d H:i:s'),
                        'units' => $data_save['donor'],
                        'city_clients' => $data_save['cty1'],
                        'state_clients' => $data_save['state1'],
                        'zip_clients' => $data_save['zip1'],
                        'contact_name_clients' => $data_save['pname'],
                    ]);
                } else {
                    $partner_complete = $partner_complete->all();
                    $partner_complete[0] = (array) $partner_complete[0];

                    $id_property = $external_app['idapp'];
                    $id_property = DB::table('properties')->insertGetId([
                        'id_partners' => $id_partner,
                        'id_companies' => $id_company,
                        'CompositeID_clients' => $data_save['ppid'],
                        'name_clients' => $data_save['dba'],
                        'subdomain_clients' => $dba_new,
                        'address_clients' => $data_save['adr1'],
                        'email_address_clients' => $data_save['email'],
                        'accounting_email_address_clients' => $data_save['email'],
                        'phone_clients' => $data_save['pphone'],
                        'url_clients' => '/master/' . $partner_complete[0]['partner_name'] . '/properties/' . $dba_new,
                        'status_clients' => 1,
                        'status_pp' => 0,
                        'date_new' => date('Y-m-d H:i:s'),
                        'units' => $data_save['donor'],
                        'city_clients' => $data_save['cty1'],
                        'state_clients' => $data_save['state1'],
                        'zip_clients' => $data_save['zip1'],
                        'contact_name_clients' => $data_save['pname'],
                    ]);
                }


                if (!$dba_new) {
                    $dba_new = $id_partner . '_' . $id_company . '_' . time();
                }
                DB::table('application')
                        ->where('id', $external_app['idapp'])
                        ->update([
                            'content' => base64_encode(json_encode($data_save)),
                            'status' => '4',
                            'id_partner' => $id_partner,
                            'id_company' => $id_company,
                            'id_property' => $id_property
                ]);
                $id_app = $external_app['idapp'];

                DB::table('external_app')
                        ->where('token', $token)
                        ->update([
                            'last_updated' => date('Y-m-d H:i:s'),
                            'ipaddr' => $request->getClientIp(),
                            'type' => 'merchant'
                ]);
            }




            $ps = null;
            if (isset($data_save['select_partner']) && isset($data_save['select_companies'])) {
                $ps = $this->appPricing($token, $id_app, $data_save['select_partner'], $data_save['select_companies'], 3);
            }

            if ($data_save['pricing_code']) {
                $ps = $application->getPricingByCode($data_save['pricing_code']);
            } else {
                $partner_p = $partner;
                $company_p = $company;
                if ($request->input('select_partner')) {
                    $pdb_temp = $application->getPartners($request->input('select_partner'));
                    if (isset($pdb_temp[0]) && isset($pdb_temp[0]->partner_name)) {
                        $partner_p = $pdb_temp[0]->partner_name;
                    }
                }
                if ($request->input('select_companies')) {
                    $cdb_temp = $application->getCompany($request->input('select_companies'));
                    if (isset($cdb_temp) && isset($cdb_temp->subdomain_companies)) {
                        $company_p = $cdb_temp->subdomain_companies;
                    }
                }
                $ps = $application->getPricingServices($partner_p, $company_p);
            }




            $email = $data_save['email'];
            if (isset($data['behalf_merchants'])) {
                $email = $data['email_behalf'];
            }




            $envelopes = $this->saveAndSignPDF($data_save, $partner, $company, $ps, null, $email, $pdf_generate, $layout);
            $string_env = null;
            foreach ($envelopes as $env) {
                $string_env.=$env . ';';
            }
            if (Session::get('openapp')) {
                $id_app = Session::get('openapp');
            }
            if ($id_app) {
                DB::table('application')
                        ->where('id', $id_app)
                        ->update([
                            'envelope' => $string_env
                ]);
            } elseif ($external_app['idapp']) {
                DB::table('application')
                        ->where('id', $external_app['idapp'])
                        ->update([
                            'envelope' => $string_env
                ]);
            }

//            if (Session::get('place') == 'admin') {
            Session::forget('openapp');
            return redirect()->route('application', ['token' => $atoken])->with('success', 'The Application has been saved successfully');
//            }
//            Session::forget('openapp');
//            return redirect()->route('applicationcreateuser', ['partner' => $partner, 'company' => $company]);
        }
    }

    public function in_array_services($value) {
        $array_echeck = [10, 11, 4, 5, 6, 7, 8, 9, 16, 32, 33];
        $array_ccard = [3, 31, 10, 12, 19, 20, 34];
        $array_evendor = [18, 22, 24, 30];
        $array_einvoice = [13, 28];


        if (in_array($value, $array_echeck)) {
            return 'ec';
        }

        if (in_array($value, $array_ccard)) {
            return 'cc';
        }

        if (in_array($value, $array_evendor)) {
            return 'ev';
        }

        if (in_array($value, $array_einvoice)) {
            return 'ei';
        }
    }

    public function getRulesUploadFilesSave() {

        return [
            'vcheck' => 'mimes:pdf,jpeg|max:12000',
            'bstatement' => 'mimes:pdf,jpeg|max:12000',
            'bsheet' => 'mimes:pdf,jpeg|max:12000',
            'taxreturn' => 'mimes:pdf,jpeg|max:12000',
            'driver' => 'mimes:pdf,jpeg|max:12000',
            'ccstatement' => 'mimes:pdf,jpeg|max:12000',
        ];
    }

    public function getMessagesUploadFilesSave() {
        return [
            'vcheck.required' => 'The Voided Check or Bank letter is required.',
            'vcheck.mimes' => 'The Voided Check or Bank letter must be a file of type: pdf, jpeg.',
            'vcheck.max' => 'The Voided Check or Bank letter must be a file of 12MB or less.',
            'bstatement.required' => 'The 1st Bank Statement or Balance Sheet is required.',
            'bstatement.mimes' => 'The 1st Bank Statement or Balance Sheet must be a file of type: pdf, jpeg.',
            'bstatement.max' => 'The 1st Bank Statement or Balance Sheet must be a file of 12MB or less.',
            'bsheet.mimes' => 'The 2nd Bank Statement or Balance Sheet  must be a file of type: pdf, jpeg.',
            'bsheet.max' => 'The 2nd Bank Statement or Balance Sheet  must be a file of 12MB or less.',
            'taxreturn.mimes' => 'The 3rd Bank Statement or Balance Sheet  must be a file of type: pdf, jpeg.',
            'taxreturn.max' => 'The 3rd Bank Statement or Balance Sheet  must be a file of 12MB or less.',
            'driver.mimes' => 'The Driver License  must be a file of type: pdf, jpeg.',
            'driver.max' => 'The Driver License  must be a file of 12MB or less.',
            'ccstatement.mimes' => 'The CC Statement must be a file of type: pdf, jpeg.',
            'ccstatement.max' => 'The CC Statement must be a file of 12MB or less.',
        ];
    }

    public function upload_file($file, $data_db, $field) {
        $remove = null;
        if (isset($data_db[$field])) {
            $remove = $data_db[$field];
        }
        if ($remove) {
            @unlink(Config::get('onlineapp.upload_onlineapp_dir') . $remove);
        }
        if ($file) {
            $extension = $file->getClientOriginalExtension();
            $name = $file->getClientOriginalName();
            $name = $this->cleanString(str_replace('.' . $extension, '', $name));
            //$name = $name.'-'.uniqid().'.'.$extension;
            $name = uniqid() . '.' . $extension;
            $file->move(
                    Config::get('onlineapp.upload_onlineapp_dir'), $name
            );
            return $name;
        }

        return null;
    }

    public function cleanString($string) {
        $string = strtolower($string);
        $string = str_replace(' ', '', $string);
        $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string);
        return preg_replace('/-+/', '_', $string);
    }

    public function adminAppMBF($id_app) {
        $type = Session::get('type');
        $ids = Session::get('ids');

        $mbf = new mbf();
        $app_db = DB::table('application')->where('id', $id_app)->first();
        if (!$app_db) {
            return Redirect::back()->with('error', 'Error sending MBF');
        }
        $datosapp = json_decode(base64_decode($app_db->content), true);
        $datosapp['appid'] = $id_app;
        $datosapp['id_partner'] = $app_db->id_partner;
        $datosapp['id_company'] = $app_db->id_company;
        $datosapp['id_property'] = $app_db->id_property;
        if (isset($datosapp['merchant_type'])) {
            if ($datosapp['merchant_type'] == 'Property') {
                $datosapp['merchant_type'] = '6513';
            } elseif ($datosapp['merchant_type'] == 'Non-Property') {
                $datosapp['merchant_type'] = '4900';
            }
            $datosapp['sic'] = $datosapp['merchant_type'];
            if (!is_numeric($datosapp['sic'])) {
                $datosapp['sic'] = '6513';
            }
        } else {
            $datosapp['sic'] = '6513';
        }
        $mbf = new mbf();

        $mbf->data = $datosapp;

        $mbffile = $mbf->headerRecord() . $mbf->chainRecord() . $mbf->storeRecord() . $mbf->merchantRecord() . $mbf->rateRecord() . $mbf->cntRecord() . $mbf->trailerRecord('7');
        //SendMBF2Q($mbffile);

        if (substr($mbffile, 0, 6) == 'HDRMBF') {
            //valid header
            $nameout = 'REVO_R0MDDGB1_' . date('Ymd_Hms') . '_' . $id_app;

            $pathout = env('vantivOut','/tmp/');
            $fname = $pathout . $nameout;
            file_put_contents($fname, $mbffile);
            if(file_exists($fname)){
                return response()->json(array('msg' => 'MBF sent succesfully.'));
            }
            else {
                return response()->json(array('msg' => 'Error creating MBF'));
            }
        } else {
            return response()->json(array('msg' => 'Error sending MBF'));
        }
    }

    public function companiesByPartner($partner_id) {
        $company = Session::get('company');
        $companies = DB::table('companies')
                ->where('id_partners', $partner_id)
                ->get();
        return view('application.companiesSelect', array('companies' => $companies, 'company' => $company));
    }

    public function createApplication($token, $partner, $company) {
        $atoken = decrypt($token);
        $type = $atoken['level'];
        $ids = $atoken['level_id'];

        $application = new Application();
        $eapp = $application->getExternalAppApplication($token);
        $app = $application->getApp($eapp['idapp']);
        $ps = $application->getPricingServices($partner, $company);

        for ($x = 0; $x < count($ps); $x++) {
            if ($ps[$x]->select == 2) {
                $ps[$x]->nameinput = 'pricing_services_radio_' . $this->in_array_services($ps[$x]->service);
            }
        }

        $layout = null;
        $p = new Partners();

        if ($ids) {
            $id = null;
            switch ($type) {
                case 'P':
                    $id = $ids;
                    $layout = $p->getPartnerLayout($id);
                    break;
                case 'G':
                    $id = $ids;
                    $comp_db = DB::table('companies')->where('id', $id)->first();
                    if ($comp_db) {
                        $layout = $p->getPartnerLayout($comp_db->id_partners);
                    }
                    break;
            }
        }

//        if($app['status'] != 4){
        $partners = null;

        switch ($type) {
            case 'B':
                if ($ids) {
                    $partnersA = DB::table('branch_partner')->where('branch_id', $ids)->select('id_partners')->get();
                    $partnersI = array();
                    foreach ($partnersA as $pa) {
                        $partnersI[] = $pa->id_partners;
                    }
                    $partners = DB::table('partners')->whereIn('id', $partnersI)->get();
                }
                break;
            case 'A':
                $partners = DB::table('partners')->get();
                break;
            case 'P':
                $partners = DB::table('partners')->where('id', $ids)->get();
        }

        Session::forget('company');


        return view('application.createApplication', array(
            'partner' => $partner,
            'company' => $company,
            'ps' => $ps,
            'partners' => $partners,
            'layout' => $layout,
            'token' => $token,
            'title' => 'New Application'
        ));
//        }else
//        if ($app['status'] == 4) {
//            return redirect()->route('applicationcreateuser', ['partner' => $partner, 'company' => $company]);
//        }
//        $verify = $this->checkPlace($token, 'group');
//        $verify_2 = $this->checkPlace($token, 'merchant');
//        if (!$verify && !$verify_2)
//            return view('application.notavailable');
//
//        $partner_db = DB::table('partners')->where('partner_name', $partner)->first();
//        if ($partner_db)
//            $layout = $p->getPartnerLayout($partner_db['id']);
//
//
//        return view('application.createApplication', array(
//            'partner' => $partner,
//            'company' => $company,
//            'ps' => $ps,
//            'layout' => $layout,
//            'token' => $token
//        ));
    }

    public function appStatus($token, $ida, $status) {
        $array_token = decrypt($token);

        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        DB::table('application')
                ->where('id', $ida)
                ->update([
                    'status' => $status
        ]);
    }

    public function appMerchant($token, $ida, $partner, $company, $merchant) {
        $array_token = decrypt($token);

        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        DB::table('application')
                ->where('id', $ida)
                ->update([
                    'id_property' => $merchant,
                    'id_company' => $company,
                    'id_partner' => $partner,
        ]);
    }

    public function importApplication($token, $partner, $company) {


        $array_token = decrypt($token);

        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        $atoken = encrypt(['level' => $level, 'level_id' => $idlevel]);



        $application = new Application();

        $ps = $application->getPricingServices($partner, $company);

        $partners = null;
        $ids = $idlevel;


        switch ($level) {
            case 'P':
                $partners = $application->getPartners($ids);
                break;
            case 'B':
                $partnersA = DB::table('branch_partner')->where('branch_id', $ids)->select('id_partners')->get();
                $partnersI = array();
                foreach ($partnersA as $pa) {
                    $partnersI[] = $pa->id_partners;
                }
                $partners = DB::table('partners')->whereIn('id', $partnersI)->get();
                break;
            case 'A':
                $partners = DB::table('partners')->get();
                break;
        }

        return view('application.importApplication', array(
            'partner' => $partner,
            'company' => $company,
            'ps' => $ps,
            'partners' => $partners,
            'token' => $atoken
        ));
    }

    public function appPricingByCode($code, $option) {
        $application = new Application();
        $ps = $application->getPricingByCode($code);
        $data = null;
        if (Session::get('openapp')) {
            $app = DB::table('application')->where('id', Session::get('openapp'))->first();
            if ($app) {
                $app = (array) $app;
                if (isset($app['content']))
                    $data = json_decode(base64_decode($app['content']));
                $data = get_object_vars($data);
            }
        }

        for ($x = 0; $x < count($ps); $x++) {
            if ($ps[$x]->select == 2) {
                $ps[$x]->nameinput = 'pricing_services_radio_' . $this->in_array_services($ps[$x]->service);
            }
        }

        if (isset($data['array_service']) && $data['array_service']) {
            $data['array_service'] = get_object_vars($data['array_service']);
        }


        if ($ps->all()) {
            if ($option == 2) {
                return view('application.pricingPartial', array('ps' => $ps, 'data' => $data));
            } else {
                return view('application.pricingPartialEdit', array('ps' => $ps, 'data' => $data));
            }
        } else {
            exit();
        }
    }

    public function storeImportApplication($token, Request $request, $partner, $company) {
        $atoken = decrypt($token);
        $token1 = $token;
        $ids = $atoken['level_id'];
        $type = $atoken['level'];
//        if (Session::get('place') == 'admin' || Session::get('token')) {
        Session::put('operation', 'import');
        $application = new Application();
        $data_submit = $request->all();

        $id_partner = $application->getIdPartner($partner);
        $id_companies = $application->getIdCompanies($company);
        $id_company = $application->getIdCompany($company);



        $import_incomplete = false;
        if (isset($data_submit['import_incomplete'])) {
            $import_incomplete = true;
        }



        if ($type != 'G') {
            if (isset($data_submit['select_partner'])) {
                $id_partner = $data_submit['select_partner'];
            }
            if (isset($data_submit['select_partner'])) {
                $id_company = $data_submit['select_companies'];
            }
        } else {
            $company_db = $application->getCompany($ids);
            $id_partner = $company_db->id_partners;
            $id_company = $company_db->id;
        }


        $partner_complete = $application->getPartners($id_partner);
        $partner_obj = new Partners();
        $layout = $partner_obj->getPartnerLayout($id_partner);

        $validator = Validator::make($data_submit, $this->getRulesImportApp());

        if ($data_submit['spreadsheet']->getMimeType() != "application/vnd.ms-office" && $data_submit['spreadsheet']->getMimeType() != "application/vnd.ms-excel") {
            return Redirect::back()->with('error', 'The file has not the correct mime type');
        }



        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator->errors())->withInput($data_submit);
        }


        $data_all = array();
        $data_all_aux = array();
        $attach = array();
        //upload files

        if (isset($data_submit['vcheck'])) {
            $attach['vcheck'] = $this->upload_file($request->file('vcheck'), null, null);
        }
        if (isset($data_submit['bstatement'])) {
            $attach['bstatement'] = $this->upload_file($request->file('bstatement'), null, null);
        }
        if (isset($data_submit['bsheet'])) {
            $attach['bsheet'] = $this->upload_file($request->file('bsheet'), null, null);
        }
        if (isset($data_submit['taxreturn'])) {
            $attach['taxreturn'] = $this->upload_file($request->file('taxreturn'), null, null);
        }

        $excel = $this->upload_excel($request->file('spreadsheet'));
        $results = Excel::load(Config::get('onlineapp.upload_onlineapp_dir').'/'.$excel);
        $sheet = $results->sheet('Property Information');
        if (!$sheet) {
            return Redirect::back()->with('error', 'The file has not the correct format');
        }
        $rows = count($sheet->rows()->getRowDimensions());
        $errors_importing = array();
        $errors = array();
        $errors_local = $errors_services = array();

        $ps = null;
        if ($data_submit['pricing_code']) {
            $ps = $application->getPricingByCode($data_submit['pricing_code']);
        } else {
            $partner_p = $partner;
            $company_p = $company;
            if ($request->input('select_partner')) {
                $pdb_temp = $application->getPartners($request->input('select_partner'));
                if (isset($pdb_temp[0]) && isset($pdb_temp[0]->partner_name)) {
                    $partner_p = $pdb_temp[0]->partner_name;
                }
            }
            if ($request->input('select_companies')) {
                $cdb_temp = $application->getCompany($request->input('select_companies'));
                if (isset($cdb_temp) && isset($cdb_temp->subdomain_companies)) {
                    $company_p = $cdb_temp->subdomain_companies;
                }
            }
            $ps = $application->getPricingServices($partner_p, $company_p);
        }


        for ($a = 3; $a <= $rows; $a++) {
            $pdf_generate = array();
            $data = array();
            $data['ppid'] = trim($sheet->rows()->getCell('A' . $a)->getValue());
            $data['dba'] = trim($sheet->rows()->getCell('B' . $a)->getValue());
            $data['legal'] = trim($sheet->rows()->getCell('C' . $a)->getValue());
            $data['adr1'] = trim($sheet->rows()->getCell('D' . $a)->getValue());
            $data['cty1'] = trim($sheet->rows()->getCell('E' . $a)->getValue());
            $data['state1'] = trim($sheet->rows()->getCell('F' . $a)->getValue());
            $data['zip1'] = trim($sheet->rows()->getCell('G' . $a)->getValue());
            $data['phone1'] = trim($sheet->rows()->getCell('H' . $a)->getValue());
            $data['bdesc'] = trim($sheet->rows()->getCell('I' . $a)->getValue());
            $data['bstruct'] = trim($sheet->rows()->getCell('J' . $a)->getValue());
            $data['date'] = $this->excelDate(trim($sheet->rows()->getCell('K' . $a)->getValue()));
            $data['cdate'] = $this->excelDate(trim($sheet->rows()->getCell('L' . $a)->getValue()));
            $data['fti'] = trim($sheet->rows()->getCell('M' . $a)->getValue());
            //$data['NAICS'] = trim($sheet->rows()->getCell('N'.$a)->getValue());
            $data['adr2'] = trim($sheet->rows()->getCell('O' . $a)->getValue());
            $data['cty2'] = trim($sheet->rows()->getCell('P' . $a)->getValue());
            $data['state2'] = trim($sheet->rows()->getCell('Q' . $a)->getValue());
            $data['zip2'] = trim($sheet->rows()->getCell('R' . $a)->getValue());

            $data['ttname'] = trim($sheet->rows()->getCell('S' . $a)->getValue());
            $data['pname'] = trim($sheet->rows()->getCell('T' . $a)->getValue());
            $data['cadr1'] = trim($sheet->rows()->getCell('U' . $a)->getValue());
            $data['ccty1'] = trim($sheet->rows()->getCell('V' . $a)->getValue());
            $data['cstate1'] = trim($sheet->rows()->getCell('W' . $a)->getValue());
            $data['czip1'] = trim($sheet->rows()->getCell('X' . $a)->getValue());
            $data['email'] = trim($sheet->rows()->getCell('Y' . $a)->getValue());
            $data['pphone'] = trim($sheet->rows()->getCell('Z' . $a)->getValue());
            $data['bdate'] = $this->excelDate(trim($sheet->rows()->getCell('AA' . $a)->getValue()));
            $data['title'] = trim($sheet->rows()->getCell('AB' . $a)->getValue());
            $data['ssn'] = trim($sheet->rows()->getCell('AC' . $a)->getValue());
            $data['donor'] = trim($sheet->rows()->getCell('AD' . $a)->getValue());

            $data['hticket'] = trim($sheet->rows()->getCell('AE' . $a)->getValue());
            $data['cticket'] = trim($sheet->rows()->getCell('AF' . $a)->getValue());
            $data['avticket'] = trim($sheet->rows()->getCell('AG' . $a)->getValue());
            $data['mticket'] = trim($sheet->rows()->getCell('AH' . $a)->getValue());

            $data['cchticket'] = trim($sheet->rows()->getCell('AI' . $a)->getValue());
            $data['ccmticket'] = trim($sheet->rows()->getCell('AJ' . $a)->getValue());

            //Request Service

            $data['vhticket'] = trim($sheet->rows()->getCell('AR' . $a)->getValue());
            $data['vcticket'] = trim($sheet->rows()->getCell('AS' . $a)->getValue());

            $data['bankname'] = trim($sheet->rows()->getCell('AT' . $a)->getValue());
            $data['bankrouting'] = trim($sheet->rows()->getCell('AU' . $a)->getValue());
            $data['banknumber'] = trim($sheet->rows()->getCell('AV' . $a)->getValue());
            $data['banktype'] = trim($sheet->rows()->getCell('AW' . $a)->getValue());

            $data['bankname_re'] = trim($sheet->rows()->getCell('AX' . $a)->getValue());
            $data['bankrouting_re'] = trim($sheet->rows()->getCell('AY' . $a)->getValue());
            $data['banknumber_re'] = trim($sheet->rows()->getCell('AZ' . $a)->getValue());
            $data['banktype_re'] = trim($sheet->rows()->getCell('BA' . $a)->getValue());

            $data['freq'] = trim($sheet->rows()->getCell('BB' . $a)->getValue());
            $data['duedate'] = trim($sheet->rows()->getCell('BC' . $a)->getValue());

            if (isset($attach['vcheck'])) {
                $data['vcheck'] = $attach['vcheck'];
            }
            if (isset($attach['bstatement'])) {
                $data['bstatement'] = $attach['bstatement'];
            }
            if (isset($attach['bsheet'])) {
                $data['bsheet'] = $attach['bsheet'];
            }
            if (isset($attach['taxreturn'])) {
                $data['taxreturn'] = $attach['taxreturn'];
            }

            // cell validate

            $validator = Validator::make($data, $this->getRulesImportExcel(), $this->getMessagesImportExcel($a));

            $error_local = false;

            if ($validator->fails()) {
                array_push($errors, $validator->errors());
                $errors_importing[$a - 3] = $validator->errors();
                $error_local = true;
            }

            array_push($errors_local, $error_local);


            $data['array_service'] = array();
            $data['partnerdb'] = $id_partner;
            $data['companydb'] = $id_company;

            $errors_services_temp = 0;

            // e-check
            switch (strtolower(trim($sheet->rows()->getCell('AK' . $a)->getValue()))) {
                case 'p':
                    $data['array_service_import']['check_service32'] = 'checked';
                    $errors_services_temp += 1;
                    break;
                case 'x':
                case 'a':
                    foreach ($ps as $s) {
                        if ($s->service != 32) {
                            if ($this->in_array_services($s->service) == 'ec') {
                                $data['array_service_import']['check_service' . $s->service] = 'checked';
                                $pdf_generate['ec'] = 1;
                                break;
                            }
                        }
                    }
                    $errors_services_temp += 1;
                    break;
            }


            // credit card
            switch (strtolower(trim($sheet->rows()->getCell('AL' . $a)->getValue()))) {
                case 'p':
                    $data['array_service_import']['check_service31'] = 'checked';
                    $errors_services_temp += 1;
                    break;
                case 'x':
                case 'a':
                    foreach ($ps as $s) {
                        $s = (array) $s;
                        if ($s['service'] != 31) {
                            if ($this->in_array_services($s['service']) == 'cc') {
                                $data['array_service_import']['check_service' . $s['service']] = 'checked';
                                $pdf_generate['cc'] = 1;
                                break;
                            }
                        }
                    }
                    $errors_services_temp += 1;
                    break;
            }

            // e-vendor
            if (strtolower(trim($sheet->rows()->getCell('AM' . $a)->getValue())) == 'x') {
                foreach ($ps as $s) {
                    if ($this->in_array_services($s->service) == 'ev') {
                        $data['array_service_import']['check_service' . $s->service] = 'checked';
                        break;
                    }
                }
                $errors_services_temp += 1;
            }

            // e-terminal
            if (strtolower(trim($sheet->rows()->getCell('AN' . $a)->getValue())) == 'x') {
                $data['array_service_import']['check_service23'] = 'checked';
                $errors_services_temp += 1;
            }

            // e-invoice
            if (strtolower(trim($sheet->rows()->getCell('AO' . $a)->getValue())) == 'x') {
                foreach ($ps as $s) {
                    if ($this->in_array_services($s->service) == 'ei') {
                        $data['array_service_import']['check_service' . $s->service] = 'checked';
                        break;
                    }
                }
                $errors_services_temp += 1;
            }


            $data['pdf_generate'] = $pdf_generate;
            array_push($data_all, $data);
            array_push($errors_services, $errors_services_temp);
        }

        $flag_error_services = 0;
        foreach ($errors_services as $es_item) {
            if ($es_item == 0) {
                $flag_error_services = 1;
            }
        }

        if (!$import_incomplete && $flag_error_services == 1) {
            $validation = Validator::make(array(), array());
            $message_bag = $validation->getMessageBag();
            $message_bag->add('pricing_services', 'You need to select at least a service for row.');
            return Redirect::back()->with('errors', $message_bag);
        }



        if ($import_incomplete == false && count($errors)) {
            if (isset($data_all['vcheck'])) {
                $this->delete_upload_file($data_all['vcheck']);
            }
            if (isset($data_all['bstatement'])) {
                $this->delete_upload_file($data_all['bstatement']);
            }
            if (isset($data_all['bsheet'])) {
                $this->delete_upload_file($data_all['bsheet']);
            }
            if (isset($data_all['taxreturn'])) {
                $this->delete_upload_file($data_all['taxreturn']);
            }

            $this->delete_upload_file($excel);


            /* foreach ($errors as $error){
              var_dump($error->all());
              }
              exit(); */
            return Redirect::back()->with('array_errors', $errors);
        } else {
            $mailgeneral = 0;
            $token = Session::get('token');
            $apps_ids = array();
            $cont = 0;

            $property = new Properties();
            $contract = $property->getPropertySettings(0, $id_company, $id_partner, 'NOCONTRACT');

            foreach ($data_all as $d) {
                $dba_new = $this->cleanString($d['dba']);
                $property_db = DB::table('properties')
                        ->where('subdomain_clients', $dba_new);
                $name_count = '';
                if ($property_db) {
                    $count_properties = 1;
                    while ($property_db) {
                        $name_count = $dba_new . $count_properties;
                        $property_db = DB::table('properties')
                                ->where('subdomain_clients', $name_count)
                                ->first();
                        $count_properties++;
                    }
                    $dba_new = $name_count;
                }




                if ($data_submit['pricing_code']) {
                    $d['pricing_code'] = $data_submit['pricing_code'];
                }

                $status = 4;
                if ($errors_local[$cont]) {
                    $status = 2;
                }


                if (!isset($d['array_service_import'])) {
                    $status = 2;
                } else {
                    $match_cont = 0;

                    foreach ($ps as $ps_item) {
                        foreach ($d['array_service_import'] as $asi_key => $asi_value) {
                            $service_number_aux = str_replace('check_service', '', $asi_key);
                            if ($service_number_aux == $ps_item->service) {
                                $match_cont++;

                                if (!$errors_local[$cont]) {
                                    $data_all_aux[$d['dba']] = $d;
                                }
                            }
                        }
                    }

                    if ($match_cont == 0) {
                        $mailgeneral ++;
                        $status = 2;
                    }
                }



                $id_app = DB::table('application')->insertGetId([
                    'status' => $status,
                    'content' => base64_encode(json_encode($d)),
                    'id_partner' => $id_partner,
                    'id_company' => $id_company,
                    'id_property' => 0,
                    'id_pricing' => $application->getIdPricing($id_partner, $id_companies)
                ]);
                array_push($apps_ids, $id_app);

                DB::table('external_app')
                        ->where('token', $token)
                        ->update([
                            'last_updated' => date('Y-m-d H:i:s'),
                            'ipaddr' => $request->getClientIp(),
                            'type' => 'merchant',
                            'idapp' => $id_app
                ]);

                if (!$errors_local[$cont] && $status != 2) {
                    $id_property = DB::table('properties')->insertGetId([
                        'id_partners' => $id_partner,
                        'id_companies' => $id_company,
                        'CompositeID_clients' => $d['ppid'],
                        'name_clients' => $d['dba'],
                        'subdomain_clients' => $dba_new,
                        'address_clients' => $d['adr1'],
                        'email_address_clients' => $d['email'],
                        'accounting_email_address_clients' => $d['email'],
                        'phone_clients' => $d['pphone'],
                        'url_clients' => '/master/' . $partner_complete[0]->partner_name . '/properties/' . $dba_new,
                        'status_clients' => 1,
                        'status_pp' => 0,
                        'units' => $d['donor'],
                        'date_new' => date('Y-m-d H:i:s'),
                        'city_clients' => $d['cty1'],
                        'state_clients' => $d['state1'],
                        'zip_clients' => $d['zip1'],
                        'contact_name_clients' => $d['pname'],
                    ]);

                    DB::table('application')
                            ->where('id', $id_app)
                            ->update([
                                'id_property' => $id_property
                    ]);
                }



                switch ($type) {
                    case 'P':
                        $partner_db = $application->getPartners($ids);
                        $token_aux = encrypt(time() . '-' . $data['email']);
                        foreach ($partner_db as $p_db) {
                            DB::table('external_app')->insert([
                                'id_partners' => $id_partner,
                                'id_companies' => $id_company,
                                'email' => $d['email'],
                                'first_name' => $d['pname'],
                                'last_name' => '',
                                'token' => $token_aux,
                                'ipaddr' => $request->getClientIp(),
                                'type' => 'merchant',
                                'idapp' => $id_app,
                                'date_send' => date('Y-m-d H:i:s')
                            ]);
                        }
                        break;
                    case 'G':
                        $group_db = $application->getCompany($ids);
                        $token_aux = encrypt(time() . '-' . $data['email']);
                        DB::table('external_app')->insert([
                            'id_partners' => $group_db->id_partners,
                            'id_companies' => $group_db->id,
                            'email' => $d['email'],
                            'first_name' => $d['pname'],
                            'last_name' => '',
                            'token' => $token_aux,
                            'ipaddr' => $request->getClientIp(),
                            'type' => 'merchant',
                            'idapp' => $id_app,
                            'date_send' => date('Y-m-d H:i:s')
                        ]);
                        break;
                    case 'B':
                        $token_aux = encrypt(time() . '-' . $data['email']);
                        DB::table('external_app')->insert([
                            'id_partners' => $id_partner,
                            'id_companies' => $id_company,
                            'email' => $d['email'],
                            'first_name' => $d['pname'],
                            'last_name' => '',
                            'token' => $token_aux,
                            'ipaddr' => $request->getClientIp(),
                            'type' => 'merchant',
                            'idapp' => $id_app,
                            'date_send' => date('Y-m-d H:i:s')
                        ]);
                        break;
                }



                if (!isset($data_submit['behalf_merchants']) && !$errors_local[$cont]) {
                    $envelopes = null;
                    if (isset($d['array_service_import']) && $status == 4) {
                        $envelopes = $this->saveAndSignPDF($d, $partner, $company, $ps, null, $d['email'], $d['pdf_generate'], $layout);
                    }
                    $string_env = null;
                    if ($envelopes) {
                        foreach ($envelopes as $env) {
                            $string_env.=$env . ';';
                        }
                    }

                    DB::table('application')
                            ->where('id', $id_app)
                            ->update([
                                'envelope' => $string_env
                    ]);
                }
                $cont++;
            }



            if (isset($data_submit['behalf_merchants'])) {
                $envelopes = null;
                $external_app = $application->getExternalApp($token);

                $email = $external_app['email'];
                if ($data_submit['email_behalf']) {
                    $email = $data_submit['email_behalf'];
                }



                if (count($data_all_aux)) {
                    $daau_cont = 0;
                    $data_all_aux_temp = array();
                    foreach ($data_all_aux as $dauitem) {
                        $data_all_aux_temp[$daau_cont] = $dauitem;
                        $daau_cont++;
                    }
                    $envelopes = $this->saveAndSignPDF($data_all_aux_temp, $partner, $company, $ps, $external_app, $email, ['cc' => 1, 'ec' => 1], $layout);
                }



                $string_env = null;

                if ($envelopes) {
                    foreach ($envelopes as $env) {
                        $string_env.=$env . ';';
                    }
                }

                foreach ($apps_ids as $id) {
                    DB::table('application')
                            ->where('id', $id)->where('status', 4)
                            ->update([
                                'envelope' => $string_env
                    ]);
                }
            }


            return redirect()->route('application', ['token' => $token1])->with('success', 'The Application has been saved successfully');


//            return redirect()->route('applicationcreateuser', ['token' => $token1, 'partner' => $partner, 'company' => $company]);
        }
//        } else {
//            return view('application.notavailable');
//        }
    }

    public function getRulesImportApp() {
        return [
            'spreadsheet' => 'required|max:12000',
            'vcheck' => 'required|max:12000',
            'bstatement' => 'required|max:12000',
            'bsheet' => 'mimes:pdf,jpeg|max:12000',
            'taxreturn' => 'mimes:pdf,jpeg|max:12000',
            'term_of_use' => 'required',
        ];
    }

    public function upload_excel($file) {
        if ($file) {
            $extension = $file->getClientOriginalExtension();
            $name = $file->getClientOriginalName();
            $name = $this->cleanString(str_replace('.' . $extension, '', $name));
            $name = $name . '-' . uniqid() . '.' . $extension;
            $file->move(
                    Config::get('onlineapp.upload_onlineapp_dir'), $name
            );
            return $name;
        }

        return null;
    }

    public function excelDate($val) {

        $phpexcepDate = $val - 25569;
        return (date("m/d/Y", strtotime("+$phpexcepDate days", mktime(0, 0, 0, 1, 1, 1970))));
    }

    public function getRulesImportExcel() {
        return [
            'pname' => 'required|max:255',
            'cadr1' => 'required|max:255',
            'ccty1' => 'required|max:255',
            'state1' => 'required|size:2|alpha|in:AL,AK,AZ,AR,CA,CO,CT,DE,DC,FL,GA,HI,ID,IL,IN,IA,KS,KY,LA,MA,ME,MD,MI,MN,MS,MO,MT,NE,NV,NH,NJ,NM,NY,NC,ND,OH,OK,OR,PA,RI,SC,SD,TN,TX,UT,VT,VA,WA,WV,WI,WY,al,ak,az,ar,ca,co,ct,de,dc,fl,ga,hi,id,il,in,ia,ks,ky,la,ma,me,md,mi,mn,ms,mo,mt,ne,nv,nh,nj,nm,ny,nc,nd,oh,ok,or,pa,ri,sc,sd,tn,tx,ut,vt,va,wa,wv,wi,wy',
            'state2' => 'required|size:2|alpha|in:AL,AK,AZ,AR,CA,CO,CT,DE,DC,FL,GA,HI,ID,IL,IN,IA,KS,KY,LA,MA,ME,MD,MI,MN,MS,MO,MT,NE,NV,NH,NJ,NM,NY,NC,ND,OH,OK,OR,PA,RI,SC,SD,TN,TX,UT,VT,VA,WA,WV,WI,WY,al,ak,az,ar,ca,co,ct,de,dc,fl,ga,hi,id,il,in,ia,ks,ky,la,ma,me,md,mi,mn,ms,mo,mt,ne,nv,nh,nj,nm,ny,nc,nd,oh,ok,or,pa,ri,sc,sd,tn,tx,ut,vt,va,wa,wv,wi,wy',
            'cstate1' => 'required|size:2|alpha|in:AL,AK,AZ,AR,CA,CO,CT,DE,DC,FL,GA,HI,ID,IL,IN,IA,KS,KY,LA,MA,ME,MD,MI,MN,MS,MO,MT,NE,NV,NH,NJ,NM,NY,NC,ND,OH,OK,OR,PA,RI,SC,SD,TN,TX,UT,VT,VA,WA,WV,WI,WY,al,ak,az,ar,ca,co,ct,de,dc,fl,ga,hi,id,il,in,ia,ks,ky,la,ma,me,md,mi,mn,ms,mo,mt,ne,nv,nh,nj,nm,ny,nc,nd,oh,ok,or,pa,ri,sc,sd,tn,tx,ut,vt,va,wa,wv,wi,wy',
            'czip1' => 'required|size:5|regex:/^[0-9]+$/',
            'pphone' => 'required|size:10|regex:/^[0-9]+$/',
            'title' => 'required|max:255',
            'email' => 'required|email|max:255',
            'ssn' => 'required|size:9',
            'legal' => 'required|max:255',
            'dba' => 'required|max:255',
            'adr1' => 'required|max:255',
            'cty1' => 'required|max:255',
            'zip1' => 'required|size:5|regex:/^[0-9]+$/',
            'phone1' => 'required|size:10|regex:/^[0-9]+$/',
            'bdesc' => 'required|max:255',
            'bstruct' => 'max:255',
            'date' => 'required|max:255',
            'cdate' => 'max:255',
            'fti' => 'required|size:9',
            'adr2' => 'required|max:255',
            'adr2_apt' => 'max:255',
            'cty2' => 'required|max:255',
            'zip2' => 'required|size:5|regex:/^[0-9]+$/',
            'donor' => 'required|max:255',
            'duedate' => 'required|max:255',
            'bankname' => 'required|max:255',
            'bankrouting' => 'required|routingnumber|size:9|regex:/^[0-9]+$/',
            'banknumber' => 'required|min:4|max:17',
            'bankname_re' => 'required|max:255',
            'bankrouting_re' => 'required|routingnumber|size:9|regex:/^[0-9]+$/',
            'banknumber_re' => 'required|max:255',
            //AJ AK
            //'AJ'=>'size:1|in:P,A,X',
            //'AK'=>'size:1|in:P,A,X',
            'banktype' => 'required|size:1|in:C,S,c,s',
            'banktype_re' => 'required|size:1|in:C,S,c,s',
            'freq' => 'required|size:1|in:M,Q,B,A,m,q,b,a',
            'duedate' => 'required|numeric|min:1|max:31',
            'bdate' => 'required',
        ];
    }

    public function getMessagesImportExcel($row) {
        return [
            'bankrouting.routingnumber' => 'The cells in column "AT", row "' . $row . '" (ABA Routing number) must be a valid Routing Number.',
            'bankrouting_re.routingnumber' => 'The cells in column "AX", row "' . $row . '" (Fee ABA Routing number) must be a valid Routing Number.',
            'pname.required' => 'The cells in column "T", row "' . $row . '" (Contact Name) is required.',
            'pname.max' => 'The cells in column "T", row "' . $row . '" (Contact Name) is too long (Maximum 255).',
            'cadr1.required' => 'The cells in column "U", row "' . $row . '" (Contact Address) is required.',
            'cadr1.max' => 'The cells in column "U", row "' . $row . '" (Contact Address) is too long (Maximum 255).',
            'ccty1.required' => 'The cells in column "V", row "' . $row . '" (Contact City) is required.',
            'ccty1.max' => 'The cells in column "V", row "' . $row . '" (Contact City) is too long (Maximum 255).',
            'cstate1.required' => 'The cells in column "W", row "' . $row . '" (Contact State) is required.',
            'cstate1.size' => 'The cells in column "W", row "' . $row . '" (Contact State) must be 2 characters.',
            'cstate1.alpha' => 'The cells in column "W", row "' . $row . '" (Contact State) must be letters.',
            'cstate1.in' => 'The cells in column "W", row "' . $row . '" (Contact State) must be valid state.',
            'czip1.required' => 'The cells in column "X", row "' . $row . '" (Contact Zip) is required.',
            'czip1.size' => 'The cells in column "X", row "' . $row . '" (Contact Zip) must be 5 characters.',
            'czip1.regex' => 'The cells in column "X", row "' . $row . '" (Contact Zip) must be numbers.',
            'pphone.required' => 'The cells in column "Z", row "' . $row . '" (Contact Phone) is required.',
            'pphone.size' => 'The cells in column "Z", row "' . $row . '" (Contact Phone) must be 10 characters.',
            'pphone.regex' => 'The cells in column "Z", row "' . $row . '" (Contact Phone) must be numbers.',
            'bdate.required' => 'The cells in column "AA", row "' . $row . '" (Birth Date) is required.',
            'title.required' => 'The cells in column "AB", row "' . $row . '" (Position) is required.',
            'title.max' => 'The cells in column "AB", row "' . $row . '" (Position) is too long (Maximum 255).',
            'email.required' => 'The cells in column "Y", row "' . $row . '" (Contact E-mail) is required.',
            'email.email' => 'The cells in column "Y", row "' . $row . '" (Contact E-mail) must be a valid email.',
            'email.max' => 'The cells in column "Y", row "' . $row . '" (Contact E-mail) is too long (Maximum 255).',
            'ssn.required' => 'The cells in column "AC", row "' . $row . '" (Social Security Number) is required.',
            'ssn.size' => 'The cells in column "AC", row "' . $row . '" (Social Security Number) must be 9 characters.',
            'legal.required' => 'The cells in column "C", row "' . $row . '" (Legal Name) is required.',
            'legal.max' => 'The cells in column "C", row "' . $row . '" (Legal Name) is too long (Maximum 255).',
            'dba.required' => 'The cells in column "B", row "' . $row . '" (DBA Name) is required.',
            'dba.max' => 'The cells in column "B", row "' . $row . '" (DBA Name) is too long (Maximum 255).',
            'adr1.required' => 'The cells in column "D", row "' . $row . '" (Address) is required.',
            'adr1.max' => 'The cells in column "D", row "' . $row . '" (Address) is too long (Maximum 255).',
            'cty1.required' => 'The cells in column "E", row "' . $row . '" (City) is required.',
            'cty1.max' => 'The cells in column "E", row "' . $row . '" (City) is too long (Maximum 255).',
            'state1.required' => 'The cells in column "F", row "' . $row . '" (State) is required.',
            'state1.size' => 'The cells in column "F", row "' . $row . '" (State) must be 2 characters.',
            'state1.alpha' => 'The cells in column "F", row "' . $row . '" (State) must be letters.',
            'state1.in' => 'The cells in column "F", row "' . $row . '" (State) must be valid state.',
            'zip1.required' => 'The cells in column "G", row "' . $row . '" (Zip) is required.',
            'zip1.size' => 'The cells in column "G", row "' . $row . '" (Zip) must be 5 characters.',
            'zip1.regex' => 'The cells in column "G", row "' . $row . '" (Zip) must be numbers.',
            'phone1.required' => 'The cells in column "H", row "' . $row . '" (Phone) is required.',
            'phone1.size' => 'The cells in column "H", row "' . $row . '" (Phone) must be 10 characters.',
            'phone1.regex' => 'The cells in column "H", row "' . $row . '" (Phone) must be numbers.',
            'bdesc.required' => 'The cells in column "I", row "' . $row . '" (Business Description) is required.',
            'bdesc.max' => 'The cells in column "I", row "' . $row . '" (Business Description) is too long (Maximum 255).',
            'bstruct.max' => 'The cells in column "J", row "' . $row . '" (Business Structure) is too long (Maximum 255).',
            'date.required' => 'The cells in column "K", row "' . $row . '" (Date Formed) is required.',
            'date.max' => 'The cells in column "K", row "' . $row . '" (Date Formed) is too long (Maximum 255).',
            'cdate.max' => 'The cells in column "L", row "' . $row . '" (Current Ownership Date) is too long (Maximum 255).',
            'fti.required' => 'The cells in column "M", row "' . $row . '" (Federal Tax ID) is required.',
            'fti.size' => 'The cells in column "M", row "' . $row . '" (Federal Tax ID) must be 9 characters.',
            'adr2.required' => 'The cells in column "O", row "' . $row . '" (Billing Address) is required.',
            'adr2.max' => 'The cells in column "O", row "' . $row . '" (Billing Address) is too long (Maximum 255).',
            'cty2.required' => 'The cells in column "P", row "' . $row . '" (Billing City) is required.',
            'cty2.max' => 'The cells in column "P", row "' . $row . '" (Billing City) is too long (Maximum 255).',
            'state2.required' => 'The cells in column "Q", row "' . $row . '" (Billing State) is required.',
            'state2.size' => 'The cells in column "Q", row "' . $row . '" (Billing State) must be 2 characters.',
            'state2.alpha' => 'The cells in column "Q", row "' . $row . '" (Billing State) must be letters.',
            'state2.in' => 'The cells in column "Q", row "' . $row . '" (Billing State) must be valid state.',
            'zip2.required' => 'The cells in column "R", row "' . $row . '" (Billing Zip) is required.',
            'zip2.size' => 'The cells in column "R", row "' . $row . '" (Billing Zip) must be 5 characters.',
            'zip2.regex' => 'The cells in column "R", row "' . $row . '" (Billing Zip) must be numbers.',
            'donor.required' => 'The cells in column "AE", row "' . $row . '" (Number of Units) is required.',
            'donor.max' => 'The cells in column "AE", row "' . $row . '" (Number of Units) is too long (Maximum 255).',
            'bankname.required' => 'The cells in column "AT", row "' . $row . '" (Name on Bank Account) is required.',
            'bankname.max' => 'The cells in column "AT", row "' . $row . '" (Name on Bank Account) is too long (Maximum 255).',
            'bankrouting.required' => 'The cells in column "AU", row "' . $row . '" (ABA Routing number) is required.',
            'bankrouting.size' => 'The cells in column "AU", row "' . $row . '" (ABA Routing number) must be 9 characters.',
            'bankrouting.regex' => 'The cells in column "AU", row "' . $row . '" (ABA Routing number) must be numbers.',
            'banknumber.required' => 'The cells in column "AV", row "' . $row . '" (Bank Account Number) is required.',
            'banknumber.min' => 'The cells in column "AV", row "' . $row . '" (Bank Account Number) must be minimum 4 characters.',
            'banknumber.max' => 'The cells in column "AV", row "' . $row . '" (Bank Account Number) must be maximum 17 characters.',
            'bankname_re.required' => 'The cells in column "AX", row "' . $row . '" (Name on Fee Bank Account) is required.',
            'bankname_re.max' => 'The cells in column "AX", row "' . $row . '" (Name on Fee Bank Account) is too long (Maximum 255).',
            'bankrouting_re.required' => 'The cells in column "AY", row "' . $row . '" (Fee ABA Routing number) is required.',
            'bankrouting_re.size' => 'The cells in column "AY", row "' . $row . '" (Fee ABA Routing number) must be 9 characters.',
            'bankrouting_re.regex' => 'The cells in column "AY", row "' . $row . '" (Fee ABA Routing number) must be numbers.',
            'banknumber_re.required' => 'The cells in column "AZ", row "' . $row . '" (Fee Bank Account Number) is required.',
            'banknumber_re.max' => 'The cells in column "AZ", row "' . $row . '" (Fee Bank Account Number) is too long (Maximum 255).',
            'banktype.required' => 'The cells in column "AW", row "' . $row . '" (Account Type) is required.',
            'banktype.size' => 'The cells in column "AW", row "' . $row . '" (Account Type) must be 1 character.',
            'banktype.in' => 'The cells in column "AW", row "' . $row . '" (Account Type) must be "C" or "S".',
            'banktype_re.required' => 'The cells in column "BA", row "' . $row . '" (Fee Account Type) is required.',
            'banktype_re.size' => 'The cells in column "BA", row "' . $row . '" (Fee Account Type) must be 1 character.',
            'banktype_re.in' => 'The cells in column "BA", row "' . $row . '" (Fee Account Type) must be "C" or "S".',
            'freq.required' => 'The cells in column "BB", row "' . $row . '" (Property Payment Frequency) is required.',
            'freq.size' => 'The cells in column "BB", row "' . $row . '" (Property Payment Frequency) must be 1 character.',
            'freq.in' => 'The cells in column "BB", row "' . $row . '" (Property Payment Frequency) must be "M" or "Q" or "B" or "A".',
            'duedate.required' => 'The cells in column "BC", row "' . $row . '" (Property Payment Due Date) is required.',
            'duedate.numeric' => 'The cells in column "BC", row "' . $row . '" (Property Payment Due Date) must be numeric.',
            'duedate.min' => 'The cells in column "BC", row "' . $row . '" (Property Payment Due Date) must be numeric and between 1 and 31',
            'duedate.max' => 'The cells in column "BC", row "' . $row . '" (Property Payment Due Date) must be numeric and between 1 and 31',
                //AJ AK
                //'AJ'=>'size:1|in:P,A,X',
                //'AK'=>'size:1|in:P,A,X',
        ];
    }

    public function saveAndSignPDF($data, $partner, $company, $ps, $external_app = null, $client_mail, $pdf_generate, $layout = null, $errors_importing = null) {


        $application = new Application();
        $conv_fee = '$2.95';
        if (isset($data['pricing_code']) && $data['pricing_code']) {
            foreach ($ps as $p) {
                $p = get_object_vars($p);
                if ($this->in_array_services($p['service']) == 'cc') {
                    $pricing = DB::table('pricing')
                            ->join('price_table', 'price_table.idpt', '=', 'pricing.id_table')
                            ->where('service', $p['service'])
                            ->where('tlabel', $data['pricing_code'])
                            ->first();
                    if ($pricing) {
                        $pricing = get_object_vars($pricing);
                        if (isset($pricing['cost']))
                            $conv_fee = $pricing['cost'];
                        break;
                    }
                }
            }
        } else {
            foreach ($ps as $p) {
                if ($this->in_array_services($p->service) == 'cc') {
                    $pdb = 0;
                    if (isset($data['partnerdb'])) {
                        $pdb = $data['partnerdb'];
                    } elseif (isset($data[0]['partnerdb'])) {
                        $pdb = $data[0]['partnerdb'];
                    }

                    $cdb = 0;
                    if (isset($data['companydb'])) {
                        $cdb = $data['companydb'];
                    } elseif (isset($data[0]['companydb'])) {
                        $cdb = $data[0]['companydb'];
                    }

                    $pricing = $application->getPricingServices($pdb, $cdb);
                    foreach ($pricing as $dbp) {
                        if ($dbp->service == $p->service) {
                            $conv_fee = $dbp->cost;
                            break;
                        }
                    }
                }
            }
        }


        $name_contractPdf = uniqid() . '-contract';

        try {
            if (isset($data[0])) {
                $this->savePdf('application.contract', $name_contractPdf, array('errors_importing' => $errors_importing, 'external_app' => $external_app, 'ps' => $ps, 'data' => $data, 'convenience_fee' => $conv_fee, 'merchant' => $company, 'multiple' => true, 'pdf_generate' => $pdf_generate, 'layout' => $layout));
            } else {
                $this->savePdf('application.contract', $name_contractPdf, array('errors_importing' => $errors_importing, 'dba_name' => $data['dba'], 'ps' => $ps, 'data' => [0 => $data], 'convenience_fee' => $conv_fee, 'data' => [0 => $data], 'merchant' => $company, 'pdf_generate' => $pdf_generate, 'layout' => $layout));
            }
        } catch (\Exception $e) {

        }


        $envelopes = array();
        array_push($envelopes, $this->sign_doc($name_contractPdf, $client_mail));

        return $envelopes;
    }

    public function savePdf($view, $name, $args = null) {


        require_once(base_path() . '/vendor/tecnickcom/tcpdf/examples/tcpdf_include.php');
        $view = \View::make($view, $args)->render();
        //var_dump($view); exit();


        $pdf = new \TCPDF();
        $pdf->SetAutoPageBreak(true, PDF_MARGIN_BOTTOM);
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->SetMargins(4, 4, 4, true);
        $pdf->AddPage();
        $pdf->writeHTML(utf8_decode($view), true, false, true, false, '');
        $pdf->Output(Config::get('onlineapp.upload_onlineapp_dir') . $name . '.pdf', 'F');
    }

    public function delete_upload_file($name) {
        @unlink(Config::get('onlineapp.upload_onlineapp_dir') . $name);
        @unlink(Config::get('onlineapp.upload_onlineapp_dir') . $name);
    }

    public function appPricing($token, $ida, $id_partner, $id_company, $option) {
        $app = null;
        $data = null;
        if ($id_company == 'null') {
            if ($id_company == 'null') {
                $id_company = null;
            }
            $application = new Application();
            if ($ida > 0) {
                $app = DB::table('application')->where('id', $ida)->first();
                $data = json_decode(base64_decode($app->content));
                $data = get_object_vars($data);
            }

            $company = $application->getCompany($id_company);
            $partner = $application->getPartners($id_partner);
            $ps = $application->getPricingServices($partner[0]->partner_name, $company->subdomain_companies);

            for ($x = 0; $x < count($ps); $x++) {
                if ($ps[$x]->select == 2) {
                    $ps[$x]->nameinput = 'pricing_services_radio_' . $this->in_array_services($ps[$x]->service);
                }
            }

            if (isset($data['array_service']) && $data['array_service']) {
                $data['array_service'] = get_object_vars($data['array_service']);
            }


            switch ($option) {
                case 1:
                    return view('application.pricingPartial', array('ps' => $ps));
                    break;
                case 2:
                    return view('application.pricingPartialEdit', array('ps' => $ps, 'data' => $data));
                    break;
                case 3:
                    return $ps;
                    break;
            }
        }
    }

    public function sign_doc($name, $client_mail) {
        if ($client_mail) {
            try {

                if (file_exists(base_path() . '/app/CustomClass/docusign/src/DocuSign_Client.php') && is_readable(base_path() . '/app/CustomClass/docusign/src/DocuSign_Client.php')) {
                    require_once(base_path() . '/app/CustomClass/docusign/src/DocuSign_Client.php');
                } else
                    return null;
                if (file_exists(base_path() . '/app/CustomClass/docusign/src/service/DocuSign_RequestSignatureService.php') && is_readable(base_path() . '/app/CustomClass/docusign/src/service/DocuSign_RequestSignatureService.php')) {
                    require_once(base_path() . '/app/CustomClass/docusign/src/service/DocuSign_RequestSignatureService.php');
                } else
                    return null;


                $client_mail = trim($client_mail);
                $client = new \DocuSign_Client(Config::get('docusign.credentials'));
                if ($client->hasError()) {
                    echo "\nError encountered in client, error is: " . $client->getErrorMessage() . "\n";
                    return;
                }


                $service = new \DocuSign_RequestSignatureService($client);
                $emailSubject = "Please Sign: ePayments Contract";
                $emailBlurb = "Thank you";
                //            $tabs = array("signHereTabs" => array(array("documentId" => "1", "pageNumber" => "1", "anchorString" => "Sign here")));
                $recipients = array(new \DocuSign_Recipient("1", "1", $client_mail, $client_mail, null));
                $documents = array(
                    new \DocuSign_Document("Contract", "1", file_get_contents(Config::get('onlineapp.upload_onlineapp_dir') . $name . '.pdf')),
                );
                $status = 'sent';
                $response = $service->signature->createEnvelopeFromDocument(
                        $emailSubject, $emailBlurb, $status, $documents, $recipients, array()
                );

                /* [
                  'EmailSettings'=>[
                  'ReplyEmailAddressOverride'=>'test@test.com',
                  'ReplyEmailNameOverride'=>'Test'
                  ]
                  ] */

                $response = get_object_vars($response);
                //var_dump($response); exit();
                return $response['envelopeId'];
            } catch (\Exception $e) {
                //var_dump($e); exit();
                return null;
            }
        } else {
            return null;
        }
    }

    public function getRulesApplication() {
        return [
            'ttname' => 'max:255',
            'pname' => 'required|max:255',
            'cadr1' => 'required|max:255',
            'cadr1_apt' => 'max:255',
            'ccty1' => 'required|max:255',
            'cstate1' => 'required|max:255',
            'czip1' => 'required|size:5|regex:/^[0-9]+$/',
            'pphone' => 'required|size:10|regex:/^[0-9]+$/',
            'title' => 'required|max:255',
            'email' => 'required|email|max:255',
            'ssn' => 'required',
            'ppid' => 'max:255',
            'legal' => 'required|max:255',
            'dba' => 'required|max:255',
            'adr1' => 'required|max:255',
            'adr1_apt' => 'max:255',
            'cty1' => 'required|max:255',
            'state1' => 'required|max:255',
            'zip1' => 'required|size:5|regex:/^[0-9]+$/',
            'phone1' => 'required|size:10|regex:/^[0-9]+$/',
            'bdesc' => 'required|max:255',
            'bstruct' => 'max:255',
            'date' => 'max:255',
            'cdate' => 'max:255',
            'fti' => 'required|size:9',
            'adr2' => 'required|max:255',
            'adr2_apt' => 'max:255',
            'cty2' => 'required|max:255',
            'state2' => 'required|max:255',
            'zip2' => 'required|size:5|regex:/^[0-9]+$/',
            'freq' => 'required|max:255',
            'donor' => 'required|max:255',
            'duedate' => 'required|max:255',
            'bankname' => 'required|max:255',
            'bankrouting' => 'required|size:9|regex:/^[0-9]+$/',
            'banknumber' => 'required|min:4|max:17',
            'banktype' => 'required|max:255',
            'bankname_re' => 'required|max:255',
            'bankrouting_re' => 'required|size:9|regex:/^[0-9]+$/',
            'banknumber_re' => 'required|max:255',
            'banktype_re' => 'required|max:255',
            'vcheck' => 'mimes:pdf,jpeg|max:12000',
            'bstatement' => 'mimes:pdf,jpeg|max:12000',
            'bsheet' => 'mimes:pdf,jpeg|max:12000',
            'taxreturn' => 'mimes:pdf,jpeg|max:12000',
            'driver' => 'mimes:pdf,jpeg|max:12000',
            'ccstatement' => 'mimes:pdf,jpeg|max:12000',
            'cchticket' => 'numeric',
            'ccmticket' => 'numeric',
            'vhticket' => 'numeric',
            'vcticket' => 'numeric',
            'avticket' => 'numeric',
            'hticket' => 'numeric',
            'cticket' => 'numeric',
            'mticket' => 'numeric',
            'term_of_use' => 'required',
            'bdate' => 'required',
        ];
    }

    public function downloadFile($file) {
        $fp = fopen(Config::get('onlineapp.upload_onlineapp_dir') . $file, 'r+');
        $output = stream_get_contents($fp);
        fclose($fp);
        header('Content-Type: application/octet-stream; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $file);
        header('Content-Length: ' . strlen($output));
        echo $output;
        exit;
    }

}
