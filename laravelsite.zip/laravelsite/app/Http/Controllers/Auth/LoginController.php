<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Controllers\DashboardController;
use App\Http\Models\Partners;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Auth;
use App\Model;
use App\Helpers\Menu;
use DB;
use App\Helpers\Token;


class LoginController extends Controller
{
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

    use AuthenticatesUsers;


    /**
     * Where to redirect users after login.
     *
     * @var string
     */
//    protected $redirectTo = '/roles';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except(['logout', 'changepassword']);
    }

    public function login(Request $request)
    {
        $obj_admin=new \App\Http\Models\Admins();
        $user = User::where(['username' => $request->login, 'userpassw' => sha1($request->password)])->first();
        if (!empty($user)) {
            $login = new User();
            $idlevel = "";
            $flag = false;
            $level = "";
            switch ($request->level) {
                case 'b':
                    // branch level
                    $branch = Model\Branch::where('subdomain_branch', '=', $request->subdomain)->first();
                    if ($branch){
                        $userAccess = Model\UsersAccessBranch::where('users_admin_id', '=', $user->id)
                            ->where('branch_id', '=', $branch->id)
                            ->first();
                        if(!empty($userAccess) || $obj_admin->isMaster($user->id)){
                            $idlevel = $branch->id;
                            $flag = true;
                            $level = "B";
                        }
                        else {
                                return redirect("/".$request->level."/".$request->subdomain)->with(['status' => true]);
                        }
                    }
                    else {
                        return redirect('/login')->with(['status' => true]);
                    }
                    break;
                case 'p':
                    // partner level
                    $partner = Model\Partners::where('partner_name', '=', $request->subdomain)->first();
                    if ($partner){
                        $userAccess = Model\UsersAccessPartners::where('users_admin_id', '=', $user->id)
                            ->where('partners_id', '=', $partner->id)
                            ->first();
                        if(!empty($userAccess) || $obj_admin->isMaster($user->id)){
                            $idlevel = $partner->id;
                            $flag = true;
                            $level = "P";
                        }
                        else {
                                return redirect("/".$request->level."/".$request->subdomain)->with(['status' => true]);
                        }
                    }
                    else {
                        return redirect('/login')->with(['status' => true]);
                    }
                    break;
                case 'g':
                    // group level
                    $company = Model\Companies::where('company_name', '=', $request->subdomain)->first();
                    if ($company){
                        $userAccess = Model\UsersAccessCompany::where('users_admin_id', '=', $user->id)
                            ->where('companies_id', '=', $company->id)
                            ->first();
                        if(!empty($userAccess) || $obj_admin->isMaster($user->id)){
                            $idlevel = $company->id;
                            $flag = true;
                            $level = "G";
                        }
                        else {
                                return redirect("/".$request->level."/".$request->subdomain)->with(['status' => true]);
                        }
                    }
                    else {
                        return redirect('/login')->with(['status' => true]);
                    }
                    break;
                case 'm':
                    // merchant level
                    $merchant = Model\Properties::where('subdomain_clients', '=', $request->subdomain)->first();
                    if ($merchant){
                        $userAccess = Model\UsersAccessMerchant::where('users_admin_id', '=', $user->id)
                            ->where('property_id', '=', $merchant->id)
                            ->first();
                        if(!empty($userAccess) || $obj_admin->isMaster($user->id)){
                            $idlevel = $merchant->id;
                            $flag = true;
                            $level = "M";
                        }
                        else {
                                return redirect("/".$request->level."/".$request->subdomain)->with(['status' => true]);
                        }
                    }
                    else {
                        return redirect('/login')->with(['status' => true]);
                    }
                    break;
                default:
                    // regular Login

                    break;
            }

            $login = new User();
            $login->id = $user->id;
            $login->username = $user->username;
            Auth::login($login);


            if ($flag) {
                $atoken = Menu::createToken($idlevel, $level);
                return redirect()->action('DashboardController@dashboard', [$atoken]);

            } else {

                return redirect()->route('entityselection');
            }


        } else {
            if(!empty($request->level))
                return redirect("/".$request->level."/".$request->subdomain)->with(['status' => true]);
            return redirect('/login')->with(['status' => true]);
        }
    }

    public function logout($token, Request $request)
    {
        $this->guard()->logout();
        $request->session()->flush();
        $request->session()->regenerate();

        $atoken = decrypt($token);
        $level = strtolower($atoken['level']);
        $idlevel = $atoken['level_id'];
        $subdomain = "";

        switch ($level) {
            case 'b':
                $subdomain = "/".Model\Branch::find($idlevel)->subdomain_branch;
                break;
            case 'p':
                $subdomain = "/".Model\Partners::find($idlevel)->partner_name;
                break;

            case 'g':
                $subdomain = "/".Model\Companies::find($idlevel)->subdomain_companies;
                break;

            case 'm':
                $subdomain = "/".Model\Properties::find($idlevel)->subdomain_clients;
                break;
            case 'a':
                $level="";
                break;

        };
        return redirect("/".$level.$subdomain);
    }


    public function changepassword($token, Request $request, $msg = "")
    {
        $atoken = decrypt($token);

        $dtoken = $token;
        //$atoken='804127|2450|'.$time.'|'.'code'.'|key';
        list($web_user_id, $property_id, $time, $code, $apikey) = explode('|', $atoken);
        if ($property_id <= 0) {
            return response()->json(array('response' => 262, 'responsetext' => 'Invalid Token'));
        }

        if ($web_user_id <= 0) {
            return response()->json(array('response' => 263, 'responsetext' => 'Invalid Token'));
        }

        if ($apikey != config('app.appAPIkey')) {
            // return response()->json(array('response'=>261,'responsetext'=>'Invalid Token'));
        }
        $obj_user = new User();
        if ($code != $obj_user->get1UserInfo($web_user_id, 'password')) {
            return response()->json(array('response' => 261, 'responsetext' => 'Token Expired'));
        }

        $obj_property = new Model\Properties();

        $merchant = $obj_property->getPropertyInfo($property_id);
        $merchant['logo'] = $obj_property->getPropertyLogo($merchant['logo'], $merchant['id_companies'], $merchant['id_partners']);
        $idproperty = $merchant['id'];
        $idcompany = $merchant['id_companies'];
        $idpartner = $merchant['id_partners'];

        $setting_ftime = $obj_property->getLoginSetting($property_id, $idcompany, $idpartner);
        $setting_qp = $obj_property->getQPaySetting($idproperty, $idcompany, $idpartner);
        $base_parts = explode('/', $request->url());
        array_pop($base_parts);
        array_pop($base_parts);
        if ($msg != '') {
            array_pop($base_parts);
        }
        $obj_partners = new Partners();
        $base_parts[] = $obj_partners->getDomain($idpartner);
        $base_parts[] = 'properties';
        $base_parts[] = $merchant['subdomain_clients'];


        $atoken = encrypt($web_user_id . '|' . $property_id . '|' . time() . '|' . config('app.appAPIkey'));
        $base_url = implode('/', $base_parts);
        $data = array('pageTitle' => 'Password', 'merchant' => $merchant, 'setting_ftime' => $setting_ftime, 'setting_qp' => $setting_qp, 'base_url' => $base_url, 'atoken' => $atoken);
        $data['dtoken'] = $dtoken;
        if ($msg != '') {
            $data['msgCode'] = 'password' . $msg;
        }
        $data['hidemerchantinfo'] = $obj_property->getPropertySettings($idproperty, $idcompany, $idpartner, 'hidemerchantinfo');
        $data['chat'] = $obj_property->getPropertySettings($idproperty, $idcompany, $idpartner, 'LIVECHAT');
        $data['chatcontent'] = $obj_property->getPropertySettings($idproperty, $idcompany, $idpartner, 'LIVECHATCONTENT');
        return view('password', $data);
    }

    public function loginb($subdomain)
    {
        $branch_db = DB::table('branch')->where('subdomain_branch', $subdomain)->first();
        if ($branch_db) {
            $logo = getLogo(['level' => "B", 'level_id' => $branch_db->id]);
            return view('auth.login', array('level' => 'b', 'subdomain' => $subdomain, 'logo' => $logo, 'name'=>$branch_db->name));
        } else {
            return redirect('/');
        }
    }

    public function loginp($subdomain)
    {
        $partner_db = DB::table('partners')->where('partner_name', $subdomain)->first();

        if ($partner_db) {
            $logo = getLogo(['level' => "P", 'level_id' => $partner_db->id]);
            return view('auth.login', array('level' => 'p', 'subdomain' => $subdomain, 'logo' => $logo, 'name'=>$partner_db->partner_title));
        } else {
            return redirect('/');
        }
    }

    public function loging($subdomain)
    {
        $group_db = DB::table('companies')->where('subdomain_companies', $subdomain)->first();
        if ($group_db) {
            $logo = getLogo(['level' => "G", 'level_id' => $group_db->id]);
            return view('auth.login', array('level' => 'g', 'subdomain' => $subdomain, 'id' => $group_db->id, 'logo' => $logo, 'name'=>$group_db->company_name));
        } else {
            return redirect('/');
        }
    }

    public function loginm($subdomain)
    {
        $merchant_db = DB::table('properties')->where('subdomain_clients', $subdomain)->first();
        if ($merchant_db) {
            $logo = getLogo(['level' => "M", 'level_id' => $merchant_db->id]);
            return view('auth.login', array('level' => 'm', 'subdomain' => $subdomain, 'id' => $merchant_db->id, 'logo' => $logo, 'name'=>$merchant_db->name_clients));
        } else {
            return redirect('/');
        }
    }
    
    public function loginsso($token,Request $request)
    {
        if (!validateToken($token)) {
            return redirect(route('accessdenied'));
        }
        list($atoken,$time,$oid) = explode('|',decrypt($token));
        $atoken=json_decode($atoken,true);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $idadmin= $atoken['admin_id'];
        $olduser= \Illuminate\Support\Facades\DB::table('users')->where('id',$idadmin)->first();
        if(empty($olduser)){
            return redirect(route('accessdenied'));
        }
        $obj_admin=new \App\Http\Models\Admins();
        $user = User::where(['username' => $olduser->login, 'userpassw' => $olduser->password])->first();
        if (!empty($user)) {
            $login = new User();
            $flag = true;
            switch ($level) {
                case 'B':
                    // branch level
                    $branch = Model\Branch::where('id', '=', $idlevel)->first();
                    if ($branch){
                        $userAccess = Model\UsersAccessBranch::where('users_admin_id', '=', $user->id)
                            ->where('branch_id', '=', $branch->id)
                            ->first();
                        if(!empty($userAccess) || $obj_admin->isMaster($user->id)){
                            $idlevel = $branch->id;
                            $flag = true;
                            $level = "B";
                        }
                        else {
                                return redirect('/login')->with(['status' => true]);
                        }
                    }
                    else {
                        return redirect('/login')->with(['status' => true]);
                    }
                    break;
                case 'P':
                    // partner level
                    $partner = Model\Partners::where('id', '=', $idlevel)->first();
                    if ($partner){
                        $userAccess = Model\UsersAccessPartners::where('users_admin_id', '=', $user->id)
                            ->where('partners_id', '=', $partner->id)
                            ->first();
                        if(!empty($userAccess) || $obj_admin->isMaster($user->id)){
                            $idlevel = $partner->id;
                            $flag = true;
                            $level = "P";
                        }
                        else {
                                return redirect('/login')->with(['status' => true]);
                        }
                    }
                    else {
                        return redirect('/login')->with(['status' => true]);
                    }
                    break;
                case 'G':
                    // group level
                    $company = Model\Companies::where('id', '=', $idlevel)->first();
                    if ($company){
                        $userAccess = Model\UsersAccessCompany::where('users_admin_id', '=', $user->id)
                            ->where('companies_id', '=', $company->id)
                            ->first();
                        if(!empty($userAccess) || $obj_admin->isMaster($user->id)){
                            $idlevel = $company->id;
                            $flag = true;
                            $level = "G";
                        }
                        else {
                                return redirect('/login')->with(['status' => true]);
                        }
                    }
                    else {
                        return redirect('/login')->with(['status' => true]);
                    }
                    break;
                case 'M':
                    // merchant level
                    $merchant = Model\Properties::where('id', '=', $idlevel)->first();
                    if ($merchant){
                        $userAccess = Model\UsersAccessMerchant::where('users_admin_id', '=', $user->id)
                            ->where('property_id', '=', $merchant->id)
                            ->first();
                        if(!empty($userAccess) || $obj_admin->isMaster($user->id)){
                            $idlevel = $merchant->id;
                            $flag = true;
                            $level = "M";
                        }
                        else {
                                return redirect('/login')->with(['status' => true]);
                        }
                    }
                    else {
                        return redirect('/login')->with(['status' => true]);
                    }
                    break;
                default:
                    // regular Login
                    return redirect('/login')->with(['status' => true]);
                    break;
            }

            $login = new User();
            $login->id = $user->id;
            $login->username = $user->username;
            Auth::login($login);


            if ($flag) {
                $atoken = Menu::createToken($idlevel, $level);
                return redirect()->action('DashboardController@dashboard', [$atoken]);

            } else {

                return redirect()->route('entityselection');
            }


        } else {
            return redirect('/login')->with(['status' => true]);
        }
    }

}
