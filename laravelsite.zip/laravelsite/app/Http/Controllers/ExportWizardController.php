<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Model\ExportWizard;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Http\Models\Autopayments;
use App\Http\Models\Outboundpayments;
use App\Http\Models\Settlement;
use App\Http\Models\Transactions;

class ExportWizardController extends Controller {

    function __construct() {
        $this->middleware('auth');
    }

    public function main($token, $tableName = null, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $obj_ewizard = new ExportWizard();
        $data_post = array();
        $data_fields = array();
        $advFilter=null;
        
        if (!empty($tableName)) {
            $table_db = $obj_ewizard->getTableByName($tableName);
            $data_post['table_name'] = $tableName;
            if ($table_db) {
                $table_name = $table_db->table_name;
                $tableF="\App\Http\Models\\".$table_name;
                $objT=new $tableF();
                $table_description=$table_db->description;
                $filterC="\App\Http\Models\\".$table_db->filter;
                $table_fields_array=array();
                if(!empty($table_db->filter)){
                    $objF=new $filterC();
                    $advFilter=$objF->getAdvancedFilters($level,$idlevel);
                }
                $table_fields_array = $objT->getXFields($level,$idlevel,true);
                $table_formats=explode(',',$table_db->formats_toapply);
                $data_fields=$table_fields_array;
            }
        }
        
        if(empty($data_fields)){
            return redirect()->back();

        }
        $tables=array('name'=>$tableName,'description'=>$table_description);
        //$templates = $obj_ewizard->getTemplates(Auth::id());
        $templates=array();
        
        return view('exportwizard.exportwizard', array(
            'templates' => $templates,
            'datafields' => $data_fields,
            'dataformats' => $table_formats,
            'data_post' => $data_post, 
            'advFilter' => $advFilter,
            'tables' => $tables, 
            'pageTitle' => 'Export Wizard',
            'token' => $token)
            );
    }

    public function save($token, $action, $id_template, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $data_post = $request->all();
        unset($data_post['_token']);

        $table_name = $data_post['table_name'];
        $filename = $data_post['file_name'];
        $description = $data_post['description'];
        $obj_ewizard = new ExportWizard();
        $table_db = $obj_ewizard->getTableByName($table_name);
        $table_fields = $table_db->fields;
        $table_fields_array = json_decode($table_fields, 1);
        $query = DB::table($table_name);
        $data_save = array();

        foreach ($table_fields_array as $item => $key) {
            $item_array = explode('|', $key);
            if (count($item_array) > 1) {
                $query = $query->join($item_array[0], "$item_array[0]" . "." . "$item_array[1]", '=', "$table_name" . "." . "$item_array[2]");
            }
        }
        $array_fields = array();
        $array_fixlength = array();
        $array_fixsize = array();
        $array_fixpadding = array();
        $array_fixcharacter = array();
        $array_fixformat = array();

        foreach ($data_post as $item => $key) {
            if (strpos($item, 'field') === 0) {
                $query->addSelect($key);
                $array_fields[] = $key;
            }

            if (strpos($item, 'fixlength') === 0) {
                $array_fixlength[] = $key;
            }

            if (strpos($item, 'fixsize') === 0) {
                $array_fixsize[] = $key;
            }

            if (strpos($item, 'fixpadding') === 0) {
                $array_fixpadding[] = $key;
            }

            if (strpos($item, 'fixcharacter') === 0) {
                $array_fixcharacter[] = $key;
            }

            if (strpos($item, 'fixformat') === 0) {
                $array_fixformat[] = $key;
            }
        }
        $data_save['table_name'] = $table_name;
        $data_save['fields'] = $array_fields;
        $data_save['fixlength'] = $array_fixlength;
        $data_save['fixsize'] = $array_fixsize;
        $data_save['fixpadding'] = $array_fixpadding;
        $data_save['fixcharacter'] = $array_fixcharacter;
        $data_save['fixformat'] = $array_fixformat;
        $data_save['separator'] = $separator;
        $data_save['file_name'] = $filename;
        $data_save['description'] = $description;
        $id_template_db = null;
        if ($action == 'create') {
            $id_template_db = $obj_ewizard->createTemplate(Auth::id(), $data_save);
        } else {
            $id_template_db = $id_template;
            $obj_ewizard->saveTemplate(Auth::id(), $data_save, $id_template);
        }
        return redirect()->route('exportwizardedit', array('token' => $token, 'id' => $id_template_db))->with('success', 'The element was saved successfully');
    }

    public function edit($token, $id, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];


        $obj_ewizard = new ExportWizard();
        $templates = $obj_ewizard->getTemplates(Session::get('user_logged')['id']);
        $tables = $obj_ewizard->getTables();
        $template = $obj_ewizard->getTemplate($id);
        $fields_db = json_decode($template->fields, 1);
        $table_db = $obj_ewizard->getTableByName($fields_db['table_name']);
        $data_fields = array();
        if ($table_db) {
            $table_fields = $table_db->fields;
            $table_fields_array = json_decode($table_fields, 1);
            foreach ($table_fields_array as $item => $key) {
                $item_array = explode('|', $key);
                if (count($item_array) > 1) {

                } else {
                    $data_fields[$item] = $key;
                }
            }
        }

        // var_dump($fields_db['fixlength']); exit();

        if ($request->get('table_name') !== null) {
            return view('admin.exportwizardedit', array('dataselected' => null, 'template_id' => $id, 'templates' => $templates, 'datafields' => $data_fields, 'data_post' => $request->all(), 'tables' => $tables, 'pageTitle' => 'Export Wizard', 'token' => $token));
        } else {
            $data_post['separator'] = $fields_db['separator'];
            $data_post['file_name'] = $fields_db['file_name'];
            $data_post['description'] = $fields_db['description'];
            $data_post['table_name'] = $fields_db['table_name'];
            $data_post['number_of_fields'] = count($fields_db['fields']);
            return view('exportwizard.exportwizardedit', array('dataselected' => $fields_db, 'template_id' => $id, 'templates' => $templates, 'datafields' => $data_fields, 'data_post' => $data_post, 'tables' => $tables, 'pageTitle' => 'Export Wizard', 'token' => $token));
        }
    }

    public function export($token, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        
        $data_post = $request->all();
        unset($data_post['_token']);

        $table_name = $data_post['table_name'];
        $filename = $data_post['file_name'];
        $description = $data_post['description'];
        $separator = $data_post['separator'];
        $format = $data_post['table_format'];
        $filter=null;
        if(isset($data_post['exfilter'])){
            $filter= json_decode(base64_decode($data_post['exfilter']),true);
        }
        $obj_ewizard = new ExportWizard();
        $table_db = $obj_ewizard->getTableByName($table_name);
        $tableF="\App\Http\Models\\".$table_name;
        $objT=new $tableF();
        $table_fields_array = $objT->getXFields($level,true);

        switch ($separator) {
            case 'comma':
                $separator = ',';
                break;
            case 'space':
                $separator = ' ';
                break;
            case 'tab':
                $separator = "\t";
                break;
            case 'semicolon':
                $separator = ';';
                break;
            case 'pipeline':
                $separator = '|';
                break;
            case 'none':
                $separator = '';
                break;
        }

        $array_fields = array();
        $array_fixlength = array();
        $array_fixsize = array();
        $array_fixpadding = array();
        $array_fixcharacter = array();
        $array_fixformat = array();

        foreach ($data_post as $item => $key) {
            if (strpos($item, 'field') === 0 && $key!='__skip__' && $item!='fieldx') {
                $array_fields[] = $key;
            }
            if (strpos($item, 'fixlength') === 0) {
                $array_fixlength[] = $key;
            }
            if (strpos($item, 'fixsize') === 0) {
                $array_fixsize[] = $key;
            }
            if (strpos($item, 'fixcharacter') === 0) {
                $array_fixcharacter[] = str_replace('+',' ',$key);
            }
            if (strpos($item, 'fixpadding') === 0) {
                $array_fixpadding[] = $key;
            }
            if (strpos($item, 'fixformat') === 0) {
                $array_fixformat[] = $key;
            }
        }
        $query=$objT->getByFilter($idlevel,$level,$filter);
        $data_db = $query->get();
        $str_export = '';
        
        if($format==0){
            //excel
            $sql = $query->toSql();
            $bindings = $query->getBindings();
            $sql1=explode(' from ',$sql);
            $sqltmp='select '.implode(',',$array_fields).' from '.$sql1[1];
            $sql_ready = $sqltmp;
            foreach ($bindings as $replace) {
                $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
            }
            $sqlEncrypted=encrypt($sql_ready);
            $exp=new ExportController();
            $exp->export('excel', $filename, $sqlEncrypted);
        }
        else {
            //CSV, Text and others
            foreach ($data_db as $record) {
                for ($x = 0; $x < count($array_fields); $x++) {
                    $field_name_array = explode('.', $array_fields[$x]);

                    if (count($field_name_array) == 1) {
                        $record = (array) $record;
                        $value = $record[$array_fields[$x]];
                    } else {
                        $record = (array) $record;
                        $value = $record[$field_name_array[1]];
                    }

                    if (isset($array_fixformat[$x]))
                        switch ($array_fixformat[$x]) {
                            case 'nnnncc':
                                $value = number_format(floatval($value), 2, "", "");
                                break;
                            case 'nnnn.cc':
                                $value = number_format(floatval($value), 2, ".", "");
                                break;
                            case 'yyyymmdd':
                                $value = date('Ymd', strtotime($value));
                                break;
                            case 'yymmdd':
                                $value = date('ymd', strtotime($value));
                                break;
                            case 'mmddyyyy':
                                $value = date('mdY', strtotime($value));
                                break;
                            case 'mm/dd/yyyy':
                                $value = date('m/d/Y', strtotime($value));
                                break;
                        }

                    if ($array_fixlength[$x] == 'yes') {
                        if($array_fixsize[$x]<0){
                           $array_fixsize[$x]=abs($array_fixsize[$x]); 
                           $array_fixpadding[$x]='pleft';
                        }
                        switch ($array_fixpadding[$x]) {
                            case 'pleft':
                                $value = substr($value, $array_fixsize[$x] * -1, strlen($value));
                                $value = str_pad($value, $array_fixsize[$x], $array_fixcharacter[$x], STR_PAD_LEFT);
                                break;
                            case 'pright':
                            default:    
                                $value = substr($value, 0, $array_fixsize[$x]);
                                $value = str_pad($value, $array_fixsize[$x], $array_fixcharacter[$x]);
                                break;
                        }
                    }

                    if ($x + 1 < count($array_fields)) {
                        $str_export .= $value . $separator;
                    } else {
                        $str_export .= $value;
                    }
                }

                $str_export .= chr(13) . chr(10);
            }
        }
        header('Content-Type: application/octet-stream; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename . '.' . 'csv');
        header('Content-Length: ' . strlen($str_export));
        echo $str_export;
        exit;
    }

    public function deleteTemplate($token, $id) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];


        $obj_ewizard = new ExportWizard();
        $obj_ewizard->deleteTemplate($id);

        return redirect()->route('exportwizard', array('token' => $token))->with('success', 'The element was removed successfully');
    }

}
