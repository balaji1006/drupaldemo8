<?php

namespace App\Http\Controllers;

use App\Model;
use App\Model\Partners;
use App\Model\Layout;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Image;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;

class ManagePartnerController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    function managepartners($token, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'B' && $level!='A') {
            return redirect(route('accessdenied'));
        }

        $partner_obj = new Partners();
        $partners = $partner_obj->getPartnersByFilter($level, [$idlevel]);

        $filter = \DataFilter::source($partners);

        $filter->add('partner_title', 'Name', 'text');
        $filter->add('partner_name', 'Subdomain', 'text');
        $filter->add('layout.lay_name', 'Layout', 'text');
        $filter->add('last_updated_by', 'Last Updated By', 'text')->attributes(array('style' => 'max-width:140px;'));
        $filter->submit('Search');
        $filter->reset('Reset');
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add($token, $token)->style("display:none;");
        $grid->add('id', 'ID')->style("display:none;");
        $grid->add('partner_title', 'Name');
        $grid->add('partner_name', 'Subdomain');
        $grid->add('layout', 'Layout');
        $grid->add('last_updated', 'Last Updated')->cell(function ($value) {
            $value = strtotime($value);
            return date("M d, Y", $value);
        });
        $grid->add('last_updated_by', 'Last Updated By');

        $grid->add('actionvalue', 'Action');


        $grid->row(
                function ($row) {
            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;
            $idadmin = $row->cells[1]->value;

          //  $open_link = '<li><a href="" >Open</a></li>';

            $edit_link = '<li><a href="../partneredit/' . $token . '/' . $id . '" >Edit</a></li>';
            //$delete_link = '<li><a onclick="deletepartner(' . $id . ')" >Delete</a></li>';

                    $token_p = \Illuminate\Support\Facades\Crypt::encrypt(['level' => "P", 'level_id' => $id]);
                    
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret white-font-color" ></span></button>
								<ul class="dropdown-menu">
								<li><a href="#" onclick="openg(\''.$token_p.'\');" >Open</a></li>
							<li><a data="' . $id . '" class="partner_details_link">Detail</a></li>
							' . $edit_link . '
							<li><a onclick="javascript:showModalNotes('.$id.','."'P'".');">Notes</a></li>
														  </ul>
	 													</div>';
            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));
        return view('manage.partners.partners', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function addpartner($token) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        if ($level != 'B' && $level != 'A') {
            return redirect(route('accessdenied'));
        }
        return view('manage.partners.addpartner', array('token' => $token));
    }

    function selectlayout() {
        $obj_layout = new Layout();
        $layout = $obj_layout->getLayoutsObj()->get();
        return view('manage.partners.layouts', array('layouts' => $layout));
    }

    function selectpartner() {
        $obj_partner = new Partners();
        $partner = $obj_partner->getPartners();
        return view('manage.partners.selectpartner', array('partners' => $partner));
    }

    function selectpartner1($token) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $obj_partner = new Partners();
        $partner = $obj_partner->getPartners1($idlevel);
        return view('manage.partners.selectpartner', array('partners' => $partner));
    }

    function savepartner($token, Request $request) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken = ['level'];

        $request->validate([
            'txttitle' => 'required|max:250',
            'txtname' => 'required|max:250',
            'txtid' => 'required|max:50',
            'ddllayout' => 'required|max:11',
            'logo' => 'required',

        ]);

        $partners = "";
        $partners = (array) $partners;
        $partners['title'] = $request['txttitle'];
        $partners['name'] = $request['txtname'];
        $partners['ID'] = $request['txtid'];
        $partners['layout'] = $request['ddllayout'];


        $partners['updated_by'] = Auth::user()->username;
        $partners['branch'] = $idlevel;
        $objpartners = new Partners();
        if ($request->hasFile('logo')) {

            $newlogof = $idlevel . '_' . time() . '_logo.jpg';
            Image::make($request->file('logo')->getRealPath())->widen(255, function ($constraint) {
                $constraint->upsize();
            })->heighten(72, function ($constraint) {
                $constraint->upsize();
            })->resizeCanvas(255, 72, 'center', false, 'ffffff')->save('logos/partners/' . $newlogof, 100);

            $partners['logo'] = $newlogof;
        }
        $objpartners->savePartner($partners);
        return redirect()->route('Partners', array('token' => $token))->with('success', 'The Partner saved successfully');
    }

    function deletepartner($id) {
        $objpartners = new Partners();
        if ($objpartners->deletePartner($id)) {
            return array('errcode' => '0', 'message' => 'Partner deleted successfully.');
        } else {
            return array('errcode' => '1', 'message' => 'Error deleting record.');
        }
    }

    function partnerdetail($token, $partner_id){
        $array_token = decrypt($token);
        $idlevel = isset($array_token['id'])?$array_token['id']:null;
        $level = isset($array_token['type'])?$array_token['type']:null;
        $idadmin = isset($array_token['iduser'])?$array_token['iduser']:null;
       // $token = Crypt::encrypt($data.'|'.time().'|'.config('app.appAPIkey'));

        //security
       // $objAdminAuth = new AuthAdminController();
        //$objAdminAuth->checkAuthPermissions($array_token['iduser']);

        $partners = new Partners();
        $partnerdetail = $partners->getPartnerDetail($idlevel, $level, $partner_id);
        $partnerdetailHtml = view('admin.partneredit',array('pageTitle'=>'Edit Partner Detail', 'partnerdetail' => $partnerdetail, 'token' => $token, 'idadmin' => $idadmin, 'idlevel' => $idlevel))->render();
        return response()->json( array('errcode' => 0, 'msg' => $partnerdetailHtml) );


    }

    function getPartnerDetails($token, Request $request) {
        $id = $request->get('id');
        $objpartner = new Partners();
        $partner_db = $objpartner->getPartnerdetail($id);
        return view('manage.partners.partnerdetails', array('partner' => $partner_db));
    }

    function editPartner($token, $id) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        $objpartner = new Partners();
        $partner_db = $objpartner->getPartnerdetail($id);
        $grid=null;
        if($level=='A'){
            $apiobj=new \App\Http\Models\ApiUser();
            $keys=$apiobj->getByLevel($id, 'P');
            $grid = \DataGrid::source($keys);
            $grid->add($token, $token)->style("display:none;");
            $grid->add('idapi', 'id')->style("display:none;");
            $grid->add('apiusername', 'Legacy Username');
            $grid->add('lvcode', 'Token');
            $grid->add('created_on','Date Created');
            $grid->add('actionvalue', 'Action')->style("text-align:right;");
            $grid->row(
                    function ($row) {
                $id = $row->cell('idapi')->value;
                $edit_link = '';
                $delete_link = '<li><a onclick="deletekey(' . $id . ')" >Delete</a></li>';
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                                <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
                                                                            <span class="caret" ></span></button>
                                                                    <ul class="dropdown-menu">
                                                            ' . $edit_link . '
                                                            ' . $delete_link . '
                                                                                                                      </ul>
                                                                                                                    </div>';
                $row->cell('idapi')->style("display:none;");
                $row->cells[0]->style("display:none;");
            }
            );
            $grid->orderBy('idapi', 'ASC');
            $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));
        }
        return view('manage.partners.editpartner', array('partner' => $partner_db, 'token' => $token,'grid'=>$grid,'idpartner'=>$id));
    }

    function updatepartner(Request $request) {
        $id = $request['id'];
        $token = $request['token'];
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken = ['level'];

        $request->validate([
            'txttitle' => 'required|max:250',
            'txtname' => 'required|max:250',
            'txtid' => 'required|max:50',
            'ddllayout' => 'required|max:11',

        ]);

        $partners = "";
        $partners = (array) $partners;
        $partners['title'] = $request['txttitle'];
        $partners['name'] = $request['txtname'];
        $partners['ID'] = $request['txtid'];
        $partners['layout'] = $request['ddllayout'];
        $partners['updated_by'] = Auth::user()->username;
        $partners['branch'] = $idlevel;

        $objpartners = new Partners();
        $logof = $request['logof'];
        if ($request->hasFile('logo')) {
            if (trim($logof) != '') {
                if (file_exists('/logos/partners/' . $logof)) {
                    unlink('/logos/partners/' . $logof);
                }
            }
            $newlogof = $idlevel . '_' . time() . '_logo.jpg';
            Image::make($request->file('logo')->getRealPath())->widen(255, function ($constraint) {
                $constraint->upsize();
            })->heighten(72, function ($constraint) {
                $constraint->upsize();
            })->resizeCanvas(255, 72, 'center', false, 'ffffff')->save('logos/partners/' . $newlogof, 100);

            $partners['logo'] = $newlogof;
        } else {
            $partners['logo'] = $logof;
        }
        $partnersD = $objpartners->getPartnersbySubdomain($partners['name']);
        if($partnersD){
                foreach ($partnersD as $partnerd) {
                    if($partnerd->id != $id)
                    return Redirect::back()->with('error', 'The subdomain'.' '.$partners['name'].' '.'already exists.');
                }
        }

        $objpartners->updatePartner($partners, $id);
        return redirect()->route('Partners', array('token' => $token))->with('success', 'The Partner updated successfully');
    }
    
    public function partnerapirevostore($token, $id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        if($level!='A'){
            return Redirect::back()->with('error', 'Invalid priviledges');
        }
        $data=$request->all();
        unset($data['_token']);
        $apiusr=trim($data['lusername']);
        $apipassw=trim($data['lpassword']);
        //verify username is unique
        $apiobj=new \App\Http\Models\ApiUser();
        if($apiobj->existsUsername($apiusr)){
            return Redirect::back()->with('error', 'This username exists already. Please change it and try again');
        }
        $newdata = array('usr' => $apiusr, 'psw' => $apipassw);
        $current_p = json_encode($newdata);
        $newtoken = \Illuminate\Support\Facades\Crypt::encrypt($current_p . "|" . time() . "|" . config('app.appAPIkey'));
        DB::table('api_user')->insert(['apiusername' => $apiusr, 'apipasswd' => sha1($apipassw), 'lvcode' => $newtoken, 'id_partner' => $id]);
        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    public function newpapirevo($token,$id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        if($level!='A'){
            return Redirect::back()->with('error', 'Invalid priviledges');
        }
        $api_obj=new \App\Http\Models\ApiUser();
        $newusername = 'apix' . $id . $level . $idlevel . time();
        $newpassw = 'pwd' . $id . $level . $idlevel . time();
        if ($api_obj->existsUsername($newusername)) {
            $newusername.=time();
        }
        $apiusr=$newusername;
        $apipassw=$newpassw;
        $newdata = array('usr' => $apiusr, 'psw' => $apipassw);
        $current_p = json_encode($newdata);
        $newtoken = \Illuminate\Support\Facades\Crypt::encrypt($current_p . "|" . time() . "|" . config('app.appAPIkey'));
        DB::table('api_user')->insert(['apiusername' => $apiusr, 'apipasswd' => sha1($apipassw), 'lvcode' => $newtoken, 'id_partner' => $id]);
        return Redirect::back()->with('success', 'The key was generated successfully');
    }

}
