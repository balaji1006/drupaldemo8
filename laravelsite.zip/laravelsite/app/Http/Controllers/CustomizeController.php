<?php

namespace App\Http\Controllers;

use App\Model;
use App\Model\ExternalIntegration;
use App\Model\MenuTabExtensions;
use Illuminate\Http\Request;
use App\Model\Partners;
use App\Model\Customize;
use App\Model\Properties;
use App\Model\Companies;
use App\Model\Categories;
use App\Model\TopsData;
use App\Models\CronBack;
use Illuminate\Support\Facades\DB;
use Image;
use App\CustomClass\TOPSintegration;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Crypt;
use App\Model\CustomField;

class CustomizeController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    public function general($token, Request $request) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        if ($level == "B") {
            return redirect(route('accessdenied'));
        }
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            if ($partnerId == 0) {
                $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                $objSettingVal->createDefaultPartnerValues($partnerId);
            }
            $idgroupM = $partnerId;
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            if ($GroupId == 0) {
                $partnerId = $objSettingVal->getPartnersGroup($idpartner);
                if ($partnerId == 0) {
                    $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                    $objSettingVal->createDefaultPartnerValues($partnerId);
                }
                $GroupId = $objSettingVal->createCompanyGroup($idlevel);
            }
            $idgroupM = $GroupId;
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            if ($MerchantId == 0) {
                $partnerId = $objSettingVal->getPartnersGroup($idpartner);
                if ($partnerId == 0) {
                    $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                    $objSettingVal->createDefaultPartnerValues($partnerId);
                }
                $MerchantId = $objSettingVal->createPropertyGroup($idlevel);
            }
            $idgroupM = $MerchantId;
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        if (!isset($Settings['ACCSETTING'])) {
            if (isset($Settings['NONEWUSER']) && $Settings['NONEWUSER'] == 1) {
                $Settings['ACCSETTING'] = 3;
            } else {
                $Settings['ACCSETTING'] = 2;
            }
            if (isset($Settings['NOTACCQP']) && $Settings['NOTACCQP'] == 1) {
                $Settings['ACCSETTING'] = 4;
            }
            $objSettingVal->saveSettingValue($idgroupM, 'accsetting', $Settings['ACCSETTING']);
        }
        if (!isset($Settings['INVSETTING'])) {
            if (isset($Settings['NOTINVREQ']) && $Settings['NOTINVREQ'] == 1) {
                $Settings['INVSETTING'] = 4;
            } else {
                $Settings['INVSETTING'] = 2;
            }
            $objSettingVal->saveSettingValue($idgroupM, 'invsetting', $Settings['INVSETTING']);
        }

        return view('customize.general', array('token' => $token, 'settings' => $Settings, 'pageTitle' => 'General', 'level' => $level, 'idlevel' => $idlevel));
    }

    public function paymentpage($token, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        if ($level == "B") {
            return redirect(route('accessdenied'));
        }


        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        if (isset($Settings['DAYSAUTOPAY'])) {
            list($in, $en) = explode('|', $Settings['DAYSAUTOPAY']);
            if (empty($in)) {
                $in = 1;
            }
            if (empty($en)) {
                $en = 31;
            }
            $Settings['STARTAUTOPAYDAY'] = $in;
            $Settings['ENDAUTOPAYDAY'] = $en;
        }

        if (isset($Settings['DRPDAYSAUTOPAY'])) {
            list($in, $en) = explode('|', $Settings['DRPDAYSAUTOPAY']);
            if (empty($in)) {
                $in = 1;
            }
            if (empty($en)) {
                $en = 31;
            }
            $Settings['DRPSTARTAUTOPAYDAY'] = $in;
            $Settings['DRPENDAUTOPAYDAY'] = $en;
        }
        if (!isset($Settings['DRPMETHODS'])) {
            $Settings['DRPMETHODS'] = 'cc|ec';
        }
        if (!isset($Settings['OPENBOXCONTENT'])) {
            $Settings['OPENBOXCONTENT'] = '';
        }
        if (!isset($Settings['SHOWOPENBOX'])) {
            $Settings['SHOWOPENBOX'] = 0;
        }

        return view('customize.paymentpage.paymentpage', array('atoken' => $token, 'token' => $token, 'settings' => $Settings, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel));
    }

    public function notifications($token, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        if ($level == "B") {
            return redirect(route('accessdenied'));
        }
        $objSettingVal = new Model\Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        return view('customize.notifications', array('token' => $token, 'settings' => $Settings, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel));
    }

    public function emailtemp($token, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $atoken = $token;
        if ($level == "B") {
            return redirect(route('accessdenied'));
        }
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        if (isset($Settings['SUCCESSFULEMAIL'])) {
            $tmp_email = explode("|", $Settings['SUCCESSFULEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['SUCCESSFULEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['SUCCESSFULEMAIL'] = $tmp_email[1];
            } else {
                $Settings['SUCCESSFULEMAIL_SUBJECT'] = "";
            }
        }

        if (isset($Settings['UNSUCCESSFULEMAIL'])) {
            $tmp_email = explode("|", $Settings['UNSUCCESSFULEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['UNSUCCESSFULEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['UNSUCCESSFULEMAIL'] = $tmp_email[1];
            } else {
                $Settings['UNSUCCESSFULEMAIL_SUBJECT'] = "";
            }
        }

        if (isset($Settings['RECCURRINGENDEMAIL'])) {
            $tmp_email = explode("|", $Settings['RECCURRINGENDEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['RECCURRINGENDEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['RECCURRINGENDEMAIL'] = $tmp_email[1];
            } else {
                $Settings['RECCURRINGENDEMAIL_SUBJECT'] = "";
            }
        }

        if (isset($Settings['RECURRINGEXPIRESEMAIL'])) {
            $tmp_email = explode("|", $Settings['RECURRINGEXPIRESEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['RECURRINGEXPIRESEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['RECURRINGEXPIRESEMAIL'] = $tmp_email[1];
            } else {
                $Settings['RECURRINGEXPIRESEMAIL_SUBJECT'] = "";
            }
        }

        if (isset($Settings['INSFEMAIL'])) {
            $tmp_email = explode("|", $Settings['INSFEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['INSFEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['INSFEMAIL'] = $tmp_email[1];
            } else {
                $Settings['INSFEMAIL_SUBJECT'] = "";
            }
        }


        return view('customize.emailtemplate.emailtemp', array('token' => $atoken, 'settings' => $Settings, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel));
    }

    public function reports($token, Request $request) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];

        if ($level == "B") {
            return redirect(route('accessdenied'));
        }
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        return view('customize.reports.reports', array('token' => $token, 'settings' => $Settings, 'level' => $level, 'idlevel' => $idlevel));
    }

    public function autoreports($token, Request $request) {

        $atoken = decrypt($token);

//        $array_token = json_decode($data, 1);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
//        $idadmin = $array_token['iduser'];
//        $atoken = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));
        if ($level == "B") {
            return redirect(route('accessdenied'));
        }


        $Settings = $reports = null;
        $report_obj = new Model\CronReport();
        $reports = $report_obj->getCronReports($idlevel, $level, 1);
        //var_dump($reports->get()); exit();
        $objSettingVal = new Model\Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        $filter = \DataFilter::source($reports);
//        $filter->submit('search');
//        $filter->reset('reset');
        $filter->build();
        $grid = \DataGrid::source($filter);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));
        $grid->add('id', 'ID')->style("display:none;");
        $grid->add('merchant_identifier', 'Merchant Identifier');
        $grid->add('type', 'Type');
        $grid->add('freq', 'Frequency');
        $grid->add('time', 'Time');
        $grid->add('cron_tz', 'Time zone');
        $grid->add('target', 'Target');
//        $grid->add('scope', 'Scope');
        $grid->add('lastrun', 'Last time');
        $grid->add('actionvalue', 'Action');


        $grid->row(function ($row) use ($level, $idlevel, $token, $atoken) {
            $id = $row->cell('id')->value;
            $token_customize = $token;

            $row->cell('id')->style("display:none;");
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
													  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span >Actions</span>
													  <span class="caret"></span></button>
													  <ul class="dropdown-menu">
														<li><a href="' . route('autoreportsedit', array('token' => $token, 'id' => $id)) . '">Edit</a></li>
														<li><a href="#" onclick="_delete(' . "'" . $token . "'" . ',' . "'" . $id . "'" . ')" >Delete</a></li>

													  </ul>
													</div>';
            $row->cell('id')->style("display:none;");

//            $scope_value = get_object_vars(json_decode($row->cell('scope')->value))['level'];
//            $scope_value = $atoken['level'];
//            switch ($scope_value) {
//                case 'P':
//                    $row->cell('scope')->value('Partner');
//                    break;
//                case 'G':
//                    $row->cell('scope')->value('Company');
//                    break;
//                case 'M':
//                    $row->cell('scope')->value('Merchant');
//                    break;
//            }

            $freq_value = $row->cell('freq')->value;
            switch ($freq_value) {
                case 'days':
                    $row->cell('freq')->value('Daily');
                    break;
                case 'weeks':
                    $row->cell('freq')->value('Weekly (Friday)');
                    break;
                case 'months':
                    $row->cell('freq')->value('Monthly (end of month)');
                    break;
            }

            $merchant_identifier_value = $row->cell('merchant_identifier')->value;
            switch ($merchant_identifier_value) {
                case '0':
                    $row->cell('merchant_identifier')->value('ID Revo');
                    break;
                case '1':
                    $row->cell('merchant_identifier')->value('Lockbox ID');
                    break;
                case '2':
                    $row->cell('merchant_identifier')->value('Misc ID');
                    break;
                case '3':
                    $row->cell('merchant_identifier')->value('Bank ID');
                    break;
            }

            $type_value = $row->cell('type')->value;
            switch ($type_value) {
                case '1':
                    $row->cell('type')->value('Transaction (TOPS)');
                    break;
                case '2':
                    $row->cell('type')->value('Transaction (CSV)');
                    break;
                case '3':
                    $row->cell('type')->value('Deposits (TOPS)');
                    break;
                case '4':
                    $row->cell('type')->value('Deposits (CSV)');
                    break;
                case '5':
                    $row->cell('type')->value('Deposits Batch (CSV)');
                    break;
                case '6':
                    $row->cell('type')->value('Autopayments (CSV)');
                    break;
                case '7':
                    $row->cell('type')->value('Autopayment (Summary) (CSV)');
                    break;
                case '8':
                    $row->cell('type')->value('Transaction (Summary) (CSV)');
                    break;
                case '9':
                    $row->cell('type')->value('Returned (CSV)');
                    break;
                case '10':
                    $row->cell('type')->value('Transactions (CALIBER)');
                    break;
                case '11':
                    $row->cell('type')->value('Transaction (Regular Lockbox file)');
                    break;
                case '12':
                    $row->cell('type')->value('Deposits (Regular Lockbox file)');
                    break;
                case '13':
                    $row->cell('type')->value('Transactions (JENARK)');
                    break;
                case '14':
                    $row->cell('type')->value('Deposits (JENARK)');
                    break;
                case '15':
                    $row->cell('type')->value('Transactions (JENARK EC CC)');
                    break;
            }

            $ts = array('0' => 'EST', '1' => 'CST', '2' => 'MST', '3' => 'PST');
            $row->cell('cron_tz')->value($ts[$row->cell('cron_tz')->value]);

            $time_value = $row->cell('time')->value;
            switch ($time_value) {
                case '1000':
                    $row->cell('time')->value('10:00am');
                    break;
                case '1100':
                    $row->cell('time')->value('11:00am');
                    break;
                case '1200':
                    $row->cell('time')->value('12:00pm');
                    break;
                case '1300':
                    $row->cell('time')->value('1:00pm');
                    break;
                case '1400':
                    $row->cell('time')->value('2:00pm');
                    break;
                case '1500':
                    $row->cell('time')->value('3:00pm');
                    break;
                case '1600':
                    $row->cell('time')->value('4:00pm');
                    break;
                case '1700':
                    $row->cell('time')->value('5:00pm');
                    break;
                case '1800':
                    $row->cell('time')->value('6:00pm');
                    break;
                case '1900':
                    $row->cell('time')->value('7:00pm');
                    break;
                case '2000':
                    $row->cell('time')->value('8:00pm');
                    break;
                case '2100':
                    $row->cell('time')->value('9:00pm');
                    break;
                case '2200':
                    $row->cell('time')->value('10:00pm');
                    break;
                case '2300':
                    $row->cell('time')->value('11:00pm');
                    break;
                case '2400':
                    $row->cell('time')->value('Mid night');
                    break;
            }

            $target = $row->cell('target')->value;
            if (strlen($target) > 40) {
                $tooltip_str = str_replace(';', '<br/>', $target);
                $row->cell('target')->value('<span data-toggle="tooltip" data-html="true" data-placement="top" title="' . $tooltip_str . '">' . substr($target, 0, 40) . '...' . '</span>');
            }
        });

        $grid->orderBy('cron_task_report.id', 'desc');
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->paginate($itemsPerPage);
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        return view('customize.autoreports.autoreports', array(
            'atoken' => $token,
            'filter' => $filter,
            'grid' => $grid,
            'token' => $token,
            'reports' => $reports,
            'settings' => $Settings,
            'pageTitle' => 'Automated Reports',
            'level' => $level,
            'idlevel' => $idlevel,
            'itemspage' => $itemsPerPage,
            'sqlEncrypted' => encrypt($sql_ready)
        ));
    }

    public function autoreportsnew($token, Request $request) {
//        list($data) = explode('|', Crypt::decrypt($token));
//        $array_token = json_decode($data, 1);
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
//        $idadmin = $array_token['iduser'];
//        $atoken = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));
        $atoken = $token;

        $scopes = null;
        $objSettingVal = new Model\Customize();
        $objReports = new Model\CronReport();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
            $obj_company = new Model\Companies();
            $scopes = $obj_company->getCompaniesByPartnerId($idlevel);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
            $obj_merchant = new Model\Properties();
            $scopes = $obj_merchant->getPropertiesByCompanyId($idlevel);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        $reports = $objReports->getCronReports($idlevel, $level, 0);

        return view('customize.autoreports.autoreportsnew', array(
            'atoken' => $atoken,
            'reports' => $reports,
            'token' => $token,
            'scopes' => $scopes,
            'pageTitle' => 'Automated Reports',
            'level' => $level,
            'idlevel' => $idlevel,
            'settings' => $Settings
        ));
    }

    public function autoreportsnewstore($token, Request $request) {
        $data = $request->all();
        $validator = Validator::make($data, $this->getRulesAutoreports());

//        list($datatoken) = explode('|', Crypt::decrypt($token));
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
//        $idadmin = $array_token['iduser'];




        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator->errors())->withInput($data);
        }


        $checks = array();

        $data_keys = array_keys($data);
        foreach ($data_keys as $key) {
            if (strpos($key, 'checkbox_') === 0) {
                array_push($checks, $data[$key]);
            }
        }
        $idp = $idc = $idm = 0;
        switch ($level) {
            case 'P':
                $idp = $idlevel;
                break;
            case 'G':
                $idc = $idlevel;
                break;
            case 'M':
                $idm = $idlevel;
                break;
        }
        $checks_string = '';
        foreach ($checks as $check) {
            $checks_string .= $check . '!';
        }
        if ($level != 'M') {
            $checks_string = substr($checks_string, 0, strlen($checks_string) - 1);
            if ($checks_string == '' || !$checks_string) {
                $checks_string = $idlevel;
            } else {
                if ($level == 'P') {
                    $level = 'G';
                } else {
                    $level = 'M';
                }
            }
        } else {
            $checks_string = $idlevel;
        }
        $scope = json_encode(array('level' => $level, 'id' => $checks_string));

        $splitpm = 0;
        if (isset($data['splitpm']) && $data['splitpm']) {
            $splitpm = 1;
        }

        $timezones = array('0' => -1, '1' => 0, '2' => 1, '3' => 2);

        $newtime = ($data['time'] / 100 + $timezones[$data['timezone']]) * 100;

        if ($newtime >= 2400) {
            $newtime -= 2400;
            $newtime = str_pad($newtime, 4, '0', STR_PAD_LEFT);
        }


        DB::table('cron_task_report')->insert([
            'idp' => $idp,
            'idc' => $idc,
            'idm' => $idm,
            'type' => $data['type'],
            'time' => $data['time'],
            'cron_time' => $newtime,
            'freq' => $data['frequency'],
            'target' => str_replace(',', ';', $data['email']),
            'scope' => $scope,
            'merchant_identifier' => $data['identify_merchant'],
            'split_payment_methods' => $splitpm,
            'cron_tz' => $data['timezone']
        ]);

        return redirect()->route('autoreport', ['token' => $token])->with('success', 'Saved successfully');
    }

    public function autoreportsdelete($token, $id) {
//        list($data) = explode('|', Crypt::decrypt($token));
//        $array_token = json_decode($data, 1);
        $atoken = decrypt($token);
//        $idlevel = $atoken['level_id'];
//        $level = $array_token['type'];
//        $idadmin = $array_token['iduser'];
//        $atoken = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));

        /* $now = time();
          if($now > (integer)$time + 86400){
          return response()->json(array('errcode'=>260,'msg'=>'Invalid Token'));
          } */


        DB::table('cron_task_report')->where('id', $id)->delete();
        return Redirect::back()->with('success', 'Deleted successfully');
    }

    public function autoreportsedit($token, $id) {

        $datatoken = decrypt($token);
//        $array_token = json_decode($datatoken, 1);
        $idlevel = $datatoken['level_id'];
        $level = $datatoken['level'];
//        $idadmin = $datatoken['iduser'];
//        $atoken = Crypt::encrypt($datatoken . '|' . time() . '|' . config('app.appAPIkey'));
        $atoken = $token;

        /*
          $now = time();
          $scopes =  null;
          if($now > (integer)$time + 86400){
          return response()->json(array('errcode'=>260,'msg'=>'Invalid Token'));
          } */
        $objSettingVal = new Model\Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);

            $obj_company = new Model\Companies();
            $scopes = $obj_company->getCompaniesByPartnerId($idlevel);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);

            $obj_merchant = new Model\Properties();
            $scopes = $obj_merchant->getPropertiesByCompanyId($idlevel);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
            $scopes = array($idlevel);
        }



        $obj_report = new Model\CronReport();
        $report = $obj_report->getCronReportById($id)[0];
        $reports_db = $obj_report->getCronReports($idlevel, $level, 0);


        $reports = array();
        foreach ($reports_db as $rep) {
            if ($rep->id != $report->id) {
                array_push($reports, $rep);
            }
        }

        return view('customize.autoreports.autoreportsedit', array(
            'id' => $id, 'atoken' => $atoken,
            'reports_db' => $reports,
            'report' => $report,
            'token' => $token,
            'scopes' => $scopes,
            'pageTitle' => 'Automated Reports',
            'level' => $level, 'idlevel' => $idlevel,
            'settings' => $Settings
        ));
    }

    public function autoreportsdownload($token) {
        list($data) = explode('|', Crypt::decrypt($token));
        $array_token = json_decode($data, 1);
        $idlevel = $array_token['id'];
        $level = $array_token['type'];
        $idadmin = $array_token['iduser'];
        $atoken = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));

        return view('admin.autoreportsdownload');
    }

    public function autoreportseditstore($token, $id, Request $request) {

        $data = $request->all();
        $validator = Validator::make($data, $this->getRulesAutoreports());

//        list($datatoken) = explode('|', Crypt::decrypt($token));
        $atoken = decrypt($token);
//        $array_token = json_decode($datatoken, 1);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
//        $idadmin = $array_token['iduser'];
//        $atoken = $token = Crypt::encrypt($datatoken . '|' . time() . '|' . config('app.appAPIkey'));



        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator->errors())->withInput($data);
        }
        $checks = array();
        $data_keys = array_keys($data);
        foreach ($data_keys as $key) {
            if (strpos($key, 'checkbox_') === 0) {
                array_push($checks, $data[$key]);
            }
        }
        $idp = $idc = $idm = 0;
        switch ($level) {
            case 'P':
                $idp = $idlevel;
                break;
            case 'G':
                $idc = $idlevel;
                break;
            case 'M':
                $idm = $idlevel;
                break;
        }
        $checks_string = '';
        foreach ($checks as $check) {
            $checks_string .= $check . '!';
        }
        if ($level != 'M') {
            $checks_string = substr($checks_string, 0, strlen($checks_string) - 1);
            if ($checks_string == '' || !$checks_string) {
                $checks_string = $idlevel;
            } else {
                if ($level == 'P') {
                    $level = 'G';
                } else {
                    $level = 'M';
                }
            }
        } else {
            $checks_string = $idlevel;
        }
        $scope = json_encode(array('level' => $level, 'id' => $checks_string));

        $splitpm = 0;
        if (isset($data['splitpm']) && $data['splitpm']) {
            $splitpm = 1;
        }

        $timezones = array('0' => -1, '1' => 0, '2' => 1, '3' => 2);
        $newtime = ($data['time'] / 100 + $timezones[$data['timezone']]) * 100;

        if ($newtime >= 2400) {
            $newtime -= 2400;
            $newtime = str_pad($newtime, 4, '0', STR_PAD_LEFT);
        }

        DB::table('cron_task_report')
                ->where('id', '=', $id)
                ->update([
                    'idp' => $idp,
                    'idc' => $idc,
                    'idm' => $idm,
                    'type' => $data['type'],
                    'time' => $data['time'],
                    'cron_time' => $newtime,
                    'freq' => $data['frequency'],
                    'target' => str_replace(',', ';', $data['email']),
                    'scope' => $scope,
                    'merchant_identifier' => $data['identify_merchant'],
                    'split_payment_methods' => $splitpm,
                    'cron_tz' => $data['timezone']
        ]);

        return redirect()->route('autoreport', ['token' => $token])->with('success', 'Saved successfully');
    }

    //config to Group level
    public function topsconfig_c($token, Request $request) {

        list($data) = explode('|', Crypt::decrypt($token));
        $array_token = json_decode($data, 1);
        $idlevel = $array_token['id'];
        $level = $array_token['type'];
        $idadmin = $array_token['iduser'];
        $atoken = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));

        $obj_tops = new TopsData();
        $tops = $obj_tops->getByMerchant($idlevel);
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
            $obj_merchant = new Companies();
            $scopes = $obj_company->getCompaniesByPartnerId($idlevel);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
            $obj_merchant = new Properties();
            $scopes = $obj_merchant->getPropertiesByCompanyId($idlevel);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        return view('admin.topsconfig_c', array('pageTitle' => 'Customize', 'atoken' => $atoken, 'token' => $atoken, 'level' => $level, 'idlevel' => $idlevel, 'scopes' => $scopes, 'settings' => $Settings));
    }

    /**
     * Tops Configutarion to PM
     * @param: atoken
     * @autor: Danieyis Santiago
     */
    public function savetopsconfig_c(Request $request) {
        $token = $request->input('tokendata');
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        list($level, $idlevel) = explode('|', $atoken);

        /* list($data)=explode('|',Crypt::decrypt($token));
          $array_token = json_decode($data,1);
          $idlevel=$array_token['id'];
          $level=$array_token['type'];
          $atoken = Crypt::encrypt($data.'|'.time().'|'.config('app.appAPIkey')); */

        $obj_tops = new TopsData();
        $obj_property = new Properties();
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
            $obj_merchant = new Companies();
            $scopes = $obj_company->getCompaniesByPartnerId($idlevel);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
            $obj_merchant = new Properties();
            $scopes = $obj_merchant->getPropertiesByCompanyId($idlevel);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        $cckey = trim($request->input('cckey'));
        if (empty($cckey)) {
            return view('admin.topsconfig_c', array('pageTitle' => 'Customize', 'atoken' => $atoken, 'token' => $token, 'msgCode' => 'tops1', 'level' => $level, 'idlevel' => $idlevel, 'scopes' => $scopes, 'settings' => $Settings));
        }

        $tops_integration = new TOPSintegration();
        $tmp = $tops_integration->getCompaniesKeys($cckey);
        error_log(print_r($tmp, true), 3, '/var/tmp/1topsint.log');
        $data = array();
        $caps = $tmp['License'];

        //get only the companies
        $companies = $tmp['License']['CommunityApiKey'];
        for ($i = 0; $i < count($companies); $i++) {
            //search the property
            $property = $obj_property->getPropertyInfoByMisc($companies[$i]['CommunityID'], $idlevel);
            if (!empty($property)) {
                $idtops = $obj_tops->getIDfromMerchant($property['id']);
                if ($idtops > 0) {
                    $obj_tops->set1Info($idtops, 'ckey', $cckey);
                } else {
                    $data = array();
                    $data['id_property'] = $property['id'];
                    $data['id_company'] = $property['id_companies'];
                    $data['id_partner'] = $property['id_partners'];
                    $data['ckey'] = $companies[$i]['ApiKey'];
                    $data['community_id'] = $companies[$i]['CommunityID'];
                    $data['options'] = json_encode($tmp['License']);
                    $idtops = $obj_tops->createTOPS($data);
                }
            }
        }
        $admin_options = "";
        $bankaccounts = "";
        $tops = "";
        return view('admin.topsconfig2_c', array('options' => $admin_options, 'atoken' => $atoken, 'caps' => $caps, 'banksc' => $bankaccounts, 'tops' => $tops, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
        return $tmp;
    }

    //danieyis

    public function savetopsconfig2_c(Request $request) {
        $token = $request->input('tokendata');
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        list($level, $idlevel) = explode('|', $atoken);
        $obj_tops = new TopsData();
        $obj_property = new Properties();
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        $overwrt = "";
        if (null !== $request->input('overwrt')) {
            $overwrt = trim($request->input('overwrt'));
        }
        $balance = "";
        if (null !== $request->input('balance')) {
            $balance = trim($request->input('balance'));
        }
        $ccode = "";
        if (null !== $request->input('ccode')) {
            $ccode = trim($request->input('ccode'));
        }
        $pay2 = "";
        if (null !== $request->input('pay2')) {
            $pay2 = trim($request->input('pay2'));
        }
        $pay2x = "";
        if (null !== $request->input('pay2x')) {
            $pay2x = trim($request->input('pay2x'));
        }
        $payr = "";
        if (null !== $request->input('payr')) {
            $payr = trim($request->input('payr'));
        }
        $payrx = "";
        if (null !== $request->input('payrx')) {
            $payrx = trim($request->input('payrx'));
        }

        $admin_options = array();
        $admin_options['overwrt'] = $overwrt;
        $admin_options['balance'] = $balance;
        $admin_options['ccode'] = $ccode;
        $admin_options['pay2'] = $pay2;
        $admin_options['pay2x'] = $pay2x;
        $admin_options['payr'] = $payr;
        $admin_options['payrx'] = $payrx;
        $idtops = $obj_tops->getIDbyCompany($idlevel);
        for ($i = 0; $i < count($idtops); $i++) {
            $obj_tops->set1Info($idtops[$i]['id'], 'admin_options', json_encode($admin_options));
        }
        $ckey = $obj_tops->get1Info($idtops, 'ckey');
        $topsconnect = new \App\CustomClass\TOPSconnection($ckey);
        $topsint = new TOPSintegration();
        $glcodes = array();
        if ($ccode == 'on') {
            //get the GL Codes
            $glcodes = $topsconnect->getChargeCodeList();
        }
        $capstext = $obj_tops->get1Info($idtops, 'options');
        $caps = json_decode($capstext, true);
        $bankaccounts = array();
        if (($pay2 == 'on' || $payr == 'on') && isset($caps['Resources'])) {
            $services = $caps['Resources'];
            $chargecode = false;
            $bank = false;
            $balance = false;
            $account = false;
            $owner = false;
            $email = false;
            $receiptbatch = false;
            $chargebatch = false;
            $property = false;
            foreach ($services as $endpoint) {
                if ($endpoint['Name'] == 'owner' && ($endpoint['Access'] == 'Full')) {
                    $owner = true;
                } elseif ($endpoint['Name'] == 'property' && ($endpoint['Access'] == 'Full')) {
                    $property = true;
                } elseif ($endpoint['Name'] == 'chargecode' && ($endpoint['Access'] == 'Full')) {
                    $chargecode = true;
                } elseif ($endpoint['Name'] == 'email' && ($endpoint['Access'] == 'Full')) {
                    $email = true;
                } elseif ($endpoint['Name'] == 'receiptbatch' && ($endpoint['Access'] == 'Full')) {
                    $receiptbatch = true;
                } elseif ($endpoint['Name'] == 'account' && ($endpoint['Access'] == 'Full')) {
                    $account = true;
                } elseif ($endpoint['Name'] == 'bank' && ($endpoint['Access'] == 'Full')) {
                    $bank = true;
                } elseif ($endpoint['Name'] == 'chargebatch' && ($endpoint['Access'] == 'Full')) {
                    $chargebatch = true;
                } elseif ($endpoint['Name'] == 'balance' && ($endpoint['Access'] == 'Full')) {
                    $balance = true;
                }
            }
            if ($bank) {
                //get the banks
                $bankaccounts = $topsint->getBanks($ckey);
                if (count($bankaccounts) <= 0) {
                    $bank = false;
                    $receiptbatch = false;
                    $chargebatch = false;
                }
            }
        }
        $tops = $obj_tops->getIDPropByCompany($idlevel);

        $obj_cron = new CronBack();
        $datacron = array();

        for ($i = 0; $i < count($tops); $i++) {
            $level = 'M';
            $idlevel = $tops[$i]['id_property'];
            $atoken = \Illuminate\Support\Facades\Crypt::encrypt($level . '|' . $idlevel . '|' . time() . '|' . config('app.appAPIkey'));
            $datacron['task'] = '/api2/cron/tops/users/' . $atoken;
            $idtask = $obj_cron->insertTask($datacron, $level, $idlevel);
        }
        /*
          if($idtask>0){
          exec('php5 /var/revopay15/patches/cron/execJob.php '.$datacron['task'].'/'.$idtask.' > /dev/null 2>/dev/null &');
          } */
        return view('admin.topsintegration_c', array('progress_bar' => 1, 'idtask' => $idtask, 'atoken' => $atoken, 'tops' => $tops, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'token' => $token, 'settings' => $Settings));

        //standard view
        /* if($admin_options['overwrt']=='on' || $admin_options['balance']=='on'){
          return view('admin.topsintegration',array('progress_bar'=>1,'idtask'=>$idtask,'token'=>$token,'tops'=>$tops,'pageTitle'=>'Customize','level'=>$level,'idlevel'=>$idlevel,'token'=>$token,'settings'=>$Settings));
          }
          else{
          return view('admin.topsintegration',array('progress_bar'=>0,'idtask'=>$idtask,'token'=>$token,'tops'=>$tops,'pageTitle'=>'Customize','level'=>$level,'idlevel'=>$idlevel,'token'=>$token,'settings'=>$Settings));
          } */
    }

    public function topsconfig($token, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        //@TODO When TOPS Key integrates companies and partners remove restriction
        if ($level == "B" || $level == "P" || $level == "G" || $level == "A") {
            return redirect(route('accessdenied'));
        }

        $Settings = $this->getSettings($level, $idlevel);

        $obj_tops = new TopsData();
        $tops = $obj_tops->getByMerchant($idlevel);

        if (empty($tops)) {
            return view('customize.tops.topsconfig', array('pageTitle' => 'Customize', 'token' => $token, 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
        }
        if (empty($tops->admin_options)) {
            //incomplete
            return view('customize.tops.topsconfig', array('pageTitle' => 'Customize', 'token' => $token, 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings, 'tops' => $tops));
        }

        return view('customize.tops.topsintegration', array('token' => $token, 'tops' => $tops, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
    }

    public function savetopsconfig1($token, Request $request) {
        $token = $request->input('tokendata');
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $messages = [
            'cckey.required' => 'TOPS\'s API Community key field is required. ',
        ];

        $request->validate([
            'cckey' => 'required',
                ], $messages);

        $objTops = new TopsData();
        $obj_property = new Properties();
        $settings = $this->getSettings($level, $idlevel);

        $cckey = trim($request->input('cckey'));
        /* if (empty($cckey)) {
          return Redirect::back()->with('error', 'A Community Key is required to establish connection with TOPS');
          return view('customize.tops.topsconfig', array('pageTitle' => 'Customize', 'token' => $token, 'level' => $level, 'idlevel' => $idlevel, 'error' => 'tops1', 'settings' => $settings));
          } */
        $idTops = $objTops->getIDfromMerchant($idlevel);
        if ($idTops > 0) {
            $objTops->set1Info($idTops, 'ckey', $cckey);
        } else {
            $data = array();
            $data['id_property'] = $idlevel;
            $data['id_company'] = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $data['id_partner'] = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $data['paypointid'] = $obj_property->get1PropertyInfo($idlevel, 'compositeID_clients');
            $obj_company = new Companies();
            $data['companyid'] = $obj_company->get1CompanyInfo($data['id_company'], 'compositeID_companies');
            $data['ckey'] = $cckey;
            $idTops = $objTops->createTOPS($data);
        }
        //validate ckey
        $topsconnect = new TOPSintegration();
        //error_log($cckey, 3, '/var/tmp/1topsint.log');
        $comm = $topsconnect->getCapabilitiesListFromKey($cckey);
        //error_log(print_r($comm, true), 3, '/var/tmp/1topsint.log');
        if (isset($comm['License']['Resources'])) {
            $tops = $objTops->getByMerchant($idlevel);
            $caps = $comm['License'];
            $objTops->set1Info($idTops, 'options', json_encode($caps));
            //verify key
            if (!isset($caps['CommunityApiKey'])) {
                //return Redirect::back()->with('error', 'The Community Key provided failed connecting with TOPS. Please verify you have the correct API key and the endpoints enabled in TOPS and try again.');
                return view('customize.tops.topsconfig', array('pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'msgCode' => 'tops1', 'settings' => $settings));
            }
            $commkeys = $caps['CommunityApiKey'];
            $found = null;
            foreach ($commkeys as $cmkey) {
                if ($cmkey['ApiKey'] == $cckey) {
                    if ($cmkey['Active'] == true) {
                        $found = $cmkey;
                    } else {
                        //return Redirect::back()->with('error', 'The Community Key provided is inactive.');
                        return view('customize.tops.topsconfig', array('pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'msgCode' => 'tops1', 'settings' => $settings));
                    }
                }
            }
            if (empty($found)) {
                //return Redirect::back()->with('error', 'The Community Key provided is inactive.');
                return view('customize.tops.topsconfig', array('pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'msgCode' => 'tops1', 'settings' => $settings));
            }
            //update compositeID
            $pid = $found['CommunityID'];
            $cid = $found['CommunityKey'];
            $obj_property->set1PropertyInfo($idlevel, 'misc_field', $pid);
            $objTops->set1Info($idTops, 'community_id', $cid);
            $admin_options = json_decode($objTops->get1Info($idTops, 'admin_options'), 1);
            $bankaccounts = $topsconnect->getBanks($cckey);
            return view('customize.tops.topsconfig2', array('token' => $token, 'options' => $admin_options, 'caps' => $caps, 'found' => $found, 'banksc' => $bankaccounts, 'tops' => $tops, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $settings, 'token' => $token));
        } else {
            return view('customize.tops.topsconfig', array('token' => $token, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'msgCode' => 'tops2', 'settings' => $settings));
        }
    }

    public function edittopsconfig1($token, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $Settings = $this->getSettings($level, $idlevel);

        $obj_tops = new TopsData();
        $topsconnect = new TOPSintegration();
        $tops = $obj_tops->getByMerchant($idlevel);
        $comm = $topsconnect->getCapabilitiesListFromKey($tops->ckey);
        $cckey = $tops->ckey;
        $caps = '';
        $found = null;
        if (isset($comm['License'])) {
            $caps = $comm['License'];
            if (isset($caps['CommunityApiKey'])) {
                $commkeys = $caps['CommunityApiKey'];
                foreach ($commkeys as $cmkey) {
                    if ($cmkey['ApiKey'] == $cckey) {
                        if ($cmkey['Active'] == true) {
                            $found = $cmkey;
                        }
                    }
                }
            }
        }
        $bankaccounts = $topsconnect->getBanks($cckey);
        $idtops = $obj_tops->getIDfromMerchant($idlevel);
        $options = $obj_tops->get1Info($idtops, 'admin_options');

        return view('customize.tops.topsconfig2', array('options' => (array) json_decode($options), 'found' => $found, 'banksc' => $bankaccounts, 'caps' => $caps, 'tops' => $tops, 'pageTitle' => 'Customize', 'token' => $token, 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
    }

    public function savetopsconfig2(Request $request) {
        $token = $request->input('tokendata');
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $Settings = $this->getSettings($level, $idlevel);
        $overwrt = "";
        if (null !== $request->input('overwrt')) {
            $overwrt = trim($request->input('overwrt'));
        }
        $balance = "";
        if (null !== $request->input('balance')) {
            $balance = trim($request->input('balance'));
        }
        $ccode = "";
        if (null !== $request->input('ccode')) {
            $ccode = trim($request->input('ccode'));
        }
        $pay2 = "";
        if (null !== $request->input('pay2')) {
            $pay2 = trim($request->input('pay2'));
        }
        $pay2x = "";
        if (null !== $request->input('pay2x')) {
            $pay2x = trim($request->input('pay2x'));
        }
        $payr = "";
        if (null !== $request->input('payr')) {
            $payr = trim($request->input('payr'));
        }
        $payrx = "";
        if (null !== $request->input('payrx')) {
            $payrx = trim($request->input('payrx'));
        }

        $admin_options = array();
        $admin_options['overwrt'] = $overwrt;
        $admin_options['balance'] = $balance;
        $admin_options['ccode'] = $ccode;
        $admin_options['pay2'] = $pay2;
        $admin_options['pay2x'] = $pay2x;
        $admin_options['payr'] = $payr;
        $admin_options['payrx'] = $payrx;
        $obj_tops = new TopsData();
        $idtops = $obj_tops->getIDfromMerchant($idlevel);
        $obj_tops->set1Info($idtops, 'admin_options', json_encode($admin_options));
        $ckey = $obj_tops->get1Info($idtops, 'ckey');
        $topsconnect = new \App\CustomClass\TOPSconnection($ckey);
        $topsint = new TOPSintegration();
        $glcodes = array();
        if ($ccode == 'on') {
            //get the GL Codes
            $glcodes = $topsconnect->getChargeCodeList();
        }
        $capstext = $obj_tops->get1Info($idtops, 'options');
        $caps = json_decode($capstext, true);
        $bankaccounts = array();
        if (($pay2 == 'on' || $payr == 'on') && isset($caps['Resources'])) {
            $services = $caps['Resources'];
            $chargecode = false;
            $bank = false;
            $balance = false;
            $account = false;
            $owner = false;
            $email = false;
            $receiptbatch = false;
            $chargebatch = false;
            $property = false;
            foreach ($services as $endpoint) {
                if ($endpoint['Name'] == 'owner' && ($endpoint['Level'] == 'Full')) {
                    $owner = true;
                } elseif ($endpoint['Name'] == 'property' && ($endpoint['Level'] == 'Full')) {
                    $property = true;
                } elseif ($endpoint['Name'] == 'chargecode' && ($endpoint['Level'] == 'Full')) {
                    $chargecode = true;
                } elseif ($endpoint['Name'] == 'email' && ($endpoint['Level'] == 'Full')) {
                    $email = true;
                } elseif ($endpoint['Name'] == 'receiptbatch' && ($endpoint['Level'] == 'Full')) {
                    $receiptbatch = true;
                } elseif ($endpoint['Name'] == 'account' && ($endpoint['Level'] == 'Full')) {
                    $account = true;
                } elseif ($endpoint['Name'] == 'bank' && ($endpoint['Level'] == 'Full')) {
                    $bank = true;
                } elseif ($endpoint['Name'] == 'chargebatch' && ($endpoint['Level'] == 'Full')) {
                    $chargebatch = true;
                } elseif ($endpoint['Name'] == 'balance' && ($endpoint['Level'] == 'Full')) {
                    $balance = true;
                }
            }
            if ($bank) {
                //get the banks
                $bankaccounts = $topsint->getBanks($ckey);
                if (count($bankaccounts) <= 0) {
                    $bank = false;
                    $receiptbatch = false;
                    $chargebatch = false;
                }
            }
        }

        if (count($bankaccounts) > 0 || count($glcodes) > 0) {
            $gl_options = json_decode($obj_tops->get1Info($idtops, 'glcode_options'), 1);
            $pay_acc_id = $obj_tops->get1Info($idtops, 'pay_account_id');
            $paycc_acc_id = $obj_tops->get1Info($idtops, 'paycc_account_id');
            if ($admin_options['overwrt'] == 'on' || $admin_options['balance'] == 'on') {
                return view('customize.tops.topsconfig3', array('payaid' => $pay_acc_id, 'payccaid' => $paycc_acc_id, 'gloptions' => $gl_options, 'progress_bar' => 1, 'glcodes' => $glcodes, 'caps' => $caps, 'admin' => $admin_options, 'bankaccounts' => $bankaccounts, 'pageTitle' => 'Customize', 'token' => $token, 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
            } else {
                return view('customize.tops.topsconfig3', array('payaid' => $pay_acc_id, 'payccaid' => $paycc_acc_id, 'gloptions' => $gl_options, 'progress_bar' => 0, 'glcodes' => $glcodes, 'caps' => $caps, 'admin' => $admin_options, 'bankaccounts' => $bankaccounts, 'pageTitle' => 'Customize', 'token' => $token, 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
            }
        } else {
            $tops = $obj_tops->getByMerchant($idlevel);

            if ($admin_options['overwrt'] == 'on' || $admin_options['balance'] == 'on') {
                return view('customize.tops.topsintegration', array('progress_bar' => 1, 'token' => $token, 'tops' => $tops, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
            } else {
                return view('customize.tops.topsintegration', array('progress_bar' => 0, 'token' => $token, 'tops' => $tops, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
            }
        }
    }

    public function savetopsconfig3(Request $request, $progress_bar = 0) {
        $token = $request->input('tokendata');
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $obj_tops = new TopsData();
        $obj_cat = new Categories();

        $Settings = $this->getSettings($level, $idlevel);
        $bank2 = "";
        if (null !== $request->input('bank2')) {
            $bank2 = trim($request->input('bank2'));
        }
        $bankr = "";
        if (null !== $request->input('bankr')) {
            $bankr = trim($request->input('bankr'));
        }
        $glcodesx = array();
        $idtops = $obj_tops->getIDfromMerchant($idlevel);
        $ckey = $obj_tops->get1Info($idtops, 'ckey');
        $topsconnect = new \App\CustomClass\TOPSconnection($ckey);
        $admin_options = json_decode($obj_tops->get1Info($idtops, 'admin_options'), true);
        if ($admin_options['ccode'] == 'on') {
            //get the GL Codes
            $glcodes = $topsconnect->getChargeCodeList();
            foreach ($glcodes as $gl) {
                if (null !== $request->input($gl['ChargeCodeKey'])) {
                    $glcodesx[] = $gl;
                }
            }
        }
        //create payment categories
        foreach ($glcodesx as $gl) {
            $data = array();
            $data['property_id'] = $idlevel;
            $data['payment_type_name'] = $gl['Description'];
            $data['payment_type_code'] = $gl['Code'];
            $data['payment_type_code_id'] = $gl['ChargeCodeKey'];
            $obj_cat->insertCategoryforMerchant($data);
        }

        $topsint = new TOPSintegration();
        $bankaccounts = $topsint->getBanks($ckey);


        if ($bank2 != '') {
            $obj_tops->set1Info($idtops, 'pay_account_id', $bank2);
            foreach ($bankaccounts as $bankaccount) {
                if ($bankaccount['Key'] == $bank2) {
                    $obj_tops->set1Info($idtops, 'pay_account_name', $bankaccount['Name']);
                    break;
                }
            }
        }
        if ($bankr != '') {
            $obj_tops->set1Info($idtops, 'paycc_account_id', $bankr);
            foreach ($bankaccounts as $bankaccount) {
                if ($bankaccount['Key'] == $bankr) {
                    $obj_tops->set1Info($idtops, 'paycc_account_name', $bankaccount['Name']);
                    break;
                }
            }
        }
        $array_checkbox = array();
        $data_submit = $request->all();

        foreach ($data_submit as $key => $item) {
            if (strrpos($key, "checkbox_") === 0) {
                $array_checkbox[$key] = $data_submit[$key];
            }
        }

        if ($array_checkbox) {
            $obj_tops->set1Info($idtops, 'glcode_options', json_encode($array_checkbox));
        }
        $tops = $obj_tops->getByMerchant($idlevel);

        return view('customize.tops.topsintegration', array('progress_bar' => $progress_bar, 'token' => $token, 'tops' => $tops, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
    }

    public function resettopsconfig($token, Request $request) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $obj_tops = new TopsData();
        $tops = $obj_tops->getByMerchant($idlevel);

        $Settings = $this->getSettings($level, $idlevel);

        return view('customize.tops.topsconfig', array('tops' => $tops, 'token' => $token, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
    }

    public function resettopsconfigkey($token = null) {
        $Settings = null;
        if ($token) {
            $array_token = decrypt($token);
            $idlevel = $array_token['level_id'];
            $level = $array_token['level'];

            $obj_tops = new TopsData();

            $idtops = $obj_tops->getIDfromMerchant($idlevel);
            $obj_tops->set1Info($idtops, 'admin_options', '');
            $obj_tops->set1Info($idtops, 'glcode_options', '');
            $obj_tops->set1Info($idtops, 'pay_account_name', '');
            $obj_tops->set1Info($idtops, 'paycc_account_name', '');
            $obj_tops->set1Info($idtops, 'pay_account_id', '');
            $obj_tops->set1Info($idtops, 'paycc_account_id', '');

            $Settings = $this->getSettings($level, $idlevel);
        }

        return view('customize.tops.topsconfig', array('pageTitle' => 'Customize', 'token' => $token, 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
    }

    public function edittopconfigkey($token) {
        //$atoken=\Illuminate\Support\Facades\Crypt::decrypt($token);
        //list($idlevel,$level)=explode('|',$atoken);

        list($data) = explode('|', Crypt::decrypt($token));
        $array_token = json_decode($data, 1);
        $idlevel = $array_token['id'];
        $level = $array_token['type'];
        $idadmin = $array_token['iduser'];
        $atoken = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));

        $obj_tops = new TopsData();
        $tops = $obj_tops->getByMerchant($idlevel);
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        return view('admin.topsconfig', array('tops' => $tops, 'atoken' => $atoken, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
    }

    public function integrations($token, Request $request) {
        exit();
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        list($level, $idlevel) = explode('|', $atoken);
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        return view('admin.integrations', array('settings' => $Settings, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel));
    }

    public function categories($token, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        list($idlevel, $level) = explode('|', $atoken);
        if ($level == 'M') {
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $grid = \DataGrid::source(Categories::where('property_id', '=', $idlevel));
            $grid->attributes(array("class" => "table table-striped table-hover"));
            $grid->add('payment_type_id', 'ID', true)->style("width:100px");
            $grid->add('payment_type_name', 'Category Name', true);
            $grid->add('amount', 'Amount');
            $grid->add('is_balance', 'Modify Balance?')->cell(function ($value) {
                if ($value == '0') {
                    return 'No';
                } elseif ($value == '1') {
                    return 'Yes';
                }
            });
            $grid->add('payment_type_code', 'GL-Code');
//            $grid->add('send_notification_to','Send Notification To');
//            $grid->add('show_qty','Show Quantity selector?');
//            $grid->add('max_qty','Max Quantity to show');

            $grid->edit('/customize/' . $token . '/editcategories', 'Action', 'modify|delete');
            $grid->link('/customize/' . $token . '/editcategories', "New Payment Category", "TR");
            $grid->orderBy('payment_type_name', 'asc');
            $grid->paginate(10);


            return view('admin.categories', array('grid' => $grid, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel));
        }
    }

    public function layout($token, Request $request) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        if ($level == "B") {
            return redirect(route('accessdenied'));
        }
        $objSettingVal = new Customize();
        $einv = 0;
        $eterm = 0;
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
            if (isset($Settings['EINVOICE']) && $Settings['EINVOICE'] == 1) {
                $einv = 1;
            }
            if ($obj_property->hasETerminal($idlevel)) {
                $eterm = 1;
            }
        }

        //new code for setting NOT MANDATORY
        if (isset($Settings['NOTMANDATORYETERM']) && !empty($Settings['NOTMANDATORYETERM'])) {
            $notMandatory = explode('|', $Settings['NOTMANDATORYETERM']);
            $Settings['NOTMANDATORYETERM'] = $notMandatory;
        }

        return view('customize.layout', array('token' => $token, 'settings' => $Settings, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'einv' => $einv, 'eterm' => $eterm));
    }

    public function myinfo($token, Request $request) {
        $atoken = decrypt($token);
//        list($data) = explode('|', Crypt::decrypt($token));
//        $array_token = json_decode($data, 1);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
//        $idadmin = $array_token['iduser'];
//        $atoken = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));
        if ($level == "B") {
            return redirect(route('accessdenied'));
        }

        $objSettingVal = new Model\Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            if ($partnerId == 0) {
                $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                $objSettingVal->createDefaultPartnerValues($partnerId);
            } else {
                $objSettingVal->refreshPartnerSettings($partnerId);
            }
            $objpartner = new Model\Partners();
            $Settings = $objpartner->getPartnerInfo($idlevel);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $partnerId = $objSettingVal->getPartnersGroup($idpartner);
            if ($GroupId == 0) {
                if ($partnerId == 0) {
                    $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                    $objSettingVal->createDefaultPartnerValues($partnerId);
                } else {
                    $objSettingVal->refreshPartnerSettings($partnerId);
                }
                $GroupId = $objSettingVal->createCompanyGroup($idlevel);
            } else {
                $objSettingVal->refreshPartnerSettings($partnerId);
            }
            $Settings = $obj_company->getCompanyInfo($idlevel);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $partnerId = $objSettingVal->getPartnersGroup($idpartner);
            if ($MerchantId == 0) {
                if ($partnerId == 0) {
                    $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                    $objSettingVal->createDefaultPartnerValues($partnerId);
                } else {
                    $objSettingVal->refreshPartnerSettings($partnerId);
                }
                $MerchantId = $objSettingVal->createPropertyGroup($idlevel);
            } else {
                $objSettingVal->refreshPartnerSettings($partnerId);
            }
            $Settings = $obj_property->getPropertyInfo($idlevel);
            $Settings['contact_name_clients'] = $obj_property->get1PropertyInfo($idlevel, 'contact_name_clients');
            $objpartner = new Model\Partners();
            $subdomain = $Settings['subdomain_clients'];
            $Settings['partner'] = $objpartner->getDomain($Settings['id_partners']);
            $partner = $Settings['partner'];
            $qplogin = $obj_property->getPropertySettings($idlevel, $idcompany, $idpartner, 'QPLOGIN');
            switch ($qplogin) {
                case 1:
                    //quickpay
                    $Settings['clickroute'] = config('app.payor_portal_url') . '/' . $partner . '/properties/' . $subdomain . '/qpay';
                    break;
                case 2:
                    $Settings['clickroute'] = config('app.payor_portal_url') . '/' . $partner . '/properties/' . $subdomain . '/registration';
                    break;
                case 0:
                default:
                    $Settings['clickroute'] = config('app.payor_portal_url') . '/' . $partner . '/properties/' . $subdomain . '/login';
            }
        }
        $asettings = array();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            if ($partnerId == 0) {
                $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                $objSettingVal->createDefaultPartnerValues($partnerId);
            }
            $idgroupM = $partnerId;
            $asettings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            if ($GroupId == 0) {
                $partnerId = $objSettingVal->getPartnersGroup($idpartner);
                if ($partnerId == 0) {
                    $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                    $objSettingVal->createDefaultPartnerValues($partnerId);
                }
                $GroupId = $objSettingVal->createCompanyGroup($idlevel);
            }
            $idgroupM = $GroupId;
            $asettings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            if ($MerchantId == 0) {
                $partnerId = $objSettingVal->getPartnersGroup($idpartner);
                if ($partnerId == 0) {
                    $partnerId = $objSettingVal->createPartnerGroup($idlevel);
                    $objSettingVal->createDefaultPartnerValues($partnerId);
                }
                $MerchantId = $objSettingVal->createPropertyGroup($idlevel);
            }
            $idgroupM = $MerchantId;
            $asettings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }


        $Settings = (array) $Settings;
        $Settings['pageTitle'] = 'My info';
        $Settings['level'] = $level;
        $Settings['idlevel'] = $idlevel;
        $Settings['settings'] = $asettings;
        $Settings['atoken'] = $token;
//        $Settings['atoken'] = $atoken;
        $Settings['token'] = $token;


        return view('customize.myinfo.myinfo', $Settings);
    }

    public function savemyinfo(Request $request) {
        $atoken = decrypt($request->input('token'));
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
//        $idadmin = $array_token['iduser'];
//        $atoken = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));


        if ($level == 'P') {
            $title = "";
            if (null !== $request->input('partner_title')) {
                $title = trim($request->input('partner_title'));
            }
            $partnerid = "";
            if (null !== $request->input('partner_composite_id')) {
                $partnerid = trim($request->input('partner_composite_id'));
            }
            $layoutid = "";
            if (null !== $request->input('layout_id')) {
                $layoutid = trim($request->input('layout_id'));
            }
            $obj_partners = new Model\Partners();
            $obj_partners->set1PartnerInfo($idlevel, 'partner_title', $title);
            $obj_partners->set1PartnerInfo($idlevel, 'partner_composite_id', $partnerid);
            $obj_partners->set1PartnerInfo($idlevel, 'layout_id', $layoutid);
            $logof = $obj_partners->get1PartnerInfo($idlevel, 'logo');
            if ($request->hasFile('logo')) {
                if (trim($logof) != '') {
                    if (file_exists('/logos/partners/' . $logof)) {
                        unlink('/logos/partners/' . $logof);
                    }
                }
                $newlogof = $idlevel . '_' . time() . '_logo.jpg';
                Image::make($request->file('logo')->getRealPath())->widen(255, function ($constraint) {
                    $constraint->upsize();
                })->heighten(72, function ($constraint) {
                    $constraint->upsize();
                })->resizeCanvas(255, 72, 'center', false, 'ffffff')->save('logos/partners/' . $newlogof, 100);
                $obj_partners->set1PartnerInfo($idlevel, 'logo', $newlogof);
            }
            $Settings = $obj_partners->getPartnerInfo($idlevel);
        } elseif ($level == 'G') {
            $title = "";
            if (null !== $request->input('company_name')) {
                $title = trim($request->input('company_name'));
            }
            $partnerid = "";
            if (null !== $request->input('compositeID_companies')) {
                $partnerid = trim($request->input('compositeID_companies'));
            }
            $layoutid = "";
            if (null !== $request->input('clayout_id')) {
                $layoutid = trim($request->input('clayout_id'));
            }
            $addr = "";
            if (null !== $request->input('address')) {
                $addr = trim($request->input('address'));
            }
            $cname = "";
            if (null !== $request->input('contact_name')) {
                $cname = trim($request->input('contact_name'));
            }
            $cemail = "";
            if (null !== $request->input('contact_email')) {
                $cemail = trim($request->input('contact_email'));
            }
            $city = "";
            if (null !== $request->input('city')) {
                $city = trim($request->input('city'));
            }
            $state = "";
            if (null !== $request->input('state')) {
                $state = trim($request->input('state'));
            }
            $zip = "";
            if (null !== $request->input('zip')) {
                $zip = trim($request->input('zip'));
            }
            $phone = "";
            if (null !== $request->input('phone_number')) {
                $phone = trim($request->input('phone_number'));
            }
            $obj_partners = new Model\Companies();
            $obj_partners->set1CompanyInfo($idlevel, 'company_name', $title);
            $obj_partners->set1CompanyInfo($idlevel, 'compositeID_companies', $partnerid);
            $obj_partners->set1CompanyInfo($idlevel, 'clayout_id', $layoutid);
            $obj_partners->set1CompanyInfo($idlevel, 'contact_name', $cname);
            $obj_partners->set1CompanyInfo($idlevel, 'contact_email', $cemail);
            $obj_partners->set1CompanyInfo($idlevel, 'address', $addr);
            $obj_partners->set1CompanyInfo($idlevel, 'city', $city);
            $obj_partners->set1CompanyInfo($idlevel, 'state', $state);
            $obj_partners->set1CompanyInfo($idlevel, 'zip', $zip);
            $obj_partners->set1CompanyInfo($idlevel, 'phone_number', $phone);
            $logof = $obj_partners->get1CompanyInfo($idlevel, 'logo_group');
            if ($request->hasFile('logo')) {
                if (trim($logof) != '') {
                    if (file_exists('logos/companies/' . $logof)) {
                        unlink('logos/companies/' . $logof);
                    }
                }
                $newlogof = $idlevel . '_' . time() . '_logo.jpg';
                Image::make($request->file('logo')->getRealPath())->widen(255, function ($constraint) {
                    $constraint->upsize();
                })->heighten(72, function ($constraint) {
                    $constraint->upsize();
                })->resizeCanvas(255, 72, 'center', false, 'ffffff')->save('logos/companies/' . $newlogof, 100);
                $obj_partners->set1CompanyInfo($idlevel, 'logo_group', $newlogof);
            }
            $Settings = $obj_partners->getCompanyInfo($idlevel);
        } elseif ($level == 'M') {
            $title = "";
            if (null !== $request->input('name_clients')) {
                $title = trim($request->input('name_clients'));
            }
            $partnerid = "";
            if (null !== $request->input('compositeID_clients')) {
                $partnerid = trim($request->input('compositeID_clients'));
            }
            $layoutid = "";
            if (null !== $request->input('playout_id')) {
                $layoutid = trim($request->input('playout_id'));
            }
            $addr = "";
            if (null !== $request->input('address_clients')) {
                $addr = trim($request->input('address_clients'));
            }
            $cname = "";
            if (null !== $request->input('contact_name_clients')) {
                $cname = trim($request->input('contact_name_clients'));
            }
            $cemail = "";
            if (null !== $request->input('email_address_clients')) {
                $cemail = trim($request->input('email_address_clients'));
            }
            $acemail = "";
            if (null !== $request->input('accounting_email_address_clients')) {
                $acemail = trim($request->input('accounting_email_address_clients'));
            }
            $city = "";
            if (null !== $request->input('city_clients')) {
                $city = trim($request->input('city_clients'));
            }
            $state = "";
            if (null !== $request->input('state_clients')) {
                $state = trim($request->input('state_clients'));
            }
            $zip = "";
            if (null !== $request->input('zip_clients')) {
                $zip = trim($request->input('zip_clients'));
            }
            $phone = "";
            if (null !== $request->input('phone_clients')) {
                $phone = trim($request->input('phone_clients'));
            }
            $lockbox_id = "";
            if (null !== $request->input('lockbox_id')) {
                $lockbox_id = trim($request->input('lockbox_id'));
            }
            $bank_id = "";
            if (null !== $request->input('bank_id')) {
                $bank_id = trim($request->input('bank_id'));
            }
            $misc_field = "";
            if (null !== $request->input('misc_field')) {
                $misc_field = trim($request->input('misc_field'));
            }
            $obj_partners = new Model\Properties();
            $obj_partners->set1PropertyInfo($idlevel, 'name_clients', $title);
            $obj_partners->set1PropertyInfo($idlevel, 'compositeID_clients', $partnerid);
            $obj_partners->set1PropertyInfo($idlevel, 'playout_id', $layoutid);
            $obj_partners->set1PropertyInfo($idlevel, 'contact_name_clients', $cname);
            $obj_partners->set1PropertyInfo($idlevel, 'email_address_clients', $cemail);
            $obj_partners->set1PropertyInfo($idlevel, 'accounting_email_address_clients', $acemail);
            $obj_partners->set1PropertyInfo($idlevel, 'address_clients', $addr);
            $obj_partners->set1PropertyInfo($idlevel, 'city_clients', $city);
            $obj_partners->set1PropertyInfo($idlevel, 'state_clients', $state);
            $obj_partners->set1PropertyInfo($idlevel, 'zip_clients', $zip);
            $obj_partners->set1PropertyInfo($idlevel, 'phone_clients', $phone);
            $obj_partners->set1PropertyInfo($idlevel, 'lockbox_id', $lockbox_id);
            $obj_partners->set1PropertyInfo($idlevel, 'bank_id', $bank_id);
            $obj_partners->set1PropertyInfo($idlevel, 'misc_field', $misc_field);
            $logof = $obj_partners->get1PropertyInfo($idlevel, 'logo');
            if ($request->hasFile('logo')) {
                if (trim($logof) != '') {
                    if (file_exists('logos/merchants/' . $logof)) {
                        unlink('logos/merchants/' . $logof);
                    }
                }


                $newlogof = $idlevel . '_' . time() . '_logo.jpg';
                Image::make($request->file('logo')->getRealPath())->widen(255, function ($constraint) {
                    $constraint->upsize();
                })->heighten(72, function ($constraint) {
                    $constraint->upsize();
                })->resizeCanvas(255, 72, 'center', false, 'ffffff')->save('logos/merchants/' . $newlogof, 100);


                $obj_partners->set1PropertyInfo($idlevel, 'logo', $newlogof);
            }
            $Settings = $obj_partners->getPropertyInfo($idlevel);
            $pp = new Model\Partners();
            $idpartner = $obj_partners->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_partners->get1PropertyInfo($idlevel, 'id_companies');
            $Settings['partner'] = $pp->getDomain($idpartner);
            $partner = $Settings['partner'];
            $subdomain = $obj_partners->get1PropertyInfo($idlevel, 'subdomain_clients');
            $qplogin = $obj_partners->getPropertySettings($idlevel, $idcompany, $idpartner, 'QPLOGIN');
            switch ($qplogin) {
                case 1:
                    //quickpay
                    $Settings['clickroute'] = route('qpay', ['partner' => $partner, 'subdomain' => $subdomain]);
                    break;
                case 2:
                    $Settings['clickroute'] = route('newuser', ['partner' => $partner, 'subdomain' => $subdomain]);
                    break;
                case 0:
                default:
                    $Settings['clickroute'] = route('login', ['partner' => $partner, 'subdomain' => $subdomain]);
            }
        }
        /* $Settings['pageTitle']='Customize';
          $Settings['level']=$level;
          $Settings['idlevel']=$idlevel;
          $Settings['msgCode']='savec1';
          $Settings['atoken']=$atoken;
          $Settings['settings']=$asettings; */

        return redirect()->route('myinfo', array('token' => $request->input('token')))->with('success', 'The Information saved successfully');
    }

    public function savelayout(Request $request) {
        $atoken = decrypt($request->input('tokendata'));
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $idgroup = $objSettingVal->getPartnersGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPartnerGroup($idlevel);
            }
        } elseif ($level == 'G') {
            $idgroup = $objSettingVal->getCompaniesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createCompanyGroup($idlevel);
            }
        } elseif ($level == 'M') {
            $idgroup = $objSettingVal->getPropertiesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPropertyGroup($idlevel);
            }
        }
        $propagate = "";
        if (null !== $request->input('propagate')) {
            $propagate = trim($request->input('propagate'));
        }
        if ($propagate == 'on') {
            $propagate = true;
        } else {
            $propagate = false;
        }
        $merchant = "";
        if (null !== $request->input('hidemerchantinfo')) {
            $merchant = trim($request->input('hidemerchantinfo'));
        }
        $reply = "";
        if (null !== $request->input('REPLYTCKCUST')) {
            $reply = trim($request->input('REPLYTCKCUST'));
        }
        $dfrom = "";
        if (null !== $request->input('default_from')) {
            $dfrom = trim($request->input('default_from'));
        }
        $help = "";
        if (null !== $request->input('HELPDISCLAIMER')) {
            $help = trim($request->input('HELPDISCLAIMER'));
        }
        $newhelp = "";
        if (null !== $request->input('NEWHELP')) {
            $newhelp = trim($request->input('NEWHELP'));
        }
        $userguide = "";
        if (null !== $request->input('userguide')) {
            $userguide = trim($request->input('userguide'));
        }
        $main = "";
        if (null !== $request->input('maintenance')) {
            $main = trim($request->input('maintenance'));
        }
        $mainmail = "";
        if (null !== $request->input('maintenancemail')) {
            $mainmail = trim($request->input('maintenancemail'));
        }
        $qlogin = "";
        if (null !== $request->input('qlogin')) {
            $qlogin = trim($request->input('qlogin'));
        }
        $fav1 = "";
        if (null !== $request->input('favorites1')) {
            $fav1 = trim($request->input('favorites1'));
        }
        $fav2 = "";
        if (null !== $request->input('favorites2')) {
            $fav2 = trim($request->input('favorites2'));
        }
        $fav3 = "";
        if (null !== $request->input('favorites3')) {
            $fav3 = trim($request->input('favorites3'));
        }
        $scn = "";
        if (null !== $request->input('SHOWCOMPANYNAME')) {
            $scn = trim($request->input('SHOWCOMPANYNAME'));
        }
        $topstab = "";
        if (null !== $request->input('TOPSTAB')) {
            $topstab = trim($request->input('TOPSTAB'));
        }
        $value_mandatory = "";
        if (isset($_POST['check_list'])) {
            $value_mandatory = implode('|', $_POST['check_list']);
        }

        $objSettingVal->saveSettingValue($idgroup, 'NOTMANDATORYETERM', $value_mandatory);

        if ($fav1 != '') {
            $favorites = implode('|', array(strip_tags($fav1), strip_tags($fav2), strip_tags($fav3)));
            $objSettingVal->saveSettingValue($idgroup, 'favorites_tiles', $favorites);
        }
        if ($merchant == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'hidemerchantinfo', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'hidemerchantinfo', 0);
        }
        if ($scn == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'SHOWCOMPANYNAME', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'SHOWCOMPANYNAME', 0);
        }
        if ($reply == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'REPLYTCKCUST', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'REPLYTCKCUST', 0);
        }
        if ($dfrom != "") {
            $objSettingVal->saveSettingValue($idgroup, 'default_from', strip_tags($dfrom));
        }
        if ($help != "") {
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $help);
            $help = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $objSettingVal->saveSettingValue($idgroup, 'helpdisclaimer', $help);
        }
        if ($newhelp != "") {
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $newhelp);
            $newhelp = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $objSettingVal->saveSettingValue($idgroup, 'newhelp', $newhelp);
        }
        if ($userguide != "") {
            $objSettingVal->saveSettingValue($idgroup, 'userguide', strip_tags($userguide));
        }
        if ($main == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'maintenance', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'maintenance', 0);
        }
        if ($mainmail != "") {
            $objSettingVal->saveSettingValue($idgroup, 'maintenancemail', strip_tags($mainmail));
        }
        if ($qlogin != "") {
            $objSettingVal->saveSettingValue($idgroup, 'qplogin', strip_tags($qlogin));
        }
        if ($topstab == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'TOPSTAB', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'TOPSTAB', 0);
        }
        if ($level == 'P') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderPartner($idlevel, 'hidemerchantinfo');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'REPLYTCKCUST');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'default_from');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'helpdisclaimer');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'newhelp');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'userguide');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'maintenance');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'maintenancemail');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'qplogin');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'favorites_tiles');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'showcompanyname');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'TOPSTAB');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'NOTMANDATORYETERM');
            }
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderPartner($partnerId, $idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderCompany($idlevel, 'hidemerchantinfo');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'REPLYTCKCUST');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'default_from');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'helpdisclaimer');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'newhelp');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'userguide');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'maintenance');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'maintenancemail');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'qplogin');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'favorites_tiles');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'showcompanyname');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'TOPSTAB');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'NOTMANDATORYETERM');
            }
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderCompany($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $objSettingVal->UpdatePublishedUnderMerchant($idlevel);
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        //new code for setting NOT MANDATORY
        if (isset($Settings['NOTMANDATORYETERM']) && !empty($Settings['NOTMANDATORYETERM'])) {
            $notMandatory = explode('|', $Settings['NOTMANDATORYETERM']);
            $Settings['NOTMANDATORYETERM'] = $notMandatory;
        }

        return back()->with('success', 'Layout Saved');
//        return view('admin.layout', array('token' => $atoken, 'settings' => $Settings, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'msgCode' => 'savec1'));
    }

    public function savereportcfg(Request $request) {
        $atoken = $request->input('tokendata');
        $array_token = decrypt($atoken);
        $level = $array_token['level'];
        $idlevel = $array_token['level_id'];

        $objSettingVal = new Customize();
        if ($level == 'P') {
            $idgroup = $objSettingVal->getPartnersGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPartnerGroup($idlevel);
            }
        } elseif ($level == 'G') {
            $idgroup = $objSettingVal->getCompaniesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createCompanyGroup($idlevel);
            }
        } elseif ($level == 'M') {
            $idgroup = $objSettingVal->getPropertiesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPropertyGroup($idlevel);
            }
        }
        $type = $request->input('treport');
        if ($type == 'excel') {
            $data = "field1:" . $request->input("excelfield1") . "|" . "field2:" . $request->input("excelfield2") . "|" . "field3:" . $request->input("excelfield3") . "|" . "field4:" . $request->input("excelfield4") . "|" . "field5:" . $request->input("excelfield5") . "|" . "field6:" . $request->input("excelfield6") . "|" . "field7:" . $request->input("excelfield7") . "|" . "field8:" . $request->input("excelfield8") . "|" . "field9:" . $request->input("excelfield9") . "|" . "field10:" . $request->input("excelfield10") . "|" . "field11:" . $request->input("excelfield11") . "|" . "field12:" . $request->input("excelfield12") . "|" . "field13:" . $request->input("excelfield13") . "|" . "field14:" . $request->input("excelfield14") . "|" . "field15:" . $request->input("excelfield15") . "|" . "field16:" . $request->input("excelfield16") . "|" . "field17:" . $request->input("excelfield17") . "|" . "field18:" . $request->input("excelfield18") . "|" . 'REPORTEXCEL';
            $objSettingVal->saveSettingValue($idgroup, 'REPORTEXCEL', $data);
        } elseif ($type == 'jenark') {
            $data = "field1:" . $request->input("jfield1") . "|" . "field2:" . $request->input("jfield2") . "|" . "field3:" . $request->input("jfield3") . "|" . "field4:" . $request->input("jfield4") . "|" . 'REPORTJENARK';
            $objSettingVal->saveSettingValue($idgroup, 'REPORTJENARK', $data);
        } elseif ($type == 'mri') {
            $data = "field1:" . $request->input("MSIfield1") . "|" . "field2:" . $request->input("MSIfield2") . "|" . "field3:JE|" . "field4:@|" . "field5:" . $request->input("MSIfield5") . "|" . "field6:" . $request->input("MSIfield6") . "|" . "field7:" . $request->input("MSIfield7") . "|" . "field8:" . $request->input("MSIfield8") . "|" . "field9:" . $request->input("MSIfield9") . "|" . "field10:" . $request->input("MSIfield10") . "|" . "field11:" . $request->input("MSIfield11") . "|" . "field12:" . $request->input("MSIfield12") . "|" . "field13:N|" . "field14:P|" . "field15:" . $request->input("MSIfield15") . "|" . "field16:A|" . "field17:" . $request->input("MSIfield17") . "|" . "field18:" . $request->input("MSIfield18") . "|" . "field19:" . $request->input("MSIfield19") . "|" . "field20:" . $request->input("MSIfield10") . "|" . "field21:" . $request->input("MSIfield21") . "|" . "field22:N|" . "field23:" . $request->input("MSIfield23") . "|" . "field24:" . $request->input("MSIfield24") . "|" . "field25:" . $request->input("MSIfield25") . "|" . "field26:" . $request->input("MSIfield26") . "|" . "field27:N|" . "field28:N|" . "field29:" . $request->input("MSIfield29") . "|" . "field30:" . $request->input("MSIfield30") . "|" . "field31:" . $request->input("MSIfield31") . "|" . "field32:" . $request->input("MSIfield32") . "|" . "field33:" . $request->input("MSIfield33") . "|" . "field34:" . $request->input("MSIfield34") . "|" . "field35:" . $request->input("MSIfield35") . "|" . "field36:" . $request->input("MSIfield36") . "|" . "field37:" . $request->input("MSIfield37") . "|" . "field38:" . $request->input("MSIfield38") . "|" . "field39:" . $request->input("MSIfield39") . "|" . "field40:0!|" . "field41:" . $request->input("MSIfield41") . "|" . "field42:" . $request->input("MSIfield42") . "|" . "field43:0!|" . "field44:" . $request->input("MSIfield44") . "|" . "field45:0!|" . 'REPORTMRI';
            $objSettingVal->saveSettingValue($idgroup, 'REPORTMRI', $data);
        } elseif ($type == 'peach') {
            $data = "field1:" . $request->input("pfield1") . "|" . "field2:" . $request->input("pfield2") . "|" . "field3:" . $request->input("pfield3") . "|" . "field4:" . $request->input("pfield4") . "|" . "field5:" . $request->input("pfield5") . "|" . "field6:" . $request->input("pfield6") . "|" . 'REPORTPEACHTREE';
            $objSettingVal->saveSettingValue($idgroup, 'REPORTPEACHTREE', $data);
        } elseif ($type == 'sage') {
            $data = "field2:" . $request->input("SAfield2") . "|" . "field5:" . $request->input("SAfield5") . "|" . "field6:" . $request->input("SAfield6") . "|" . "field7:" . $request->input("SAfield7") . "|" . "field8:" . $request->input("SAfield8") . "|" . 'REPORTSAGE';
            $objSettingVal->saveSettingValue($idgroup, 'REPORTSAGE', $data);
        } elseif ($type == 'sky') {
            $data = "field1:GLDET|" . "field2:" . $request->input("Sfield2") . "|" . "field3:" . $request->input("Sfield3") . "|" . "field4:" . $request->input("Sfield4") . "|" . "field5:" . $request->input("Sfield5") . "|" . "field6:" . $request->input("Sfield6") . "|" . "field7:" . $request->input("Sfield7") . "|" . "field8:!1|" . "field9:" . $request->input("Sfield9") . "|" . "field10:C|" . 'REPORTSKYLINE';
            $objSettingVal->saveSettingValue($idgroup, 'REPORTSKYLINE', $data);
        } elseif ($type == 'yardi') {
            $data = "field2:" . $request->input("yfield2") . "|" . "field3:" . $request->input("yfield3") . "|" . "field4:" . $request->input("yfield4") . "|" . "field5:" . $request->input("yfield5") . "|" . "field6:Month|" . "field7:" . $request->input("yfield7") . "|" . "field8:" . $request->input("yfield8") . "|" . "field9:" . $request->input("yfield9") . "|" . "field10:" . $request->input("yfield10") . "|" . "field11:" . $request->input("yfield11") . "|" . "field12:" . $request->input("yfield12") . "|" . "field13:" . $request->input("yfield13") . "|" . "field14:" . $request->input("yfield14") . "|" . "field15:" . $request->input("yfield15") . "|" . "field16:!0|" . "field17:" . $request->input("yfield17") . "|" . 'REPORTYARDI';
            $objSettingVal->saveSettingValue($idgroup, 'REPORTYARDI', $data);
        }

        return redirect()->route('creports', ['token' => $atoken]);
    }

    public function savereports(Request $request) {
        $atoken = $request->input('tokendata');

        $array_token = decrypt($atoken);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $idgroup = $objSettingVal->getPartnersGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPartnerGroup($idlevel);
            }
        } elseif ($level == 'G') {
            $idgroup = $objSettingVal->getCompaniesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createCompanyGroup($idlevel);
            }
        } elseif ($level == 'M') {
            $idgroup = $objSettingVal->getPropertiesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPropertyGroup($idlevel);
            }
        }
        $propagate = "";
        if (null !== $request->input('propagate')) {
            $propagate = trim($request->input('propagate'));
        }
        if ($propagate == 'on') {
            $propagate = true;
        } else {
            $propagate = false;
        }
        $check = "";
        if (null !== $request->input('CHECKEXCEL')) {
            $check = trim($request->input('CHECKEXCEL'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKEXCEL', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKEXCEL', 0);
        }
        $check = "";
        if (null !== $request->input('CHECKJENARK')) {
            $check = trim($request->input('CHECKJENARK'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKJENARK', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKJENARK', 0);
        }
        $check = "";
        if (null !== $request->input('CHECKPEACHTREE')) {
            $check = trim($request->input('CHECKPEACHTREE'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKPEACHTREE', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKPEACHTREE', 0);
        }
        $check = "";
        if (null !== $request->input('CHECKQBOOKS')) {
            $check = trim($request->input('CHECKQBOOKS'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKQBOOKS', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKQBOOKS', 0);
        }
        $check = "";
        if (null !== $request->input('CHECKYARDI')) {
            $check = trim($request->input('CHECKYARDI'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKYARDI', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKYARDI', 0);
        }
        $check = "";
        if (null !== $request->input('CHECKSAGE')) {
            $check = trim($request->input('CHECKSAGE'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKSAGE', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKSAGE', 0);
        }
        $check = "";
        if (null !== $request->input('CHECKTOPS')) {
            $check = trim($request->input('CHECKTOPS'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKTOPS', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKTOPS', 0);
        }
        $check = "";
        if (null !== $request->input('CHECKSKYLINE')) {
            $check = trim($request->input('CHECKSKYLINE'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKSKYLINE', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKSKYLINE', 0);
        }
        $check = "";
        if (null !== $request->input('CHECKMRI')) {
            $check = trim($request->input('CHECKMRI'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKMRI', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CHECKMRI', 0);
        }
        $check = "";
        if (null !== $request->input('CM8')) {
            $check = trim($request->input('CM8'));
        }
        if ($check == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CM8', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CM8', 0);
        }
        if ($level == 'P') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CM8');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKMRI');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKSKYLINE');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKTOPS');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKSAGE');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKYARDI');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKQBOOKS');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKPEACHTREE');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKJENARK');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CHECKEXCEL');
            }
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderPartner($partnerId, $idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CM8');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKMRI');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKSKYLINE');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKTOPS');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKSAGE');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKYARDI');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKQBOOKS');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKPEACHTREE');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKJENARK');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CHECKEXCEL');
            }
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderCompany($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $objSettingVal->UpdatePublishedUnderMerchant($idlevel);
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        return redirect()->route('creports', array('token' => $atoken))->with('success', 'Report formats saved successfully');
    }

    public function saveemailtemp(Request $request) {
        $atoken = $request->input('tokendata');
        $array_token = decrypt($atoken);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $objSettingVal = new Customize();
        if ($level == 'P') {
            $idgroup = $objSettingVal->getPartnersGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPartnerGroup($idlevel);
            }
        } elseif ($level == 'G') {
            $idgroup = $objSettingVal->getCompaniesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createCompanyGroup($idlevel);
            }
        } elseif ($level == 'M') {
            $idgroup = $objSettingVal->getPropertiesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPropertyGroup($idlevel);
            }
        }
        $propagate = "";
        if (null !== $request->input('propagate')) {
            $propagate = trim($request->input('propagate'));
        }
        if ($propagate == 'on') {
            $propagate = true;
        } else {
            $propagate = false;
        }
        $subject = "";
        if (null !== $request->input('SUCCESSFULEMAIL_SUBJECT')) {
            $subject = trim($request->input('SUCCESSFULEMAIL_SUBJECT'));
        }
        $body = "";
        if (null !== $request->input('SUCCESSFULEMAIL')) {
            $body = trim($request->input('SUCCESSFULEMAIL'));
        }
        if ($body != "") {
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $subject);
            $subject = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $body);
            $body = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $objSettingVal->saveSettingValue($idgroup, 'SUCCESSFULEMAIL', $subject . '|' . $body);
        }
        $subject = "";
        if (null !== $request->input('UNSUCCESSFULEMAIL_SUBJECT')) {
            $subject = trim($request->input('UNSUCCESSFULEMAIL_SUBJECT'));
        }
        $body = "";
        if (null !== $request->input('UNSUCCESSFULEMAIL')) {
            $body = trim($request->input('UNSUCCESSFULEMAIL'));
        }
        if ($body != "") {
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $subject);
            $subject = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $body);
            $body = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $objSettingVal->saveSettingValue($idgroup, 'UNSUCCESSFULEMAIL', $subject . '|' . $body);
        }
        $subject = "";
        if (null !== $request->input('INSFEMAIL_SUBJECT')) {
            $subject = trim($request->input('INSFEMAIL_SUBJECT'));
        }
        $body = "";
        if (null !== $request->input('INSFEMAIL')) {
            $body = trim($request->input('INSFEMAIL'));
        }
        if ($body != "") {
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $subject);
            $subject = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $body);
            $body = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $objSettingVal->saveSettingValue($idgroup, 'INSFEMAIL', $subject . '|' . $body);
        }
        $subject = "";
        if (null !== $request->input('RECCURRINGENDEMAIL_SUBJECT')) {
            $subject = trim($request->input('RECCURRINGENDEMAIL_SUBJECT'));
        }
        $body = "";
        if (null !== $request->input('RECCURRINGENDEMAIL')) {
            $body = trim($request->input('RECCURRINGENDEMAIL'));
        }
        if ($body != "") {
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $subject);
            $subject = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $body);
            $body = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $objSettingVal->saveSettingValue($idgroup, 'RECCURRINGENDEMAIL', $subject . '|' . $body);
        }
        $subject = "";
        if (null !== $request->input('RECURRINGEXPIRESEMAIL_SUBJECT')) {
            $subject = trim($request->input('RECURRINGEXPIRESEMAIL_SUBJECT'));
        }
        $body = "";
        if (null !== $request->input('RECURRINGEXPIRESEMAIL')) {
            $body = trim($request->input('RECURRINGEXPIRESEMAIL'));
        }
        if ($body != "") {
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $subject);
            $subject = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $html = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $body);
            $body = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $html);
            $objSettingVal->saveSettingValue($idgroup, 'RECURRINGEXPIRESEMAIL', $subject . '|' . $body);
        }
        if ($level == 'P') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderPartner($idlevel, 'SUCCESSFULEMAIL');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'UNSUCCESSFULEMAIL');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'INSFEMAIL');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'RECCURRINGENDEMAIL');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'RECURRINGEXPIRESEMAIL');
            }
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderPartner($partnerId, $idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderCompany($idlevel, 'SUCCESSFULEMAIL');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'UNSUCCESSFULEMAIL');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'INSFEMAIL');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'RECCURRINGENDEMAIL');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'RECURRINGEXPIRESEMAIL');
            }
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderCompany($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $objSettingVal->UpdatePublishedUnderMerchant($idlevel);
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        if (isset($Settings['SUCCESSFULEMAIL'])) {
            $tmp_email = explode("|", $Settings['SUCCESSFULEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['SUCCESSFULEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['SUCCESSFULEMAIL'] = $tmp_email[1];
            } else {
                $Settings['SUCCESSFULEMAIL_SUBJECT'] = "";
            }
        }

        if (isset($Settings['UNSUCCESSFULEMAIL'])) {
            $tmp_email = explode("|", $Settings['UNSUCCESSFULEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['UNSUCCESSFULEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['UNSUCCESSFULEMAIL'] = $tmp_email[1];
            } else {
                $Settings['UNSUCCESSFULEMAIL_SUBJECT'] = "";
            }
        }

        if (isset($Settings['RECCURRINGENDEMAIL'])) {
            $tmp_email = explode("|", $Settings['RECCURRINGENDEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['RECCURRINGENDEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['RECCURRINGENDEMAIL'] = $tmp_email[1];
            } else {
                $Settings['RECCURRINGENDEMAIL_SUBJECT'] = "";
            }
        }

        if (isset($Settings['RECURRINGEXPIRESEMAIL'])) {
            $tmp_email = explode("|", $Settings['RECURRINGEXPIRESEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['RECURRINGEXPIRESEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['RECURRINGEXPIRESEMAIL'] = $tmp_email[1];
            } else {
                $Settings['RECURRINGEXPIRESEMAIL_SUBJECT'] = "";
            }
        }

        if (isset($Settings['INSFEMAIL'])) {
            $tmp_email = explode("|", $Settings['INSFEMAIL'], 2);
            if (count($tmp_email) > 1) {
                $Settings['INSFEMAIL_SUBJECT'] = $tmp_email[0];
                $Settings['INSFEMAIL'] = $tmp_email[1];
            } else {
                $Settings['INSFEMAIL_SUBJECT'] = "";
            }
        }
        return redirect()->route('emailtemp', array('token' => $atoken))->with('success', 'Email saved successfully');
    }

    public function savenotifications(Request $request) {
        $atoken = decrypt($request->input('tokendata')); // its orignial token
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];

        $objSettingVal = new Customize();
        if ($level == 'P') {
            $idgroup = $objSettingVal->getPartnersGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPartnerGroup($idlevel);
            }
        } elseif ($level == 'G') {
            $idgroup = $objSettingVal->getCompaniesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createCompanyGroup($idlevel);
            }
        } elseif ($level == 'M') {
            $idgroup = $objSettingVal->getPropertiesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPropertyGroup($idlevel);
            }
        }
        $propagate = "";
        if (null !== $request->input('propagate')) {
            $propagate = trim($request->input('propagate'));
        }
        if ($propagate == 'on') {
            $propagate = true;
        } else {
            $propagate = false;
        }
        $showlimit = "";
        if (null !== $request->input('notsuccessfulemail')) {
            $showlimit = trim($request->input('notsuccessfulemail'));
        }
        if ($showlimit == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'notsuccessfulemail', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'notsuccessfulemail', 0);
        }

        $showlimit = "";
        if (null !== $request->input('notsuccessfulemailrec')) {
            $showlimit = trim($request->input('notsuccessfulemailrec'));
        }
        if ($showlimit == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'notsuccessfulemailrec', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'notsuccessfulemailrec', 0);
        }

        $showlimit = "";
        if (null !== $request->input('notnsf')) {
            $showlimit = trim($request->input('notnsf'));
        }
        if ($showlimit == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'notnsf', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'notnsf', 0);
        }
        $showlimit = "";
        if (null !== $request->input('notunsuccessfulemail')) {
            $showlimit = trim($request->input('notunsuccessfulemail'));
        }
        if ($showlimit == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'notunsuccessfulemail', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'notunsuccessfulemail', 0);
        }
        $showlimit = "";
        if (null !== $request->input('notrecurringexpiresemail')) {
            $showlimit = trim($request->input('notrecurringexpiresemail'));
        }
        if ($showlimit == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'notrecurringexpiresemail', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'notrecurringexpiresemail', 0);
        }
        $showlimit = "";
        if (null !== $request->input('notrecurringendemail')) {
            $showlimit = trim($request->input('notrecurringendemail'));
        }
        if ($showlimit == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'notrecurringendemail', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'notrecurringendemail', 0);
        }
        $showlimit = "";
        if (null !== $request->input('donotreplyemail')) {
            $showlimit = trim($request->input('donotreplyemail'));
        }
        if ($showlimit == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'donotreplyemail', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'donotreplyemail', 0);
        }
        if ($level == 'P') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderPartner($idlevel, 'donotreplyemail');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'notrecurringendemail');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'notrecurringexpiresemail');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'notunsuccessfulemail');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'notnsf');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'notsuccessfulemail');
            }
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderPartner($partnerId, $idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderCompany($idlevel, 'donotreplyemail');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'notrecurringendemail');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'notrecurringexpiresemail');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'notunsuccessfulemail');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'notnsf');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'notsuccessfulemail');
            }
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderCompany($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $objSettingVal->UpdatePublishedUnderMerchant($idlevel);
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

//        return view('customize.notifications', array('atoken' => $atoken, 'settings' => $Settings, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'msgCode' => 'savec1', 'token' => $request->input('tokendata')));
        return Redirect::back()->with('success', 'Successfully Update Notification');
    }

    public function savepaymentpage(Request $request) {
        $atoken = $request->input('tokendata');


        $array_token = decrypt($atoken);

        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];



        $objSettingVal = new Customize();
        if ($level == 'P') {
            $idgroup = $objSettingVal->getPartnersGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPartnerGroup($idlevel);
            }
        } elseif ($level == 'G') {
            $idgroup = $objSettingVal->getCompaniesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createCompanyGroup($idlevel);
            }
        } elseif ($level == 'M') {
            $idgroup = $objSettingVal->getPropertiesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPropertyGroup($idlevel);
            }
        }
        $propagate = "";
        if (null !== $request->input('propagate')) {
            $propagate = trim($request->input('propagate'));
        }
        if ($propagate == 'on') {
            $propagate = true;
        } else {
            $propagate = false;
        }
        $lockedfields = array();
        if (null !== $request->input('locked_account_number')) {
            $val = $request->input('locked_account_number');
            if ($val == 'on') {
                $lockedfields[] = 'account_number';
            }
        }
        if (null !== $request->input('locked_first_name')) {
            $val = $request->input('locked_first_name');
            if ($val == 'on') {
                $lockedfields[] = 'first_name';
            }
        }
        if (null !== $request->input('locked_last_name')) {
            $val = $request->input('locked_last_name');
            if ($val == 'on') {
                $lockedfields[] = 'last_name';
            }
        }
        if (null !== $request->input('locked_email_address')) {
            $val = $request->input('locked_email_address');
            if ($val == 'on') {
                $lockedfields[] = 'email_address';
            }
        }
        if (null !== $request->input('locked_phone')) {
            $val = $request->input('locked_phone');
            if ($val == 'on') {
                $lockedfields[] = 'phone_number';
            }
        }
        if (null !== $request->input('locked_address')) {
            $val = $request->input('locked_address');
            if ($val == 'on') {
                $lockedfields[] = 'address';
            }
        }
        if (null !== $request->input('locked_unit')) {
            $val = $request->input('locked_unit');
            if ($val == 'on') {
                $lockedfields[] = 'address_unit';
            }
        }
        if (null !== $request->input('locked_city')) {
            $val = $request->input('locked_city');
            if ($val == 'on') {
                $lockedfields[] = 'city';
            }
        }
        if (null !== $request->input('locked_state')) {
            $val = $request->input('locked_state');
            if ($val == 'on') {
                $lockedfields[] = 'state';
            }
        }
        if (null !== $request->input('locked_zip')) {
            $val = $request->input('locked_zip');
            if ($val == 'on') {
                $lockedfields[] = 'zip';
            }
        }
        $locked_fields = implode('|', $lockedfields);
        $objSettingVal->saveSettingValue($idgroup, 'LOCKED_PROFILE_FIELDS_SELF', $locked_fields);
        $drpmethod = array();
        if (null !== $request->input('drpcc')) {
            $val = $request->input('drpcc');
            if ($val == 'on') {
                $drpmethod[] = 'cc';
            }
        }
        if (null !== $request->input('drpec')) {
            $val = $request->input('drpec');
            if ($val == 'on') {
                $drpmethod[] = 'ec';
            }
        }
        $drp_fields = implode('|', $drpmethod);
        $objSettingVal->saveSettingValue($idgroup, 'DRPMETHODS', $drp_fields);
        $nomemo = "";
        if (null !== $request->input('nomemo')) {
            $nomemo = trim($request->input('nomemo'));
        }
        if ($nomemo == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'nomemo', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'nomemo', 0);
        }
        $oneclick = "";
        if (null !== $request->input('oneclick')) {
            $oneclick = trim($request->input('oneclick'));
        }
        if ($oneclick == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'oneclick', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'oneclick', 0);
        }
        $showlimit = "";
        if (null !== $request->input('SHOWLIMIT1')) {
            $showlimit = trim($request->input('SHOWLIMIT1'));
        }
        if ($showlimit == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'showlimit1', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'showlimit1', 0);
        }
        $nosocial = "";
        if (null !== $request->input('nosocial')) {
            $nosocial = trim($request->input('nosocial'));
        }
        if ($nosocial == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'nosocial', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'nosocial', 0);
        }
        $showlimit = "";
        if (null !== $request->input('DEFAULTPC')) {
            $showlimit = trim($request->input('DEFAULTPC'));
        }
        if ($showlimit != "") {
            $objSettingVal->saveSettingValue($idgroup, 'defaultpc', $showlimit);
        }
        $showbalance = "";
        if (null !== $request->input('SHOW_BALANCE')) {
            $showbalance = trim($request->input('SHOW_BALANCE'));
        }
        if ($showbalance == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'show_balance', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'show_balance', 0);
        }
        $disclaimer = null;
        if (null !== $request->input('SETTLMENT_DISCLAIMER')) {
            $disclaimer = trim($request->input('SETTLMENT_DISCLAIMER'));
        }
        if (notNullValue($disclaimer)) {
            if ($disclaimer != "") {
                $disclaimer = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $disclaimer);
                $disclaimer = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $disclaimer);
            }
            $objSettingVal->saveSettingValue($idgroup, 'SETTLMENT_DISCLAIMER', $disclaimer);
        }
        $showobox = "";
        if (null !== $request->input('showopenbox'))
            $showobox = trim($request->input('showopenbox'));
        if ($showobox == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'SHOWOPENBOX', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'SHOWOPENBOX', 0);
        }
        $openboxcontent = NULL;
        if (null !== $request->input('OPENBOXCONTENT'))
            $openboxcontent = trim($request->input('OPENBOXCONTENT'));
        if (notNullValue($openboxcontent)) {
            if ($openboxcontent != "") {
                $openboxcontent = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $openboxcontent);
                $openboxcontent = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $openboxcontent);
            }
            $objSettingVal->saveSettingValue($idgroup, 'OPENBOXCONTENT', $openboxcontent);
        }
        $fixauto = "";
        if (null !== $request->input('FIXEDRECURRING')) {
            $fixauto = trim($request->input('FIXEDRECURRING'));
        }
        if ($fixauto == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'FIXEDRECURRING', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'FIXEDRECURRING', 0);
        }
        $fixauto = "";
        if (null !== $request->input('DYNAMICRECURRING')) {
            $fixauto = trim($request->input('DYNAMICRECURRING'));
        }
        if ($fixauto == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'DYNAMICRECURRING', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'DYNAMICRECURRING', 0);
        }
        $fixauto = "";
        if (null !== $request->input('keep_auto')) {
            $fixauto = trim($request->input('keep_auto'));
        }
        if ($fixauto == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'keepauto', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'keepauto', 0);
        }
        $cancel_restrictions = "";
        if (null !== $request->input('cancel_restrictions')) {
            $cancel_restrictions = trim($request->input('cancel_restrictions'));
        }
        if ($cancel_restrictions == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'CANCELRESTRICTIONS', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'CANCELRESTRICTIONS', 0);
        }

        //no apply fee to eterminal
        $no_conveniencefee = "";
        if (null !== $request->input('no_conveniencefee')) {
            $no_conveniencefee = trim($request->input('no_conveniencefee'));
        }
        if ($no_conveniencefee == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'NOAPPLYCFEE', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'NOAPPLYCFEE', 0);
        }

        //walkin payments
        $services_fee = "";
        if (null !== $request->input('allow_servicesfee')) {
            $services_fee = trim($request->input('allow_servicesfee'));
        }
        if ($services_fee == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'ETERMSERV', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'ETERMSERV', 0);
        }

        $auto_reminder = "";
        if (null !== $request->input('AUTOREMINDER')) {
            $auto_reminder = trim($request->input('AUTOREMINDER'));
        }
        if ($auto_reminder == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'AUTOREMINDER', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'AUTOREMINDER', 0);
        }

        $maxauto = "0";
        if (null !== $request->input('MAXRECURRINGPAYMENTPERUSER')) {
            $maxauto = trim($request->input('MAXRECURRINGPAYMENTPERUSER'));
            if(trim($maxauto)==''){
                $maxauto="0";
            }
        }
        $objSettingVal->saveSettingValue($idgroup, 'MAXRECURRINGPAYMENTPERUSER', $maxauto);
        $freq = array();
        if (null !== $request->input('monthly')) {
            $val = $request->input('monthly');
            if ($val == 'on') {
                $freq[] = 'monthly';
            }
        }
        if (null !== $request->input('quarterly')) {
            $val = $request->input('quarterly');
            if ($val == 'on') {
                $freq[] = 'quarterly';
            }
        }
        if (null !== $request->input('triannually')) {
            $val = $request->input('triannually');
            if ($val == 'on') {
                $freq[] = 'triannually';
            }
        }
        if (null !== $request->input('biannually')) {
            $val = $request->input('biannually');
            if ($val == 'on') {
                $freq[] = 'biannually';
            }
        }
        if (null !== $request->input('annually')) {
            $val = $request->input('annually');
            if ($val == 'on') {
                $freq[] = 'annually';
            }
        }
        if (null !== $request->input('onetime')) {
            $val = $request->input('onetime');
            if ($val == 'on') {
                $freq[] = 'onetime';
            }
        }
        if (null !== $request->input('weekly')) {
            $val = $request->input('weekly');
            if ($val == 'on') {
                $freq[] = 'weekly';
            }
        }
        if (null !== $request->input('biweekly')) {
            $val = $request->input('biweekly');
            if ($val == 'on') {
                $freq[] = 'biweekly';
            }
        }
        if (null !== $request->input('untilcancel')) {
            $val = $request->input('untilcancel');
            if ($val == 'on') {
                $freq[] = 'untilcancel';
            }
        }
        $freqday = implode('|', $freq);
        $objSettingVal->saveSettingValue($idgroup, 'FREQAUTOPAY', $freqday);
        $in = 1;
        if (null !== $request->input('STARTAUTOPAYDAY')) {
            $in = $request->input('STARTAUTOPAYDAY');
        }
        $en = 31;
        if (null !== $request->input('ENDAUTOPAYDAY')) {
            $en = $request->input('ENDAUTOPAYDAY');
        }
        $objSettingVal->saveSettingValue($idgroup, 'DAYSAUTOPAY', $in . '|' . $en);
        $disclaimer = null;
        if (null !== $request->input('DYNAMICRECURRINGTEXT')) {
            $disclaimer = trim($request->input('DYNAMICRECURRINGTEXT'));
        }

        if (notNullValue($disclaimer)) {
            if ($disclaimer != "") {
                $disclaimer = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $disclaimer);
                $disclaimer = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $disclaimer);
            }
            $objSettingVal->saveSettingValue($idgroup, 'DYNAMICRECURRINGTEXT', $disclaimer);
        }
        $freq = array();
        if (null !== $request->input('drpmonthly')) {
            $val = $request->input('drpmonthly');
            if ($val == 'on') {
                $freq[] = 'monthly';
            }
        }
        if (null !== $request->input('drpquarterly')) {
            $val = $request->input('drpquarterly');
            if ($val == 'on') {
                $freq[] = 'quarterly';
            }
        }
        if (null !== $request->input('drptriannually')) {
            $val = $request->input('drptriannually');
            if ($val == 'on') {
                $freq[] = 'triannually';
            }
        }
        if (null !== $request->input('drpbiannually')) {
            $val = $request->input('drpbiannually');
            if ($val == 'on') {
                $freq[] = 'biannually';
            }
        }
        if (null !== $request->input('drpannually')) {
            $val = $request->input('drpannually');
            if ($val == 'on') {
                $freq[] = 'annually';
            }
        }
        if (null !== $request->input('drponetime')) {
            $val = $request->input('drponetime');
            if ($val == 'on') {
                $freq[] = 'onetime';
            }
        }
        if (null !== $request->input('drpweekly')) {
            $val = $request->input('drpweekly');
            if ($val == 'on') {
                $freq[] = 'weekly';
            }
        }
        if (null !== $request->input('drpbiweekly')) {
            $val = $request->input('drpbiweekly');
            if ($val == 'on') {
                $freq[] = 'biweekly';
            }
        }
        if (null !== $request->input('drpuntilcancel')) {
            $val = $request->input('drpuntilcancel');
            if ($val == 'on') {
                $freq[] = 'untilcancel';
            }
        }

        $freqday = implode('|', $freq);
        $objSettingVal->saveSettingValue($idgroup, 'DRPFREQAUTOPAY', $freqday);
        $in = 1;
        if (null !== $request->input('DRPSTARTAUTOPAYDAY')) {
            $in = $request->input('DRPSTARTAUTOPAYDAY');
        }
        $en = 31;
        if (null !== $request->input('DRPENDAUTOPAYDAY')) {
            $en = $request->input('DRPENDAUTOPAYDAY');
        }
        $objSettingVal->saveSettingValue($idgroup, 'DRPDAYSAUTOPAY', $in . '|' . $en);



        if ($level == 'P') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderPartner($idlevel, 'LOCKED_PROFILE_FIELDS_SELF');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'oneclick');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'showlimit1');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'defaultpc');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'show_balance');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'SETTLMENT_DISCLAIMER');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'FIXEDRECURRING');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'DYNAMICRECURRING');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'keepauto');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'NOAPPLYCFEE');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'ETERMSERV');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'CANCELRESTRICTIONS');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'MAXRECURRINGPAYMENTPERUSER');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'FREQAUTOPAY');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'DAYSAUTOPAY');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'DYNAMICRECURRINGTEXT');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'DRPFREQAUTOPAY');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'DRPDAYSAUTOPAY');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'DRPMETHODS');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'nomemo');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'nosocial');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'AUTOREMINDER');
            }

            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderPartner($partnerId, $idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderCompany($idlevel, 'LOCKED_PROFILE_FIELDS_SELF');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'oneclick');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'showlimit1');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'defaultpc');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'show_balance');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'SETTLMENT_DISCLAIMER');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'FIXEDRECURRING');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'NOAPPLYCFEE');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'DYNAMICRECURRING');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'keepauto');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'CANCELRESTRICTIONS');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'MAXRECURRINGPAYMENTPERUSER');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'FREQAUTOPAY');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'DAYSAUTOPAY');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'DYNAMICRECURRINGTEXT');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'DRPFREQAUTOPAY');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'DRPDAYSAUTOPAY');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'DRPMETHODS');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'nomemo');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'nosocial');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'AUTOREMINDER');
            }
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderCompany($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $objSettingVal->UpdatePublishedUnderMerchant($idlevel);
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }
        if (isset($Settings['DAYSAUTOPAY'])) {
            list($in, $en) = explode('|', $Settings['DAYSAUTOPAY']);
            if (empty($in)) {
                $in = 1;
            }
            if (empty($en)) {
                $en = 31;
            }
            $Settings['STARTAUTOPAYDAY'] = $in;
            $Settings['ENDAUTOPAYDAY'] = $en;
        }

        if (isset($Settings['DRPDAYSAUTOPAY'])) {
            list($in, $en) = explode('|', $Settings['DRPDAYSAUTOPAY']);
            if (empty($in)) {
                $in = 1;
            }
            if (empty($en)) {
                $en = 31;
            }
            $Settings['DRPSTARTAUTOPAYDAY'] = $in;
            $Settings['DRPENDAUTOPAYDAY'] = $en;
        }
        return redirect()->route('paymentpage', ['token' => $atoken])->with('success', 'saved successfully');
    }

    public function savegeneral(Request $request) {
        $atoken = decrypt($request->input('tokendata'));
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];

        $manager_approval_not_required = "";
        if (null !== $request->input('manager_approval_not_required')) {
            $manager_approval_not_required = trim($request->input('manager_approval_not_required'));
        }
        $payment_numbers = "";
        if (null !== $request->input('payment_numbers')) {
            $payment_numbers = trim($request->input('payment_numbers'));
        }
        $payment_number_reg_welcome = "";
        if (null !== $request->input('payment_number_reg_welcome')) {
            $payment_number_reg_welcome = trim($request->input('payment_number_reg_welcome'));
        }
        $payment_number_qp_welcome = "";
        if (null !== $request->input('payment_number_qp_welcome')) {
            $payment_number_qp_welcome = trim($request->input('payment_number_qp_welcome'));
        }
        $payment_number_logon_welcome = "";
        if (null !== $request->input('payment_number_logon_welcome')) {
            $payment_number_logon_welcome = trim($request->input('payment_number_logon_welcome'));
        }
        $payment_number_reg_number = "";
        if (null !== $request->input('payment_number_reg_number')) {
            $payment_number_reg_number = trim($request->input('payment_number_reg_number'));
        }
        $paynow = "";
        if (null !== $request->input('paynow')) {
            $paynow = trim($request->input('paynow'));
        }
        $accsetting = "";
        if (null !== $request->input('accsetting')) {
            $accsetting = trim($request->input('accsetting'));
        }
        $invsetting = "";
        if (null !== $request->input('invsetting')) {
            $invsetting = trim($request->input('invsetting'));
        }
        $notreg = "";
        if (null !== $request->input('notreg')) {
            $notreg = trim($request->input('notreg'));
        }
        $invdefault = "";
        if (null !== $request->input('INVOICEDEFAULTQUICKPAY')) {
            $invdefault = trim($request->input('INVOICEDEFAULTQUICKPAY'));
        }
        $invrem = "";
        if (null !== $request->input('SEND_REMINDERS')) {
            $invrem = trim($request->input('SEND_REMINDERS'));
        }
        $invbefore = "";
        if (null !== $request->input('freq_before_due')) {
            $invbefore = trim($request->input('freq_before_due'));
        }
        $invafter = "";
        if (null !== $request->input('freq_after_due')) {
            $invafter = trim($request->input('freq_after_due'));
        }
        $invday = "";
        if (null !== $request->input('days_after_due_value')) {
            $invday = trim($request->input('days_after_due_value'));
        }
        $invtax = "";
        if (null !== $request->input('INVOICETAXES')) {
            $invtax = trim($request->input('INVOICETAXES'));
        }
        $invopc = "";
        if (null !== $request->input('einvoice')) {
            $invopc = trim($request->input('einvoice'));
        }
        $regreg = "";
        if (null !== $request->input('regreg')) {
            $regreg = trim($request->input('regreg'));
        }
        $propagate = "";
        if (null !== $request->input('propagate')) {
            $propagate = trim($request->input('propagate'));
        }
        $nocaptcha2 = null === $request->input('notcaptcha2') || $request->input('notcaptcha2') != "on" ? 0 : 1;
        $nocaptcha4 = null === $request->input('notcaptcha4') || $request->input('notcaptcha4') != "on" ? 0 : 1;

        $objSettingVal = new Customize();
        if ($level == 'P') {
            $idgroup = $objSettingVal->getPartnersGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPartnerGroup($idlevel);
            }
        } elseif ($level == 'G') {
            $idgroup = $objSettingVal->getCompaniesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createCompanyGroup($idlevel);
            }
        } elseif ($level == 'M') {
            $idgroup = $objSettingVal->getPropertiesGroup($idlevel);
            if ($idgroup == 0) {
                $idgroup = $objSettingVal->createPropertyGroup($idlevel);
            }
        }

        $objSettingVal->saveSettingValue($idgroup, 'NOTCAPTCHA2', $nocaptcha2);
        $objSettingVal->saveSettingValue($idgroup, 'NOTCAPTCHA4', $nocaptcha4);

        if ($propagate == 'on') {
            $propagate = true;
        } else {
            $propagate = false;
        }
        if ($notreg == 'on') {
            $manager_approval_not_required = 0;
            $payment_numbers = 0;
            $objSettingVal->saveSettingValue($idgroup, 'notreg', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'notreg', 0);
        }
        if ($paynow == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'PAYNOW', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'PAYNOW', 0);
        }
        if ($regreg == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'REGREG', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'REGREG', 0);
        }
        if ($invdefault == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'INVOICEDEFAULTQUICKPAY', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'INVOICEDEFAULTQUICKPAY', 0);
        }
        if ($invopc == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'EINVOICE', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'EINVOICE', 0);
        }
        if ($invrem == 'on') {
            $objSettingVal->saveSettingValue($idgroup, 'SEND_REMINDERS', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'SEND_REMINDERS', 0);
        }
        if ($invbefore != "") {
            $objSettingVal->saveSettingValue($idgroup, 'freq_before_due', $invbefore);
        }
        if ($invafter != "") {
            $objSettingVal->saveSettingValue($idgroup, 'freq_after_due', $invafter);
        }
        if ($invday != "") {
            $objSettingVal->saveSettingValue($idgroup, 'days_after_due_value', $invday);
        }
        if ($invtax != "") {
            $objSettingVal->saveSettingValue($idgroup, 'INVOICETAXES', $invtax);
        }

        if ($manager_approval_not_required == 'on') {
            $manager_approval_not_required = 1;
        } else {
            $manager_approval_not_required = 0;
        }
        $objSettingVal->saveSettingValue($idgroup, 'manager_approval_not_required', $manager_approval_not_required);
        if ($payment_number_logon_welcome != "") {
            $payment_number_logon_welcome = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $payment_number_logon_welcome);
            $payment_number_logon_welcome = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $payment_number_logon_welcome);
            $objSettingVal->saveSettingValue($idgroup, 'payment_number_logon_welcome', $payment_number_logon_welcome);
        }
        if ($payment_number_reg_number != "") {
            $payment_number_reg_number = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $payment_number_reg_number);
            $payment_number_reg_number = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $payment_number_reg_number);
            $payment_number_reg_number = strip_tags($payment_number_reg_number);
            $objSettingVal->saveSettingValue($idgroup, 'payment_number_reg_number', $payment_number_reg_number);
        }
        if ($payment_number_reg_welcome != "") {
            $payment_number_reg_welcome = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $payment_number_reg_welcome);
            $payment_number_reg_welcome = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $payment_number_reg_welcome);
            $payment_number_reg_welcome = strip_tags($payment_number_reg_welcome);
            $objSettingVal->saveSettingValue($idgroup, 'payment_number_reg_welcome', $payment_number_reg_welcome);
        }
        if ($payment_number_qp_welcome != "") {
            $payment_number_qp_welcome = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $payment_number_qp_welcome);
            $payment_number_qp_welcome = preg_replace('#<scr(.*?)>(.*?)</scr(.*?)>#is', '', $payment_number_qp_welcome);
            $payment_number_qp_welcome = strip_tags($payment_number_qp_welcome);
            $objSettingVal->saveSettingValue($idgroup, 'payment_number_qp_welcome', $payment_number_qp_welcome);
        }
        if ($payment_numbers == 'on') {
            $accsetting = 3;
            $objSettingVal->saveSettingValue($idgroup, 'payment_numbers', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'payment_numbers', 0);
        }
        $objSettingVal->saveSettingValue($idgroup, 'accsetting', $accsetting);
        switch ($accsetting) {
            case 1:
                $objSettingVal->saveSettingValue($idgroup, 'acchide', 1);
                $objSettingVal->saveSettingValue($idgroup, 'nonewuser', 0);
                $objSettingVal->saveSettingValue($idgroup, 'payment_numbers', 0);
                $objSettingVal->saveSettingValue($idgroup, 'notaccqp', 1);
                break;
            case 2:
                $objSettingVal->saveSettingValue($idgroup, 'acchide', 0);
                $objSettingVal->saveSettingValue($idgroup, 'nonewuser', 0);
                $objSettingVal->saveSettingValue($idgroup, 'payment_numbers', 0);
                $objSettingVal->saveSettingValue($idgroup, 'notaccqp', 0);
                break;
            case 3:
                $objSettingVal->saveSettingValue($idgroup, 'acchide', 0);
                $objSettingVal->saveSettingValue($idgroup, 'nonewuser', 1);
                //$objSettingVal->saveSettingValue($idgroup, 'payment_numbers', 1);
                $objSettingVal->saveSettingValue($idgroup, 'notaccqp', 0);
                break;
            case 4:
                $objSettingVal->saveSettingValue($idgroup, 'acchide', 0);
                $objSettingVal->saveSettingValue($idgroup, 'nonewuser', 0);
                $objSettingVal->saveSettingValue($idgroup, 'payment_numbers', 0);
                $objSettingVal->saveSettingValue($idgroup, 'notaccqp', 1);
                break;
        }
        $objSettingVal->saveSettingValue($idgroup, 'invsetting', $invsetting);
        if ($invsetting == 4) {
            $objSettingVal->saveSettingValue($idgroup, 'notinvreq', 1);
        } else {
            $objSettingVal->saveSettingValue($idgroup, 'notinvreq', 0);
        }

        if ($level == 'P') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderPartner($idlevel, 'notreg');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'manager_approval_not_required');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'payment_number_logon_welcome');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'payment_number_reg_number');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'payment_number_reg_welcome');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'payment_number_qp_welcome');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'payment_numbers');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'acchide');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'nonewuser');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'notaccqp');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'accsetting');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'invsetting');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'notinvreq');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'INVOICETAXES');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'days_after_due_value');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'freq_after_due');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'freq_before_due');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'SEND_REMINDERS');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'INVOICEDEFAULTQUICKPAY');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'EINVOICE');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'PAYNOW');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'REGREG');
                if ($paynow == 'on') {

                } else {

                }
            }
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderPartner($partnerId, $idlevel);

            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            if ($propagate) {
                $objSettingVal->removeSettingUnderCompany($idlevel, 'notreg');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'manager_approval_not_required');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'payment_number_logon_welcome');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'payment_number_reg_number');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'payment_number_reg_welcome');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'payment_number_qp_welcome');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'payment_numbers');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'acchide');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'nonewuser');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'notaccqp');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'accsetting');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'invsetting');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'notinvreq');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'INVOICETAXES');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'days_after_due_value');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'freq_after_due');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'freq_before_due');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'SEND_REMINDERS');
                $objSettingVal->removeSettingUnderCompany($idlevel, 'INVOICEDEFAULTQUICKPAY');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'EINVOICE');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'PAYNOW');
                $objSettingVal->removeSettingUnderPartner($idlevel, 'REGREG');
                if ($paynow == 'on') {

                } else {

                }
            }
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $objSettingVal->UpdatePublishedUnderCompany($idlevel);
            $obj_company = new Model\Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $objSettingVal->UpdatePublishedUnderMerchant($idlevel);
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Model\Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            if ($paynow == 'on') {

            } else {

            }
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        if (isset($Settings["CAPTCHA"])) {
            $Settings["CAPTCHA"] = json_encode($Settings["CAPTCHA"]);
        }
        return redirect()->route('general', array('token' => $request->input('tokendata')))->with('success', 'The Information saved successfully');
//        return view('admin.general', array('atoken' => $atoken, 'settings' => $Settings, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'msgCode' => 'savec1'));
    }

    function reportsedit($token, $type, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $obj_partner = new Partners();
        $obj_company = new Companies();
        $obj_property = new Properties();
        $obj_settings = new Customize();
        if ($type == 'excel') {
            if ($level == 'P') {
                $id_group = $obj_settings->getPartnersGroup($idlevel);
                $report = $obj_settings->getSettingsValue($id_group, 'REPORTEXCEL');
            } elseif ($level == 'G') {
                $idpartner = $obj_company->get1CompanyInfo($idlevel, 'id_partners');
                $id_group = $obj_settings->getCompaniesGroup($idlevel);
                $report = $obj_settings->getSettingValueGroup($id_group, $idpartner, 'REPORTEXCEL');
            } elseif ($level == 'M') {
                $id_partner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
                $id_company = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
                $id_group = $obj_settings->getPropertiesGroup($idlevel);
                $report = $obj_settings->getSettingValueProperty($id_partner, $id_company, $id_group, 'REPORTEXCEL');
            } else {
                return redirect()->back();
            }
            if (empty($report)) {
                $report = 'field1:0|field2:20|field3:21|field4:22|field5:1|field6:2|field7:3|field8:4|field9:5|field10:6|field11:7|field12:8|field13:9|field14:10|field15:11|field16:12|field17:15|field18:16|format:0|separator:0';
            }
            return view('customize.reports.editreport', array('settings' => $report, 'pageTitle' => 'Customize', 'level' => $level, 'idlevel' => $idlevel, 'type' => $type, 'token' => $token));
        } elseif ($type == 'jenark') {
            if ($level == 'P') {
                $id_group = $obj_settings->getPartnersGroup($idlevel);
                $report = $obj_settings->getSettingsValue($id_group, 'REPORTJENARK');
            } elseif ($level == 'G') {
                $idpartner = $obj_company->get1CompanyInfo($idlevel, 'id_partners');
                $id_group = $obj_settings->getCompaniesGroup($idlevel);
                $report = $obj_settings->getSettingValueGroup($id_group, $idpartner, 'REPORTJENARK');
            } elseif ($level == 'M') {
                $id_partner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
                $id_company = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
                $id_group = $obj_settings->getPropertiesGroup($idlevel);
                $report = $obj_settings->getSettingValueProperty($id_partner, $id_company, $id_group, 'REPORTJENARK');
            } else {
                return redirect()->back();
            }
            if (empty($report)) {
                $report = 'field1:2|field2:11|field3:18|field4:19|field5:3|field6:0|field7:13|field8:5|field9:11|field10:0|field11:0';
            }
            return view('customize.reports.editreport', array('settings' => $report, 'level' => $level, 'idlevel' => $idlevel, 'type' => $type, 'token' => $token));
        } elseif ($type == 'peach') {
            if ($level == 'P') {
                $id_group = $obj_settings->getPartnersGroup($idlevel);
                $report = $obj_settings->getSettingsValue($id_group, 'REPORTPEACHTREE');
            } elseif ($level == 'G') {
                $idpartner = $obj_company->get1CompanyInfo($idlevel, 'id_partners');
                $id_group = $obj_settings->getCompaniesGroup($idlevel);
                $report = $obj_settings->getSettingValueGroup($id_group, $idpartner, 'REPORTPEACHTREE');
            } elseif ($level == 'M') {
                $id_partner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
                $id_company = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
                $id_group = $obj_settings->getPropertiesGroup($idlevel);
                $report = $obj_settings->getSettingValueProperty($id_partner, $id_company, $id_group, 'REPORTPEACHTREE');
            } else {
                return redirect()->back();
            }
            if (empty($report)) {
                $report = 'field1:1|field2:17|field3:19|field4:3|field5:11|field6:5';
            }
            return view('customize.reports.editreport', array('settings' => $report, 'level' => $level, 'idlevel' => $idlevel, 'type' => $type, 'token' => $token));
        } elseif ($type == 'yardi') {
            if ($level == 'P') {
                $id_group = $obj_settings->getPartnersGroup($idlevel);
                $report = $obj_settings->getSettingsValue($id_group, 'REPORTYARDI');
            } elseif ($level == 'G') {
                $idpartner = $obj_company->get1CompanyInfo($idlevel, 'id_partners');
                $id_group = $obj_settings->getCompaniesGroup($idlevel);
                $report = $obj_settings->getSettingValueGroup($id_group, $idpartner, 'REPORTYARDI');
            } elseif ($level == 'M') {
                $id_partner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
                $id_company = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
                $id_group = $obj_settings->getPropertiesGroup($idlevel);
                $report = $obj_settings->getSettingValueProperty($id_partner, $id_company, $id_group, 'REPORTYARDI');
            } else {
                return redirect()->back();
            }
            if (empty($report)) {
                $report = 'field2:2|field3:0|field4:0|field5:18|field6:18|field7:0|field8:11|field9:19|field10:5|field11:0|field12:1|field13:0|field14:0|field15:0|field16:0|field17:5';
            }
            return view('customize.reports.editreport', array('settings' => $report, 'level' => $level, 'idlevel' => $idlevel, 'type' => $type, 'token' => $token));
        } elseif ($type == 'sage') {
            if ($level == 'P') {
                $id_group = $obj_settings->getPartnersGroup($idlevel);
                $report = $obj_settings->getSettingsValue($id_group, 'REPORTSAGE');
            } elseif ($level == 'G') {
                $idpartner = $obj_company->get1CompanyInfo($idlevel, 'id_partners');
                $id_group = $obj_settings->getCompaniesGroup($idlevel);
                $report = $obj_settings->getSettingValueGroup($id_group, $idpartner, 'REPORTSAGE');
            } elseif ($level == 'M') {
                $id_partner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
                $id_company = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
                $id_group = $obj_settings->getPropertiesGroup($idlevel);
                $report = $obj_settings->getSettingValueProperty($id_partner, $id_company, $id_group, 'REPORTSAGE');
            } else {
                return redirect()->back();
            }
            if (empty($report)) {
                $report = 'field2:15|field5:3|field6:5|field7:11|field8:17';
            }
            return view('customize.reports.editreport', array('settings' => $report, 'level' => $level, 'idlevel' => $idlevel, 'type' => $type, 'token' => $token));
        } elseif ($type == 'sky') {
            if ($level == 'P') {
                $id_group = $obj_settings->getPartnersGroup($idlevel);
                $report = $obj_settings->getSettingsValue($id_group, 'REPORTSKYLINE');
            } elseif ($level == 'G') {
                $idpartner = $obj_company->get1CompanyInfo($idlevel, 'id_partners');
                $id_group = $obj_settings->getCompaniesGroup($idlevel);
                $report = $obj_settings->getSettingValueGroup($id_group, $idpartner, 'REPORTSKYLINE');
            } elseif ($level == 'M') {
                $id_partner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
                $id_company = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
                $id_group = $obj_settings->getPropertiesGroup($idlevel);
                $report = $obj_settings->getSettingValueProperty($id_partner, $id_company, $id_group, 'REPORTSKYLINE');
            } else {
                return redirect()->back();
            }
            if (empty($report)) {
                $report = 'field1:GLDET|field2:19|field3:18|field4:18|field5:12|field6:1|field7:11|field8:!1|field9:5|field10:C';
            }
            return view('customize.reports.editreport', array('settings' => $report, 'level' => $level, 'idlevel' => $idlevel, 'type' => $type, 'token' => $token));
        } elseif ($type == 'mri') {
            if ($level == 'P') {
                $id_group = $obj_settings->getPartnersGroup($idlevel);
                $report = $obj_settings->getSettingsValue($id_group, 'REPORTMRI');
            } elseif ($level == 'G') {
                $idpartner = $obj_company->get1CompanyInfo($idlevel, 'id_partners');
                $id_group = $obj_settings->getCompaniesGroup($idlevel);
                $report = $obj_settings->getSettingValueGroup($id_group, $idpartner, 'REPORTMRI');
            } elseif ($level == 'M') {
                $id_partner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
                $id_company = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
                $id_group = $obj_settings->getPropertiesGroup($idlevel);
                $report = $obj_settings->getSettingValueProperty($id_partner, $id_company, $id_group, 'REPORTMRI');
            } else {
                return redirect()->back();
            }
            if (empty($report)) {
                $report = 'field1:1|field2:2|field3:0|field4:19|field5:12|field6:19|field7:3|field8:0|field9:0|field10:6|field11:11|field12:18|field13:0|field14:0|field15:0|field16:0|field17:18|field18:0|field19:0|field20:6|field21:0|field22:0|field23:0|field24:0|field25:0|field26:0|field27:0|field28:0|field29:5|field30:0|field31:0|field32:0|field33:0|field34:0|field35:0|field36:0|field37:0|field38:0|field39:0|field40:0|field41:0|field42:0|field43:0|field44:0|field45:0';
            }
            return view('customize.reports.editreport', array('settings' => $report, 'level' => $level, 'idlevel' => $idlevel, 'type' => $type, 'token' => $token));
        } else {
            return redirect()->back();
        }
    }

    public function aabintegrationedit($token, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        list($idlevel, $level) = explode('|', $atoken);
        $objSettingVal = new Customize();
        if ($level == 'P') {
            $partnerId = $objSettingVal->getPartnersGroup($idlevel);
            $Settings = $objSettingVal->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $GroupId = $objSettingVal->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idpartner = $obj_company->getPartnerID($idlevel);
            $Settings = $objSettingVal->getSettingsValuesGroup($GroupId, $idpartner);
        } elseif ($level == 'M') {
            $MerchantId = $objSettingVal->getPropertiesGroup($idlevel);
            $obj_property = new Properties();
            $idpartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $Settings = $objSettingVal->getSettingsValueProperties($idpartner, $idcompany, $MerchantId);
        }

        if ($level == 'G') {
            $extintegration = new ExternalIntegration();
            $record = $extintegration->getByFieldValue('id_company', $idlevel);
            if ($record) {
                $data = json_decode($record['data'], 1);
                $data['usrname'] = base64_decode($data['usrname']);
                $data['usrpsw'] = base64_decode($data['usrpsw']);
                return view('admin.aabintegrationedit', array('data' => $data, 'token' => $token, 'pageTitle' => 'AAB Integration', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
            } else {
                return view('admin.aabintegration', array('token' => $token, 'pageTitle' => 'AAB Integration', 'level' => $level, 'idlevel' => $idlevel, 'settings' => $Settings));
            }
        }
    }

    public function aabintegrationeditstore($token, Request $request) {
        $data = $request->all();
        $validator = Validator::make($data, $this->getRulesAABIntegration(), $this->getMessagesAABIntegration());
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator->errors())->withInput($data);
        }

        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        list($idlevel, $level) = explode('|', $atoken);
        $objcompany = new Companies();
        if ($level == 'G') {
            $extintegration = new ExternalIntegration();
            $record = $extintegration->getByFieldValue('id_company', $idlevel);
            unset($data['_token']);
            //$data['usrname'] = base64_encode($data['usrname']);
            //$data['usrpsw'] = base64_encode($data['usrpsw']);
            $data['mgmid'] = $objcompany->get1CompanyInfo($idlevel, 'compositeID_companies');
            if ($record) {
                //update
                $extintegration->setByField('id_company', $idlevel, 'data', json_encode($data));
            } else {
                //insert
                $extintegration->insertData([
                    'id_company' => $idlevel,
                    'icode' => 'AAB',
                    'data' => json_encode($data),
                ]);
            }
            return redirect()->route('aabintegrationedit', ['token' => $token])->with('success', 'The element was saved successfully');
        }
    }

    public function simulator() {
        header('Content-Type: application/json');
        echo '{"id":"31","task":"\/api2\/cron\/tops\/users\/eyJpdiI6ImtXMGRBbVdmdHpnOTNOUXA2eE5TR2c9PSIsInZhbHVlIjoiQmY2bm1RclVtT3pIR2tic1c2Qjl4NDdzNWtTV3B4SzlZV3Q3OVBVUVZCbkdVSXprRitOQXhsdjlVTmRBdW1ydyIsIm1hYyI6IjViMmFhNjkxYTRkODRiZjc1MjNiZmViYWFhOWEyNzM2ZDM5OWU0OTgyNzgyODkzYjcwYjRlNGNiMGNiNmY4NTQifQ==","status":"0","total":"85","var1":"10","var2":"20","var3":"","text":"","inputdata":"","created":"2016-04-18 16:40:03","errcode":1}';
    }

    public function getRulesAutoreports() {
        return [
            'type' => 'required|max:255',
            'frequency' => 'required|max:11',
            'time' => 'required|max:10',
            'email' => 'required|max:255',
            'identify_merchant' => 'required',
        ];
    }

    public function getRulesAABIntegration() {

        return [
            'mgmkey' => 'required',
        ];
    }

    public function getMessagesAABIntegration() {
        return [
            'mgmkey.required' => 'This field API Key is required.',
        ];
    }

    /**
     * Gets the setting by Level(P,G,M) and id
     * @param string $level
     * @param int $idlevel
     */
    private function getSettings($level, $idlevel) {
        $settings = '';
        $obj_property = new Properties();
        $objCustomize = new Customize();
        if ($level == 'P') {
            $partnerId = $objCustomize->getPartnersGroup($idlevel);
            $settings = $objCustomize->getSettingsValuesPartner($partnerId);
        } elseif ($level == 'G') {
            $groupId = $objCustomize->getCompaniesGroup($idlevel);
            $obj_company = new Companies();
            $idPartner = $obj_company->getPartnerID($idlevel);
            $settings = $objCustomize->getSettingsValuesGroup($groupId, $idPartner);
        } elseif ($level == 'M') {
            $merchantId = $objCustomize->getPropertiesGroup($idlevel);

            $idPartner = $obj_property->get1PropertyInfo($idlevel, 'id_partners');
            $idCompany = $obj_property->get1PropertyInfo($idlevel, 'id_companies');
            $settings = $objCustomize->getSettingsValueProperties($idPartner, $idCompany, $merchantId);
        }
        return $settings;
    }

    public function menutab($token, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];

        //$idlevel = 1125;
        //$idlevel = 333;
        //$level = 'M';

        $objSettingVal = new Customize();

        $objMenuTab = new MenuTabExtensions();
        switch (strtoupper($level)) {
            case "G":
                $tabs = $objMenuTab->getAllItemMenuTabOrderGroup($idlevel);
                break;
            case "M":
                $tabs = $objMenuTab->getAllItemMenuTabOrder($idlevel);
                if ($tabs->isEmpty()) {
                    $objMenuTab->createItemDefaultMenuTab($idlevel);
                    $tabs = $objMenuTab->getAllItemMenuTabOrder($idlevel);
                }
                break;
            default:
                die;
                break;
        }



        return view('customize.menutab', array('tabs' => $tabs, 'token' => $token, 'settings' => array(), 'pageTitle' => 'Menu & Extensions', 'level' => $level, 'idlevel' => $idlevel));
    }

    public function menutabSave($token, Request $request) {


        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];


        $data_post = $request->all();
        $objMenuTab = new MenuTabExtensions();


        if (strtoupper($level) == 'M') {
            $objMenuTab->removeTabMerchant($idlevel);

            for($a =1; $a <= 12;$a++ ){

                if (isset($data_post['savenew_' . $a])) {

                    $name = isset($data_post['namenew_' . $a]) ? $data_post['namenew_' . $a] : '';
                    $title = isset($data_post['titlenew_' . $a]) ? $data_post['titlenew_' . $a] : '';
                    $image = isset($data_post['iconnew_' . $a]) ? $data_post['iconnew_' . $a] : '';
                    $priority = isset($data_post['ordernew_' . $a]) ? $data_post['ordernew_' . $a] : '';

                    $data = [
                        'name' => $name,
                        'title' => $title,
                        'image' => $image,
                        'priority' => $priority,
                        'id_property' => $idlevel
                    ];

                    $objMenuTab->insertTab($data);
                }

                if (isset($data_post['save_' . $a])) {

                    $name = isset($data_post['name_' . $a]) ? $data_post['name_' . $a] : '';
                    $title = isset($data_post['title_' . $a]) ? $data_post['title_' . $a] : '';
                    $image = isset($data_post['icon_' . $a]) ? $data_post['icon_' . $a] : '';
                    $priority = isset($data_post['order_' . $a]) ? $data_post['order_' . $a] : '';

                    $data = [
                        'name' => $name,
                        'title' => $title,
                        'image' => $image,
                        'priority' => $priority,
                        'id_property' => $idlevel
                    ];

                    $objMenuTab->insertTab($data);
                }

            }


        }elseif(strtoupper($level) == "G"){
            $objMenuTab->removeTabGroup($idlevel);
            $idps = DB::table('properties')->where('id_companies', $idlevel)->select('id')->get();
            foreach ($idps as $idproperty) {
                for($a =1; $a <= 12;$a++ ){

                    if (isset($data_post['savenew_' . $a])) {

                        $name = isset($data_post['namenew_' . $a]) ? $data_post['namenew_' . $a] : '';
                        $title = isset($data_post['titlenew_' . $a]) ? $data_post['titlenew_' . $a] : '';
                        $image = isset($data_post['iconnew_' . $a]) ? $data_post['iconnew_' . $a] : '';
                        $priority = isset($data_post['ordernew_' . $a]) ? $data_post['ordernew_' . $a] : '';

                        $data = [
                            'name' => $name,
                            'title' => $title,
                            'image' => $image,
                            'priority' => $priority,
                            'id_property' => $idproperty
                        ];

                        $objMenuTab->insertTab($data);
                    }

                    if (isset($data_post['save_' . $a])) {

                        $name = isset($data_post['name_' . $a]) ? $data_post['name_' . $a] : '';
                        $title = isset($data_post['title_' . $a]) ? $data_post['title_' . $a] : '';
                        $image = isset($data_post['icon_' . $a]) ? $data_post['icon_' . $a] : '';
                        $priority = isset($data_post['order_' . $a]) ? $data_post['order_' . $a] : '';

                        $data = [
                            'name' => $name,
                            'title' => $title,
                            'image' => $image,
                            'priority' => $priority,
                            'id_property' => $idlevel
                        ];

                        $objMenuTab->insertTab($data);
                    }

                }
            }
        }


        return redirect()->back()->with('success', 'Saved successfully');
    }

    //Fisher Brown Bottrell- Client Custom Fields --By Abhishek Jain
    public function customfield($token, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];

        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }

        $obj_customfield = new CustomField();
        $cf = $obj_customfield->getCustomFields($idlevel);

        $filter = \DataFilter::source($cf);
        $grid = \DataGrid::source($filter);

        $grid->add($token, $token)->style("display:none;");
        $grid->add('id', 'ID')->style("display:none;");
        $grid->add('field_description', 'Field Description');
        $grid->add('type', 'Field Type')->cell(function ($value) {
            switch ($value) {
                case 'A':
                    return 'Alphanumeric';
                    break;
                case 'N':
                    return 'Numeric';
                    break;
            }
        });
        $grid->add('position', 'Field Position')->cell(function ($value) {
            switch ($value) {
                case 'A':
                    return 'User account section';
                    break;
                case 'P':
                    return 'Payment section';
                    break;
            }
        });
        $grid->add('in_txreport', 'Transaction report')->cell(function ($value) {
            switch ($value) {
                case 0:
                    return '<span class="label label-danger pull-left">No</span>';
                    break;
                case 1:
                    return '<span class="label label-success pull-left">Yes</span>';
                    break;
            }
        });
        $grid->add('in_dpreport', 'Settlement report')->cell(function ($value) {
            switch ($value) {
                case 0:
                    return '<span class="label label-danger pull-left">No</span>';
                    break;
                case 1:
                    return '<span class="label label-success pull-left">Yes</span>';
                    break;
            }
        });


        $grid->add('actionvalue', 'Action')->style("text-align:right;");
//
        $grid->row(
                function ($row) {
            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;

            $edit_link = '<li><a href="'.route('editcustomfield', array('token'=>$token, 'id'=>$id)).'" >Edit</a></li>';
            $delete_link = '<li><a onclick="deletecustomfield(' . $id . ')" >Delete</a></li>';



            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret" ></span></button>
								<ul class="dropdown-menu">


							' . $edit_link . '
							' . $delete_link . '
														  </ul>
	 													</div>';
            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));


        return view('customize.custom_fields.customfield', array('token' => $token, 'grid' => $grid, 'itemspage' => $itemsPerPage));
    }

    public function addcustomfield($token) {
        return view('customize.custom_fields.addcustomfield', array('token' => $token));
    }

    public function savecustomfield($token, Request $request) {
        $atoken = decrypt($token);
        $data = $request->all();
        $data['property_id'] = $atoken['level_id'];

        $request->validate([
            'txtfd' => 'required|string|max:250',
            'ddlfieldtype' =>  'required|string|max:1',
            'ddlposition' =>  'required|string|max:1',
            'ddlvtr' => 'required|numeric|max:1',
            'ddlvsr' => 'required|numeric|max:1',
        ]);

        $obj_customfield = new CustomField();
        $obj_customfield->saveCustomField($data);
        return redirect()->route('customfieldlist', array('token' => $token))->with('success', 'Custom Field saved successfully');
    }

    public function editcustomfield($token, $id) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $obj_customfield = new CustomField();
        $customfield = $obj_customfield->selectCustomField($id, $idlevel);

        return view('customize.custom_fields.editcustomfield', array('token' => $token, 'data' => $customfield, 'id' => $id));
    }

    public function updatecustomfield($token, Request $request) {
        $atoken = decrypt($token);
        $data = $request->all();
        $data['property_id'] = $atoken['level_id'];
        $obj_customfield = new CustomField();
        $obj_customfield->updateCustomField($data);
        return redirect()->route('customfieldlist', array('token' => $token))->with('success', 'Custom Field saved successfully');
    }

    public function deletecustomfield($token, $id) {
        $obj_customfield = new CustomField();
        $obj_customfield->deleteCustomField($id);
        return redirect()->back()->with('success', 'Field deleted successfully');
    }

}
