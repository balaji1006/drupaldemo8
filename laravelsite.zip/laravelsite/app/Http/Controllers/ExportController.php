<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use App\CustomClass\ReportLabels;

class ExportController extends Controller
{

    function __construct()
    {

        $this->middleware('auth');
//        $this->middleware('permission');
    }
    
    function export($type, $sheetName, $sqlEncrypted, $token = null)
    {
        header('Set-Cookie: fileDownload=true; path=/');
        $sql = decrypt($sqlEncrypted);
        $sql=$this->removeFieldsBysheet($sql,$sheetName);
        $records = DB::select(DB::raw($sql));
        $data['sheetName'] = $sheetName;
        $dbResult = json_decode(json_encode($records), true);
        $data['dbResult'] = $this->changeQueryLabels($dbResult);
        
        switch (strtolower($type)) {
            case 'excel':
                Excel::create($data['sheetName'], function ($excel) use ($data) {
                    $excel->sheet($data['sheetName'], function ($sheet) use ($data) {
                        $sheet->fromArray($data['dbResult']);
                    });
                })->export('xls');
                break;
            case 'csv':
                Excel::create($data['sheetName'], function ($excel) use ($data) {
                    $excel->sheet($data['sheetName'], function ($sheet) use ($data) {
                        $sheet->fromArray($data['dbResult']);
                    });
                })->export('csv');
                break;
        }
    }
    
    /**
     * Change the data base headers for the customized ones
     * @param array $records
     * @return array
     */
    function changeQueryLabels($records) {
        $newRecords = [];
        foreach ($records as $record) {
            $newRecord = [];
            foreach ($record as $key => $value) {
                //If the record header exists in the customized label the header is replaced
                if (array_key_exists($key, ReportLabels::$labels)) {
                    $newRecord[ReportLabels::$labels[$key]] = $value;
                } else {
                    //If the record does not exist in the customized label the header is not replaced
                    $newRecord[$key] = $value;
                }
            }
            //adds the new record to the new array
            array_push($newRecords, $newRecord);
        }

        //returns the cuztomized records
        return $newRecords;
    }
    
    function removeFieldsBysheet($sql,$sheetName){
        $sql_str=$sql;
        if($sheetName=='applicationList'){
            $sql_str=str_replace(['`application`.`content`,',', `envelope`'],'',$sql);
        }
        return $sql_str;
    }

}
