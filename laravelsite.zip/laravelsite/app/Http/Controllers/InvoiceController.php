<?php

namespace App\Http\Controllers;

use App\Model\Customize;
use App\Model\Invoices;
use App\Model\Properties;
use App\Model\WebUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Validator;
use Illuminate\Support\Facades\Redirect;

class InvoiceController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    public function invoices($token, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Invoices();
        $filter = \DataFilter::source($catdb->getInvoiceByFilter($idlevel));
        $filter->add('invoice_number', 'Invoice #', 'text');
        $filter->add('name', 'Name', 'text');
        $filter->add('description', 'Subject', 'text');
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add($token, $token)->style("display:none;");
        $grid->add('id', 'id')->style("display:none;");
        $grid->add('property_id', 'property_id')->style("display:none;");
        $grid->add('invoice_number', 'Invoice #');
        $grid->add('description', 'Subject', true);
        $grid->add('name', 'Name');
        $grid->add('amount', 'Amount', true);
        $grid->add('discount', 'Discount');
        $grid->add('paid', 'Paid', true);
        $grid->add('invoice_date', 'Invoice date', true);
        $grid->add('invoice_due_date', 'Due date', true);
        $grid->add('sentby', 'Sent by');
        $grid->add('status', 'Status');
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(
                function ($row) {
            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;
            $sts = $row->cell('status')->value;
            $edit_link = '';
            $delete_link = '';
            $cancel_link = '';
            $send_link = '';
            $close_link = '';
            $pay_link = '';
            $export_link = '';
            if ($sts != 'closed' && $sts != 'paid' && $sts != 'cancelled') {
                $edit_link = '<li><a href="/editinvoice/' . $token . '/' . $id . '" >Edit</a></li>';
            } 
            if ($sts != 'closed' && $sts != 'paid' && $sts != 'cancelled' && $sts != 'sent' && $sts != 'open') {
                $delete_link = '<li><a onclick="deleteinvoice(' . $id . ')" >Delete</a></li>';
            }
            if ($sts == 'sent' || $sts == 'open') {
                $cancel_link = '<li><a onclick="cancelinvoice(' . $id . ')" >Cancel</a></li>';
            }
            $view_link = '<li><a href="' . route('viewinvoice', array('token' => $token, 'id' => $id)) . '" >View</a></li>';
            if ($sts != 'closed' && $sts != 'cancelled') {
                $send_link = '<li><a href="/sendinvoice/' . $token . '/' . $id . '" >Send</a></li>';
            }
            if ($sts != 'closed' && $sts != 'draft' && $sts != 'cancelled') {
                $close_link = '<li><a onclick="closeinvoice(' . $id . ')" >Close</a></li>';
            }
            if ($sts == 'sent' || $sts == 'open' || $sts == 'paid') {
                $pay_link = '<li><a href="/ssoInvoice/' . $id . '/' . $token . '" >Pay</a></li>';
                $export_link = '<li><a href="/exportinvoice/' . $token . '/' . $id . '" target="_blank">Export</a></li>';
            }
            switch ($sts) {
                case 'closed':
                    $sts = '<span class="label label-success pull-left">Closed</span>';
                    break;
                case 'sent':
                    $sts = '<span class="label label-danger pull-left">Sent</span>';
                    break;
                case 'paid':
                    $sts = '<span class="label label-warning pull-left">Paid</span>';
                    break;
                case 'open':
                    $sts = '<span class="label label-info pull-left">Open</span>';
                    break;
                default:
                    $sts = '<span class="label label-default pull-left">' . ucfirst($sts) . '</span>';
            }
            $row->cell('status')->value = $sts;
            $invdb = new Invoices();
            $disc = $invdb->getDiscountByInvoice($id, $row->cell('property_id')->value, $row->cell('amount')->value, $row->cell('invoice_date')->value);
            $row->cell('discount')->value = '$' . number_format($disc['discountamount'], 2);
            $row->cell('amount')->value = '$' . number_format($row->cell('amount')->value, 2);
            $row->cell('paid')->value = '$' . number_format($row->cell('paid')->value, 2);
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                                                    <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown">
                                                    <span>Actions</span>
                                                    <span class="caret" ></span></button>
                                                    <ul class="dropdown-menu">
							' . $edit_link . '
							' . $view_link . '
							' . $pay_link . '
                                                        ' . $export_link . '
							' . $cancel_link . '
							' . $delete_link . '
							' . $send_link . '
							' . $close_link . '
                                                    </ul>
                                                </div>';
            $row->cell('id')->style("display:none;");
            $row->cell('property_id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer "));

        return view('invoices.invoices', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function deleteinvoice($token, $id, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Invoices();
        $catdb->deleteInvoiceTotal($id);
        return redirect()->route('invoices', ['token' => $token]);
    }

    public function closeinvoice($token, $id, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Invoices();
        $catdb->set1InvInfo($id, 'status', 'closed');
        return redirect()->route('invoices', ['token' => $token]);
    }

    public function cancelinvoice($token, $id, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Invoices();
        $catdb->set1InvInfo($id, 'status', 'cancelled');
        return redirect()->route('invoices', ['token' => $token]);
    }

    public function sendinvoice($token, $id, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Invoices();
        $invoice = $catdb->getInvoiceByInvoiceID($id, $idlevel);
        $obj_property = new \App\Model\Properties();
        $objusr = new \App\Model\WebUsers();
        $error = '';
        if ($invoice->status != 'closed' && $invoice->status != 'cancelled') {
            $usr = $objusr->getUserData($invoice->web_user_id);
            if ($usr->email_address != '') {
                
                //Validate if the user email is correct
                if (!filter_var($usr->email_address, FILTER_VALIDATE_EMAIL)) {
                    return redirect()->route('invoices', array('token' => $token))->with('error', 'Invalid email format');
                }

                $data = array();
                $objprop = new \App\Model\Properties();
                $id_companies = $objprop->get1PropertyInfo($idlevel, 'id_companies');
                $id_partners = $objprop->get1PropertyInfo($idlevel, 'id_partners');
                $email_address_clients = $objprop->get1PropertyInfo($idlevel, 'email_address_clients');
                $merchant = $objprop->getMerchantdetail1($idlevel);
                $merchant->email_address_clients = $email_address_clients;
                $data['merchant'] = $merchant;
                if ($data['merchant']->email_address_clients == '') {
                    $data['merchant']->email_address_clients = 'donotreply@revopay.com';
                }

                $merchantIds = $objprop->getPropertyInfo($idlevel);
                $data['logo'] = public_path() . $objprop->getPropertyLogo($merchantIds['logo'], $merchantIds['id_companies'], $merchantIds['id_partners']);

                $payor_portal_url = config('app.payor_portal_url');
                $data['base_url'] = public_path();

                $data['atoken'] = \Illuminate\Support\Facades\Crypt::encrypt($invoice->id . '|' . $invoice->web_user_id . '|' . $invoice->property_id . '|' . time() . '|' . config('app.appAPIkey'));
                $data['url_qpay'] = $payor_portal_url . '/loginInv2/' . $data['atoken'];

                //usr info
                $data['usr'] = $usr;

                $items = $catdb->getInvoiceItems($id, $idlevel);
                $data['items'] = $items;
                $data['invoice'] = $invoice;
                $discount = $catdb->getInvoiceDiscount($invoice->id, $invoice->property_id, $invoice->amount, $invoice->invoice_date);
                $data['discount'] = $discount;
                $data['attachments'] = '';

                if ($invoice->status == 'open' || $invoice->status == 'paid' || $invoice->status == 'sent') {
                    $data['isInvoiceTopay'] = 1;
                }

                $data['invoice']['inv_id'] = $invoice->id;
                //get title account # setting
                $acctitle = 'Account #';
                $data['acctitle'] = $acctitle;
                $name_clients = $objprop->get1PropertyInfo($idlevel, 'name_clients');
                //adds the invoice subject
                if (!empty($invoice->description)) {
                    $data['subject'] = $invoice->description;
                } else {
                    $data['subject'] = $name_clients . ', ' . 'Invoice #' . $invoice->invoice_number;
                }

                // Send the emails
                Mail::send('invoices.preview_mail_invoice', $data, function($message) use ($data) {
                    $message->from($data['merchant']->email_address_clients);
                    $message->to($data['usr']->email_address)
                            ->subject($data['subject']);
                });
                $catdb->set1InvInfo($invoice->id, 'status', 'sent');
                $catdb->set1InvInfo($invoice->id, 'sentby', Auth::user()->username);
                
                return redirect()->route('invoices', array('token' => $token))->with('success', 'The Invoice was sent successfully');
            } else {
                $error = 'Empty Email address';
            }
        } else {
            $error = 'Invalid Invoice';
        }
        return redirect()->route('invoices', ['token' => $token, 'error' => $error]);
    }

    public function newinvoice($token, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];

        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }

        $objMerchant = new Properties();
        $merchant = $objMerchant->getMerchantById($idlevel)->first();

        $objWebuser = new WebUsers();
        $objManagerAdmin = new ManageAdminController();

        $objCustomize = new \App\Model\Customize();
        $invTax = $objCustomize->getSettingByKey($level, $idlevel, 'INVOICETAXES');

        $objInvoice = new Invoices();
        $nextInvNumber = $objInvoice->getNextInvoiceNumber($idlevel);

        $users = $objManagerAdmin->objDBToArray($objWebuser->getWebUserByPropertyIdWithEmail($idlevel), 'web_user_id', 'first_name', false, array('companyname', 'first_name', 'last_name', 'email_address'));

        return view('invoices.newinvoice', array(
            'token' => $token,
            'merchant' => $merchant,
            'users' => $users,
            'invTax' => $invTax,
            'invoicenumber' => $nextInvNumber,
        ));
    }

    function getInvoiceDetails($token, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
    }

    function viewinvoice($token, $id, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Invoices();
        $objprop = new \App\Model\Properties();

        $invoice = $catdb->getInvoiceByInvoiceID($id, $idlevel);
        $merchant = $objprop->getMerchantdetail1($idlevel);
        $items = $catdb->getInvoiceItems($id, $idlevel);
        $discount = $catdb->getInvoiceDiscount($invoice->id, $invoice->property_id, $invoice->amount, $invoice->invoice_date);

        $proplogo = $objprop->get1PropertyInfo($idlevel, 'logo');
        $idPartner = $objprop->get1PropertyInfo($idlevel, 'id_partners');
        $idCompany = $objprop->get1PropertyInfo($idlevel, 'id_companies');
        $logo = $objprop->getPropertyLogo($proplogo, $idCompany, $idPartner);

        $payor_portal_url = config('app.payor_portal_url');
        $hostName = config('app.hostName');
        $lastChar = substr($hostName, -1);
        if ('/' === $lastChar) {
            $data['base_url'] = substr($hostName, 0, -1);
        } else {
            $data['base_url'] = $hostName;
        }

        // if we store the notes in the database decode the array
        if (strpos($invoice['notes'], "{") !== false) {
            $tmp = json_decode($invoice['notes'], true);
            if (isset($tmp['notes'])) {
                if (base64_encode(base64_decode($tmp['notes'])) === $tmp['notes']) {
                    $tmp['notes'] = base64_decode($tmp['notes']);
                }
                $invoice['notes'] = $tmp['notes'];
            } else {
                $invoice['notes'] = "";
            }
            if (isset($tmp['notes1'])) {
                $invoice['notes1'] = $tmp['notes1'];
            } else {
                $invoice['notes1'] = "";
            }
        } else {
            if (!isset($invoice['notes1'])) {
                $invoice['notes1'] = "";
            }
        }

        return view('invoices.viewinvoice', array(
            'token' => $token,
            'invoice' => $invoice,
            'items' => $items,
            'discount' => $discount,
            'merchant' => $merchant,
            'logo' => $logo
        ));
    }

    function editinvoice($token, $id, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Invoices();
        $objprop = new \App\Model\Properties();
        $objusr = new \App\Model\WebUsers();

        $invoice = $catdb->getInvoiceByInvoiceID($id, $idlevel);
        $merchant = $objprop->getMerchantdetail1($idlevel);
        $items = $catdb->getInvoiceItems($id, $idlevel);
        $usr = $objusr->getUserData($invoice->web_user_id);
        $discount = $catdb->getDiscountByInvoiceId($id);

        $obj_webuser = new WebUsers();
        $obj_manageradmin = new ManageAdminController();
        $users = $obj_manageradmin->objDBToArray($obj_webuser->getWebUserByPropertyIdWithEmail($idlevel), 'web_user_id', 'first_name', false, array('companyname', 'first_name', 'last_name', 'email_address'));

        $objCustomize = new \App\Model\Customize();
        $invTax = $objCustomize->getSettingByKey($level, $idlevel, 'INVOICETAXES');

        // if we store the notes in the database decode the array
        if (strpos($invoice['notes'], "{") !== false) {
            $tmp = json_decode($invoice['notes'], true);
            if (isset($tmp['notes'])) {
                if (base64_encode(base64_decode($tmp['notes'])) === $tmp['notes']) {
                    $tmp['notes'] = base64_decode($tmp['notes']);
                }
                $invoice['notes'] = str_replace("<br />", "\n", $tmp['notes']);
            } else {
                $invoice['notes'] = "";
            }
            if (isset($tmp['notes1'])) {
                $invoice['notes1'] = str_replace("<br />", "\n", $tmp['notes1']);
            } else {
                $invoice['notes1'] = "";
            }
        } else {
            if (!isset($invoice['notes1']))
                $invoice['notes1'] = "";
        }


        return view('invoices.editinvoice', array(
            'token' => $token,
            'invoice' => $invoice,
            'items' => $items,
            'merchant' => $merchant,
            'user' => $usr,
            'users' => $users,
            'discount' => $discount,
            'invTax' => $invTax
        ));
    }

    function saveInvoice(Request $request, $token) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];

        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }

        $validator = Validator::make(
                        $request->all(), [
                    'invoicenumber' => 'required|max:25',
                    'to' => 'required|max:10',
                    'invoicedate' => 'required|max:10',
                    'invoiceduedate' => 'required|max:10',
                    'subject' => 'required|max:150',
                    'billto' => 'required|max:1000',
                    'Comments' => 'max:5000',
                    'days' => 'max:2',
                    'discount' => 'max:11',
                    'item' => 'required',
                        ]
        );

        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator->errors())->withInput($request->all());
        } else {
            $objInvoices = new Invoices();
            $idInvoice = !empty($request['invoiceId']) ? $request['invoiceId'] : null;
            $exists = $objInvoices->validateInvoice($token, $request['invoicenumber'], $idInvoice);
            if ($exists) {
                return Redirect::back()->with->withErrors('This Charge Code already exists.')->withInput($request->all());
            }

            //Gets the items ids marked to delete
            if (!empty($request['itemDelete'])) {
                $itemsDelete = explode(",", $request['itemDelete']);
                //Deletes the items that were marked to delete
                foreach ($itemsDelete as $item) {
                    $objInvoices->deleteItemData($item);
                }
            }

            $itemsAdded = [];
            for ($i = 0; $i < count($request['item']); $i++) {
                //Creates the item data
                $itemData = [
                    'id_item' => !empty($request['id_item'][$i]) ? $request['id_item'][$i] : '', //if itemId exists
                    'property_id' => $idlevel,
                    'code' => !empty($request['item'][$i]) ? $request['item'][$i] : '',
                    'price' => !empty($request['unitprice'][$i]) ? $request['unitprice'][$i] : 0,
                    'description' => !empty($request['item'][$i]) ? $request['item'][$i] : 0, //@TODO this field is not in the form
                    'um' => !empty($request['item'][$i]) ? $request['item'][$i] : 0, //@TODO this field is not in the form
                    'updated_by' => Auth::user()->username,
                ];

                if (!empty($itemData['id_item'])) {
                    $objInvoices->updateItemData($itemData);
                    $itemDataId = $itemData['id_item'];
                } else {
                    $itemDataId = $objInvoices->createItemData($itemData);
                }

                $itemsAdded[$i] = $itemDataId;
            }

            // create the notes
            $notes = [];
            $notes['notes'] = str_replace("\n", "<br />", base64_decode(base64_encode($request['billto'])));
            $notes['notes'] = str_replace("\r", "", $notes['notes']);
            $notes['notes'] = strip_tags($notes['notes'], '<br>');

            $notes['notes1'] = str_replace("\n", "<br />", base64_decode(base64_encode($request['Comments'])));
            $notes['notes1'] = str_replace("\r", "", $notes['notes1']);
            $notes['notes1'] = strip_tags($notes['notes1'], '<br>');

            //Creates an invoice record
            $invoiceInfo = [
                'id' => !empty($request['invoiceId']) ? $request['invoiceId'] : '',
                'property_id' => $idlevel,
                'web_user_id' => $request['to'],
                'invoice_number' => $request['invoicenumber'],
                'invoice_date' => substr($request['invoicedate'], 6) . '-' . substr($request['invoicedate'], 0, 2) . '-' . substr($request['invoicedate'], 3, 2),
                'invoice_due_date' => substr($request['invoiceduedate'], 6) . '-' . substr($request['invoiceduedate'], 0, 2) . '-' . substr($request['invoiceduedate'], 3, 2),
                'description' => $request['subject'],
                'amount' => $request['totalamount'],
                'status' => 'draft',
                'notes' => json_encode($notes),
                'updated_by' => Auth::user()->username,
                    /* @TODO review these fields for recurring invoices
                      'invoice_reference' => ''
                      'recurring' => '0',
                      'freq' => 'none',
                      'terms' => $request[''],
                      'sentby' => '',
                      'end_date' => '', */
            ];

            if (!empty($invoiceInfo['id'])) {
                $objInvoices->updateInvoice($invoiceInfo);
                $invoiceId = $invoiceInfo['id'];
            } else {
                $invoiceId = $objInvoices->createInvoice($invoiceInfo);
            }

            if (!empty($invoiceId)) {//@checkbox validation
                //creates a new invoice_discount record
                if (isset($request['offerdiscount']) && $request['offerdiscount'] == 1) {
                    $discount_amount = $request['totalamount'] - ($request['totalamount'] * $request['discount'] / 100);
                    $discountData = [
                        'discount_id' => !empty($request['discount_id']) ? $request['discount_id'] : '',
                        'discount_idproperty' => $idlevel,
                        'discount_idinvoice' => $invoiceId,
                        'discount_days' => $request['days'],
                        'discount_percent' => $request['discount'],
                        'discount_amount' => $discount_amount,
                        'discount_date' => $invoiceInfo['invoice_date'],
                        'discount_dynamic' => isset($request['enableddynamic']) ? $request['enableddynamic'] : 0,
                    ];

                    if (!empty($discountData['discount_id'])) {
                        $objInvoices->updateInvoiceDiscount($discountData);
                    } else {
                        $objInvoices->createInvoiceDiscount($discountData);
                    }
                } else {
                    $objInvoices->deleteInvoiceDiscount($invoiceId);
                }

                //Gets the invoice data ids marked to delete
                if (!empty($request['dataDelete'])) {
                    $dataDelete = explode(",", $request['dataDelete']);

                    //Deletes the invoice data that were marked to delete
                    foreach ($dataDelete as $invoiceData) {
                        $objInvoices->deleteInvoiceData($invoiceData);
                    }
                }

                $objCustomize = new \App\Model\Customize();
                $invTax = $objCustomize->getSettingByKey($level, $idlevel, 'INVOICETAXES');

                //Creates a new invoice_data record
                for ($i = 0; $i < count($itemsAdded); $i++) {
                    $itemArray = [
                        'id' => !empty($request['id_data'][$i]) ? $request['id_data'][$i] : '',
                        'id_invoice' => $invoiceId,
                        'property_id' => $idlevel,
                        'item' => $itemsAdded[$i],
                        'qty' => !empty($request['quantity'][$i]) ? $request['quantity'][$i] : 0,
                        'price' => !empty($request['unitprice'][$i]) ? $request['unitprice'][$i] : 0,
                        //if the setting value exists and is > 0 replace the tax value
                        'tax' => isset($invTax) && $invTax > 0 ? $invTax : (!empty($request['tax'][$i]) ? $request['tax'][$i] : 0),
                        'total' => !empty($request['totalprice'][$i]) ? $request['totalprice'][$i] : 0
                    ];

                    if (!empty($itemArray['id'])) {
                        $objInvoices->updateInvoiceData($itemArray);
                    } else {
                        $objInvoices->createInvoiceData($itemArray);
                    }
                }
            } else {
                return Redirect::back()->withErrors('Error please try again.')->withInput($request->all());
            }
            return redirect()->route('invoices', array('token' => $token))->with('success', 'The Invoice was saved successfully');
        }
    }

    /**
     * Gets and format the user info, showed on Invoices, "Bill to" label
     * @param Request $request
     * @param int $webUserId
     * @return string
     */
    function getUserInfo($webUserId) {
        $objWebUser = new WebUsers();
        $user = $objWebUser->getUserData($webUserId);

        $billto = '';
        if (!empty($user)) {
            if (!empty($user->first_name || !empty($user->last_name))) {
                $billto .= $user->first_name . ' ' . $user->last_name . " \n";
            }
            if (!empty($user->address)) {
                $billto .= $user->address . "\n";
            }
            if (!empty($user->city)) {
                $billto .= $user->city . "\n";
            }
            if (!empty($user->state)) {
                $billto .= $user->state . ". ";
            }
            if (!empty($user->zip)) {
                $billto .= $user->zip . "\n";
            } else {
                $billto .= "\n";
            }
            if (!empty($user->phone_number)) {
                $billto = $billto . 'Phone: ' . $user->phone_number . "\n";
            }
            if (!empty($user->email_address)) {
                $billto = $billto . 'Email: ' . $user->email_address;
            }
        }

        return $billto;
    }

    function exportInvoiceToPDF($token, $invoiceId) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Invoices();
        $invoice = $catdb->getInvoiceByInvoiceID($invoiceId, $idlevel);
        $obj_property = new \App\Model\Properties();
        $objusr = new \App\Model\WebUsers();
        $error = '';

        $usr = $objusr->getUserData($invoice->web_user_id);

        $data = array();
        $objprop = new \App\Model\Properties();
        $id_companies = $objprop->get1PropertyInfo($idlevel, 'id_companies');
        $id_partners = $objprop->get1PropertyInfo($idlevel, 'id_partners');
        $email_address_clients = $objprop->get1PropertyInfo($idlevel, 'email_address_clients');
        $merchant = $objprop->getMerchantdetail1($idlevel);
        $merchant->email_address_clients = $email_address_clients;
        $data['merchant'] = $merchant;
        if ($data['merchant']->email_address_clients == '') {
            $data['merchant']->email_address_clients = 'donotreply@revopay.com';
        }

        $merchantIds = $objprop->getPropertyInfo($idlevel);
        $data['logo'] = public_path() . $objprop->getPropertyLogo($merchantIds['logo'], $merchantIds['id_companies'], $merchantIds['id_partners']);

        $payor_portal_url = env('PAYOR_PORTAL_URL');

        $data['atoken'] = \Illuminate\Support\Facades\Crypt::encrypt($invoice->id . '|' . $invoice->web_user_id . '|' . $invoice->property_id . '|' . time() . '|' . config('app.appAPIkey'));
        $data['url_qpay'] = $payor_portal_url . '/loginInv2/' . $data['atoken'];

        //usr info
        $data['usr'] = $usr;

        $items = $catdb->getInvoiceItems($invoiceId, $idlevel);
        $data['items'] = $items;
        $data['invoice'] = $invoice;
        $discount = $catdb->getInvoiceDiscount($invoice->id, $invoice->property_id, $invoice->amount, $invoice->invoice_date);
        $data['discount'] = $discount;
        $data['attachments'] = '';

        if ($invoice->status == 'open' || $invoice->status == 'paid' || $invoice->status == 'sent') {
            $data['isInvoiceTopay'] = 1;
        }

        $data['invoice']['inv_id'] = $invoice->id;
        //get title account # setting
        $acctitle = 'Account #';
        $data['acctitle'] = $acctitle;


        $html = \View::make('invoices.invoicepdfview', $data)->render();
        $name = 'invoice' . $invoice->invoice_number;

        $tcpdf = new \TCPDF();
        $tcpdf->SetAutoPageBreak(true, PDF_MARGIN_BOTTOM);
        $tcpdf->setPrintHeader(false);
        $tcpdf->setPrintFooter(false);
        $tcpdf->SetMargins(10, 10, 10, true);
        $tcpdf->AddPage();
        $tcpdf->writeHTML(utf8_decode($html), true, false, true, false, '');
        $tcpdf->Output($name . '.pdf', 'I');
    }

}
