<?php
namespace App\Http\Controllers;

use App\Model\Bill;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class BillController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function bills($token, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level!='M'){
            return redirect(route('accessdenied'));
        }
        $catdb = new Bill();
        $filter = \DataFilter::source($catdb->getByFilter($idlevel));


        $filter->add('bill.name','Description','text');
        $filter->add('invoice','Bill #','text');
        $filter->add('vname','Vendor','text');
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();	

        $grid = \DataGrid::source($filter);		
        $grid->attributes(array("class"=>"table table-striped table-hover"));
        $grid->add($token, $token)->style("display:none;");
        $grid->add('id', 'id')->style("display:none;");
        $grid->add('invoice','Bill#',true);
        $grid->add('name','Description');
        $grid->add('vendor','Vendor',true);
        $grid->add('amount','Amount')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('due_from','Pay Date',true);
        $grid->add('recurring','Type',true);
        $grid->add('cycle','Cycle');
        $grid->add('due_to','End Date');
        $grid->add('status','Status');
	    $grid->add('actionvalue', 'Action')->style('text-align:right;');
        $grid->row(
        function ($row) {
            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;
            $sts=$row->cell('status')->value;
            $cancel_link = '<li><a onclick="cancelbill(' . $id . ')" >Cancel</a></li>';
            $edit_link = '<li><a href="' .route('editbill',['token'=>$token,'id'=>$id]). '" >Edit</a></li>';
            $pay_link = '<li><a href="' .route('paybill',['token'=>$token,'id'=>$id]) . '" >Pay</a></li>';
            $r=$row->cell('recurring')->value;
            if($sts==999){
                $cancel_link='';
                $edit_link='';
                $pay_link='';
                $row->cell('status')->value='<span class="label label-info pull-left">Paid</span>';
            }
            elseif($sts==150){
                $cancel_link='<li><a onclick="deletebill(' . $id . ')" >Delete</a></li>';
                $row->cell('status')->value='<span class="label label-danger pull-left">Error</span>';
            }
            else {
                $row->cell('status')->value='<span class="label label-success pull-left">Active</span>';
            }
            if($r==1){
               $row->cell('recurring')->value='Recurring'; 
               if($row->cell('due_to')->value=='0000-00-00'){
                   $row->cell('due_to')->value='Until Cancel';
               }
            }
            else {
                $row->cell('recurring')->value='OneTime';
                $row->cell('cycle')->value='';
                $row->cell('due_to')->value='';
            }
            if($sts!=999){
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret white-font-color" ></span></button>
								<ul class="dropdown-menu">
                                                                '.$pay_link.'
                                                                '.$edit_link.'
                                                                '.$cancel_link.'
                          </ul>
                        </div>';
            }
            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('manage.bills.bills', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    
    }
    
     public function cancelbill($token,$id, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level!='M'){
            return redirect(route('accessdenied'));
        }
        $catdb = new Bill();
        $catdb->cancelBill($id);
        return redirect()->route('bills', ['token'=>$token])->with('success', 'Bill cancelled successfully.');
     }
     
     public function paybill($token,$id, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level!='M'){
            return redirect(route('accessdenied'));
        }
        $catdb = new Bill();
        $bill=$catdb->getBillById($id);
        $idproperty=$idlevel;
        $objvendor=new \App\Model\Vendors();
        $objproperty=new \App\Model\Properties();
        $credentials=$objproperty->getcredBillCredentials($idproperty);
        if(empty($credentials)){
            $catdb->setStatus($id,150);
            return redirect()->route('bills', ['token'=>$token,'error'=>'Invalid Credentials']);
        }
        $cfee=0; //TODO calculate cfee
        $objbillpayment=new \App\Models\Evendorpay();
        $vendor=$objvendor->getVendorByIdx($idproperty, $bill->vendor_id);
        $data=array();
        $data['property_id']=$idproperty;
        $data['trans_unique_id']=str_replace(' ','',$idproperty.microtime());
        $data['trans_net_amount']=$bill->amount;
        $data['trans_convenience_fee']=$cfee;
        $data['trans_total_amount']=  number_format(($bill->amount+$cfee), 2,'.', '');
        $data['trans_descr']=$bill->name;
        $data['trans_source_key']=$credentials->payment_source_key;
        $data['vendor_id']=$bill->vendor_id;
        $data['bill_id']=$bill->id;
        $data['invoice_num']=$bill->invoice;
        $data['trans_last_post_date']=date('Y-m-d H:i:s');
        $txid=$objbillpayment->insertPayment($data);
        $paymentInfo=array();
        $paymentInfo['trans_id']=$txid;
        $paymentInfo['trans_unique_id']=$data['trans_unique_id'];
        $paymentInfo['ec_routing_number']=$vendor->routing;
        $paymentInfo['ec_account_number']=$vendor->account;
        $paymentInfo['total_amount']=$data['trans_net_amount'];
        $paymentInfo['ec_checking_savings']=trim($vendor->account_type);
        $paymentInfo['memo']=$bill->name;
        $paymentInfo['ec_account_holder']=$vendor->name;
        if(!empty($vendor->address)){
            $paymentInfo['address']=$vendor->address;
            $paymentInfo['city']=$vendor->city;
            $paymentInfo['zip']=$vendor->zip;
        }
        if (!empty($vendor->state)) {
            $paymentInfo['state'] = $vendor->state;
        }
        if (!empty($vendor->mail)) {
            $paymentInfo['email'] = $vendor->mail;
        }

        /*$cred=array();
        $cred['lid']=$credentials->payment_source_location_id;
        $cred['sid']=$credentials->payment_source_store_id;
        $cred['mid']=$credentials->payment_source_merchant_id;
        $cred['key']=$credentials->payment_source_key;
        $cred['gateway']=$credentials->gateway;*/

        $pay=new \App\CustomClass\PaymentProcessor();
        $result=$pay->runCreditTx($paymentInfo, $credentials);
        if($result['response']==1 && $cfee>0){
            $data=array();
            $data['property_id']=$idproperty;
            $data['trans_unique_id']=str_replace(' ','',$idproperty.microtime().'-FEE');
            $data['trans_net_amount']=$cfee;
            $data['trans_convenience_fee']=0;
            $data['trans_total_amount']=  number_format(($cfee), 2,'.', '');
            $data['trans_descr']='Services Fee';
            $data['vendor_id']=$bill->vendor_id;
            $data['bill_id']=$bill->id;
            $data['invoice_num']=$bill->invoice;
            $data['trans_last_post_date']=date('Y-m-d H:i:s');
            $data['is_fee_transaction']=1;
            $data['parent_transaction_id']=$txid;
            $txidfee=$objbillpayment->insertPayment($data);
            $convFeeCredential = new \stdClass();
            $paymentInfo['trans_id']=$txidfee;
            $paymentInfo['total_amount']=$cfee;
            $paymentInfo['memo']='Service Fee';
            $result1=$pay->runCreditTx($paymentInfo, $convFeeCredential);
        }
        if($result['response']==1){
            $objbillpayment->set1Payment($txid,'trans_result_refnum' , $result['authcode']);
            $objbillpayment->set1Payment($txid,'trans_result_auth_code' , $result['authcode']);
            $objbillpayment->set1Payment($txid,'trans_status' , 1);
            $catdb->setStatus($id,999);
            $error='Payment Approved '.$result['authcode'];
        }
        else {
            $objbillpayment->set1Payment($txid,'trans_result_error_desc' , $result['responsetext']);
            $objbillpayment->set1Payment($txid,'trans_status' , 3);
            $error='Payment Declined '.$result['responsetext'];
            $catdb->setStatus($id,150);
        }
       
        return redirect()->route('bills', ['token'=>$token]);
    }
    
    public function addbill($token, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level!='M'){
            return redirect(route('accessdenied'));
        }
        $catdb = new \App\Model\Vendors();
        $vendors= $catdb->getVendorstoBill($idlevel);
        return view('manage.bills.addbill', array('token' => $token,'vendors'=>$vendors));
     }
     
     public function editbill($token,$id, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level!='M'){
            return redirect(route('accessdenied'));
        }
        $catdb = new Bill();
        $bill=$catdb->getBillById($id);
         if(!$bill){
             return Redirect::back()->with('error', 'Bill not found');
         }


        if($bill->due_to=='0000-00-00')$bill->due_to='';
        $catdb = new \App\Model\Vendors();
        $vendors= $catdb->getVendorstoBill($idlevel);
        return view('manage.bills.editbill', array('token' => $token,'vendors'=>$vendors,'bill'=>$bill));
     }
     
    function billSave($token, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];


        if($level!='M'){
            return redirect(route('accessdenied'));
        }

        $validator = $request->validate([
            'ddlvendor' => 'required|max:10',
            'txtinvoice' => 'required',
            'txtdescription' => 'required|max:255',
            'txtamount' => 'required|numeric',
            'txtdate' => 'required',
        ]);



        
        $bill = $request->all();
        $newbill=array();
        $newbill['property_id']=$idlevel;
        $newbill['vendor_id']=$bill['ddlvendor'];
        $newbill['amount']=$bill['txtamount'];
        $newbill['name']=$bill['txtdescription'];
        $newbill['invoice']=$bill['txtinvoice'];
        $newbill['status']=1;
        $newbill['updated_by'] = Auth::user()->username;
        if(isset($bill['txtrecurring'])){
            $newbill['recurring']=$bill['txtrecurring'];
        }


        $newbill['due_from']=date('Y-m-d',strtotime($bill['txtdate']));
        if(isset($bill['ddlfreq'])){
            $newbill['cycle']=$bill['ddlfreq'];
        }

        if(isset($bill['txtrecurring'])){
            if($bill['txtdaterecurring']){
                $newbill['due_to']=date('Y-m-d',strtotime($bill['txtdaterecurring']));

            }
            else{
                $newbill['due_to'] = null;
            }

        }
        else{
            $newbill['due_to'] = null;
            $newbill['recurring']=0;
        }


        $catdb = new \App\Model\Vendors();
        $ibill=$catdb->insertBill($newbill);
        if($bill['txtdate']==date('Y-m-d')){
            return redirect()->route('paybill',['token'=>$token,'id'=>$ibill]);
        }
        return redirect()->route('bills',['token'=>$token])->with('success', 'The element was saved successfully');
    }

    function billUpdate($token, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        if($level!='M'){
            return redirect(route('accessdenied'));
        }

        $validator = $request->validate([
            'ddlvendor' => 'required|max:10',
            'txtinvoice' => 'required',
            'txtdescription' => 'required|max:255',
            'txtamount' => 'required|numeric',
            'txtdate' => 'required',
        ]);
        
        $bill = $request->all();
        if(!isset($bill['id']))return redirect()->route('bills',['token'=>$token]);
        if(empty($bill['id']))return redirect()->route('bills',['token'=>$token]);
        $newbill=array();
        $newbill['property_id']=$idlevel;
        $newbill['vendor_id']=$bill['ddlvendor'];
        $newbill['amount']=$bill['txtamount'];
        $newbill['name']=$bill['txtdescription'];
        $newbill['invoice']=$bill['txtinvoice'];
        $newbill['status']=1;
        $newbill['updated_by'] = Auth::user()->username;

        if(isset($bill['txtrecurring'])){
            $newbill['recurring']=$bill['txtrecurring'];
        }


        $newbill['due_from']=date('Y-m-d',strtotime($bill['txtdate']));

        if(isset($bill['ddlfreq'])){
            $newbill['cycle']=$bill['ddlfreq'];
        }
        if(isset($bill['txtrecurring'])){
            if($bill['txtdaterecurring']){
                $newbill['due_to']=date('Y-m-d',strtotime($bill['txtdaterecurring']));

            }
            else{
                $newbill['due_to'] = null;
            }
        }
        else{
            $newbill['due_to'] = null;
            $newbill['recurring']=0;
        }
        $catdb = new Bill();
        $catdb->updateBill($bill['id'],$newbill);

        if($bill['txtdate']==date('m/d/Y')){
            return redirect()->route('paybill',['token'=>$token,'id'=>$bill['id']]);
        }
        return redirect()->route('bills',['token'=>$token])->with('success', 'The element was saved successfully');
    }

}