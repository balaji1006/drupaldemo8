<?php
namespace App\Http\Controllers;

use App\Model\Pricing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;

class PricingController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function pricinglist($token, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level!='A'){
            return redirect(route('accessdenied'));
        }
        $catdb = new Pricing();
        $filter = \DataFilter::source($catdb->getPricingByFilter());


        $filter->add('tlabel','Code','text');
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();	

        $grid = \DataGrid::source($filter);		
        $grid->attributes(array("class"=>"table table-striped table-hover"));
        $grid->add($token, $token)->style("display:none;");
        $grid->add('idpt', 'id')->style("display:none;");
        $grid->add('tlabel','Table Code',true);
        $grid->add('created_at','Created At',true);
	    $grid->add('actionvalue', 'Action')->style("text-align:right");

        $grid->row(
                function ($row) {
            $id = $row->cell('idpt')->value;
            $token = $row->cells[0]->name;
            $edit_link = '<li><a href="'.route('pricingview', array('token'=>$token, 'id'=>$id)).'" >View</a></li>';
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret white-font-color" ></span></button>
								<ul class="dropdown-menu">
							' . $edit_link . '
														  </ul>
	 													</div>';
            $row->cell('idpt')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('created_at', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('reports.pricing', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    
    }
    
    public function pricingview($token, $id, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level!='A'){
            return redirect(route('accessdenied'));
        }
        $catdb = new Pricing();
        $ptt=$catdb->getPricingTable($id);
        $ptname=$ptt->tlabel;
        $grid = \DataGrid::source($catdb->getServices($id));		
        $grid->attributes(array("class"=>"table table-striped table-hover"));
        $grid->add('description','Service');
        $grid->add('cost','Price');
	$grid->add('name_cycle', 'Frequency');
        $grid->add('billto', 'Bill To');
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        $grid1 = \DataGrid::source($catdb->getPAT($id));		
        $grid1->attributes(array("class"=>"table table-striped table-hover"));
        $grid1->add('partner_title','Partner');
        $grid1->add('company_name','Group');
	$grid1->add('name_clients', 'Merchant');
        $grid1->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('reports.pricingview', array(
            'token' => $token,
            'grid' => $grid,
            'grid1'=>$grid1,
            'ptname'=>$ptname
        ));
    }

}