<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Crypt;
use DB;

class adminUtilsController extends Controller
{
    public function notes($token, Request $request){

        $id = $request->get('idobj');
        $type = $request->get('type');
        $notes = $request->get('note');


        switch (strtoupper($type)){
            case 'P':
                $note = DB::table('notes')->where('idp','=',$id)->first();
                if($note){
                    DB::table('notes')->where('idp', $id)->update(['note' => $notes]);
                }else{
                    DB::table('notes')->insert(['idp' => $id,'idc' => 0,'idm' => 0, 'note'=>$notes]);
                }

                break;
            case 'G':
                $note = DB::table('notes')->where('idc','=',$id)->first();
                if($note){
                    DB::table('notes')->where('idc', $id)->update(['note' => $notes]);
                }else{
                    DB::table('notes')->insert(['idc' => $id,'idp' => 0,'idm' => 0, 'note'=>$notes]);
                }

                break;
            case 'M':
                $note = DB::table('notes')->where('idm','=',$id)->first();
                if($note){
                    DB::table('notes')->where('idm', $id)->update(['note' => $notes]);
                }else{
                    DB::table('notes')->insert(['idm' => $id,'idc' => 0,'idp' => 0, 'note'=>$notes]);
                }
                break;
        }

        return 1;

    }

    public function getnotes(Request $request){
        $id = $request->get('idobj');
        $type = $request->get('type');
        $note =  null;
        switch (strtoupper($type)){
            case 'P':
                $note = DB::table('notes')->where('idp','=',$id)->first();
                break;
            case 'G':
                $note = DB::table('notes')->where('idc','=',$id)->first();
                break;
            case 'M':
                $note = DB::table('notes')->where('idm','=',$id)->first();
                break;
        }
        if($note){
            return $note->note;
        }
        else{
            return '';
        }
    }
}