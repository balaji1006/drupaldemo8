<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Mail;
use App\CustomClass\csvFile;

class CronController extends Controller
{
    function consumebatch($tid){
        $tid= base64_decode($tid);
        $objbatch=new \App\Model\ImportBatchFile();
        $record=$objbatch->getBatchInfo($tid);
        //$objbatch->updateStatus($tid,1); //processing
        if(!empty($record) && $record->status==0){
            $content=file($record->tmp_file);
            $level=$record->level;
            $idlevel=$record->idlevel;
            if(!empty($content)){
                //$objbatch->updateStatus($tid,1);
                $data=json_decode($record->data,true);
                if(!empty($data)){
                    if($data['mode']=='csv'){
                        $objcsv=new \App\CustomClass\csvFile($content,$tid);
                        if($record->oper=='U'){
                            $objcsv->updatePayments($level,$idlevel,$data);
                            $objbatch->updateStatus($tid,90); //completed
                        }
                        elseif($record->oper=='L'){
                            if($data['fq']=='now'){
                                $objcsv->processPayments($level,$idlevel,$data);
                                $objbatch->updateStatus($tid,90); //completed
                            }
                            else {
                                $objcsv->createPayments($level,$idlevel,$data);
                                $objbatch->updateStatus($tid,90); //completed
                            }
                        }
                        else {
                            //invalid oper
                            $objbatch->insertSummaryLine($tid, 0, 'invalid operation');
                            $objbatch->updateBatchTask($tid, ['errors'=>1]);
                            $objbatch->updateStatus($tid,102);
                        }
                    }
                    elseif($data['mode']=='nacha'){
                        if($record->oper=='L'){
                            $objcsv=new \App\CustomClass\nachaFile($content,$tid);
                            if($data['fq']=='now'){
                                $objcsv->processPayments($level,$idlevel,$data);
                                $objbatch->updateStatus($tid,90); //completed
                            }
                            else {
                                $objcsv->createPayments($level,$idlevel,$data);
                                $objbatch->updateStatus($tid,90); //completed
                            }
                        }
                        else {
                            //invalid oper
                            $objbatch->insertSummaryLine($tid, 0, 'invalid operation');
                            $objbatch->updateBatchTask($tid, ['errors'=>1]);
                            $objbatch->updateStatus($tid,102);
                        }
                    }
                    else {
                        //invalid type
                        $objbatch->insertSummaryLine($tid, 0, 'invalid batch file');
                        $objbatch->updateBatchTask($tid, ['errors'=>1]);
                        $objbatch->updateStatus($tid,101);
                    }
                }
                else {
                    //missing data
                    $objbatch->insertSummaryLine($tid, 0, 'missing data for batch file');
                    $objbatch->updateBatchTask($tid, ['errors'=>1]);
                    $objbatch->updateStatus($tid,100);
                }
            }
            else {
                //closed file
                $objbatch->insertSummaryLine($tid, 0, 'empty batch file');
                $objbatch->updateBatchTask($tid, ['errors'=>1]);
                $objbatch->updateStatus($tid,99);
            }
        }
    }
}
