<?php

namespace App\Http\Controllers;

use App\Objects\PartnersConnector;
use App\Objects\CompaniesConnector;
use App\Objects\PropertiesConnector;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class TestController extends Controller
{
    function test(Request $request)
    {
        $obj=new \App\Http\Models\Transactions();
        $response=$obj->getSummaryByPeriod('M', [10586], 'months', 24);
        var_dump($response);
    }
}
