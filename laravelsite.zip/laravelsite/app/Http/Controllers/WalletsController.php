<?php
namespace App\Http\Controllers;

use App\Model\Wallets;
use Illuminate\Http\Request;
use Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class WalletsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    function merchantWallets($token,$id, Request $request){
        /* list($data)=explode('|',Crypt::decrypt($token));
         $array_token = json_decode($data,1);
         $idlevel = $array_token['id'];
         $level = $array_token['type'];
         $idadmin = $array_token['iduser'];
         $token = Crypt::encrypt($data.'|'.time().'|'.config('app.appAPIkey'));

         //security
 //		$objAdminAuth = new AuthAdminController();
 //		$objAdminAuth->checkAuthPermissions($array_token['iduser']); */

        $result=DB::table('properties')->where('id',$id)->first();
        $wallet_data=DB::table('merchant_wallet')->where('property_id',$id)->get();

        if(!$result)
            return redirect()->back()->with('error', 'Merchant not found');

        $data['pageTitle']= "Wallets";
        $data['token']=$token;
        $data['propertyId']=$id;

        $wallet = new Wallets();
        $wallets = $wallet->getWallets($id);

        $selected = array();
        foreach ($wallets as $item) {
            $selected[$item->type] = true;
        }
        $data['merchant'] = $result;
        $data['selected']=$selected;
        $data['wallet_data']=$wallet_data;
        return view('manage.merchant.wallets',$data);



    }


    function merchantWalletsSave($token,$id, Request $request){

        //masterpass_checkoutid

        $data_submit = $request->all();
        unset($data_submit['_token']);


        $data_masterpass = array();
        if (isset($data_submit['masterpass_checkoutid_val'])){
            $data_masterpass['checkoutid'] = $data_submit['masterpass_checkoutid_val'];
        }

        $wallet = new Wallets();
        $wallet->removeAllWallets($id);

        foreach ($data_submit as $w){
            switch ($w){
                case "mp":
                    $wallet->insertWallet($id, $w, json_encode($data_masterpass) );
                    break;
            }

        }

        return redirect()->back()->with('success', 'Saved successfully');
    }
}