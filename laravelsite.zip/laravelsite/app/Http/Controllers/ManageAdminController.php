<?php

namespace App\Http\Controllers;


use App\Http\Models\Merchants;
use App\Model\Branch;
use App\Model\Companies;
use App\Model\Partners;
use App\Model\Permissions;
use App\Model\Properties;
use App\Model\UsersAdmin;
use App\Model\UsersPermissions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ManageAdminController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function adminlist($token, Request $request)
    {

        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];



        $usersAdmins =  new UsersAdmin();
        $data = $usersAdmins->getUsersAdmins($level, $idlevel);

        $filter = \DataFilter::source($data);


        $filter->add('users_admin.username', 'Username', 'text');
        $filter->add('users_admin.name', 'Name', 'text');
        $filter->add('users_admin.emailaddress', 'Email', 'text');

        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();
        $grid = \DataGrid::source($filter);
        $grid->attributes(
            array(
                "class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction",

            )
        );

        $grid->add('users_admin_id', "idadmin")->style("display:none;");
        $grid->add('username', "Username", true);
        $grid->add('name', "Name", true);
        $grid->add('emailaddress', "Email", true);


        switch (strtoupper($level)){
            case "B":

                break;
            case "P":
                $grid->add('partner_title', "Partner", true);
                break;
            case "G":
                $grid->add('partner_title', "Partner", true);
                $grid->add('company_name', "Company", true);
                break;
            case "M":
                $grid->add('partner_title', "Partner", true);
                $grid->add('company_name', "Company", true);
                $grid->add('name_clients', "Merchant", true);
                break;

        }





        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(

            function ($row)use ($token) {
                $idadmin = $row->cell('users_admin_id')->value;
                $row->cell('users_admin_id')->style("display:none;");
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
													  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
													  <span class="caret"></span></button>
													  <ul class="dropdown-menu">
														<li><a href="'.route('manageadminedit',array('token'=>$token,'idadmin'=>$idadmin)).'">Edit</a></li>
														<li><a onclick="deleteAdmin('.$idadmin.')">Delete</a></li>
													  </ul>
													</div>';
            }
        );


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }

        $grid->paginate($itemsPerPage);

        return view(
            'manageadmin.adminlist',
            array(
                'grid'=>$grid,
                'atoken' => $token,
                'token' => $token,
                'filter' => $filter,
                'sqlEncrypted' => encrypt($sql_ready),
                'itemspage' => $itemsPerPage,
                'level'=>$level,
                'idlevel'=>$idlevel
            )
        );
    }

    public function adminlistCompany($token, Request $request)
    {

        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $usersAdmins =  new UsersAdmin();
        $data = $usersAdmins->getUsersAdminsCompanies($level,$idlevel);

        $filter = \DataFilter::source($data);


        $filter->add('users_admin.username', 'Username', 'text');
        $filter->add('users_admin.name', 'Name', 'text');
        $filter->add('users_admin.emailaddress', 'Email', 'text');

        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();
        $grid = \DataGrid::source($filter);
        $grid->attributes(
            array(
                "class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer",

            )
        );

        $grid->add('users_admin_id', "idadmin")->style("display:none;");
        $grid->add('username', "Username", true);
        $grid->add('name', "Name", true);
        $grid->add('emailaddress', "Email", true);
        $grid->add('partner_title', "Partner", true);
        $grid->add('company_name', "Company", true);
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(
            function ($row) use ($token){
                $idadmin = $row->cell('users_admin_id')->value;
                $row->cell('users_admin_id')->style("display:none;");
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
													  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
													  <span class="caret"></span></button>
													  <ul class="dropdown-menu">
														<li><a href="'.route('manageadminedit',array('token'=>$token,'idadmin'=>$idadmin)).'">Edit</a></li>
														<li><a onclick="deleteAdmin('.$idadmin.')">Delete</a></li>
													  </ul>
													</div>';
            }
        );


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }

        $grid->paginate($itemsPerPage);

        return view(
            'manageadmin.adminlistG',
            array(
                'grid'=>$grid,
                'atoken' => $token,
                'token' => $token,
                'filter' => $filter,
                'sqlEncrypted' => encrypt($sql_ready),
                'itemspage' => $itemsPerPage,
                'level'=>$level,
                'idlevel'=>$idlevel
            )
        );
    }

    public function adminlistMerchant($token, Request $request)
    {

        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $usersAdmins =  new UsersAdmin();
        $data = $usersAdmins->getUsersAdminsMerchants($level,$idlevel);

        $filter = \DataFilter::source($data);


        $filter->add('users_admin.username', 'Username', 'text');
        $filter->add('users_admin.name', 'Name', 'text');
        $filter->add('users_admin.emailaddress', 'Email', 'text');

        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();
        $grid = \DataGrid::source($filter);
        $grid->attributes(
            array(
                "class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer",

            )
        );

        $grid->add('users_admin_id', "idadmin")->style("display:none;");;
        $grid->add('username', "Username", true);
        $grid->add('name', "Name", true);
        $grid->add('emailaddress', "Email", true);
        $grid->add('partner_title', "Partner", true);
        $grid->add('company_name', "Company", true);
        $grid->add('name_clients', "Merchant", true);
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(
            function ($row) use ($token){
                $idadmin = $row->cell('users_admin_id')->value;
                $row->cell('users_admin_id')->style("display:none;");
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
													  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
													  <span class="caret"></span></button>
													  <ul class="dropdown-menu">
														<li><a href="'.route('manageadminedit',array('token'=>$token,'idadmin'=>$idadmin)).'">Edit</a></li>
														<li><a onclick="deleteAdmin('.$idadmin.')">Delete</a></li>
													  </ul>
													</div>';
            }
        );


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }

        $grid->paginate($itemsPerPage);

        return view(
            'manageadmin.adminlistM',
            array(
                'grid'=>$grid,
                'atoken' => $token,
                'token' => $token,
                'filter' => $filter,
                'sqlEncrypted' => encrypt($sql_ready),
                'itemspage' => $itemsPerPage,
                'level'=>$level,
                'idlevel'=>$idlevel
            )
        );
    }

    public function adminlistPartner($token, Request $request)
    {

        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $usersAdmins =  new UsersAdmin();
        $data = $usersAdmins->getUsersAdminsPartners($level,$idlevel);

        $filter = \DataFilter::source($data);


        $filter->add('users_admin.username', 'Username', 'text');
        $filter->add('users_admin.name', 'Name', 'text');
        $filter->add('users_admin.emailaddress', 'Email', 'text');

        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();
        $grid = \DataGrid::source($filter);
        $grid->attributes(
            array(
                "class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer",

            )
        );

        $grid->add('users_admin_id', "idadmin")->style("display:none;");;
        $grid->add('username', "Username", true);
        $grid->add('name', "Name", true);
        $grid->add('emailaddress', "Email", true);
        $grid->add('partner_title', "Partner", true);
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(
            function ($row) use ($token){
                $idadmin = $row->cell('users_admin_id')->value;
                $row->cell('users_admin_id')->style("display:none;");
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
													  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
													  <span class="caret"></span></button>
													  <ul class="dropdown-menu">
														<li><a href="'.route('manageadminedit',array('token'=>$token,'idadmin'=>$idadmin)).'">Edit</a></li>
														<li><a onclick="deleteAdmin('.$idadmin.')">Delete</a></li>
													  </ul>
													</div>';
            }
        );


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }

        $grid->paginate($itemsPerPage);

        return view(
            'manageadmin.adminlistP',
            array(
                'grid'=>$grid,
                'atoken' => $token,
                'token' => $token,
                'filter' => $filter,
                'sqlEncrypted' => encrypt($sql_ready),
                'itemspage' => $itemsPerPage,
                'level'=>$level,
                'idlevel'=>$idlevel
            )
        );
    }

    public function adminNew($token){
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $partners = array();
        $groups = array();
        $merchants = array();
        $branch = array();

        $obj_permissions = new Permissions();
        $permissions = $obj_permissions->getPermissions($level);


        switch (strtoupper($level)){
            case "B":
                $obj_branch = new Branch();
                $branch =  $this->objDBToArray($obj_branch->getById($idlevel), 'id' , 'name');

                $obj_partner = new Partners();
                $branch_partners = $obj_partner->getPartnersByBranch($idlevel);
                $array_partners = array();
                foreach ($branch_partners->all() as $partner){
                    $array_partners[] = $partner->id_partners;
                }
                $partners =  $this->objDBToArray($obj_partner->getPartnersByIds($array_partners), 'id' , 'partner_title');
                break;
            case "P":
                $obj_partner = new Partners();
                $partners =  $this->objDBToArray($obj_partner->getPartnersByIds($idlevel), 'id' , 'partner_title');

                $obj_company = new Companies();
                $groups =  $this->objDBToArray($obj_company->getCompaniesByPartnerId($idlevel), 'id','company_name');

                $obj_merchant = new Properties();
                $merchants =  $this->objDBToArray($obj_merchant->getMerchantsByPartner($idlevel), 'id','name_clients');

                break;
            case "G":
                $obj_company = new Companies();
                $groups =  $this->objDBToArray($obj_company->getCompanyById($idlevel), 'id','company_name');

                $obj_merchant = new Properties();
                $merchants =  $this->objDBToArray($obj_merchant->getMerchantsByCompany($idlevel), 'id','name_clients');

                break;
            case "M":
                $obj_merchant = new Properties();
                $merchants =  $this->objDBToArray($obj_merchant->getMerchantById($idlevel), 'id','name_clients');
                break;
        }


        return view(
            'manageadmin.newAdmin',
            array(
                'partners'=>$partners,
                'groups'=>$groups,
                'merchants'=>$merchants,
                'branch'=>$branch,
                'atoken' => $token,
                'token' => $token,
                'level'=>$level,
                'permissions'=>$permissions
            )
        );
    }

    public function adminNewSave($token, Request $request){
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $validator = $request->validate([
            'username' => 'required|max:255|min:3',
            'name' => 'required|max:255|min:3',
            'email' => 'required|max:255|email',
            'phone' => '',
            'password' => 'required|min:5|confirmed',
        ]);


        $obj_usersAdmin = new UsersAdmin();
        if($obj_usersAdmin->getUserAdminByUsername($request->get('username'))){
            return redirect()->back()->withErrors("The username is in use, please change it and try again.")->withInput();
        }
        else{
            $id_user = DB::table('users_admin')->insertGetId([
                'username' => $request->get('username'),
                'name' => $request->get('name'),
                'emailaddress' => $request->get('email'),
                'phone_number' => $request->get('phone'),
                'userpassw' => sha1($request->get('password')),

            ]);


            switch (strtoupper($level)){
                 case "A":
                        DB::table('users_access_master')->insert(['users_admin_id' => $id_user]);
                    break;
                case "B":
                    if($request->get('branches')){
                        foreach ($request->get('branches') as $branch){
                            DB::table('users_access_branch')->insert(['users_admin_id' => $id_user,'branch_id' => $branch]);
                        }
                    }
                    else{
                        if($request->get('partners')){
                            foreach ($request->get('partners') as $partner){
                                DB::table('users_access_partners')->insert(['users_admin_id' => $id_user,'partners_id' => $partner]);
                            }
                        }
                    }

                   break;
                case "P":
                    if($request->get('partners')){
                        foreach ($request->get('partners') as $partner){
                            DB::table('users_access_partners')->insert(['users_admin_id' => $id_user,'partners_id' => $partner]);
                        }
                    }
                    else{
                        $cpid=array();
                        if($request->get('companies')){
                            foreach ($request->get('companies') as $partner){
                                DB::table('users_access_company')->insert(['users_admin_id' => $id_user,'companies_id' => $partner]);
                                $cpid[]=$partner;
                            }
                        }
                        if($request->get('merchants'))
                        foreach ($request->get('merchants') as $partner){
                            $pass=false;
                            if(count($cpid)>0){
                                foreach($cpid as $cp){
                                    $ct= DB::table('properties')->where('id',$partner)->where('id_companies',$cp)->count();
                                    if($ct>0)$pass=true;
                                }
                            }
                            if($pass)continue;
                            DB::table('users_access_merchant')->insert(['users_admin_id' => $id_user,'property_id' => $partner]);
                        }
                    }
                    break;
                case "G":
                    if($request->get('companies')){
                        foreach ($request->get('companies') as $partner){
                            DB::table('users_access_company')->insert(['users_admin_id' => $id_user,'companies_id' => $partner]);
                        }
                    }
                    else{
                        if($request->get('merchants'))
                            foreach ($request->get('merchants') as $partner){
                                DB::table('users_access_merchant')->insert(['users_admin_id' => $id_user,'property_id' => $partner]);
                            }
                    }

                    break;
                case "M":
                    if($request->get('merchants'))
                    foreach ($request->get('merchants') as $partner){
                        DB::table('users_access_merchant')->insert(['users_admin_id' => $id_user,'property_id' => $partner]);
                    }
                    break;
            }

            foreach ($request->all() as $key => $item) {
                if(strpos($key, 'permission_') === 0){
                    $id_permission = str_replace('permission_','',$key);
                    DB::table('users_permissions')->insert(['users_admin_id' => $id_user,'permissions_id' => $id_permission]);
                }

            }


           return redirect()->route('manageadmin',array('token'=>$token))->with('success', 'Admin created successfully.');
        }

    }

    public function adminEditSave($token, $idadmin, Request $request){
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $validator = $request->validate([
            'username' => 'required|max:255|min:3',
            'name' => 'required|max:255|min:3',
            'email' => 'required|max:255|email',
            'phone' => '',
            'password' => 'confirmed',
        ]);



        $obj_usersAdmin = new UsersAdmin();
        $db_user = $obj_usersAdmin->getUserAdminByUsername($request->get('username'));
        if($db_user && $db_user->id != $idadmin){
            return redirect()->back()->withErrors("The username is in use, please change it and try again.")->withInput();
        }
        else{


            if($request->get('password')){
                DB::table('users_admin')
                    ->where('id', $idadmin)
                    ->update([
                        'username' => $request->get('username'),
                        'name' => $request->get('name'),
                        'emailaddress' => $request->get('email'),
                        'phone_number' => $request->get('phone'),
                        'userpassw' => sha1($request->get('password')),
                    ]);
            }
            else{
                DB::table('users_admin')
                    ->where('id', $idadmin)
                    ->update([
                        'username' => $request->get('username'),
                        'name' => $request->get('name'),
                        'emailaddress' => $request->get('email'),
                        'phone_number' => $request->get('phone'),
                    ]);
            }


            switch (strtoupper($level)){
                case "A":
                    $this->deleteRecordsAccess($level,$idlevel,$idadmin);
                    DB::table('users_access_master')
                                ->where('users_admin_id', $idadmin)
                                ->delete();
                    DB::table('users_access_master')->insert(['users_admin_id' => $idadmin]);
                    break;
                case "B":
                    if($request->get('branches')){
                        foreach ($request->get('branches') as $branch){

                            $branch_partner = DB::table('branch_partner')
                                ->where('branch_id', $branch)
                                ->get();
                            foreach ($branch_partner as $bp){
                                $this->deleteRecordsAccess('P', $bp->id_partners, $idadmin);
                            }

                            DB::table('users_access_branch')
                                ->where('users_admin_id', $idadmin)
                                ->where('branch_id', $branch)
                                ->delete();

                            DB::table('users_access_branch')->insert(['users_admin_id' => $idadmin,'branch_id' => $branch]);
                        }
                    }
                    else {


                        if ($request->get('partners')) {

                            DB::table('users_access_branch')
                                ->where('users_admin_id', $idadmin)
                                ->where('branch_id', $idlevel)
                                ->delete();

                            foreach ($request->get('partners') as $partner) {
                                $this->deleteRecordsAccess('P', $partner, $idadmin);
                                DB::table('users_access_partners')->insert(['users_admin_id' => $idadmin, 'partners_id' => $partner]);
                            }
                        }
                    }
                   break;
                case "P":
                    $this->deleteRecordsAccess($level,$idlevel,$idadmin);
                    if($request->get('partners')){
                        foreach ($request->get('partners') as $partner){
                            DB::table('users_access_partners')->insert(['users_admin_id' => $idadmin,'partners_id' => $partner]);
                        }
                    }
                    else{
                        $cpid=array();
                        if($request->get('companies')) {
                            DB::table('users_access_partners')->where('users_admin_id', $idadmin)->delete();
                            DB::table('users_access_company')->where('users_admin_id', $idadmin)->delete();
                            foreach ($request->get('companies') as $partner) {
                                DB::table('users_access_company')->insert(['users_admin_id' => $idadmin, 'companies_id' => $partner]);
                                $cpid[]=$partner;
                            }
                        }
                            
                        if($request->get('merchants')) {
                            DB::table('users_access_partners')->where('users_admin_id', $idadmin)->delete();
                            DB::table('users_access_merchant')->where('users_admin_id', $idadmin)->delete();
                            foreach ($request->get('merchants') as $partner) {
                                $pass=false;
                                if(count($cpid)>0){
                                    foreach($cpid as $cp){
                                        $ct= DB::table('properties')->where('id',$partner)->where('id_companies',$cp)->count();
                                        if($ct>0)$pass=true;
                                    }
                                }
                            if($pass)continue;
                                DB::table('users_access_merchant')->insert(['users_admin_id' => $idadmin, 'property_id' => $partner]);
                            }
                        }
                    }
                    break;
                case "G":
                    $this->deleteRecordsAccess($level,$idlevel,$idadmin);
                    if($request->get('companies')){
                        foreach ($request->get('companies') as $partner){
                            DB::table('users_access_company')->insert(['users_admin_id' => $idadmin,'companies_id' => $partner]);
                        }
                    }
                    else{
                        if($request->get('merchants')) {
                            foreach ($request->get('merchants') as $partner) {
                                DB::table('users_access_merchant')->insert(['users_admin_id' => $idadmin, 'property_id' => $partner]);
                            }
                        }
                    }

                    break;
                case "M":
                    $this->deleteRecordsAccess($level,$idlevel,$idadmin);
                    if($request->get('merchants')) {
                        foreach ($request->get('merchants') as $partner) {
                            DB::table('users_access_merchant')->insert(['users_admin_id' => $idadmin, 'property_id' => $partner]);
                        }
                    }
                    break;
            }

            DB::table('users_permissions')->where('users_admin_id', $idadmin)->delete();
            foreach ($request->all() as $key => $item) {
                if(strpos($key, 'permission_') === 0){
                    $id_permission = str_replace('permission_','',$key);
                    DB::table('users_permissions')->insert(['users_admin_id' => $idadmin,'permissions_id' => $id_permission]);
                }

            }


           return redirect()->route('manageadmin',['token' => $token])->with('success', 'Admin updated successfully.');
        }

    }

    public function adminEdit($token, $idadmin){
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $partners = array();
        $groups = array();
        $merchants = array();
        $branch = array();

        $obj_useradmin = new UsersAdmin();
        $user_admin = $obj_useradmin->getUserAdminById($idadmin);

        if(!$user_admin){
            return redirect()->back()->with('error', 'We can\'t find the admin.');
        }

        $obj_user_permissions = new UsersPermissions();
        $user_permissions = $this->objDBToArray($obj_user_permissions->getUserAdminPermissions($idadmin), 'permissions_id', 'id');


        $branches_selected = $this->objDBToArray(DB::table('users_access_branch')->where('users_admin_id',$idadmin)->get(),'branch_id','users_admin_id',true);
        $partners_selected = $this->objDBToArray(DB::table('users_access_partners')->where('users_admin_id',$idadmin)->get(),'partners_id','users_admin_id',true);
        $companies_selected = $this->objDBToArray(DB::table('users_access_company')->where('users_admin_id',$idadmin)->get(),'companies_id','users_admin_id',true);
        $merchants_selected = $this->objDBToArray(DB::table('users_access_merchant')->where('users_admin_id',$idadmin)->get(),'property_id','users_admin_id',true);


        $obj_permissions = new Permissions();
        $permissions = $obj_permissions->getPermissions($level);

        switch (strtoupper($level)){
            case "B":
                $obj_branch = new Branch();
                $branch =  $this->objDBToArray($obj_branch->getById($idlevel), 'id' , 'name');

                $obj_partner = new Partners();
                $branch_partners = $obj_partner->getPartnersByBranch($idlevel);
                $array_partners = array();
                foreach ($branch_partners->all() as $partner){
                    $array_partners[] = $partner->id_partners;
                }
                $partners =  $this->objDBToArray($obj_partner->getPartnersByIds($array_partners), 'id' , 'partner_title');
                break;
            case "P":
                $obj_partner = new Partners();
                $partners =  $this->objDBToArray($obj_partner->getPartnersByIds($idlevel), 'id' , 'partner_title');

                $obj_company = new Companies();
                $groups =  $this->objDBToArray($obj_company->getCompaniesByPartnerId($idlevel), 'id','company_name');

                $obj_merchant = new Properties();
                $merchants =  $this->objDBToArray($obj_merchant->getMerchantsByPartner($idlevel), 'id','name_clients');

                break;
            case "G":
                $obj_company = new Companies();
                $groups =  $this->objDBToArray($obj_company->getCompanyById($idlevel), 'id','company_name');

                $obj_merchant = new Properties();
                $merchants =  $this->objDBToArray($obj_merchant->getMerchantsByCompany($idlevel), 'id','name_clients');

                break;
            case "M":
                $obj_merchant = new Properties();
                $merchants =  $this->objDBToArray($obj_merchant->getMerchantById($idlevel), 'id','name_clients');
                break;
        }



        return view(
            'manageadmin.editAdmin',
            array(
                'branch'=>$branch,
                'partners'=>$partners,
                'groups'=>$groups,
                'merchants'=>$merchants,
                'atoken' => $token,
                'token' => $token,
                'level'=>$level,
                'permissions'=>$permissions,
                'user'=>$user_admin,
                'user_permissions'=>$user_permissions,
                'partners_selected'=>$partners_selected,
                'companies_selected'=>$companies_selected,
                'merchants_selected'=>$merchants_selected,
                'branches_selected'=>$branches_selected,
            )
        );
    }

    public function adminDelete($token, $idadmin){

        DB::table('users_access_partners')->where(['users_admin_id' => $idadmin])->delete();
        DB::table('users_access_company')->where(['users_admin_id' => $idadmin])->delete();
        DB::table('users_access_merchant')->where(['users_admin_id' => $idadmin])->delete();
        DB::table('users_access_master')->where(['users_admin_id' => $idadmin])->delete();
        DB::table('users_access_branch')->where(['users_admin_id' => $idadmin])->delete();
        DB::table('users_permissions')->where(['users_admin_id' => $idadmin])->delete();
        DB::table('users_admin')->where(['id' => $idadmin])->delete();


        return redirect()->back()->with('success', 'Admin deleted successfully.');
    }

    public function objDBToArray($obj,$key,$value, $flat = false, $array_label = null){
        $array = array();

        if(!$flat){
            if($array_label){

                foreach ($obj->all() as $item) {
                    $lab = '';
                    foreach ($array_label as $label){
                        if(!empty($item->$label)){
                            $lab = $lab . ' '.$item->$label;
                        }
                        else{
                            $lab = $lab .$item->$label;
                        }

                    }
                    $array[$item->$key]=$lab;
                }
            }
            else{

                if(method_exists($obj,'all')){
                    foreach ($obj->all() as $item) {
                        $array[$item->$key] = $item->$value;
                    }
                }
                else{
                    $array[$obj->$key] = $obj->$value;
                }

            }

        }
        else{
            foreach ($obj->all() as $item) {
                $array[] = $item->$key;
            }

        }

        return $array;
    }

    public function deleteRecordsAccess($level, $idlevel, $idadmin){
        switch (strtoupper($level)){
            case 'M':
                $merchant_obj = new Properties();
                $merchant =  $merchant_obj->getMerchantById($idlevel);

                DB::table('users_access_merchant')
                    ->where('users_admin_id', $idadmin)
                    ->where('property_id', $merchant->all()[0]->id)
                    ->delete();

                DB::table('users_access_company')
                    ->where('users_admin_id', $idadmin)
                    ->where('companies_id', $merchant->all()[0]->id_companies)
                    ->delete();

                DB::table('users_access_partners')
                    ->where('users_admin_id', $idadmin)
                    ->where('partners_id', $merchant->all()[0]->id_partners)
                    ->delete();

                $branch_partners = DB::table('branch_partner')
                    ->where('id_partners', $merchant->all()[0]->id_partners)
                    ->get();


                foreach ($branch_partners as $bp){
                    DB::table('users_access_branch')
                        ->where('users_admin_id', $idadmin)
                        ->where('branch_id', $bp->branch_id)
                        ->delete();
                }

                break;

            case 'G':
                $company_obj = new Companies();
                $company =  $company_obj->getCompanyById($idlevel);

                DB::table('users_access_merchant')
                    ->where('users_admin_id', $idadmin)
                    ->whereIn('property_id', function ($query) use ($idlevel) {
                        $query->from('properties');
                        $query->select('id as property_id');
                        $query->where('id_companies', $idlevel);
                    })
                    ->delete();

                DB::table('users_access_company')
                    ->where('users_admin_id', $idadmin)
                    ->where('companies_id', $idlevel)
                    ->delete();

                DB::table('users_access_partners')
                    ->where('users_admin_id', $idadmin)
                    ->where('partners_id', $company->all()[0]->id_partners)
                    ->delete();

                $branch_partners = DB::table('branch_partner')
                    ->where('id_partners', $company->all()[0]->id_partners)
                    ->get();


                foreach ($branch_partners as $bp){
                    DB::table('users_access_branch')
                        ->where('users_admin_id', $idadmin)
                        ->where('branch_id', $bp->branch_id)
                        ->delete();
                }

                break;
            case 'P':

                DB::table('users_access_merchant')
                    ->where('users_admin_id', $idadmin)
                    ->whereIn('property_id', function ($query) use ($idlevel) {
                        $query->from('properties');
                        $query->select('id as property_id');
                        $query->where('id_partners', $idlevel);
                    })
                    ->delete();

                DB::table('users_access_company')
                    ->where('users_admin_id', $idadmin)
                    ->whereIn('companies_id', function ($query) use ($idlevel) {
                        $query->from('companies');
                        $query->select('id as companies_id');
                        $query->where('id_partners', $idlevel);
                    })
                    ->delete();

                DB::table('users_access_partners')
                    ->where('users_admin_id', $idadmin)
                    ->where('partners_id', $idlevel)
                    ->delete();


                $branch_partners = DB::table('branch_partner')
                    ->where('id_partners', $idlevel)
                    ->get();


                foreach ($branch_partners as $bp){
                    DB::table('users_access_branch')
                        ->where('users_admin_id', $idadmin)
                        ->where('branch_id', $bp->branch_id)
                        ->delete();
                }


                break;
        }
    }

}
