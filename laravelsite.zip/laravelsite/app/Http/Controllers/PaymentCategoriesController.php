<?php
namespace App\Http\Controllers;

use App\Model\Categories;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;

class PaymentCategoriesController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function paymentCategories($token, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $catdb = new Categories();
        $filter = \DataFilter::source($catdb->getCategoriesPGM($idlevel,$level));
        $obj_layout=new \App\Model\Layout();
        $layouts=$obj_layout->getLayoutValues($idlevel,$level);
        switch (strtolower($level)){
            case 'b':
            case 'a':    
                $filter->add('partners.partner_title',$obj_layout->extractLayoutValue('label_partner',$layouts),'text');
                $filter->add('companies.company_name',$obj_layout->extractLayoutValue('label_group',$layouts),'text');
                $filter->add('properties.name_clients',$obj_layout->extractLayoutValue('label_merchant',$layouts),'text');
                break;
            case 'p':
                $filter->add('companies.company_name',$obj_layout->extractLayoutValue('label_group',$layouts),'text');
                $filter->add('properties.name_clients',$obj_layout->extractLayoutValue('label_merchant',$layouts),'text');
                break;
            case 'g':
                $filter->add('properties.name_clients',$obj_layout->extractLayoutValue('label_merchant',$layouts),'text');
                break;
        }

        $filter->add('account_number',$obj_layout->extractLayoutValue('label_acc_number',$layouts),'text');
        $filter->add('trans_user_name','Name','text');
        $filter->add('category_name','Description','text');
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();	

        $grid = \DataGrid::source($filter);		
        $grid->attributes(array("class"=>"table table-striped table-hover"));

        $grid->add('trans_first_post_date','Date',true);
        $grid->add('trans_id','TransID',true);
        switch (strtolower($level)){
            case 'b':
            case 'a':    
                $grid->add('partner_title',$obj_layout->extractLayoutValue('label_partner',$layouts));
                $grid->add('company_name',$obj_layout->extractLayoutValue('label_group',$layouts));
                $grid->add('name_clients',$obj_layout->extractLayoutValue('label_merchant',$layouts));
                break;
            case 'p':
                $grid->add('company_name',$obj_layout->extractLayoutValue('label_group',$layouts));
                $grid->add('name_clients',$obj_layout->extractLayoutValue('label_merchant',$layouts));
                break;
            case 'g':
                $grid->add('name_clients',$obj_layout->extractLayoutValue('label_merchant',$layouts));
                break;
        }
        $grid->add('trans_account_number',$obj_layout->extractLayoutValue('label_acc_number',$layouts));
        $grid->add('trans_user_name','Name');
        $grid->add('qty','Quantity',  true);
        $grid->add('amount','Amount',  true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('category_name','Description',true)->style("text-align:left");
	
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer "));

        return view('reports.categories', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    
    }

    public function paymentCategoriesList($token, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        $catdb = new Categories();
        $filter = \DataFilter::source($catdb->getCategoriesByFilter($idlevel));
        $filter->add('payment_type_name','Description','text');
        $filter->add('payment_type_code','Charge Code','text');
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();	

        $grid = \DataGrid::source($filter);		
        $grid->attributes(array("class"=>"table table-striped table-hover"));
        $grid->add($token, $token)->style("display:none;");
        $grid->add('payment_type_id', 'id')->style("display:none;");
        $grid->add('payment_type_name','Description',true);
        $grid->add('payment_type_code','Charge Code',true);
        $grid->add('amount','Amount')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('is_balance','impact balance?')->cell(
                function($value){
                    if($value==0){
                        return 'No';
                    }
                    else {
                        return 'Yes';
                    }
                }
                );
        $grid->add('qty','show quantity?')->cell(
                function($value){
                    if($value==0){
                        return 'No';
                    }
                    else {
                        return 'Yes';
                    }
                }
                );
        $grid->add('qtymax','Quantity limit');
	$grid->add('actionvalue', 'Action')->style("text-align:right");;

        $grid->row(
                function ($row) {
            $id = $row->cell('payment_type_id')->value;
            $token = $row->cells[0]->name;
            $edit_link = '<li><a href="'.route('editcategory', array('token'=>$token, 'id'=>$id)).'">Edit</a></li>';
            $delete_link = '<li><a onclick="deletecategory(' . $id . ')" >Delete</a></li>';
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret white-font-color" ></span></button>
								<ul class="dropdown-menu">
							' . $edit_link . '
							' . $delete_link . '
														  </ul>
	 													</div>';
            $row->cell('payment_type_id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('payment_type_name', 'ASC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('customize.categories.categories', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    
    }
    
    function addcategory($token) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        return view('customize.categories.addcategory', array('token' => $token));
    }
    
    function savecategory($token, Request $request) {


        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken = ['level'];

        //validations
        $messajes =array(
            'txtname.max' => 'The Description may not be greater than 40 characters.',
            'txtname.required' => 'The Description is required.',

            'txtcode.max' => 'The Charge Code may not be greater than 40 characters.',

            'txtlimit.max' => 'The Quantity Limit may not be greater than 11 characters.',

        );
        $request->validate([
            'txtname' => 'required|max:40',
            'txtcode' => 'max:40',
            'ddlbalance' => 'numeric|max:1',
            'ddlqty' => 'numeric|max:1',
            'txtlimit' => 'max:11',
        ], $messajes);


        $category = array();
        $category['property_id'] = $idlevel;
        $category['payment_type_name'] = $request['txtname'];
        $category['is_balance'] = $request['ddlbalance'];
        $category['qty'] = $request['ddlqty'];
        if($request['txtcode']!==null){
            $catdb = DB::table('payment_type')->where('payment_type_code',$request['txtcode'])->first();
            if($catdb){
                return back()->withInput()->with('error', 'This Charge Code already exists');
            }
            $category['payment_type_code'] = $request['txtcode'];
        }

        if($request['txtamount']!==null)$category['amount'] = $request['txtamount']*1;
        $category['qtymax'] = $request['txtlimit']*1;
        $category['last_updated_by'] = Auth::user()->username;
        $category['last_updated'] = date('Y-m-d H:i:s');
        $objcategory = new Categories();
        $objcategory->createCategory($category);
        return redirect()->route('categorieslist', array('token' => $token))->with('success', 'The Category was saved successfully');
    }
	
    function deletecategory($id) {
        $objcategory = new Categories();
        $objcategory->removeCategory($id);
        return back()->with('success', 'Category deleted successfully.');
    }
    
    function editcategory($token, $id) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken = ['level'];
        $objcategory = new Categories();
        $category_db = $objcategory->getCatByID($id,$idlevel);
        return view('customize.categories.editcategory', array('category' => $category_db, 'token' => $token));
    }
    
    function updatecategory(Request $request) {
        $id = $request['id'];
        if(empty($id)){
            return redirect()->back();
        }



        //validations
        $messajes =array(
            'txtname.max' => 'The Description may not be greater than 40 characters.',
            'txtname.required' => 'The Description is required.',

            'txtcode.max' => 'The Charge Code may not be greater than 40 characters.',

            'txtlimit.max' => 'The Quantity Limit may not be greater than 11 characters.',

        );
        $request->validate([
            'txtname' => 'required|max:40',
            'txtcode' => 'max:40',
            'ddlbalance' => 'numeric|max:1',
            'ddlqty' => 'numeric|max:1',
            'txtlimit' => 'max:11',
        ], $messajes);

        $token = $request['token'];
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken = ['level'];
        $category = array();
        $category['property_id'] = $idlevel;
        $category['payment_type_name'] = $request['txtname'];
        $category['is_balance'] = $request['ddlbalance'];
        $category['qty'] = $request['ddlqty'];
        if($request['txtcode']!==null){
            $catdb = DB::table('payment_type')->where('payment_type_code',$request['txtcode'])->first();
            if($catdb && $catdb->payment_type_id !=$id){
                return back()->withInput()->with('error', 'This Charge Code already exists');
            }
            $category['payment_type_code'] = $request['txtcode'];
        }
        
        // validate if show quantity is "NO" then quantity limit has to be 0
        if(empty($category['qty'])) {
            $category['qtymax'] = 0;
        } else {
            $category['qtymax'] = $request['txtlimit']*1;
        }
        if($request['txtamount']!==null)$category['amount'] = $request['txtamount']*1;
        $category['last_updated_by'] = Auth::user()->username;
        $category['last_updated'] = date('Y-m-d H:i:s');
        $objcategory = new Categories();
        $objcategory->UpdateCat($id,$category);
        return redirect()->route('categorieslist', array('token' => $token))->with('success', 'The Category was updated successfully');
    }
}
