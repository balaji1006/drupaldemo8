<?php

namespace App\Http\Controllers;

//use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Model;
use App\Http\Models\Transactions;
use App\Http\Models\Settlement;
use App\Http\Models\Autopayments;
use App\Http\Models\Payors;
use App\Http\Models\Admins;

class DashboardController extends Controller {

    function __construct() {
        $this->middleware('auth');
    }

    function entitySelection() {
        //verify if user is master admin
        $obj_admin = new Admins();
        if (!$obj_admin->isMaster(Auth::id())) {
            $data = [
                'branch' => Model\UsersAccessBranch::where(['users_admin_id' => Auth::id()])->get(),
                'company' => Model\UsersAccessCompany::where(['users_admin_id' => Auth::id()])->get(),
                'merchant' => Model\UsersAccessMerchant::where(['users_admin_id' => Auth::id()])->get(),
                'partners' => Model\UsersAccessPartners::where(['users_admin_id' => Auth::id()])->get(),
            ];
            return view('dashboard.entityselection', $data);
        } else {

            return redirect(route('dashboard', ['token' => encrypt(['level' => 'A', 'level_id' => 0])]));
        }
    }

    function dashboard($token = null)
    {

        if (!validateToken($token)) {
            return redirect(route('accessdenied'));
        }
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];

        return view('dashboard.dashboard', ['token' => $token]);
    }

    public function accessdenied() {
        return view('dashboard.accessdenied');
    }

    public function getPayors($token){

        if (!validateToken($token)) {
            return redirect(route('accessdenied'));
        }
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];

        $payors = new Payors();
        $payors = $payors->getAdoptionRate($level, $idlevel);

        return view('dashboard.payorsTotal', ['payors' => $payors]);
    }

    public function getAutopayments($token){

        if (!validateToken($token)) {
            return redirect(route('accessdenied'));
        }
        $autop = new Autopayments();
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $autopayments = $autop->getActive($level, $idlevel);

        return view('dashboard.autopayments', ['autopayments' => $autopayments]);
    }

    public function getSettlements($token){

        if (!validateToken($token)) {
            return redirect(route('accessdenied'));
        }
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $settlement = new Settlement();
        $settlement = $settlement->getSettlementToday($level, $idlevel);

        return view('dashboard.settlement', ['settlement' => $settlement]);
    }

    public function getActivity($token){
        if (!validateToken($token)) {
            return redirect(route('accessdenied'));
        }
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];

        $transaction = new Transactions();
        $data = $transaction->getSummaryByPeriod($level, [$idlevel], 'months', 12);

        if(isset($data['total'])){
            $data['total'] = number_format($data['total'], 2);
        }
        else{
            $data['total'] = number_format(0, 2);
        }

        if(!isset($data['count'])){
            $data['total'] = 0;
        }

        $records_chart = array();
        $records_chart_dates = array();

        if(isset($data['records'])){
            if(isset($data['records']->all()[0])){
                $firstDate = $data['records']->all()[0];
                $firstDate = explode('-', $firstDate->tx_date);
                $data['since'] = $firstDate[0];

                foreach ($data['records'] as $key=>$record) {
                    $records_chart[$key]=[$key,$record->net_amount];
                    $records_chart_dates[$key]=[$key,$record->tx_date];
                }
            }
            unset($data['records']);
        }
        else{
            $data['since'] = 0;
        }


        $data['records_chart']=$records_chart;
        $data['records_chart_dates']=$records_chart_dates;

        if(isset($data['last_date'])){
            $last_date_time = strtotime($data['last_date']);
            $data['last_date'] = date("M d, Y", $last_date_time);
        }

        return response()->json(array('msg' => '1','data'=>$data));
    }

    public function getRecentActivity($token){
        if (!validateToken($token)) {
            return redirect(route('accessdenied'));
        }
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $transaction = new Transactions();
        $dataviews['recent_payments'] = view('dashboard.recentPayments', ['recent_payments' => $transaction->getRecentActivity($level, [$idlevel])])->render();
        $dataviews['recent_activity'] = view('dashboard.recentActivity', ['recent_activity' => $transaction->getActivityPeriod($level, [$idlevel], strtotime('-12 months'), strtotime('now'))])->render();

        return response()->json(array('msg' => '1','data'=>$dataviews));

    }

}
