<?php

namespace App\Http\Controllers;

use App\Http\Models\Autopayments;
use App\Http\Models\Outboundpayments;
use App\Http\Models\Settlement;
use App\Http\Models\Transactions;
use App\Http\Models\Emaf;
use App\Model\AccountingTransactions;
use App\Model\Partners;
use App\Model\WebUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use function Sodium\add;
use Zofe\Rapyd\DataForm\Field\Date;
use Illuminate\Support\Facades\Auth;
use App\Model\Properties;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use App\Model\CustomField;

class ReportsController extends Controller {

    function __construct() {
        $this->middleware('auth');
    }

    function transactions($token, Request $request, $data = '') {

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $filterdata = null;
        $field = array();
        if ($level == 'M') {

            $obj_customfield = new CustomField();
            $field = $obj_customfield->getTransactionField($idlevel);
        }
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $transaction_obj = new Transactions();
        $transactions = $transaction_obj->getTransactionsByFilter($level, $idlevel, $filterdata);

        $advFilter = $transaction_obj->getAdvancedFilters($level,$idlevel);

        //gets the hide ec void setting
        $objCustomize = new \App\Model\Customize();
        $hideVoid = $objCustomize->getSettingByKey($atoken['level'], $atoken['level_id'], 'HIDEVOIDEC');
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $filter = \DataFilter::source($transactions);
        $filter->add('trans_payment_type', 'Method', 'select')->options(array(
            '' => 'Method',
            'cc' => 'Credit Card',
            'ec' => 'eCheck',
            'CASH' => 'Cash',
        ));

        $filter->add('trans_status', 'Status', 'select')->options(array(
            '' => 'Status',
            '1' => 'Approved',
            '0' => 'Errored',
            '3' => 'Declined',
        ));

        $filter->add('trans_type', 'Type', 'select')->options(array(
            '' => 'Type',
            '0' => 'Onetime',
            '1' => 'Autopayment',
            '2' => 'Returned',
            '5' => 'Refunded',
            '9' => 'Void',
        ));

        $filter->add('accounting_transactions.trans_id', 'Trans ID', 'text');
        $filter->add('trans_total_amount', 'Total', 'text')->scope(
                function ($query, $value) {
            $value = str_replace(",", ".", $value);
            return $query->where('trans_total_amount', 'like', '%' . $value . '%');
        }
        );
        $filter->add('accounting_transactions.source', 'Source', 'select')->options(array(
            '' => 'Source',
            'web' => 'Web',
            'eterm' => 'E-terminal',
            'ivr' => 'IVR',
            'api' => 'API',
            'lox' => 'Lockbox',
            'rdc' => 'RDC',
            'HAX' => 'HAX',
            'CDO' => 'CDO',
            'Swipe' => 'Swipe',
            'OneClick' => 'OneClick',
            'qpay' => 'QuickPay',
            'MOBILE' => 'Mobile',
            'nacha' => 'Nacha',
            'AUTO' => 'Auto',
        ))->scope(
                function ($query, $value) {
            return $query->where('accounting_transactions.source', 'like', '%' . $value . '%');
        }
        );
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('trans_first_post_date', 'Date', true)->cell(function ($value) {
            $value = strtotime($value);
            return date("m/d/Y H:i:s", $value);
        });
        if ($level == 'B' || $level == 'A') {
            $grid->add('partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts), true);
        }
        if ($level != 'G' && $level != 'M') {
            $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts), true);
        }
        if ($level != 'M') {
            $grid->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), true);
        }
        $grid->add('trans_id', 'Trans ID', true);
        $grid->add('trans_net_amount', 'Amount', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        if ($level == 'A') {
            $grid->add('trans_convenience_fee', 'Fee', true)->cell(function ($value) {
                return '$' . number_format($value, 2);
            });
        }
        $grid->add('trans_total_amount', 'Total', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), true);
        $grid->add('invoice_number', 'Invoice #', true);
        $grid->add('trans_user_name', 'Name', true);
        $grid->add('trans_payment_type', 'Method', true)->cell(function ($value) {
            switch ($value) {
                case 'cc':
                    return 'Credit Card';
                    break;
                case 'ec':
                    return 'eCheck';
                    break;
                default:
                    return $value;
                    break;
            }
        });
        $grid->add('trans_type', 'Trans Type', true)->cell(function ($value) {
            switch ($value) {
                case 0:
                    return 'Onetime';
                    break;
                case 1:
                    return 'Autopayment';
                    break;
                case 2:
                    return 'Returned';
                    break;
                case 5:
                    return 'Refunded';
                    break;
                case 9:
                    return 'Void';
                    break;
                default:
                    echo '-';
            }
        });
        if ($level == 'M') {
            if (!empty($field)) {
                foreach ($field as $customfieldname) {
                    $grid->add($customfieldname->field_description, $customfieldname->field_description);
                }
            }
        }
        $grid->add('trans_card_type', 'Payment Type', true)->cell(function ($value) {
            if (strtolower(substr($value, 0, 4)) === "visa") {
                $value = '<img class="iconreport" src="' . asset('img/visa.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 8)) === "checking" || strtolower(substr($value, 0, 6)) === "saving") {
                $value = '<img class="iconreport" src="' . asset('img/checking.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 3)) === "ame") {
                $value = '<img class="iconreport" src="' . asset('img/amex.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 4)) === "cash") {
                $value = '<img class="iconreport" src="' . asset('img/money.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 8)) === "discover") {
                $value = '<img class="iconreport" src="' . asset('img/discover.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 10)) === "mastercard") {
                $value = '<img class="iconreport" src="' . asset('img/mastercard.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 5)) === "swipe") {
                $value = '<img class="iconreport" src="' . asset('img/swipe.png') . '"> ' . $value;
            }
            return $value;
        });
        $grid->add('source', 'Source', true)->cell(function ($value) {
            switch ($value) {
                case 'eterm':
                    return 'E-terminal';
                    break;
                case 'web':
                    return 'Web';
                    break;
                case 'ivr':
                    return 'IVR';
                    break;
                case 'lox':
                    return 'Lockbox';
                    break;
                case 'rdc':
                    return 'RDC';
                    break;
                case 'Swipe':
                    return 'Swipe';
                    break;
                case 'HAX':
                    return 'HAX';
                    break;
                case 'CDO':
                    return 'CDO';
                    break;
                case 'OneClick':
                    return 'OneClick';
                    break;
                case 'qpay':
                    return 'QuickPay';
                    break;
                case 'API':
                    return 'API';
                    break;
                case 'AUTO':
                    return 'AUTO';
                    break;
                case 'nacha':
                    return 'Nacha';
                    break;
                case 'MOBILE':
                    return 'Mobile';
                    break;
                default:
                    return $value;
            }
        });

        $grid->add('trans_status', 'Status', true)->cell(function ($value) {
            switch ($value) {
                case 4:
                    return '<span class="label label-info pull-left">Voided</span>';
                    break;
                case 1:
                    return '<span class="label label-success pull-left">Approved</span>';
                    break;
                case 0:
                    $this->status_trans = 0;
                    return '<span class="label label-danger pull-left">Error</span>';
                    break;
                default:
                    return '<span class="label label-warning pull-left">Declined</span>';
            }
        });

        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(function ($row) use ($token, $hideVoid, $transaction_obj, $level, $idlevel) {
            $id = $row->cell('trans_id')->value;
            $isrefund = $row->cell('trans_type')->value;
            $settled = new Transactions();
            $issettled = $settled->getTransactionSettled($id);
            $status_trans = $row->cell('trans_status')->value;
            $method = $row->cell('trans_payment_type')->value;

            if ($status_trans == '<span class="label label-success pull-left">Approved</span>') {
                if (!empty($method) && $method == 'eCheck' && !empty($hideVoid) && $hideVoid == 1) {
                    dd('inif');
                    $voidLink = '';
                    $refundLink = '';
                } else if (empty($issettled)) {
                    if($isrefund != "Refunded"){
                        $voidLink = '<li><a data-toggle="modal" data-target="#myModal" data-url="' . route('showRefundPopUp', array('token' => $token, 'trans_id' => $id, 'ttype' => 0)) . '" >Void</a></li>';
                    }else{
                        $voidLink = '';
                    }
                    $refundLink = '';
                } else {
                    $voidLink='';
                    if($isrefund != "Refunded"){
                        $refundLink = '<li><a data-toggle="modal" data-target="#myModalRefund" data-url="' . route('showRefundPopUp', array('token' => $token, 'trans_id' => $id, 'ttype' => 1)) . '" >Refund</a></li>';
                    }else{
                        $refundLink = '';
                    }
            }
            $detailslLink = '<li><a data-toggle="modal" data-target="#myModal1" data-url="' . route('userpayhistorydetail', array('token' => $token, 'id' => $id)) . '" >Details</a></li>';
            $receiptLink = '<li><a data-toggle="modal" data-target="#receiptModal" data-url="' . route('showSendReceiptPopUp', array('token' => $token, 'trans_id' => $id)) . '" >Send Receipt</a></li>';
            $row->cell('actionvalue')->value = '<div class="dropdown pull-right"><button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span> <span class="caret white-font-color" ></span></button>

            <ul class="dropdown-menu">' . $voidLink . $refundLink . $detailslLink . $receiptLink . '</ul></div>';
            } else {
                $detailslLink = '<li><a data-toggle="modal" data-target="#myModal1" data-url="' . route('userpayhistorydetail', array('token' => $token, 'id' => $id)) . '" >Details</a></li>';
                $row->cell('actionvalue')->value = '<div class="dropdown pull-right"><button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span> <span class="caret white-font-color" ></span></button>
                <ul class="dropdown-menu">' . $detailslLink . '</ul></div>';
            }
            if ($level == 'M') {
                $custom = $transaction_obj->getTransactionsCustomField($id, $idlevel);

                for ($i = 0; $i < count($custom); $i++) {
                    $row->cell($custom[$i]->field_description)->value = $custom[$i]->field_value;
                }
            }
        });

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
//        $sql_ready = $sql_ready);

        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }

        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('reports.transactions', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage,
            'advFilter' => $advFilter,
            'advFilterRoute' => route('transactionreport', ['token' => $token]),
            'sqlEncrypted' => encrypt($sql_ready)
        ));
    }

    public function showRefundPopUp($token, $transID, $ttype) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        //var_dump($idlevel);die;

        if ($idlevel <= 0 && $idlevel != -954581 && $atoken['level'] != 'A') {
            return response()->json(array('errcode' => 261, 'msg' => 'Invalid Request'));
        }
        if ($transID <= 0) {
            return response()->json(array('errcode' => 264, 'msg' => 'Invalid Request'));
        }

        $obj_trans = new Transactions();
        $data = array();

        $property_id = $obj_trans->get1TransInfo($transID, 'property_id');
        $amount = $obj_trans->get1TransInfo($transID, 'trans_net_amount');
        $trans_payment_type = $obj_trans->get1TransInfo($transID, 'trans_payment_type');
        $refamount = $obj_trans->getRefundAmount($transID, $property_id);
        $data['trans_payment_type'] = $trans_payment_type;
        $data['property_id'] = $property_id;

        if ($trans_payment_type == 'ec') {
            $data['noPartial'] = true;
        }
        if ($ttype == 1) {
            //refund
            $data['refund'] = 1;
            $data['transType'] = "Refund";
            $data['text_body'] = "Please Confirm that you want to Refund the transaction with ID " . $transID . " by clicking on the Refund Button";
            $data['amount'] = $amount - $refamount;
            if ($data['amount'] > 0) {
                $data['availableRefund'] = true;
            } else {
                $data['availableRefund'] = false;
            }
            $obj_msg = new \App\Model\Message();
            $data['msgrefunded'] = $obj_msg->getMessageByKey("transactionRefunded");
        } else if ($ttype == 0) {
            //void
            $data['refund'] = 0;
            $data['transType'] = "Void";
            $data['noPartial'] = true;
            $data['text_body'] = "Please Confirm that you want to Void the transaction with ID " . $transID . " by clicking on the Void Button";
        }

        $data['pageTitle'] = "Transaction";
        $data['uxtoken'] = $token;
        $data['trans_id'] = $transID;
        return view('reports.refund', $data);
    }

    public function transRefund($trans_id, Request $request) {
        $obj_msg = new \App\Model\Message();
        $uxtoken = "";
        $amount = "";
        if ($request->get('amount') != null) {
            $amount = $request->get('amount');
        }
        $trans_id;
        if ($trans_id <= 0) {
            return response()->json(array('errcode' => 264, 'responsetext' => 'Invalid Request'));
        }

        $transInfo = array();
        $obj_trans = new \App\Model\Transations();
        $obj_property = new \App\Model\Properties();


        $property_id = $obj_trans->get1TransInfo($trans_id, 'property_id');
        $net_amount = $obj_trans->get1TransInfo($trans_id, 'trans_net_amount');
        $trans_payment_type = $obj_trans->get1TransInfo($trans_id, 'trans_payment_type');
        $trans_result_refnum = $obj_trans->get1TransInfo($trans_id, 'trans_result_refnum');
        $convFee = $obj_trans->get1TransInfo($trans_id, 'trans_convenience_fee');
        $trans_result_auth_code = $obj_trans->get1TransInfo($trans_id, 'trans_result_auth_code');
        $transInfo['trans_result_auth_code'] = $trans_result_auth_code;
        $transInfo['property_id'] = $property_id;
        $transInfo['trans_payment_type'] = $trans_payment_type;
        $transInfo['trans_result_refnum'] = $trans_result_refnum;
        $transInfo['trans_id'] = $trans_id;

        //ask for previous partial refund
        /* if($obj_trans->hasPartialRefund($trans_id)){
          return response()->json(array('errcode'=>264,'responsetext'=>$obj_msg->getMessageByKey('hasPartialRefund')));
          } */


        //setting asking for permitions to refund convenience fee (by default convenience fee is  no refundable)
        $ids = $obj_property->getOnlyIds($property_id);
        $settingrefundConvFee = $obj_property->getPropertySettings($property_id, $ids["id_companies"], $ids["id_partners"], 'REFUNDCONVFEE');

        $isPartial = false;
        if (empty($amount) || $net_amount == $amount) { //Total Refund
            $transInfo['trans_net_amount'] = $net_amount;
        } else if ($amount < $net_amount) { // Partial Refund
            $transInfo['trans_net_amount'] = $amount;
            $isPartial = true;
        } else {//Error
            return response()->json(array('errcode' => 264, 'responsetext' => $obj_msg->getMessageByKey('invalidRefundAmount')));
        }

        //getting credentials
        $cred = $obj_property->getCredentialtype_isrecurring($trans_payment_type, $property_id, 0);
        if (empty($cred->toArray())) {
            $cred = $obj_property->getCredentialtype_isrecurring($trans_payment_type, $property_id, 1);
        }

        if (empty($cred->toArray())) {
            return response()->json(array('errcode' => 264, 'responsetext' => $obj_msg->getMessageByKey('nocredential')));
        }

        $credential = $cred[0];
        $obj_paymentProcessor = new \App\CustomClass\PaymentProcessor();

        switch ($credential->gateway) {
            case 'nmi':
            case 'fd4':
            case 'fde4':
                if ($trans_payment_type == "cc") {
                    $transInfo['trans_net_amount'] = ($isPartial || !$settingrefundConvFee) ? $transInfo['trans_net_amount'] : $transInfo['trans_net_amount'] + $convFee;
                }
                $result = $obj_paymentProcessor->refund($transInfo, $credential);
                break;
            case 'express':
            case 'vantiv':
                if ($trans_payment_type == "cc") {
                    $transInfo['trans_net_amount'] = ($isPartial || !$settingrefundConvFee) ? $transInfo['trans_net_amount'] : $transInfo['trans_net_amount'] + $convFee;

                    //error_log(print_r($transInfo,true),3,'/var/tmp/aarefund.log');
                }

                $result = $obj_paymentProcessor->refund($transInfo, $credential);
                break;
            case 'profistars':
                $result = $obj_paymentProcessor->refund($transInfo, $credential);
                break;
            case 'prismpay':
                $result = $obj_paymentProcessor->refund($transInfo, $credential);
                break;
            default:
                return response()->json(array('errcode' => 265, 'responsetext' => 'Invalid credentials'));
                break;
        }
        //error_log(print_r($result,true),3,'/var/tmp/aarefund.log');
        if ($result['response'] == 1) { //Success
            $obj_trans->createRefund($trans_id, $amount, $credential->gateway, $settingrefundConvFee, $result);
        }

        if (!$isPartial && $settingrefundConvFee && $trans_payment_type != "cc") {
            $convFee_transaction = $obj_trans->GetConvFee($trans_id);
            if (!empty($convFee_transaction)) {
                $emptyConvFee = array('gateway' => $credential->gateway);
                $result1 = $obj_paymentProcessor->refund($convFee_transaction, $emptyConvFee);
                if ($result1['response'] == 1) { //Success
                    $obj_trans->createRefund($convFee_transaction['trans_id'], $convFee_transaction['trans_net_amount'], $emptyConvFee['gateway'], $settingrefundConvFee, $result);
                }
            }
        }


        return response()->json($result);
    }

    public function transVoid($trans_id, Request $request) {
        $uxtoken = "";
        $transInfo = array();
        $obj_trans = new \App\Model\Transations();
        $obj_property = new \App\Model\Properties();
        $obj_msg = new \App\Model\Message();
        if ($request->get('uxtoken') != null) {
            $uxtoken = $request->get('uxtoken');
        }
        if (empty($uxtoken)) {
            return response()->json(array('errcode' => 261, 'responsetext' => $obj_msg->getMessageByKey('invtoken')));
        }
        if ($trans_id <= 0) {
            return response()->json(array('errcode' => 264, 'responsetext' => 'Invalid Request'));
        }
        $property_id = $obj_trans->get1TransInfo($trans_id, 'property_id');
        $amount = $obj_trans->get1TransInfo($trans_id, 'trans_net_amount');
        $trans_payment_type = $obj_trans->get1TransInfo($trans_id, 'trans_payment_type');
        $trans_result_refnum = $obj_trans->get1TransInfo($trans_id, 'trans_result_refnum');
        $trans_result_auth_code = $obj_trans->get1TransInfo($trans_id, 'trans_result_auth_code');
        $transInfo['trans_result_auth_code'] = $trans_result_auth_code;
        $transInfo['trans_net_amount'] = $amount;
        $transInfo['property_id'] = $property_id;
        $transInfo['trans_payment_type'] = $trans_payment_type;
        $transInfo['trans_result_refnum'] = $trans_result_refnum;
        $transInfo['trans_id'] = $trans_id;


        $cred = $obj_property->getCredentialtype_isrecurring($trans_payment_type, $property_id, 0);
        if (empty($cred->toArray())) {
            $cred = $obj_property->getCredentialtype_isrecurring($trans_payment_type, $property_id, 1);
        }


        if (empty($cred->toArray())) {
            return response()->json(array('errcode' => 264, 'responsetext' => $obj_msg->getMessageByKey('nocredential')));
        }

        //return response()->json(array('errcode'=>264,'responsetext'=>$obj_msg->getMessageByKey('norefund')));
        $credential = $cred[0];
//        dd($credential,$transInfo);
//        $credential->gateway = 'prismpay';
        $obj_paymentProcessor = new \App\CustomClass\PaymentProcessor();
        $result = $obj_paymentProcessor->void($transInfo, $credential);
        if ($result['response'] == 1) { //Success
            $obj_trans->VoidTransaction($trans_id);
        }
        $convFee_transaction = $obj_trans->GetConvFee($trans_id);
        if (!empty($convFee_transaction)) {
            $emptyConvFee = array('gateway' => $credential['gateway'], 'isFee' => 1, 'payment_method' => $credential['payment_method']);
            $result1 = $obj_paymentProcessor->void($convFee_transaction, $emptyConvFee);
            if ($result1['response'] == 1) { //Success
                $obj_trans->VoidTransaction($convFee_transaction['trans_id']);
            }
        }


        return response()->json($result);
    }

    function autopayments($token, Request $request, $data = '') {

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $autopayments_obj = new Autopayments();
        $autopayments = $autopayments_obj->getTransactionsByFilter($level, $idlevel, 1, 'onetime', $filterdata);
        $advFilter = $autopayments_obj->getAdvancedFilters($level,$idlevel);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);

        $filter = \DataFilter::source($autopayments);

        if ($level != 'M') {
            $filter->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text');
        }
        $filter->add('account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), 'text');
        $filter->add('web_users.first_name', 'First Name', 'text');
        $filter->add('web_users.last_name', 'Last Name', 'text');
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('id', 'txnID')->style('display:none');
        if ($level == 'B' || $level == 'A') {
            $grid->add('partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts), true);
        }
        if ($level != 'M' && $level != 'G') {
            $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts), true);
        }
        if ($level != 'M') {
            $grid->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), true);
        }
        $grid->add('trans_next_post_date', 'Next Date', true)->cell(function ($value) {
            $value = strtotime($value);
            return date("M d, Y", $value);
        });
        $grid->add('trans_numleft', 'Rem.', true);
        $grid->add('account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), true);

        $grid->add('name', 'Name', true)->cell(
                function ($value) {
            if (strlen($value) > 15) {
                return '<a href="#" data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 15) . '....</a>';
            } else {
                return $value;
            }
        }
        );
        $grid->add('trans_payment_type', 'Method', true)->cell(function ($value) {
            switch ($value) {
                case 'cc':
                    return 'Credit Card';
                    break;
                case 'ec':
                    return 'eCheck';
                    break;
                default :
                    return $value;
                    break;
            }
        });
        $grid->add('trans_recurring_net_amount', 'Amount', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_recurring_convenience_fee', 'Fee', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('net_charge', 'Total', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('dynamic', 'Dynamic', true)->cell(
                function($value) {
            if ($value == 1)
                return 'Yes';
            else
                return 'No';
        }
        );
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(function ($row) use ($token) {
            $id = $row->cell('id')->value;
            $row->cell('id')->style("display:none;");
            $cancelLink = '<li><a onClick="cancel_autopayment(' . $id . ')">Cancel</a></li>';
            // $editlLink = '<li><a href="#modal-autodetails-form-' . $id . '" data-toggle="modal">Edit</a></li>';
            $editlLink = '<li><a href=" ' . route('editautopayment', ['token' => $token, 'id' => $id]) . '">Edit</a></li>';
            $detailslLink = '<li><a href="#modal-autodetails-' . $id . '" data-toggle="modal">Details</a></li>';
            $row->cell('actionvalue')->value = '<div class="dropdown pull-right"><button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span> <span class="caret white-font-color" ></span></button>
                <ul class="dropdown-menu">' . $cancelLink . $editlLink . $detailslLink . '</ul></div>';
            echo \App\Helpers\Reports::AutopaymentDetails($id);
            //echo \App\Helpers\Reports::AutopaymentEditForm($id, $token);
        });

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('reports.autopayments.autopayments', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'advFilter' => $advFilter,
            'advFilterRoute' => route('autopayreport', ['token' => $token]),
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function editautopayment($token, $id) {

        $autopayment = new Autopayments();
        $details = $autopayment->getDetails($id);


        $count_dynamic_auto = $autopayment->getDynamicByWebUser($details->trans_web_user_id);
        $obj_property = new Properties();
        $last = $details->trans_last_post_date;
        $date = explode('-',$last);
        $month = '';
        $year = $date[0];
        switch ($date[1]){
            case '01':
                $month = 'January';
                break;
            case '02':
                $month = 'February';
                break;
            case '03':
                $month = 'March';
                break;
            case '04':
                $month = 'April';
                break;
            case '05':
                $month = 'May';
                break;
            case '06':
                $month = 'June';
                break;
            case '07':
                $month = 'July';
                break;
            case '08':
                $month = 'August';
                break;
            case '09':
                $month = 'September';
                break;
            case '10':
                $month = 'October';
                break;
            case '11':
                $month = 'November';
                break;
            case '12':
                $month = 'December';
                break;
        }
        $yearnow = date('Y');
        if($year - $yearnow > 5){$last_day_selected = 'Until Canceled';}
        $last_day_selected = $month . ', ' . $year;
        $details['enddate'] = $obj_property->get5yearInAdvance();
        return view('reports.autopayments.recurringtransactionedit', array('details' => $details, 'token' => $token, 'count_dynamic_auto' => $count_dynamic_auto, 'last_day_selected' => $last_day_selected));
    }

    function completeautopayments($token, Request $request, $data = '') {

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $autopayments_obj = new Autopayments();
        $autopayments = $autopayments_obj->getCompleteTransactionsByFilter($level, $idlevel, 3, $filterdata);
        $advFilter = $autopayments_obj->getAdvancedFilters($level,$idlevel);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $filter = \DataFilter::source($autopayments);

        if ($level != 'M') {
            $filter->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text');
        }
        $filter->add('account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), 'text');
        $filter->add('web_users.first_name', 'First Name', 'text');
        $filter->add('web_users.last_name', 'Last Name', 'text');
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('id', 'txnID')->style('display:none');
        if ($level == 'B' || $level == 'A') {
            $grid->add('partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts), true);
        }
        if ($level != 'M' && $level != 'G') {
            $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts), true);
        }
        if ($level != 'M') {
            $grid->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), true);
        }
        $grid->add('trans_next_post_date', 'Next Date', true)->cell(function ($value) {
            $value = strtotime($value);
            return date("M d, Y", $value);
        });
        $grid->add('trans_numleft', 'Rem.', true);
        $grid->add('account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), true);

        $grid->add('name', 'Name', true)->cell(
                function ($value) {
            if (strlen($value) > 15) {
                return '<a href="#" data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 15) . '....</a>';
            } else {
                return $value;
            }
        }
        );
        $grid->add('trans_payment_type', 'Method', true)->cell(function ($value) {

            switch ($value) {
                case 'cc':
                    return 'Credit Card';
                    break;
                case 'ec':
                    return 'eCheck';
                    break;
                default :
                    return $value;
                    break;
            }
        });
        $grid->add('trans_recurring_net_amount', 'Amount', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_recurring_convenience_fee', 'Fee', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('net_charge', 'Total', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('dynamic', 'Dynamic', true)->cell(
                function($value) {
            if ($value == 1)
                return 'Yes';
            else
                return 'No';
        }
        );
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(function ($row) use ($token) {
            $id = $row->cell('id')->value;
            $row->cell('id')->style("display:none;");
            // $editlLink = '<li><a href="#modal-autodetails-form-' . $id . '" data-toggle="modal">Edit</a></li>';
            $editlLink = '<li><a href=" ' . route('editautopayment', ['token' => $token, 'id' => $id]) . '">Edit</a></li>';
            $detailslLink = '<li><a href="#modal-autodetails-' . $id . '" data-toggle="modal">Details</a></li>';
            $restarTomorrowlLink = '<li><a onclick="restartTomorrow(' . $id . ')" data-toggle="modal">Restart Tomorrow</a></li>';
            $restarMonthlLink = '<li><a onclick="restartNextMonth(' . $id . ')" data-toggle="modal">Restart on the next Month</a></li>';
            $row->cell('actionvalue')->value = '<div class="dropdown pull-right"><button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span> <span class="caret white-font-color" ></span></button>
                <ul class="dropdown-menu">' . $editlLink . $detailslLink . $restarTomorrowlLink . $restarMonthlLink . '</ul></div>';
            echo \App\Helpers\Reports::AutopaymentDetails($id);
            // echo \App\Helpers\Reports::AutopaymentEditForm($id, $token);
        });

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('reports.autopayments.completeautopayment', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'advFilter' => $advFilter,
            'advFilterRoute' => route('completeautopayreport', ['token' => $token]),
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function cancleautopayments($token, Request $request, $data = '') {

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $autopayments_obj = new Autopayments();
        $autopayments = $autopayments_obj->getCancleTransactionsByFilter($level, $idlevel, 4, $filterdata);
        $advFilter = $autopayments_obj->getAdvancedFilters($level,$idlevel);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);

        $filter = \DataFilter::source($autopayments);

        if ($level != 'M') {
            $filter->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text');
        }
        $filter->add('account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), 'text');
        $filter->add('web_users.first_name', 'First Name', 'text');
        $filter->add('web_users.last_name', 'Last Name', 'text');
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('id', 'txnID')->style('display:none');
        if ($level == 'B' || $level == 'A') {
            $grid->add('partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts), true);
        }
        if ($level != 'M' && $level != 'G') {
            $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts), true);
        }
        if ($level != 'M') {
            $grid->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), true);
        }
        $grid->add('trans_next_post_date', 'Next Date', true)->cell(function ($value) {
            $value = strtotime($value);
            return date("M d, Y", $value);
        });
        $grid->add('trans_numleft', 'Rem.', true);
        $grid->add('account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), true);

        $grid->add('name', 'Name', true)->cell(
                function ($value) {
            if (strlen($value) > 15) {
                return '<a href="#" data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 15) . '....</a>';
            } else {
                return $value;
            }
        }
        );
        $grid->add('trans_payment_type', 'Method', true)->cell(function ($value) {

            switch ($value) {
                case 'cc':
                    return 'Credit Card';
                    break;
                case 'ec':
                    return 'eCheck';
                    break;
                default :
                    return $value;
                    break;
            }
        });
        $grid->add('trans_recurring_net_amount', 'Amount', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_recurring_convenience_fee', 'Fee', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('net_charge', 'Total', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('dynamic', 'Dynamic', true)->cell(
                function($value) {
            if ($value == 1)
                return 'Yes';
            else
                return 'No';
        }
        );
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(function ($row) use ($token) {
            $id = $row->cell('id')->value;
            $row->cell('id')->style("display:none;");
            // $editlLink = '<li><a href="#modal-autodetails-form-' . $id . '" data-toggle="modal">Edit</a></li>';
            $editlLink = '<li><a href=" ' . route('editautopayment', ['token' => $token, 'id' => $id]) . '">Edit</a></li>';
            $detailslLink = '<li><a href="#modal-autodetails-' . $id . '" data-toggle="modal">Details</a></li>';
            $restarTomorrowlLink = '<li><a onclick="restartTomorrow(' . $id . ')" data-toggle="modal">Restart Tomorrow</a></li>';
            $restarMonthlLink = '<li><a onclick="restartNextMonth(' . $id . ')" data-toggle="modal">Restart on the next Month</a></li>';
            $row->cell('actionvalue')->value = '<div class="dropdown pull-right"><button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span> <span class="caret white-font-color" ></span></button>
                <ul class="dropdown-menu">' . $editlLink . $detailslLink . $restarTomorrowlLink . $restarMonthlLink . '</ul></div>';
            echo \App\Helpers\Reports::AutopaymentDetails($id);
            //echo \App\Helpers\Reports::AutopaymentEditForm($id, $token);
        });

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('reports.autopayments.cancleautopayment', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'advFilter' => $advFilter,
            'advFilterRoute' => route('cancleautopayreport', ['token' => $token]),
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function cancelautopayment($token, $id) {
        $autopayments_obj = new Autopayments();
        $autopayments_obj->cancelAuto($id);
        $txd = $autopayments_obj->getDetails($id);
        $web_user_id = $txd->trans_web_user_id;
        \App\Providers\RevoPayAuditLogger::autopaymentDelete('admin', array("trans_id" => $id), 'M', $txd->property_id, \App\Model\WebUsers::getAuditData($web_user_id), Auth::user());
        return back()->with('success', 'Autopayment canceled');
    }

    function onetimeautopayments($token, Request $request, $data = '') {

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $autopayments_obj = new Autopayments();
        $autopayments = $autopayments_obj->getOneTimeTransactionsByFilter($level, $idlevel, 1, 'onetime', $filterdata);
        $advFilter = $autopayments_obj->getAdvancedFilters($level,$idlevel);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $filter = \DataFilter::source($autopayments);
        if ($level != 'M') {
            $filter->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text');
        }
        $filter->add('account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), 'text');
        $filter->add('web_users.first_name', 'First Name', 'text');
        $filter->add('web_users.last_name', 'Last Name', 'text');
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('id', 'txnID')->style('display:none');
        if ($level == 'B' || $level == 'A') {
            $grid->add('partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts), true);
        }
        if ($level != 'M' && $level != 'G') {
            $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts), true);
        }
        if ($level != 'M') {
            $grid->add('name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), true);
        }
        $grid->add('trans_next_post_date', 'Next Date', true)->cell(function ($value) {
            $value = strtotime($value);
            return date("M d, Y", $value);
        });

        $grid->add('account_number', $obj_layout->extractLayoutValue('label_acc_number',$layouts), true);

        $grid->add('name', 'Name', true)->cell(
                function ($value) {
            if (strlen($value) > 15) {
                return '<a href="#" data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 15) . '....</a>';
            } else {
                return $value;
            }
        }
        );
        $grid->add('trans_payment_type', 'Method', true)->cell(function ($value) {

            switch ($value) {
                case 'cc':
                    return 'Credit Card';
                    break;
                case 'ec':
                    return 'eCheck';
                    break;
                default :
                    return $value;
                    break;
            }
        });
        $grid->add('trans_recurring_net_amount', 'Amount', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_recurring_convenience_fee', 'Fee', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('net_charge', 'Total', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        ;
        $grid->row(function ($row) use ($token) {
            $id = $row->cell('id')->value;
            $row->cell('id')->style("display:none;");
            $cancelLink = '<li><a onclick="cancelauto(' . $id . ')" >Cancel</a></li>';
            // $editlLink = '<li><a href="#modal-autodetails-form-' . $id . '" data-toggle="modal">Edit</a></li>';
            $editlLink = '<li><a href=" ' . route('editautopayment', ['token' => $token, 'id' => $id]) . '">Edit</a></li>';
            $detailslLink = '<li><a href="#modal-autodetails-' . $id . '" data-toggle="modal">Details</a></li>';
            $row->cell('actionvalue')->value = '<div class="dropdown pull-right"><button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span> <span class="caret white-font-color" ></span></button>
                <ul class="dropdown-menu">' . $cancelLink . $editlLink . $detailslLink . '</ul></div>';
            echo \App\Helpers\Reports::AutopaymentDetails($id);
            //echo \App\Helpers\Reports::AutopaymentEditForm($id, $token);
        });


        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('reports.autopayments.onetimeautopayment', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'advFilter' => $advFilter,
            'advFilterRoute' => route('onetimeautopayreport', ['token' => $token]),
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    public function saveautopaymentdetails($token, $recurr_id, Request $request) {
        $atoken = decrypt($token);
        $validator = $request->validate([
            'trans_next_post_date' => 'required',
            'trans_recurring_net_amount' => 'required|numeric',
            'frequency' => 'required',
        ]);
        $autopayments_obj = new Autopayments();
        $txd = $autopayments_obj->getDetails($recurr_id);
        $web_user_id = $txd->trans_web_user_id;
        //var_dump($request->input('dynamic_trans'));die;
        if ($request->input('dynamic_trans') == 1) {
            $active_dynamic = DB::table('accounting_recurring_transactions')->where('trans_web_user_id', '=', $web_user_id)->where('dynamic', '=', 1)->where('trans_id', '!=', $recurr_id)->count();
            if ($active_dynamic >= 1) {
                return back()->with('error', 'Only one DRP is allowed per Payor. Please modify and try again');
            }
        } else {
            $objCustomize = new \App\Model\Customize();
            $maxrecurring = $objCustomize->getSettingByKey($atoken['level'], $atoken['level_id'], 'MAXRECURRINGPAYMENTPERUSER');
            $active_dynamic = DB::table('accounting_recurring_transactions')->where('trans_web_user_id', '=', $web_user_id)->where('dynamic', '=', 0)->where('trans_id', '!=', $recurr_id)->count();
            if($maxrecurring != "") {
                if ($active_dynamic >= $maxrecurring) {
                    return back()->with('error', 'You have reached the limit for allowed scheduled payments. Please modify and try again');
                }
            }
        }


        $autopayments_obj->saveautopaymentdetails($request, $recurr_id);

        \App\Providers\RevoPayAuditLogger::autopaymentUpdate('admin', array('trans_id' => $recurr_id, 'operation' => 'Autopayment Updated', 'data' => $request->all()), 'M', $txd->property_id, \App\Model\WebUsers::getAuditData($web_user_id), Auth::user());
        return redirect()->route('autopayreport',['token'=>$token])->with('success', 'Autopayment Details Updated');
    }

    public function saveautopaymentStarttomorrow($token, $recurr_id, Request $request) {
        $autopayments_obj = new Autopayments();
        $txd = $autopayments_obj->getDetails($recurr_id);
        $web_user_id = $txd->trans_web_user_id;
        $user_obj = new WebUsers();
        $status_web = $user_obj->get1UserInfo($web_user_id, 'web_status');
        if ($status_web > 1000) {
            return Redirect::back()->with('error', 'You can not restar an inactive user');
        } else {
            $autopayments_obj->savestartomorrowcanceled($request, $recurr_id);
        }
        \App\Providers\RevoPayAuditLogger::autopaymentUpdate('admin', array('trans_id' => $recurr_id, 'operation' => 'start tomorrow'), 'M', $txd->property_id, \App\Model\WebUsers::getAuditData($web_user_id), Auth::user());
        return back()->with('success', 'Autopayment Restarted');
    }

    public function saveautopaymentStartnextmonth($token, $recurr_id, Request $request) {
        $autopayments_obj = new Autopayments();
        $txd = $autopayments_obj->getDetails($recurr_id);
        $web_user_id = $txd->trans_web_user_id;
        $user_obj = new WebUsers();
        $status_web = $user_obj->get1UserInfo($web_user_id, 'web_status');
        if ($status_web > 1000) {
            return Redirect::back()->with('error', 'You can not restar an inactive user');
        } else {
            $autopayments_obj->savestartnextmonthcanceled($request, $recurr_id);
        }
        \App\Providers\RevoPayAuditLogger::autopaymentUpdate('admin', array('trans_id' => $recurr_id, 'operation' => 'start next month'), 'M', $txd->property_id, \App\Model\WebUsers::getAuditData($web_user_id), Auth::user());
        return back()->with('success', 'Autopayment Restarted');
    }

    function settlements($token, Request $request, $data = '') {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $settlement_obj = new Settlement();
        $settlements = $settlement_obj->getSettledTransactions($level, $idlevel, $filterdata);
        $advFilter = $settlement_obj->getAdvancedFilters($level,$idlevel);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);

        $filter = \DataFilter::source($settlements);

        $filter->add('batch', 'Batch ID', 'text');
        $filter->add('transaction_type', 'Method', 'select')->options(array(
            '' => 'Method',
            'Credit Card' => 'Credit Card',
            'eCheck' => 'eCheck',
        ));
        if ($level != 'M') {
            $filter->add('property_name', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text');
            $filter->add('property_id', 'PaypointID', 'text');
        }
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('id', 'id')->style('display:none');
        $grid->add('date_formatted', 'Date', true)->cell(function ($value) {
            $value = strtotime($value);
            return date("M d, Y", $value);
        });
        $grid->add('batch', 'Batch ID', true);
        $grid->add('debit', 'Debits', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('credit', 'Credits', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('total', 'Total', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('transaction_type', 'Type', true);
        if ($level != 'M' && $level != 'G') {
            $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts), true);
        }
        if ($level != 'M') {
            $grid->add('property_name', $obj_layout->extractLayoutValue('label_merchant',$layouts));
        }
        $grid->add('action', 'Action')->style("text-align:right;");

        $grid->row(
                function ($row) use ($token) {
            $url = route('settlementsbatch', ['token' => $token, 'batch' => $row->data->batch]);
            $row->cell('action')->value = '<a href="' . $url . '" class="btn btn-default btn-xs">Details</a>';
            $row->cell('action')->style("text-align:right;");
            $row->cell('id')->style('display:none');
        }
        );

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('reports.settlements.settlements', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'advFilter' => $advFilter,
            'advFilterRoute' => route('settlements', ['token' => $token]),
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function settlementsBatch($token, Request $request, $batch = null) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level == 'B') {
            return redirect(route('accessdenied'));
        }
        if (empty($batch)) {
            return redirect(route('settlements', ['token' => $token]));
        }
        if ($level == 'M') {

            $obj_customfield = new CustomField();
            $field = $obj_customfield->getTransactionField($idlevel);
        }
        $transaction_obj = new Transactions();
        $settlement_obj = new Settlement();
        $settlements = $settlement_obj->getSettledTransactionsBatch($level, $idlevel, $batch);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $filter = \DataFilter::source($settlements);
        $filter->add('customer_name', $obj_layout->extractLayoutValue('label_user',$layouts), 'text');
        $filter->add('customer_id', $obj_layout->extractLayoutValue('label_acc_number',$layouts), 'text');
        $filter->add('trans_id', 'Transaction ID', 'text');
        $filter->add('transaction_type', 'Method', 'select')->options(array(
            '' => 'Type',
            'Credit Card' => 'Credit Card',
            'eCheck' => 'eCheck',
        ));

        $filter->submit('Search');
        $filter->reset('Reset');
        $filter->build();
        $grid = \DataGrid::source($filter);
        $grid->add('batch', 'Batch ID');
        $grid->add('date_formatted', 'Date', true);
        $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts));
        $grid->add('property_name', $obj_layout->extractLayoutValue('label_merchant',$layouts));
        $grid->add('customer_id', $obj_layout->extractLayoutValue('label_acc_number',$layouts), true);
        $grid->add('customer_name', $obj_layout->extractLayoutValue('label_user',$layouts), true);
        $grid->add('trans_id', 'Transaction ID', true);
        $grid->add('transaction_type', 'Pay Type', true)->cell(function ($value) {
            if (($value == 'Credit Card')) {
                return '<img src="/img/credit-cards.png" alt="Visa" data-original-title="' . $value . '" title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif ($value == 'eCheck') {
                return '<img src="/img/echeck.png" alt="Checking" data-original-title="' . $value . '" title="" class="tooltip_hover" data-toggle="tooltip"  />';
            } elseif (isset($valueArray[0]) && ($valueArray[0] == 'MasterCard')) {
                return $value;
            }
        })->attributes(array("class" => "trans-column"))->style("text-align:center;width:10%");
        if ($level == 'M') {
            if (!empty($field)) {
                foreach ($field as $customfieldname) {
                    $grid->add($customfieldname->field_description, $customfieldname->field_description);
                }
            }
        }
        $grid->add('credit', 'Credit', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('debit', 'Debit', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('total', 'Total', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_recurring', 'Trans type', true);
        $grid->row(function ($row) use ($transaction_obj, $level, $idlevel) {
            $id = $row->cell('trans_id')->value;
            $row->cell('trans_recurring');
            $row->cell('transaction_type')->style("text-align:center");
            if ($level == 'M') {
                $custom = $transaction_obj->getTransactionsCustomField($id, $idlevel);

                for ($i = 0; $i < count($custom); $i++) {
                    $row->cell($custom[$i]->field_description)->value = $custom[$i]->field_value;
                }
            }
        });

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('reports.settlements.details', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function outbounds($token, Request $request, $data = '') {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $outbound_obj = new Outboundpayments();
        $outbounds = $outbound_obj->getTransactionsByFilter($level, [$idlevel], $filterdata);
        $advFilter = $outbound_obj->getAdvancedFilters($level,$idlevel);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $filter = \DataFilter::source($outbounds);

        $filter->add('properties.name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text');
        $filter->add('trans_unique_id', 'Trans ID', 'text');
        $filter->add('vendor.vname', 'Name', 'text');
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('trans_date', 'Date', true)->cell(function ($value) {
            $value = strtotime($value);
            return date("M d, Y", $value);
        });
        if ($level == 'B' || $level == 'A') {
            $grid->add('partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts), true);
        }
        if ($level != 'M' && $level != 'G') {
            $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts), true);
        }
        if ($level != 'M') {
            $grid->add('merchant', $obj_layout->extractLayoutValue('label_merchant',$layouts), true);
        }
        $grid->add('trans_id', 'Trans ID', true);
        $grid->add('description', 'Description', true);
        $grid->add('webname', 'Name', true);
        $grid->add('net_amount', 'Amount', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('net_fee', 'Fee', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('net_charge', 'Total', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });


        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('reports.outbounds', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'advFilter' => $advFilter,
            'advFilterRoute' => route('outbounds', ['token' => $token]),
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function emaf($token, Request $request, $data = '') {

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'A') {
            return redirect(route('accessdenied'));
        }
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $emaf_obj = new Emaf();
        $emaf = $emaf_obj->getTransactionsByFilter($level, $filterdata);

        $filter = \DataFilter::source($emaf);

        $filter->add('partner_title', 'Partner', 'text');
        $filter->add('name_clients', 'Merchant', 'text');
        $filter->add('mid', 'MID', 'text');
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('id', 'id')->style('display:none');
        $grid->add('partner_title', 'Partner', true);
        $grid->add('company_name', 'Group', true);
        $grid->add('name_clients', 'Merchant', true);
        $grid->add('fdate', 'Settlement Date', true)->cell(function ($value) {
            return $value;
        });
        $grid->add('txdate', 'Tx Date', true)->cell(function ($value) {
            return $value;
        });
        $grid->add('amount', 'Amount', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('cfee_amount', 'Fee', false)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('card_type', 'Card', true);
        $grid->add('inter_fee_amount', 'IFee', false)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('mid', 'MID', true);

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);

        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('reports.emaf', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function audit($token, Request $request, $data = '') {

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $audit_obj = new \App\Http\Models\Audit();
        $audit = $audit_obj->getByFilter($level, $idlevel, $filterdata);

        $filter = \DataFilter::source($audit);

        $filter->add('event', 'Event', 'text');
        $filter->add('name', 'Payor', 'text');
        $filter->add('modified_by_name', 'Modified By', 'text');
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('id', 'id')->style('display:none');
        $grid->add('level', 'level')->style('display:none');
        $grid->add('idlevel', 'idlevel')->style('display:none');
        if ($level != 'G' && $level != 'M') {
            $grid->add('partner_title', 'Partner', true);
            $grid->add('company_name', 'Group', true);
        }
        if ($level != 'M') {
            $grid->add('name_clients', 'Merchant', true);
        }
        $grid->add('timestamp', 'Date', true);
        $grid->add('type', 'Type', true);
        $grid->add('event', 'Event', true);
        $grid->add('name', 'Payor', false);
        $grid->add('modified_by_name', 'Modified By', false);
        $grid->row(function ($row) use ($level) {
            if ($level != 'M') {
                $rlevel = $row->cell('level')->value;
                $ilevel = $row->cell('idlevel')->value;
                if ($rlevel == 'P') {
                    $rs = \Illuminate\Support\Facades\DB::table('partners')->where('id', $ilevel)->select('partner_title')->first();
                    $row->cell('partner_title')->value = $rs->partner_title;
                } elseif ($rlevel == 'G') {
                    $rs = \Illuminate\Support\Facades\DB::table('companies')->where('id', $ilevel)->select('company_name', 'id_partners')->first();
                    $row->cell('company_name')->value = $rs->company_name;
                    $rs = \Illuminate\Support\Facades\DB::table('partners')->where('id', $rs->id_partners)->select('partner_title')->first();
                    $row->cell('partner_title')->value = $rs->partner_title;
                } elseif ($rlevel == 'M') {
                    $rs = \Illuminate\Support\Facades\DB::table('properties')->where('id', $ilevel)->select('name_clients', 'id_companies')->first();
                    $row->cell('name_clients')->value = $rs->name_clients;
                    $rs = \Illuminate\Support\Facades\DB::table('companies')->where('id', $rs->id_companies)->select('company_name', 'id_partners')->first();
                    $row->cell('company_name')->value = $rs->company_name;
                    $rs = \Illuminate\Support\Facades\DB::table('partners')->where('id', $rs->id_partners)->select('partner_title')->first();
                    $row->cell('partner_title')->value = $rs->partner_title;
                }
            }
            $row->cell('id')->style("display:none;");
            $row->cell('level')->style("display:none;");
            $row->cell('idlevel')->style("display:none;");
        });

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);

        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('reports.audit', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function autopaymentsAudit($token, Request $request, $data = '') {

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'A') {
            return redirect(route('accessdenied'));
        }
        $filterdata = null;
        if ($data != '') {
            $filterdata = json_decode(base64_decode($data), true);
        }
        $autopayments_obj = new \App\Http\Models\AutopaymentsAudit();
        $autopayments = $autopayments_obj->getTransactionsByFilter($level, $idlevel, $filterdata);
        //$advFilter = $autopayments_obj->getAdvancedFilters($level);

        $filter = \DataFilter::source($autopayments);

        if ($level != 'M') {
            $filter->add('name_clients', 'Merchant', 'text');
        }
        $filter->add('account_number', 'Account #', 'text');
        $filter->add('web_users.first_name', 'First Name', 'text');
        $filter->add('web_users.last_name', 'Last Name', 'text');
        $filter->submit('Search');
        $filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('audit_timestamp', 'Date', true);
        $grid->add('audit_action', 'Action', false);
        $grid->add('id', 'txnID');
        $grid->add('company_name', 'Group', true);
        $grid->add('name_clients', 'Merchant', true);
        $grid->add('trans_next_post_date', 'Next Date', true)->cell(function ($value) {
            $value = strtotime($value);
            return date("M d, Y", $value);
        });
        $grid->add('trans_schedule', 'Freq', true);
        $grid->add('account_number', 'Account #', true);

        $grid->add('name', 'Name', true)->cell(
                function ($value) {
            if (strlen($value) > 15) {
                return '<a href="#" data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 15) . '....</a>';
            } else {
                return $value;
            }
        }
        );
        $grid->add('trans_payment_type', 'Method', true)->cell(function ($value) {

            switch ($value) {
                case 'cc':
                    return 'Credit Card';
                    break;
                case 'ec':
                    return 'eCheck';
                    break;
                default :
                    return $value;
                    break;
            }
        });
        $grid->add('trans_recurring_net_amount', 'Amount', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_recurring_convenience_fee', 'Fee', true)->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('dynamic', 'Dynamic');
        $grid->add('tag', 'Tag', false);

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);


        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('audit_timestamp', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('reports.autopayments.audit', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            //'advFilter'=>$advFilter,
            //'advFilterRoute'=>route('autopayreport',['token'=>$token]),
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    public function showSendReceiptPopUp($token, $trans_id) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];

        if ($idlevel <= 0 && $idlevel != -954581 && $atoken['level'] != 'A') {
            return response()->json(array('errcode' => 261, 'msg' => 'Invalid Request'));
        }
        if ($trans_id <= 0) {
            return response()->json(array('errcode' => 264, 'msg' => 'Invalid Request'));
        }
        $data = [
            'trans_id' => $trans_id,
            'uxtoken' => $token
        ];
        return view('reports.sendReceipt', $data);
    }

    public function sendreceipt(Request $request, $token, $trans_id) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $email = $request->email;
        if (empty($email)) {
            $result = \Illuminate\Support\Facades\DB::table('web_users')
                    ->join('accounting_transactions', 'trans_web_user_id', '=', 'web_user_id')
                    ->where('accounting_transactions.trans_id', $trans_id)
                    ->select('trans_web_user_id', 'accounting_transactions.property_id', 'web_users.email_address')
                    ->first();

            if (!empty($result) && !empty($result->email_address)) {
                $email = $result->email_address;
            }
        }

        if (empty($email)) {
            return Redirect::back()->with('error', 'Recipient not found.');
        } else {
            $property = \Illuminate\Support\Facades\DB::table('properties')
                    ->join('accounting_transactions', 'accounting_transactions.property_id', '=', 'properties.id')
                    ->where('accounting_transactions.trans_id', $trans_id)
                    ->select('properties.accounting_email_address_clients', 'properties.id', 'properties.subdomain_clients', 'properties.id_partners')
                    ->first();

            if (!empty($property->accounting_email_address_clients)) {
                $accd = explode(";", $property->accounting_email_address_clients);
                $accountingEmail = $accd[0];
            } else {
                $accountingEmail = 'info@revopayments.com';
            }

            $objCustomize = new \App\Model\Customize();
            $dnr = $objCustomize->getSettingByKey('M', $property->id, 'donotreplyemail');

            if (!empty($dnr) && $dnr == 1) {
                $accountingEmail = 'do_not_reply@revopayments.com';
            }
            if (strpos($accountingEmail, 'yahoo') > 0) {
                $accountingEmail = 'info@revopayments.com';
            }
            if (strpos($accountingEmail, 'aol.com') > 0) {
                $accountingEmail = 'info@revopayments.com';
            }

            $text = $this->getReceipt($trans_id);

            if (!empty($text)) {
                $html = str_replace('|', '', $text);
                // Send the email
                Mail::send([], [], function($message) use ($html, $trans_id, $accountingEmail, $email) {
                    $message->from($accountingEmail)
                            ->to($email)
                            ->subject('Payment Receipt Id ' . $trans_id . '(Copy)')
                            ->setBody($html, 'text/html');
                });
            } else {
                $transaction = \Illuminate\Support\Facades\DB::table('accounting_transactions')->where('trans_id', $trans_id)->first();
                $userInfo = \Illuminate\Support\Facades\DB::table('web_users')->where('web_user_id', $transaction->trans_web_user_id)->first();

                $errorMsg = $transaction->trans_result_error_desc;
                $msg = "";
                $msg = $objCustomize->getSettingByKey('M', $property->id, 'SUCCESSFULEMAIL');

                $subject = 'Payment Receipt Id ' . $trans_id . ' (Copy)';
                $propertyObj = new Properties();
                $orgUrl = $propertyObj->get1PropertyInfo($property->id, 'url_clients');
                $orgName = $propertyObj->get1PropertyInfo($property->id, 'name_clients');

                $merchantIds = $propertyObj->getPropertyInfo($property->id);
                $logoUrl = public_path() . $propertyObj->getPropertyLogo($merchantIds['logo'], $merchantIds['id_companies'], $merchantIds['id_partners']);
                $disclaimer = $objCustomize->getSettingByKey('M', $property->id, 'SETTLMENT_DISCLAIMER');

                $subdomain = $property->subdomain_clients;
                $objPartner = new Partners();
                $partner = $objPartner->getDomain($property->id_partners);

                $clickRoute = env('PAYOR_PORTAL_URL') . '/' . $partner . '/properties/' . $subdomain . '/login';

                if (empty($msg)) {
                    $msg = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                                    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
                                    <head>
                                    <style> td {font-family: arial,helvetica,sans-serif; font-size: 10pt; color: #000;} </style>
                                    </head>
                                    <body>
                                        <table border="0" cellpadding="1" cellspacing="2" width="90%">
                                            <tr>
                                                    <td><img src="\" . $logoUrl . "\" alt="Revo Payments" title="Revo Payments"/></td>
                                                    <td><h3>Thank you for using Revo Payments, your online Payment Provider.</h3></td>
                                            </tr>
                                            <tr><td colspan="2"><br />For customer service please <a href="' . $orgUrl . '/newhelp.php">contact us</a><br /></td></tr>
                                            <tr><td bgcolor="#C4C7D4" colspan="2"><b>Transaction Result</b></td></tr>
                                            <tr><td><b>Date:</b></td><td>' . $transaction->trans_last_post_date . '</td></tr>
                                            <tr><td><b>Reference #:</b></td><td>' . $transaction->trans_result_refnum . '</td></tr>
                                            <tr><td><b>Authorization:</b></td><td>' . $transaction->trans_result_auth_code . '</td></tr>
                                            <tr><td bgcolor="#C4C7D4" colspan="2"><b>Transaction Details</b></td></tr>
                                            <tr><td><b>Paying in:</b></td><td>' . $orgName . '</td></tr>
                                            <tr><td><b>Type:</b></td><td>Sale</td></tr>
                                            <tr><td><b>Source:</b></td><td>WEB</td></tr>
                                            <tr><td><b>Account #:</b></td><td>' . $userInfo->account_number . "/" . $userInfo->first_name . " " . $userInfo->last_name . "/" . $userInfo->username . '</td></tr>
                                            <tr><td><b>Net Payment:</b></td><td>' . number_format($transaction->trans_net_amount, 2, ".", ",") . '</td></tr>
                                            <tr><td><b>Convenience Fee:</b></td><td>' . number_format($transaction->trans_convenience_fee, 2, ".", ",") . '</td></tr>
                                            <tr><td><b>Total Payment Amount:</b></td><td>' . number_format($transaction->trans_total_amount, 2, ".", ",") . '</td></tr>
                                            <tr><td valign="top"><b>Payment Details:</b></td><td><pre>' . str_replace('$', '&#36;', $transaction->trans_descr) . '</pre></td></tr>
                                            <tr><td><b>Card Holder:</b></td><td>' . $userInfo->first_name . ' ' . $userInfo->last_name . '</td></tr>
                                            <tr><td><b>Card Number:</b></td><td>' . $transaction->trans_card_type . '</td></tr>
                                            <tr><td><b>Payment Type:</b></td><td>' . $transaction->trans_payment_type . '</td></tr>
                                            <tr><td bgcolor="#C4C7D4" colspan="2"><b>Billing Information</td></tr>
                                            <tr><td><b>Customer ID:</b></td><td>' . $userInfo->account_number . "/" . $userInfo->first_name . ' ' . $userInfo->last_name . "/" . $userInfo->username . '</td></tr>
                                            <tr><td><b>First Name:</b></td><td>' . $userInfo->first_name . '</td></tr>
                                            <tr><td><b>Last Name:</b></td><td>' . $userInfo->last_name . '</td></tr>
                                            <tr><td><b>Street:</b></td><td>' . $userInfo->address . '</td></tr>
                                            <tr><td><b>Street2:</b></td><td>n/a</td></tr>
                                            <tr><td><b>City:</b></td><td>' . $userInfo->city . '</td></tr>
                                            <tr><td><b>State:</b></td><td>' . $userInfo->state . '</td></tr>
                                            <tr><td><b>Zip:</b></td><td>' . $userInfo->zip . '</td></tr>
                                            <tr><td><b>Country:</b></td><td>USA</td></tr>
                                            <tr><td><b>Phone:</b></td><td>' . $userInfo->phone_number . '</td></tr>
                                            <tr><td><b>Email:</b></td><td>' . $userInfo->email_address . '</td></tr>
                                            <tr><td colspan="2">' . $disclaimer . '</td></tr>
                                            <tr><td colspan="2"><p style="color: #666666; font-size: 12px"> Please do not reply to this email message, as this email was sent from a notification-only address.</p></td></tr>
                                        </table>
                                    </body>
                                    </html>';
                } else {

                    $companyId = $propertyObj->get1PropertyInfo($property->id, 'id_companies');
                    $companyObj = new \App\Model\Companies();
                    $companyName = $companyObj->get1CompanyInfo($companyId, 'company_name');
                    $description = "<pre>" . str_replace('$', '&#36;', $transaction->trans_descr) . "</pre>";
                    $replacedata = array("LOGINLINK" => "<a href=\"" . $clickRoute . "\">" . $orgName . "</a>", "TICKETLINK" => "<a href=\"" . $orgUrl . "/newhelp.php\">contact us</a>", "DESCRIPTION" => $description, "LOGO" => '<img src="' . $logoUrl . '">', "DISCLAIMER" => $disclaimer, "COMPANYNAME" => $companyName, "COMPANYID" => $property->id, "DBA_NAME" => $orgName, "FIRSTNAME" => $userInfo->first_name, "LASTNAME" => $userInfo->last_name, "ACCOUNTNUMBER" => $userInfo->account_number, "ACCOUNT_NUMBER" => $userInfo->account_number, "NETAMOUNT" => number_format($transaction->trans_net_amount, 2, ".", ","), "TRANS_DATE" => $transaction->trans_last_post_date, "PAYMENT_INFO" => $transaction->trans_card_type, "AUTHNUM" => $transaction->trans_result_auth_code, "ERRORMSG" => $errorMsg, "new_trans_id" => $trans_id, "REFNUM" => $trans_id, "SOURCE" => $transaction->source);
                    foreach ($replacedata as $key => $value) {
                        $msg = preg_replace('/\[:' . $key . ':\]/', $value, $msg);
                    }
                }

                $html = str_replace('|', '', $msg);
                // Send the email
                Mail::send([], [], function($message) use ($html, $trans_id, $accountingEmail, $email) {
                    $message->from($accountingEmail)
                            ->to($email)
                            ->subject('Payment Receipt Id ' . $trans_id . '(Copy)')
                            ->setBody($html, 'text/html');
                });

                \Illuminate\Support\Facades\DB::table('log_payment_receipt')->insert([
                    'id_property' => $property->id,
                    'id_webuser' => $userInfo->web_user_id,
                    'trans_id' => $trans_id,
                    'receipt_content' => $html,
                    'from_email' => $accountingEmail,
                    'to_email' => $email
                ]);
            }

            return back()->with('success', 'Receipt sent');
        }
    }

    /**
     * Gets the receipt if exits
     * @param int $trans_id
     * @return string
     */
    function getReceipt($trans_id) {
        $receipt = \Illuminate\Support\Facades\DB::table('log_payment_receipt')
                ->where('trans_id', $trans_id)
                ->select('receipt_content')
                ->first();

        if (!empty($receipt) && !empty($receipt->receipt_content)) {
            return $receipt->receipt_content;
        }

        return '';
    }

}
