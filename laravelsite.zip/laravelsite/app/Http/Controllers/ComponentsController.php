<?php

namespace App\Http\Controllers;

use App\Http\Models\Admins;
use Illuminate\Support\Facades\Auth;

class ComponentsController extends Controller
{

    static function payIconImage($name, $callController = 0)
    {
        $payment_icon = array(
            'v' => 'visa',
            'm' => 'mastercard',
            'c' => 'checking',
            's' => 'saving',
            'a'=> 'amex',
            'd'=> 'discover',
        );


        if(isset($name[0])) {
            if (isset($payment_icon[strtolower($name[0])])) {
                if ($callController == 1) {
                    return '<img width="28px" height="28px" src="' . asset('img/' . $payment_icon[strtolower($name[0])] . '.svg') . '">';
                } else {
                    echo '<img width="40px" height="28px" src="' . asset('img/' . $payment_icon[strtolower($name[0])] . '.svg') . '">';
                }
            } else {
                if ($callController == 1) {
                    return '<img width="28px" height="28" src="' . asset('img/money.svg') . '">';
                } else {
                    echo '<img width="40px" height="28px" src="' . asset('img/money.svg') . '">';
                }
            }
        }
    }

    static function getUserData($token)
    {
        $array = json_decode(decrypt($token), 1);
        $admin = new Admins();
        $array['adminName'] = $admin->getAdminName(Auth::id());
        return $array;
    }
}
