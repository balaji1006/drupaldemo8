<?php

namespace App\Http\Controllers;

use App\Http\Models\Admins;
use App\Http\Models\Autopayments;
use App\Http\Models\Payors;
use App\Http\Models\Settlement;
use App\Http\Models\Transactions;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class BasicController extends Controller
{
    function __construct()
    {
        $this->middleware('auth', ['except' => ['accessDenied']]);
        $this->middleware('permission', ['except' => ['selectpgm','accessDenied']]);
    }

    function selectPGM()
    {

        $admin = new Admins();
        $roles = $admin->getRoles(Auth::id());
        return view('basic.pgmSelect', array('selection'=>$roles));
    }

    function postSelectPGM(Request $request)
    {
        if ($request->get('account')) {
            $token_array = json_decode($request->get('account'), 1);
            $token_array['key']=config('app.key');
            $token_array['time']=time();
            $token_array['name']=$token_array['name'];

            return redirect(route('dashboard', array('token'=>encrypt(json_encode($token_array)))));
        } else {
            return redirect(route('accessDenied'));
        }
    }

    function dashboard($token = null, Request $request)
    {

        if ($token) {
            $level = $request->get('level');
            $idlevel = $request->get('idlevel');
            $transaction = new Transactions();
            $settlement = new Settlement();
            $payors = new Payors();
            $autop = new Autopayments();
            $data = $transaction->getSummaryByPeriod($level, $idlevel, 'months', 12);
            $data['settlement'] = $settlement->getSettlementToday($level, $idlevel);
            $data['payors'] = $payors->getAdoptionRate($level, $idlevel);
            $data['autopayments'] = $autop->getActive($level, $idlevel);
            $data['recent_payments'] = $transaction->getRecentActivity($level, $idlevel);
            $data['recent_activity'] = $transaction->getActivityPeriod($level, $idlevel, strtotime('-12 months'), strtotime('now'));
            return view('basic.dashboard', $data);
        } else {
            return redirect(route('selectpgm'));
        }
    }

    function accessDenied()
    {

        return view('basic.error', array(
            'icon_error' => 'pe-7s-lock',
            'number_error'=>'401',
            'title_error'=>'Access denied',
            'description_error'=>'Sorry, you don\'t have permissions to access to this page.<br/> Please contact with your Administrator',
        ));
    }
}
