<?php

namespace App\Http\Controllers;

use App\Models\Companies;
use App\Model\Partners;
use App\Models;
use App\Model;
use Illuminate\Http\Request;
use App\Model\WebUsers;
use App\Model\Transations;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Validator;
use Maatwebsite\Excel\Facades\Excel;
use App\User;
use Crypt;
use Illuminate\Support\Facades\Session;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Auth;

class ManageUserController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    private $validWebUserImportExtensions = array('csv', 'tsv');
    private $validMIMEType = array();
    private $import_file_upload_directory = '';
    private $fields_to_skip = array('entered', 'last_updated', 'last_updated_by', 'paago_id', 'nacha_company_info', 'misc', 'lang', 'data', 'photo', 'remember_token', 'topsdata', 'password');
    private $fields_to_not_to_import = array('entered', 'last_updated', 'paago_id', 'nacha_company_info', 'misc', 'lang', 'data', 'photo', 'remember_token', 'topsdata');

    public function userlist($token, Request $request) {
        //        list($data) = explode('|', Crypt::decrypt($token));
        //        $array_token = json_decode($data, 1);
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        //        $idadmin = $array_token['iduser'];
        //        $token = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));

        $webusers = new WebUsers();
        $obj_customize = new \App\Model\Customize();
        $filter = \DataFilter::source($webusers->getWebUserList($idlevel, $level));
        $showcn = false;
        $layoutid = 1;
        $acctext = 'Account Number';
        if ($level == 'P') {
            $dp = explode(':', $idlevel);
            foreach ($dp as $ddp) {
                $idgroup = $obj_customize->getPartnersGroup($ddp);
                if (!empty($idgroup)) {
                    $df = $obj_customize->getSettingsValue($idgroup, 'SHOWCOMPANYNAME');
                    $acctext = $obj_customize->getSettingsValue($idgroup, 'PAYMENT_NUMBER_REG_NUMBER');
                    if ($df == 1) {
                        $showcn = true;
                    }
                }
            }
            $idpar = $dp[0];
            $obj_partner = new \App\Model\Partners();
            $layoutid = $obj_partner->get1PartnerInfo($idpar, 'layout_id');
        } elseif ($level == 'G') {
            $idgroup = $obj_customize->getCompaniesGroup($idlevel);
            $obj_group = new \App\Model\Companies();
            $idpartner = $obj_group->get1CompanyInfo($idlevel, 'id_partners');
            $df = $obj_customize->getSettingValueGroup($idgroup, $idpartner, 'SHOWCOMPANYNAME');
            $acctext = $obj_customize->getSettingValueGroup($idgroup, $idpartner, 'PAYMENT_NUMBER_REG_NUMBER');
            if ($df == 1) {
                $showcn = true;
            }
            $layoutid = $obj_group->getLayoutID($idlevel);
        } elseif ($level == 'M') {
            $idgroup = $obj_customize->getPropertiesGroup($idlevel);
            $obj_prop = new \App\Model\Properties();
            $idpartner = $obj_prop->get1PropertyInfo($idlevel, 'id_partners');
            $idcompany = $obj_prop->get1PropertyInfo($idlevel, 'id_companies');
            $df = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'SHOWCOMPANYNAME');
            $acctext = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'PAYMENT_NUMBER_REG_NUMBER');
            if ($df == 1) {
                $showcn = true;
            }
            $layoutid = $obj_prop->getLayoutID($idlevel);
        }
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $acctext= $obj_layout->extractLayoutValue('label_acc_number',$layouts);
        if ($level == 'B' || $level == 'A') {
            $filter->add('partners.partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts), 'text');
            $filter->add('companies.company_name', $obj_layout->extractLayoutValue('label_group',$layouts), 'text');
        }
        if ($level == 'P') {
            //            $filter->add('partners.partner_title', $layouts['layout_partner_partner'], 'text');
            $filter->add('companies.company_name', $obj_layout->extractLayoutValue('label_group',$layouts), 'text');
        }
        if ($level != 'M') {
            if ($level == 'P') {
                $filter->add('properties.name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text');
            } else {
                $filter->add('properties.name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text');
            }
        }
        $filter->add('web_users.account_number', $acctext, 'text');
        $filter->add('web_users.first_name', 'First Name', 'text');
        $filter->add('web_users.last_name', 'Last Name', 'text');
        $filter->add('web_users.address', 'Address', 'text')->scope(
                function ($query, $value) {
            return $query->where('web_users.address', 'like', '%' . $value . '%');
        }
        );

        $filter->add('web_users.email_address', 'Email', 'text')->scope(
                function ($query, $value) {
            return $query->where('web_users.email_address', 'like', '%' . $value . '%');
        }
        );
        $filter->add('web_users.web_status', 'Status', 'select')->options(array('' => '--Status--', '1' => 'Active', '0' => 'Inactive', '46' => 'Locked', '998' => 'Authorized', '999' => 'Unauthorized'));
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();
        $grid = \DataGrid::source($filter);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));
        $grid->add($token, $token)->style("display:none;");

        $grid->add('idlevel', 'idlevel')->style("display:none;");
        $grid->add('id', 'ID')->style("display:none;");

        $acctext=$obj_layout->extractLayoutValue('label_acc_number',$layouts);

        switch (strtoupper($level)) {
            case "A":
            case "B":
                $grid->add('partner', $obj_layout->extractLayoutValue('label_partner',$layouts));
                $grid->add('group', $obj_layout->extractLayoutValue('label_group',$layouts));
                $grid->add('merchant', $obj_layout->extractLayoutValue('label_merchant',$layouts));
                break;
            case "P":
                //                $grid->add('partner', $layouts['layout_partner_partner'], true);
                $grid->add('group', $obj_layout->extractLayoutValue('label_group',$layouts));
                $grid->add('merchant', $obj_layout->extractLayoutValue('label_merchant',$layouts));
                break;
            case "G":
                //                $grid->add('group', $layouts['layout_partner_companies']);
                $grid->add('merchant', $obj_layout->extractLayoutValue('label_merchant',$layouts));
                break;
            case "M":
                //                $grid->add('merchant', $layouts['layout_partner_property_name']);
                break;
        }

        /* if ($showcn) {
          $grid->add('companyname', $cmptext, true);
          } */
        $grid->add('webuser', $acctext, true);
        $grid->add('first_name', 'First Name', true)->cell(
                function ($value) {
                    if (strlen($value) > 20) {
                        return '<a href="#" data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 20) . '....</a>';
                    } else {
                        return $value;
                    }
                });
        $grid->add('last_name', 'Last Name', true)->cell(
                function ($value) {
                    if (strlen($value) > 20) {
                        return '<a href="#" data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 20) . '....</a>';
                    } else {
                        return $value;
                    }
                });

        $grid->add('email', 'Email')->cell(
                function ($value) {
            if (strlen($value) > 10) {
                return '<a href="#" data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 10) . '....</a>';
            } else {
                return $value;
            }
        }
        );
        $grid->add('address', 'Address');
        $grid->add('balance', 'Balance')->cell(
                function ($value) {
            if ($value < 0) {
                return '-$' . ($value * -1);
            } else {
                return '$' . $value;
            }
        }
        );

        $grid->add('status', 'Status')->cell(
                function ($value) {
            if ($value == 1) {
                return '<span class="label alert-success pull-left">Active</span>';
            } elseif ($value == 0) {
                return '<span class="label alert-danger pull-left">Inactive</span>';
            } elseif ($value == 998) {
                return '<span class="label alert-info pull-left">Authorize</span>';
            } elseif ($value == 46) {
                return '<span class="label alert-warning pull-left">Locked</span>';
            } else {
                return '<span class="label alert-info pull-left">Unauthorize</span>';
            }
        }
        );
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(
                function ($row) {
            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;
            $idlevel = $row->cells[1]->value;
            $status = $row->cell('status')->value;

            $edit_link = '<li><a href="' . route('edituser', array('token' => $token, 'id' => $id)) . '" >Open Profile</a></li>';
            //$delete_link = '<li><a href="#" onclick="deleteWebUser(\'' . $id . '\', \'/manageuser/deleteWebUser/\');return false;" >Delete</a></li>';
            $deleteuser_Link = '<li><a onClick="deleteWebUser(' . $id . ')">Delete</a></li>';
            $resetpassword_link = '<li><a href="#" onclick="resetpasswordwu(\'' . $id . '\');" >Reset Password</a></li>';

            if ($status != '<span class="label alert-success pull-left">Active</span>' && $status != '<span class="label alert-warning pull-left">Locked</span>') {
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
														  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
														  <span class="caret" ></span></button>
														  <ul class="dropdown-menu">
														    <li><a data="' . $id . '" class="user_details_link">View Details</a></li>
                                                            ' . $edit_link . '
                                                            ' . $deleteuser_Link . '
														  </ul>
														</div>';
            } else {
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
														  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
														  <span class="caret white-font-color" ></span></button>
														  <ul class="dropdown-menu">
														    <li><a data="' . $id . '" class="user_details_link">View Details</a></li>
															' . $edit_link . '
															' . $deleteuser_Link . '
															' . $resetpassword_link . '
														  </ul>
														</div>';
            }

            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
            $row->cells[1]->style("display:none;");
        }
        );

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        //        $grid->link('/webuser/' . $token . '/viewimport', 'Import', "TR", array('id' => 'importWebUser', 'class' => 'btn btn-md btn-success btn-margin-left'));
        //$grid->orderBy('web_user_id');
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->paginate($itemsPerPage);

        //import config
        /* $array_config_import = array();
          $array_config_import['table_name'] = 'web_users';
          $array_config_import['table_fields_required'] = array('property_id', 'first_name');
          //$array_config_import['table_field_key_update']='account_number';
          $array_config_import['route_return'] = 'manageuser'; */
        $array_config_import['table_fields_hidden'] = array('web_user_id', 'photo', 'remember_token', 'topsdata', 'companyname', 'balance_due');

        $array_config_import = array();
        $array_config_import['table_name'] = 'web_users';
        $array_config_import['route_return'] = 'manageuser';
        $array_config_import['table_fields'] = array(
            'account_number', 'property_id', 'first_name', 'last_name', 'username', 'email_address',
            'phone_number', 'phone_number', 'address', 'city', 'state', 'zip', 'web_status', 'balance', 'composite_id'
        );

        $array_config_import['columns_required'] = array('first_name');
        $array_config_import['columns_unique'] = array('username');
        $array_config_import['matching_extra_where'] = array(array('web_status', '<', '1000'));
        $array_config_import['fixed_values_insert_if_empty'] = array(array('web_status' => '998'));
        $array_config_import['filters'] = array('phone_number' => ['cleanString']);

        $array_config_import['simple_validations'] = array(
            array(
                'conditions' => [
                    ['web_status', '>=', [1000]]
                ],
                'result' => [
                    'web_status', '9999'
                ]),
            array(
                'conditions' => [
                    ['web_status', '!=', [0, 1, 46, 998, 999]],
                    ['web_status', '<', [1000]],
                ],
                'result' => [
                    'web_status', '0'
                ]),
            array(
                'conditionsFunction' => [
                    ['phone_number', 'strlen', '!=', [10]],
                ],
                'result' => [
                    'phone_number', ''
                ]),
            array(
                'conditionsFunction' => [
                    ['zip', 'strlen', '!=', [5]],
                ],
                'result' => [
                    'zip', ''
                ])
        );
        if (strtolower($level) == 'm') {
            $array_config_import['fixed_value_to_save'] = array('property_id' => $idlevel);
            $array_config_import['columns_unique'] = array('username', 'account_number');
            $array_config_import['table_fields_matching_required'] = array('account_number');
        } elseif (strtolower($level) == 'g') {
            $array_config_import['columns_required'] = array('property_id', 'first_name');
            $array_config_import['table_fields_extra'][] = array(
                'label' => 'Paypoint',
                'FOREIGN' => array(
                    'table' => 'properties',
                    'field_where' => 'compositeID_clients',
                    'extra_where' => array(['id_companies' => $idlevel]),
                    'select' => 'id',
                    'assign_to' => 'property_id',
            ));
            $array_config_import['table_fields_matching_required'] = array('account_number', 'Paypoint');
        } elseif (strtolower($level) == 'p') {
            $array_config_import['columns_required'] = array('property_id', 'first_name');
            $array_config_import['table_fields_extra'][] = array(
                'label' => 'Paypoint',
                'FOREIGN' => array(
                    'table' => 'properties',
                    'field_where' => 'compositeID_clients',
                    'extra_where' => array(['id_partners' => $idlevel]),
                    'select' => 'id',
                    'assign_to' => 'property_id',
            ));
            $array_config_import['table_fields_matching_required'] = array('account_number', 'Paypoint');
        }
        $tokentable = encrypt($array_config_import);


        return view(
                'manageuser.userlist', array(
            'level' => $level,
            'tokentable' => $tokentable,
            'pageTitle' => $obj_layout->extractLayoutValue('label_manage_user',$layouts),
            'filter' => $filter,
            'grid' => $grid,
            'atoken' => $token,
            'token' => $token,
            'itemspage' => $itemsPerPage,
            'sqlEncrypted' => encrypt($sql_ready),
            'layouts' => $layouts
                )
        );
    }

    public function editwebuser($token, $web_user_id) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $payment_is_checked = '';
        $user_payment_type = array();

        $webusers = new WebUsers();
        $property_id = $webusers->getPropertyIdByUserId($web_user_id);
        $user_payment_type = array();
        $showcn = false;
        $count = 0;
        $countr = 0;
        $einv = false;
        $estm = 0;
        $sdibill = 0;
        $gsbbill = 0;
        $accreq = 0;
        $acctext = 'Account Number';

        //default layout
        $obj_layout = new Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        if (!empty($property_id)) {
            $obj_prop = new Model\Properties();
            $property_id = $property_id->property_id;
            $idpartner = $obj_prop->get1PropertyInfo($property_id, 'id_partners');
            $idcompany = $obj_prop->get1PropertyInfo($property_id, 'id_companies');
            $ot = $obj_prop->getcredOneTimeCredentials($property_id);
            if (!empty($ot))
                $count = count($ot);
            $ot = $obj_prop->getcredRecurringCredentials($property_id);
            if (!empty($ot))
                $countr = count($ot);
            $obj_customize = new Model\Customize();
            $idgroup = $obj_customize->getPropertiesGroup($property_id);
            $ddf = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'SHOWCOMPANYNAME');
            if ($ddf == 1)
                $showcn = true;
            $ddf = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'EINVOICE');
            if ($ddf == 1)
                $einv = true;
            $estm = $webusers->getCountStatementByUser($web_user_id);
            $sdibill = \App\Model\MenuTabExtensions::hasMenuTab($property_id, '%viewbill');
            $acctext = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'PAYMENT_NUMBER_REG_NUMBER');
            $accreq = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'PAYMENT_NUMBERS');
            $property_type_detail = $webusers->getPaymentTypeDetail($property_id);
            if (!empty($property_type_detail)) {
                $payment_is_checked = $webusers->isCatChecked($property_type_detail->payment_type_id, $web_user_id);
                $user_payment_type = array('text' => $property_type_detail->payment_type_name, 'ptid' => $property_type_detail->payment_type_id, 'chk' => $payment_is_checked);
            }

            //Calling the api and get the json response
            $bills = new \App\CustomClass\GSBBilling($web_user_id);
            $result = $bills->getBills();
            if(!empty($result))
            {
                $result = json_decode($result);
                if (!empty($result->bill_count)) {
                    $gsbbill = $result->bills;
                }
            }
            $layouts = $obj_layout->getLayoutValues($property_id,'M');
        }
        $acctext=$obj_layout->extractLayoutValue('label_acc_number',$layouts);
        $partnerlist = $webusers->getPartnerList();
        $companylist = $webusers->getCompanyList();
        $merchantlist = $webusers->getMerchantList();
        $webuserdetail = $webusers->getWebUserdetail($web_user_id);
        $data = array('pageTitle' => $obj_layout->extractLayoutValue('label_edit_user',$layouts), 'webuserdetail' => $webuserdetail, 'partnerlist' => $partnerlist, 'companylist' => $companylist, 'merchantlist' => $merchantlist, 'web_user_id' => $web_user_id, 'token' => $token, 'level' => $level, 'idlevel' => $idlevel, 'user_payment_type' => $user_payment_type, 'showcn' => $showcn, 'property_id' => $property_id, 'otc' => $count, 'rtc' => $countr, 'layouts' => $layouts, 'acctext' => $acctext, 'accreq' => $accreq);
        if ($einv) {
            $data['einv'] = true;
        }

        $categories = $webusers->getCategByProperty($property_id);
        $categories_user = $webusers->getCategByUser($web_user_id);
        $categories_user_created = $webusers->getCategCreatedByUser($web_user_id);
        $data['categories'] = $categories;
        $data['categories_user'] = $categories_user;
        $data['categories_created_user'] = $categories_user_created;
        $data['property_id'] = $property_id;
        $data['atoken'] = $token;
        $data['estm'] = $estm;
        $data['sdibill'] = $sdibill;
        $data['gsbbill'] = $gsbbill;

        return view('manageuser.useredit', $data);
    }

    public function editprofile(Request $request) {

        $validator = Validator::make(
                        $request->all(), [
                    'first_name' => 'required',
                    'email_address' => 'email'
                        ]
        );
        if ($validator->fails()) {
            $validationMsg = '';
            $messages = $validator->messages();
            //echo '<pre>';
            //print_r($messages); die;
            if (!empty($messages)) {
                foreach ($messages->all() as $key => $error) {
                    //echo '<pre>';
                    //print_r($error);
                    $validationMsg .= $error . '<br/>';
                }
            }

            return json_encode(array('error' => 1, 'msg' => $validationMsg));
        } else {
            $webusers = new WebUsers();
            $web_user_id = $webusers->saveWebUser($request->all());
            if ($web_user_id > 0) {
                $idproperty = $webusers->getPropertyIdByUserId($web_user_id);
                $obj_prop = new Model\Properties();
                $idproperty = $idproperty->property_id;
                $idcompany = $obj_prop->get1PropertyInfo($idproperty, 'id_companies');
                $idpartner = $obj_prop->get1PropertyInfo($idproperty, 'id_partners');
                $esdi = $obj_prop->getPropertySettings($idproperty, $idcompany, $idpartner, 'ESDI');
                if ($esdi == 1) {
                    $obj_paperinvoice = new \App\CustomClass\PaperInvoiceConnection();
                    $params = array();
                    $params['accountNumber'] = trim($webusers->get1UserInfo($web_user_id, 'account_number'));
                    $params['street'] = trim($webusers->get1UserInfo($web_user_id, 'address'));
                    $params['optOut'] = trim($webusers->get1UserInfo($web_user_id, 'suppression'));
                    $result = $obj_paperinvoice->SDIconnectionSet($params);
                }
                $objtx = new Transations();
                if ($request->get('balance') !== null) {
                    $balance = $request->get('balance');
                    if (empty($balance)) {
                        $balance = 0;
                    }
                    if ($balance < 0) {
                        $balance = 0;
                    }
                    $balance = $balance * 1;

                    //update autopayments
                    $fld = array();
                    $fld['trans_recurring_net_amount'] = $balance;
                    $fld['trans_descr'] = 'Payment:      ' . number_format($balance, 2);
                    $objtx->updateRTxByUser($web_user_id, $fld, true);
                }
                if ($request->get('web_status') !== null) {
                    $web_status = $request->get('web_status');
                    if ($web_status == 0 || $web_status == 999) {
                        $objtx->cancelRTxByUser($web_user_id);
                    }
                }
                if ($request->get('id') !== null) {
                    return json_encode(array('error' => -1, 'msg' => 'User information has been updated successfully.'));
                } else {
                    return json_encode(array('error' => -1, 'msg' => 'User information has been added successfully.'));
                }
            } else {
                if ($web_user_id == -3) {
                    return json_encode(array('error' => -3, 'msg' => 'A payor with this account number exists in the system already. Please verify and try again'));
                } else {
                    return json_encode(array('error' => -6, 'msg' => 'A payor with this username exists in the system already. Please verify and try again'));
                }
            }
        }
    }

    public function savewebuserPost($token, Request $request) {


        $validator = Validator::make(
                        $request->all(), [
                    'account_number33' => 'max:100',
                    'first_name' => 'required|max:150',
                    'last_name' => 'max:150',
                    'username' => 'max:50',
                    'email_address' => 'email|max:150',
                    'phone_number' => 'max:25',
                    'city' => 'max:150',
                    'state' => 'max:15',
                    'zip' => 'max:15',
                    'web_status' => 'max:11',
                    'balance' => 'numeric',
                        ]
        );
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator->errors())->withInput($request->all());
        } else {
            $webusers = new WebUsers();
            $web_user_id = $webusers->saveWebUser($request->all());

            if ($web_user_id > 0) {
                $idproperty = $webusers->getPropertyIdByUserId($web_user_id);
                $obj_prop = new \App\Model\Properties();
                $idproperty = $idproperty->property_id;
                $idcompany = $obj_prop->get1PropertyInfo($idproperty, 'id_companies');
                $idpartner = $obj_prop->get1PropertyInfo($idproperty, 'id_partners');
                $esdi = $obj_prop->getPropertySettings($idproperty, $idcompany, $idpartner, 'ESDI');
                if ($esdi == 1) {
                    $obj_paperinvoice = new \App\CustomClass\PaperInvoiceConnection();
                    $params = array();
                    $params['accountNumber'] = trim($webusers->get1UserInfo($web_user_id, 'account_number'));
                    $params['street'] = trim($webusers->get1UserInfo($web_user_id, 'address'));
                    $params['optOut'] = trim($webusers->get1UserInfo($web_user_id, 'suppression'));
                    $result = $obj_paperinvoice->SDIconnectionSet($params);
                }
                $objtx = new Transations();
                if ($request->get('balance') !== null) {
                    $balance = $request->get('balance');
                    if (empty($balance)) {
                        $balance = 0;
                    }
                    if ($balance < 0) {
                        $balance = 0;
                    }
                    $balance = $balance * 1;

                    //update autopayments
                    if ($objtx->getRecByUser($web_user_id) > 0) {
                        \App\Providers\RevoPayAuditLogger::autopaymentUpdate('admin', array('operation' => 'updating balance: ' . $balance, 'data' => (array) $objtx->getRecListByUser($web_user_id)), 'M', $idproperty, \App\Model\WebUsers::getAuditData($web_user_id), Auth::user());
                        $fld = array();
                        $fld['trans_recurring_net_amount'] = $balance;
                        $fld['trans_descr'] = 'Payment:      ' . number_format($balance, 2);
                        $objtx->updateRTxByUser($web_user_id, $fld, true);
                    }
                }
                if ($request->get('web_status') !== null) {
                    $web_status = $request->get('web_status');
                    if ($web_status == 0 || $web_status == 999) {
                        if (($objtx->getRecByUser($web_user_id) + $objtx->getRecByUser($web_user_id, 0)) > 0) {
                            $dyn = $objtx->getRecListByUser($web_user_id);
                            $ndyn = $objtx->getRecListByUser($web_user_id, 0);
                            \App\Providers\RevoPayAuditLogger::autopaymentDelete('admin', array('operation' => 'updating payor status: ' . $web_status, 'data' => array_merge($dyn, $ndyn)), 'M', $idproperty, \App\Model\WebUsers::getAuditData($web_user_id), Auth::user());
                        }
                        $objtx->cancelRTxByUser($web_user_id);
                    }
                }
                return Redirect::route('manageuser', array('token' => $token))->with('success', 'Data has been saved successfully.');
            } else {
                if ($web_user_id == -3) {
                    return Redirect::back()->with('error', 'A payor with this account number exists in the system already. Please verify and try again')->withInput($request->all());
                } else {
                    return Redirect::back()->with('error', 'A payor with this username exists in the system already. Please verify and try again')->withInput($request->all());
                }
            }
        }
    }

    public function resetpswemail($token, $web_user_id, Request $request) {
        $webuser = new WebUsers();
        $idproperty = $webuser->getPropertyIdByUserId($web_user_id);

        $obj_property = new \App\Model\Properties();
        $idproperty = $idproperty->property_id;
        $merchant = $obj_property->getPropertyInfo($idproperty);
        $idproperty = $merchant['id'];
        $idcompany = $merchant['id_companies'];
        $idpartner = $merchant['id_partners'];
        $subdomain = $obj_property->get1PropertyInfo($idproperty, 'subdomain_clients');
        $obj_partner = new Partners();
        $partner = $obj_partner->get1PartnerInfo($idpartner, 'partner_name');
        $obj_user = new WebUsers();
        $email = $obj_user->get1UserInfo($web_user_id, 'email_address');
        if (trim($email) == '') {
            return response()->json(array('errcode' => 101, 'msg' => 'Not exists email address in file for this user.'));
        }
        //send email
        //        if ($request->secure()) {
        //            $hostname = "https://" . $_SERVER['SERVER_NAME'];
        //        } else {
        //            $hostname = "http://" . $_SERVER['SERVER_NAME'];
        //        }
        $hostname = config('app.url');
        $nameuser = $obj_user->getFullNameById($web_user_id);
        $base_url = $hostname . $partner . '/properties/' . $subdomain;
        $data = array();
        $data['logo'] = $hostname . $merchant['logo'];
        $randnum = rand(10000000, 99999999);
        $randnum = $obj_property->getUniqAuthCode($randnum);
        $send_token = encrypt(['web_user_id' => $web_user_id, 'idproperty' => $idproperty, 'randnum' => $randnum]);
        $data['hashlink'] = $hostname . 'password/' . $send_token;
        $obj_user->set1UserInfo($web_user_id, 'password', $randnum);
        $data['merchantname'] = $merchant['name_clients'];
        $data['name'] = $nameuser;
        $data['ticketlink'] = $base_url . '/help';
        $data['email'] = trim($email);
        $data['from'] = $obj_property->getCustomerServiceFrom($idproperty, $idcompany, $idpartner);
        if (empty($data['from'])) {
            $data['from'] = 'info@revopayments.com';
        }
        \Illuminate\Support\Facades\Mail::send(
                'mail.forgotpass', $data, function ($message) {

        }
        );

        return response()->json(array('errcode' => 1, 'msg' => 'An email to ' . $email . ' was sent.'));
    }

    //function to export merchants
    public function webuserexport($token, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        list($idlevel, $level) = explode('|', $atoken);
        $webusers = new WebUsers();
        $webuserTableFieldList = array();
        $webuserTableFields = $webusers->getTableStructure();
        $join_table_key_webusers = array('partners.partner_title' => 'partner', 'companies.company_name' => 'group', 'properties.name_clients' => 'merchant');
        if (!empty($webuserTableFields)) {
            foreach ($webuserTableFields as $table_fields_key => $table_fields_value) {
                if (($table_fields_value['Key'] != 'PRI') && !in_array($table_fields_value['Field'], $this->fields_to_skip)) {
                    //$insert_field .= '`'.trim($table_fields_value['Field']).'`,';
                    $webuserTableFieldList[trim('web_users.' . $table_fields_value['Field'])] = trim(str_replace('_', ' ', $table_fields_value['Field']));
                }
            }
        }
        $webuserTableFieldList = array_merge($join_table_key_webusers, $webuserTableFieldList);
        //$userautopaymentdetail = $transactions->getWebUserAutoPayHistoryDetail($idlevel, $level, $trans_id);
        $obj_property = new \App\Models\Properties();
        $layout_id = $obj_property->getLayoutID($idlevel);
        $labels = $obj_property->getLabels_Layout($layout_id);

        return view('admin.webuserexport', array('webuserTableFieldList' => $webuserTableFieldList, 'pageTitle' => 'Export Users', 'atoken' => $token, 'idlevel' => $idlevel, 'layout' => $labels));
    }

    public function exportwebuserlist(Request $request) {

        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($request->get('atoken'));
        list($idlevel, $level) = explode('|', $atoken);
        $validator = Validator::make(
                        $request->all(), [
                    'frmDelimiter' => 'required'
                        ]
        );

        $querySelect = explode(",", $request->get('webuserfieldtoexport'));
        unset($querySelect[count($querySelect) - 1]);

        if ($validator->fails()) {
            $validationMsg = '';
            $messages = $validator->messages();
            //echo '<pre>';
            //print_r($messages); die;
            if (!empty($messages)) {
                foreach ($messages->all() as $key => $error) {
                    //echo '<pre>';
                    //print_r($error);
                    $validationMsg .= $error;
                }
            }

            return json_encode(array('error' => 1, 'msg' => $validationMsg));
        } else {
            $delimiter = "";
            if ($request->get('frmDelimiter') == 1) {
                $delimiter = ",";
            } elseif ($request->get('frmDelimiter') == 2) {
                $delimiter = ";";
            } elseif ($request->get('frmDelimiter') == 3) {
                $delimiter = "\t";
            } else {
                $delimiter = "|";
            }
            if ($querySelect == '') {
                return json_encode(array('error' => 1, 'msg' => 'Please select at least a field to export.'));
            }


            //$file = public_path('uploads/csv/webusers/web_users_list'.date('Y-m-d'));
            $webusers = new WebUsers();
            //echo '<pre>';
            //print_r($request->get('webuserfieldtoexport')); die;
            $web_user_list = $webusers->getWebUserListByFields($idlevel, $level, $querySelect);
            if (count($web_user_list) > 0) {
                if (isset($web_user_list[0]['suppression']) || isset($web_user_list[0]['web_status'])) {
                    for ($i = 0; $i < count($web_user_list); $i++) {
                        if (isset($web_user_list[$i]['suppression'])) {
                            switch ($web_user_list[$i]['suppression']) {
                                case 0:
                                    $web_user_list[$i]['suppression'] = "Disabled";
                                    break;
                                case 1:
                                    $web_user_list[$i]['suppression'] = "Enabled";
                                    break;
                                default:
                                    break;
                            }
                        }

                        if (isset($web_user_list[$i]['web_status'])) {
                            switch ($web_user_list[$i]['web_status']) {
                                case 0:
                                    $web_user_list[$i]['web_status'] = "Inactive";
                                    break;
                                case 1:
                                    $web_user_list[$i]['web_status'] = "Active";
                                    break;
                                case 46:
                                    $web_user_list[$i]['web_status'] = "Locked";
                                    break;
                                case 998:
                                    $web_user_list[$i]['web_status'] = "Authorized";
                                    break;
                                case 999:
                                    $web_user_list[$i]['web_status'] = "Unauthorized";
                                    break;
                                case 9999:
                                    $web_user_list[$i]['web_status'] = "Purged";
                                    break;
                                case 1000:
                                    $web_user_list[$i]['web_status'] = "Deleted";
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
            }

            if (!empty($web_user_list)) {
                if (!file_exists(env('CSV_UPLOAD_DIR') . '/webusers')) {
                    mkdir(env('CSV_UPLOAD_DIR') . '/webusers', 0777, true);
                }
                $fp = fopen(env('CSV_UPLOAD_DIR') . '/webusers/web_users_list' . date('Y-m-d') . '.csv', 'w+');
                $string = implode(addslashes($delimiter), array_keys($web_user_list[0])) . "\r\n";
                fwrite($fp, $string);
                foreach ($web_user_list as $webuserrow) {
                    $string = implode(addslashes($delimiter), $webuserrow) . "\r\n";
                    fwrite($fp, $string);
                }
            } else {
                return json_encode(array('error' => 1, 'msg' => 'No result found for generation csv file.'));
            }
            return json_encode(array('error' => -1, 'msg' => ''));
        }
    }

    public function downloadwebuserexportfile() {

        $file = env('CSV_UPLOAD_DIR') . '/webusers/web_users_list' . date('Y-m-d') . '.csv';
        //echo $file; die;
        header('Content-Description: File Transfer');
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename=' . basename($file));
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        //ob_clean();
        flush();
        readfile($file);
        exit;
    }

    public function userpaymenthistory(Request $request, $token, $web_user_id) {

        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);

        //        list($idlevel, $level) = explode('|', $atoken);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $transactions = new Transations();
        $grid = \DataGrid::source($transactions->getPaymentHistoryByUserId($idlevel, $level, $web_user_id));
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));
        //print_r($grid); die;
        $grid->add($token, 'token')->style("display:none;");
        //$grid->add($idlevel,'idlevel')->style("display:none;");
        $grid->add('trans_id', 'ID')->style("display:none;");
        //$grid->add('name','Name', true)->style("width:100px");
        $grid->add('trans_date', 'Date');
        $grid->add('trans_total_amount', 'Amount')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_convenience_fee', 'CFee')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        //$grid->add('trans_descr','Description');
        //$grid->add('trans_source_key','Source Key');
        $grid->add('trans_type', 'Transaction Type')->cell(
                function ($value) {
            if ($value == '0') {
                return 'One Time';
            } elseif ($value == '1') {
                return 'Auto Payment';
            } elseif ($value == '9') {
                return 'Void';
            } elseif ($value == '10') {
                return 'Refunded';
            }
        }
        );
        $grid->add('trans_card_type', 'Pay Type')->cell(function ($value) {

            if (strtolower(substr($value, 0, 4)) === "visa") {
                $value = '<img class="iconreport" src="' . asset('img/visa.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 8)) === "checking" || strtolower(substr($value, 0, 6)) === "saving") {
                $value = '<img class="iconreport" src="' . asset('img/checking.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 3)) === "ame") {
                $value = '<img class="iconreport" src="' . asset('img/amex.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 4)) === "cash") {
                $value = '<img class="iconreport" src="' . asset('img/money.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 8)) === "discover") {
                $value = '<img class="iconreport" src="' . asset('img/discover.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 10)) === "mastercard") {
                $value = '<img class="iconreport" src="' . asset('img/mastercard.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 5)) === "swipe") {
                $value = '<img class="iconreport" src="' . asset('img/swipe.png') . '"> ' . $value;
            }
            return $value;
        });
        $grid->add('source', 'Source');
        /* $grid->add('trans_status','Status')->cell( function($value){
          if($value == 1){
          return 'Active';
          }else if($value == 0){
          return 'Inactive';
          }else{
          return 'Unauthourize';
          }
          }); */

        $grid->add('actionvalue', 'Action')->style("text-align:right");
        ;
        $grid->row(
                function ($row) {

            $id = $row->cell('trans_id')->value;
            $token = $row->cells[0]->name;

            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
													  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
													  <span class="caret"></span></button>
													  <ul class="dropdown-menu">
														<li><a href="javascript:;" onclick="viewWebUserPayHistory(\'' . $token . '\', \'' . $id . '\');" >View</a></li>
													  </ul>
													</div>';

            $row->cell('trans_id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate(5)->attributes(array("id" => "web-users-pay-history-pg"));
        $userpaymenthistorylisthtml = view('manageuser.web_users_payment_history', array('grid' => $grid, 'token' => $token, 'idlevel' => $idlevel))->render();
        return response()->json(array('errcode' => 0, 'msg' => $userpaymenthistorylisthtml));
    }

    public function userautopayhistory(Request $request, $token, $web_user_id) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        //        list($idlevel, $level) = explode('|', $atoken);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $transactions = new Transations();
        $grid = \DataGrid::source($transactions->getWebUserAutoPayHistoryByUserId($idlevel, $level, $web_user_id));
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));
        //print_r($grid); die;
        $grid->add($token, 'token')->style("display:none;");
        //$grid->add($idlevel,'idlevel')->style("display:none;");
        $grid->add('trans_id', 'ID')->style("display:none;");
        $grid->add('trans_next_date', 'Date');
        $grid->add('trans_recurring_net_amount', 'Amount')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_recurring_convenience_fee', 'CFee')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('net_charge', 'Net Charge')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('trans_numleft', 'Num left');
        $grid->add('stype', 'Dynamic')->cell(
                function ($value) {
            if ($value == 0) {
                return 'No';
            } else {
                return 'Yes';
            }
        }
        );
        $grid->add('trans_card_type', 'Pay Type')->cell(function ($value) {
            if (strtolower(substr($value, 0, 4)) === "visa") {
                $value = '<img class="iconreport" src="' . asset('img/visa.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 8)) === "checking" || strtolower(substr($value, 0, 6)) === "saving") {
                $value = '<img class="iconreport" src="' . asset('img/checking.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 3)) === "ame") {
                $value = '<img class="iconreport" src="' . asset('img/amex.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 4)) === "cash") {
                $value = '<img class="iconreport" src="' . asset('img/money.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 8)) === "discover") {
                $value = '<img class="iconreport" src="' . asset('img/discover.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 10)) === "mastercard") {
                $value = '<img class="iconreport" src="' . asset('img/mastercard.svg') . '"> ' . $value;
            }
            if (strtolower(substr($value, 0, 5)) === "swipe") {
                $value = '<img class="iconreport" src="' . asset('img/swipe.png') . '"> ' . $value;
            }
            return $value;
        });
        $grid->add('actionvalue', 'Action')->style("text-align:right");
        ;
        $grid->row(
                function ($row) {

            $id = $row->cell('trans_id')->value;
            $token = $row->cells[0]->name;
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
													  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
													  <span class="caret"></span></button>
													  <ul class="dropdown-menu">
														<li><a href="javascript:;" onclick="viewWebUserAutoPay(\'' . $token . '\', \'' . $id . '\');" >View</a></li>
													  </ul>
													</div>';
            $row->cell('trans_id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $grid->orderBy('trans_id', 'DESC');
        $grid->paginate(5)->attributes(array("id" => "web-users-autopay-history-pg"));
        $userautopayhistorylisthtml = view('manageuser.web_users_auto_pay_history', array('grid' => $grid, 'token' => $token, 'idlevel' => $idlevel))->render();
        return response()->json(array('errcode' => 0, 'msg' => $userautopayhistorylisthtml));
    }

    public function userpayhistorydetail(Request $request, $token, $trans_id) {

        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);

        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $transactions = new Transations();
        $userpayhistorydetail = $transactions->getWebUserPayHistoryDetail($idlevel, $level, $trans_id);
        $userpayhistorydetailhtml = view('manageuser.web_users_pay_history_detail', array('webuserpayhistorydetail' => $userpayhistorydetail, 'token' => $token, 'idlevel' => $idlevel))->render();
        return response()->json(array('errcode' => 0, 'msg' => $userpayhistorydetailhtml));
    }

    public function userautopayhistorydetail(Request $request, $token, $trans_id) {
        $atoken = decrypt($token);
        //        list($idlevel, $level) = explode('|', $atoken);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $transactions = new Transations();
        $userautopaymentdetail = $transactions->getWebUserAutoPayHistoryDetail($idlevel, $level, $trans_id);
        $userautopaymentdetailhtml = view('manageuser.web_users_autopay_history_detail', array('webuserautopaymentdetail' => $userautopaymentdetail, 'token' => $token, 'idlevel' => $idlevel))->render();
        return response()->json(array('errcode' => 0, 'msg' => $userautopaymentdetailhtml));
    }

    public function webuserimport($token, $tokentable, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        //        $webusers = new WebUsers();
        //$userautopaymentdetail = $transactions->getWebUserAutoPayHistoryDetail($idlevel, $level, $trans_id);
        $obj_property = new Model\Properties();
        $obj_layout=new \App\Model\Layout();
        $labels = $obj_layout->getLayoutValues($idlevel,$level);
        
        $rule_company_data = null;
        switch ($level) {
            case 'G':
                $rule_company_data = Model\Companies::find($idlevel);
                break;
            case 'M':
                $rule_company_data = $obj_property->find_company($idlevel);
                break;
        }
        return view(
                //'manageuser.web_users_import',
                'manageuser.webusers_import', array(
            'webuserimportData' => array(''),
            'pageTitle' => 'Import Web Users',
            'token' => $token,
            'idlevel' => $idlevel,
            'level' => $level,
            'layout' => $labels,
            'ruleData' => $rule_company_data,
            'tokentable' => $tokentable
                )
        );
    }

    function csvToArray($filename = '', $delimiter = ',') {

        switch ($delimiter) {
            case 1:
                $delimiter = ',';
                break;
            case 2:
                $delimiter = ';';
                break;
            case 3:
                $delimiter = '|';
                break;
        }


        if (!file_exists($filename) || !is_readable($filename))
            return false;

        $header = null;
        $data = array();
        if (($handle = fopen($filename, 'r')) !== false) {
            while (($row = fgetcsv($handle, 1000, $delimiter)) !== false) {
                if (!$header)
                    $header = $row;
                else {
                    if (count($header) != count($row)) {
                        return false;
                    } else {
                        $data[] = array_combine($header, $row);
                    }
                }
            }
            fclose($handle);
        }

        return $data;
    }

    function importAction($token, $tokentable, Request $request) {

        try {
            $data_tokentable = decrypt($tokentable);
        } catch (DecryptException $e) {
            return Redirect::back()->with('error', 'The config has errors');
        }
        if (!isset($data_tokentable['table_name']))
            return Redirect::back()->with('error', '"table_name" is required');

        if ($request->hasFile('importfile')) {

            $file = $request->file('importfile');
            if ($file->getClientOriginalExtension() == 'csv') {
                //var_dump('sd1');die;
                $destinationPath = config('importExport.upload_dir');
                $filename = $file->getClientOriginalName();
                $file->move($destinationPath, $filename);
                $separator = 1;
                if ($request->get('separator'))
                    $separator = $request->get('separator');
                $array_csv = $this->csvToArray($destinationPath . '/' . $filename, $separator);
                if (!$array_csv) {
                    return Redirect::back()->with('error', 'The file has not the correct structure');
                }
                if ($array_csv) {

                    $data_tokentable['filename'] = $destinationPath . '/' . $filename;
                    $data_tokentable['separator'] = $separator;
                    $tokentable = encrypt($data_tokentable);
                    if (isset($array_csv[0])) {

                        $keys = array();
                        foreach ($array_csv as $item) {

                            foreach ($item as $key => $value) {
                                if (!in_array($key, $keys)) {
                                    $keys[] = $key;
                                }
                            }
                        }

                        $columns = Schema::getColumnListing($data_tokentable['table_name']);
                        $columns_lenght = count($columns);

                        if (isset($data_tokentable['table_fields_hidden'])) {
                            for ($i = 0; $i < $columns_lenght; $i++) {

                                if (in_array($columns[$i], $data_tokentable['table_fields_hidden'])) {
                                    unset($columns[$i]);
                                }
                            }
                        }
                        return view('manageuser.webusers_import2', array(
                            'pageTitle' => 'Import ' . $data_tokentable['table_name'],
                            'token' => $token,
                            'tokentable' => $tokentable,
                            'datatokentable' => $data_tokentable,
                            'columns' => $columns,
                            'keys' => $keys
                        ));
                    } else {
                        return Redirect::back()->with('error', 'The file has not the correct structure');
                    }
                } else {
                    return Redirect::back()->with('error', 'The file has not the correct structure');
                }
            } else {
                return Redirect::back()->with('error', 'The file has not the correct mime type');
            }
        } else {
            return Redirect::back()->with('error', 'The file is required');
        }
    }

    function importProcessAction($token, $tokentable, Request $request) {
        $datasubmit = $request->all();
        $datasubmit_match = array();
        $update = array();
        $fields_affected = 0;
        $array_validate = array();
        try {
            $data_tokentable = decrypt($tokentable);
        } catch (DecryptException $e) {
            return Redirect::back()->with('error', 'The config has errors');
        }
        if (!isset($data_tokentable['table_name']))
            return Redirect::back()->with('error', '"table_name" is required');
        // clean array data submit
        foreach ($datasubmit as $fkey => $f) {
            if (strpos($fkey, 'match_') === 0) {
                if ($f == 'yes') {
                    $datasubmit_match[str_replace('match_', '', $fkey)] = 1;
                }
                unset($datasubmit[$fkey]);
            }
            if ($f == 'zip') {
                $array_validate['zip'] = $fkey;
            }
            if ($f == 'email_address') {
                $array_validate['email_address'] = $fkey;
            }
            if ($f == 'phone_number') {
                $array_validate['phone_number'] = $fkey;
            }
        }
        // var_dump($datasubmit_match);die;
        if ($datasubmit) {
            unset($datasubmit['_token']);
            unset($datasubmit['primary']);
        }
        if (isset($data_tokentable['filename'])) {
            //validations
            foreach ($datasubmit as $field) {
                $count = 0;
                foreach ($datasubmit as $field_aux) {
                    if ($field == $field_aux && $field) {
                        $count++;
                    }
                }
                if ($count > 1) {
                    return Redirect::back()->with('error', 'Duplicated field "' . $field . '"');
                }
            }
            $separator = 1;
            if (isset($data_tokentable['separator']) && $data_tokentable['separator'])
                $separator = $data_tokentable['separator'];
            $datafile = $this->csvToArray($data_tokentable['filename'], $separator);
            //var_dump($datafile);die;
            if (!$datafile) {
                return Redirect::back()->with('error', 'The file has not the correct structure');
            }
            foreach ($datafile as $item) {
                $update = array();
                $save_array = array();

                //validating field zip, phone, email.
                if (isset($array_validate['zip'])) {
                    if (!preg_match('/^\d{5}$/', $item[$array_validate['zip']])) {
                        $item[$array_validate['zip']] = '';
                    }
                }
                if (isset($array_validate['phone_number'])) {
                    if (!preg_match('/^\d{10}$/', $item[$array_validate['phone_number']])) {
                        $item[$array_validate['phone_number']] = '';
                    }
                }
                if (isset($array_validate['email_address'])) {
                    if (!filter_var($item[$array_validate['email_address']], FILTER_VALIDATE_EMAIL)) {
                        $item[$array_validate['email_address']] = '';
                    }
                }


                foreach ($datasubmit as $d => $key) {
                    if (isset($datasubmit_match[$d])) {

                        if (isset($item[$d]) && $key) {
                            $update[][$key] = $item[$d];
                        } else {
                            $d_aux = str_replace('_', ' ', $d);
                            if (isset($item[$d_aux]) && $key) {
                                $update[][$key] = $item[$d_aux];
                            }
                        }
                    }
                    $d_aux = str_replace('_', ' ', $d);
                    if (isset($item[$d]) && $key) {
                        $save_array[$key] = $item[$d];
                    }
                    if (isset($item[$d_aux]) && $key) {
                        $save_array[$key] = $item[$d_aux];
                    }
                    if (isset($data_tokentable['table_fields_extra'])) {
                        foreach ($data_tokentable['table_fields_extra'] as $extra) {
                            if ($key == $extra['label']) {
                                $query = DB::table($extra['FOREIGN']['table'])
                                        ->where($extra['FOREIGN']['field_where'], $item[$d]);
                                if (isset($extra['FOREIGN']['extra_where'])) {
                                    foreach ($extra['FOREIGN']['extra_where'] as $where) {
                                        $query->where($where);
                                    }
                                }
                                $value_db = $query->first();
                                if ($value_db) {
                                    $save_array[$extra['FOREIGN']['assign_to']] = $value_db[$extra['FOREIGN']['select']];
                                    if (isset($datasubmit_match[$d])) {
                                        if (isset($item[$d]) && $item[$d])
                                            $update[][$extra['FOREIGN']['assign_to']] = $value_db[$extra['FOREIGN']['select']];
                                    }
                                }
                                unset($save_array[$extra['label']]);
                                foreach ($update as $ukey => $udata) {
                                    if (isset($update[$ukey][$extra['label']])) {
                                        unset($update[$ukey]);
                                    }
                                }
                            }
                        }
                    }
                }
                if (isset($data_tokentable['columns_required'])) {
                    foreach ($data_tokentable['columns_required'] as $required) {
                        if (!isset($save_array[$required])) {
                            return Redirect::back()->with('error', $fields_affected . ' Fields affected. Field' . ' "' . $required . '" is required or not matching');
                        }
                    }
                }
                if (isset($data_tokentable['fixed_value_to_save'])) {
                    $save_array = array_merge($save_array, $data_tokentable['fixed_value_to_save']);
                }
                if (isset($data_tokentable['columns_unique'])) {
                    foreach ($data_tokentable['columns_unique'] as $unique) {
                        if (isset($save_array[$unique])) {
                            $dbdata = DB::table($data_tokentable['table_name'])
                                    ->where($unique, $save_array[$unique])
                                    ->where('web_status', '!=', 9999)
                                    ->first();
                            if ($dbdata) {
                                if (!$update) {
                                    return Redirect::back()->with('error', $fields_affected . ' Fields affected. Field' . ' "' . $unique . '" should be unique');
                                }
                            }
                        }
                    }
                }
                //simple validations and replacements
                // $save_array['phone_number']='(786) 555 6678';
                if (isset($data_tokentable['filters'])) {
                    foreach ($data_tokentable['filters'] as $key => $functions) {
                        if (isset($save_array[$key])) {
                            foreach ($functions as $func) {
                                $save_array[$key] = $this->$func($save_array[$key]);
                            }
                        }
                    }
                }
                if (isset($data_tokentable['simple_validations'])) {
                    foreach ($data_tokentable['simple_validations'] as $sv) {
                        if (isset($sv['conditions']) && isset($save_array[$sv['conditions'][0][0]])) {
                            $string_conditions = '';
                            foreach ($sv['conditions'] as $validation) {
                                if (isset($save_array[$validation[0]])) {
                                    foreach ($validation[2] as $val) {
                                        $string_conditions .= '$save_array[$validation[0]] ' . $validation[1] . ' ' . $val . ' && ';
                                    }
                                }
                            }
                            $string_conditions = substr($string_conditions, 0, -4);
                            $string_eval = 'if(' . $string_conditions . '){ $save_array[$sv[\'result\'][0]]= $sv[\'result\'][1]; }';
                            eval($string_eval);
                        }
                        if (isset($sv['conditionsFunction']) && isset($save_array[$sv['conditionsFunction'][0][0]])) {
                            $string_conditions = '';
                            foreach ($sv['conditionsFunction'] as $validation) {
                                if (isset($save_array[$validation[0]])) {
                                    foreach ($validation[3] as $val) {
                                        $string_conditions .= $validation[1] . '($save_array[$validation[0]])' . $validation[2] . $val . ' && ';
                                    }
                                }
                            }
                            $string_conditions = substr($string_conditions, 0, -4);
                            $string_eval = 'if(' . $string_conditions . '){ $save_array[$sv[\'result\'][0]]= $sv[\'result\'][1]; }';
                            eval($string_eval);
                        }
                        //Default values if not mapped when insert
                        if (isset($data_tokentable['fixed_values_insert_if_empty'])) {
                            foreach ($data_tokentable['fixed_values_insert_if_empty'] as $fvie) {
                                if (!isset($save_array[array_keys($fvie)[0]])) {
                                    $save_array = $save_array + $fvie;
                                }
                            }
                        }
                    }
                }
                //saving into database
                if (count($update)) {
                    if (isset($data_tokentable['fixed_value_to_save'])) {
                        foreach ($data_tokentable['fixed_value_to_save'] as $keyfvs => $fvs) {
                            $update[] = array($keyfvs => $fvs);
                        }
                    }
                    if (isset($data_tokentable['table_name'])) {
                        $query_update = DB::table($data_tokentable['table_name']);
                        foreach ($update as $u) {
                            $query_update->where($u);
                        }
                        if (isset($data_tokentable['matching_extra_where'])) {
                            foreach ($data_tokentable['matching_extra_where'] as $mew) {
                                $query_update->where($mew[0], $mew[1], $mew[2]);
                            }
                        }
                        if ($query_update->first()) {
                            $query_update->update($save_array);
                            $fields_affected++;
                        } else {
                            $query_update->insert($save_array);
                            $fields_affected++;
                        }
                    } else {
                        return Redirect::back()->with('error', 'Undefined field "table_name" in config.');
                    }
                } else {
                    if (isset($data_tokentable['table_name'])) {
                        if (isset($save_array['web_status']) && $save_array['web_status'] > 1000) {
                            continue;
                        } else {
                            DB::table($data_tokentable['table_name'])->insert([
                                $save_array
                            ]);
                            $fields_affected++;
                        }
                    } else {
                        return Redirect::back()->with('error', 'Undefined field "table_name" in config.');
                    }
                }
            }
            @unlink($data_tokentable['filename']);
            if (isset($data_tokentable['route_return']) && $data_tokentable['route_return']) {
                return redirect()->route($data_tokentable['route_return'], array('token' => $token))->with('success', 'The elements was imported successfully');
            } else {
                return Redirect::back()->with('success', 'The elements was imported successfully');
            }
        } else {
            return Redirect::back()->with('error', 'Something wrong');
        }
    }

    function importView($token, $tokentable, Request $request) {
        return $this->webuserimport($token, $tokentable, $request);
    }

    public function uploadfile(Request $request) {

        //echo '<pre>';
        //print_r($request->file('upfile')); die;
        //echo Session::token().' == '.Input::get('_token'); die;
        $destinationPath = public_path() . '/uploads/importfiles/web_users/';
        if ($request->hasFile('upfile')) {
            $fileExtension = $request->file('upfile')->getClientOriginalExtension();
            $filename = $request->file('upfile')->getClientOriginalName();
            $maxFileUploadSize = $request->file('upfile')->getMaxFilesize();
            $fileSize = $request->file('upfile')->getClientSize();
            //echo $maxFileUploadSize; die;
            //check for valid uploadedfile
            if (!in_array($fileExtension, $this->validWebUserImportExtensions)) {
                return json_encode(array('error' => 1, 'msg' => 'Please upload valid file. Ex. CSV and TSV.'));
            } elseif ($fileSize > $maxFileUploadSize) {
                return json_encode(array('error' => 1, 'msg' => 'Max upload limit is ' . $maxFileUploadSize . ' bytes.'));
            } elseif ($fileSize == 0) {
                return json_encode(array('error' => 1, 'msg' => 'File should be greater than zero byte.'));
            } else {
                $filename = time() . $filename;
                if (!$request->file('upfile')->move($destinationPath, $filename)) {
                    return json_encode(array('error' => 1, 'msg' => 'Error in uploading file .Please try again.'));
                } else {
                    return json_encode(array('error' => -1, 'msg' => 'File has been uploaded successfully.', 'uploadedFile' => $filename));
                }
            }
        } else {
            return json_encode(array('error' => 1, 'msg' => 'Please choose CSV, TSV and XLS files to upload.'));
        }
    }

    public function retrievedataintoarray(Request $request) {

        //echo '<pre>';
        //print_r($request->all()); die;
        $this->import_file_upload_directory = public_path() . '/uploads/importfiles/web_users/';
        $file_data = array();
        $encoding_format = $request->get('encoding_format');
        $webusers = new WebUsers();
        $ext = pathinfo($request->get('file_name'), PATHINFO_EXTENSION);
        $filename = $this->import_file_upload_directory . $request->get('file_name');
        //echo $filename; die;
        $webusertabledata = $webusers->getTableStructure();
        $saveMappingForFuture = 0;
        $level = $request->get('level');
        $idlevel = $request->get('idlevel');
        $future_mapping = $webusers->getFutureMappingName($request->get('table_name') . '_mapping', $level, $idlevel);
        //echo '<pre>';
        //print_r($future_mapping); die;
        if (!empty($future_mapping)) {
            //$future_mapping = json_encode($future_mapping['mapped_file_data']);
            $saveMappingForFuture = 1;
        }
        //echo '<pre>';
        //print_r($webusertabledata); die;
        if ($request->get('delimiter_value') == 1) {
            $delimiter = ',';
        } elseif ($request->get('delimiter_value') == 2) {
            $delimiter = ';';
        } elseif ($request->get('delimiter_value') == 3) {
            $delimiter = "\t";
        } else {
            $delimiter = '|';
        }

        if ($ext == 'xls' || $ext == 'xlsx') {
            if ($request->get('level') == 'groups') {
                $file_data = $this->getFileDataInArray($filename, '', $encoding_format, $request->get('ID_PROPERTY'));
            } elseif ($request->get('level') == 'partners') {
                $file_data = $this->getFileDataInArray($filename, '', $encoding_format, $request->get('ID_PROPERTY'));
            } else {
                $file_data = $this->getFileDataInArray($filename, '', $encoding_format);
                //echo '<pre>';
                //print_r($file_data); die;
            }

            $datareadyformapping = $this->setFileDataForMapping($request->get('table_name'), $request->get('file_name'), $request->get('delete_previous_users'), $request->get('do_not_update'), $file_data, $webusertabledata, 0, $delimiter, $encoding_format, $request->get('level'), 0, $request->get('ID_PROPERTY'));
            return array('error' => '0', 'datareadyformapping' => $datareadyformapping, 'saveMappingForFuture' => $saveMappingForFuture, 'boolsavedmapping' => $future_mapping['boolmappingsavedforfuture'], 'mapping_name' => $future_mapping['mapping_name']);
        } elseif ($ext == 'csv') {
            if ($delimiter == "\t") {
                if ($request->get('level') == 'groups') {
                    $file_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format, $request->get('ID_PROPERTY'));
                } elseif ($request->get('level') == 'partners') {
                    $file_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format, $request->get('ID_PROPERTY'));
                } else {
                    $file_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format);
                }
            } else {
                if ($request->get('level') == 'groups') {
                    $file_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format, $request->get('ID_PROPERTY'));
                } elseif ($request->get('level') == 'partners') {
                    $file_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format, $request->get('ID_PROPERTY'));
                } else {
                    $file_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format);
                }
            }
            //echo '<pre>';
            //print_r($file_data); die;
            $datareadyformapping = $this->setFileDataForMapping($request->get('table_name'), $request->get('file_name'), $request->get('delete_previous_users'), $request->get('do_not_update'), $file_data, $webusertabledata, 0, $delimiter, $encoding_format, $request->get('level'), 0, $request->get('ID_PROPERTY'));
            $boolmappingsavedforfuture = empty($future_mapping->boolmappingsavedforfuture) ? 0 : $future_mapping->boolmappingsavedforfuture;
            $mapping_name = empty($future_mapping->mapping_name) ? '' : $future_mapping->mapping_name;
            return array('error' => '0', 'datareadyformapping' => $datareadyformapping, 'saveMappingForFuture' => $saveMappingForFuture, 'boolsavedmapping' => $boolmappingsavedforfuture, 'mapping_name' => $mapping_name);
        } else {
            return array('error' => '1', 'datareadyformapping' => '');
        }
    }

    private function convertToEncoding($str) {

        if (isset($this->data['encoding_format']) && $this->data['encoding_format'] != '') {
            $encoding_format = $this->data['encoding_format'];
        } else {
            $encoding_format = 'UTF-8';
        }

        //echo mb_detect_encoding($str).'====='.$encoding_format;

        return @iconv(strtoupper(mb_detect_encoding($str)), strtoupper($encoding_format) . '//TRANSLIT', $str);
    }

    private function getFileDataInArray($filename, $delimiter, $outputencoding = 'UTF-8', $parent_level_id = 0) {

        $excelData = array();
        //echo $filename; die;
        $excelData = Excel::load($filename, $outputencoding)->toArray();
        //die;
        if ($excelData) {
            foreach ($excelData as $rowKey => $rowValue) {
                foreach ($rowValue as $columnKey => $columnValue) {
                    if (strtolower($columnKey) == 'web_status' || strtolower($columnKey) == 'action') {
                        $web_status = $this->getWebUserStatus($columnValue);
                        $excelData[$rowKey][$columnKey] = $web_status['web_status'];
                    } elseif (strtolower($columnKey) == 'partner_name') {
                        $webusers = new WebUsers();
                        $partner_detail = $webusers->getPartnerIdByName($columnValue);

                        if (!empty($partner_detail)) {
                            $excelData[$rowKey]['partner_name'] = $partner_detail['id'];
                            ;
                        } else {
                            $excelData[$rowKey]['partner_name'] = 0;
                        }
                    } elseif (strtolower($columnKey) == 'company_name') {
                        $webusers = new WebUsers();
                        $company_detail = $webusers->getCompanyIdByName($columnValue);
                        if (!empty($company_detail)) {
                            $excelData[$rowKey]['company_name'] = $company_detail['id'];
                        } else {
                            $excelData[$rowKey]['company_name'] = 0;
                        }
                    } elseif ($parent_level_id != 0) {
                        $excelData[$rowKey]['plid'] = $parent_level_id;
                    }
                }
            }
        }
        //echo '<pre>';
        //print_r($excelData); die;
        return $excelData;
    }

    //function is used to get status of the web users
    private function getWebUserStatus($action = '') {

        //var_dump($action); die;
        if (trim($action) == 'CreateInactive') {
            return array('web_status' => 0, 'force_update' => false);
        } elseif (trim($action) == 'CreateActive') {
            return array('web_status' => 1, 'force_update' => false);
        } elseif (trim($action) == 'CreateAuthorized') {
            return array('web_status' => 998, 'force_update' => false);
        } elseif (trim($action) == 'CreateUnAuthorized') {
            return array('web_status' => 999, 'force_update' => false);
        } elseif (trim($action) == 'Activate') {
            return array('web_status' => 1, 'force_update' => true);
        } elseif (trim($action) == 'Deactivate') {
            return array('web_status' => 0, 'force_update' => true);
        } else {
            return array('web_status' => 0, 'force_update' => true);
        }
    }

    private function setFileDataForMapping($tablename, $uploadedfilename, $delete_previous_users, $do_not_update, $fileData = array(), $mysqltableData = array(), $saveMappingForFuture = 0, $delimitervalue = ',', $encoding_format = 'UTF-8', $level = 'web_users', $screenaftermapping = 0, $propertyid = 0) {

        if (!$screenaftermapping) {
            $html = '<div class="col-xs-12"><div class="import_txt"><label><b>Map Fields</b></label></div></div><br>
                                <div class="col-xs-12 text-muted"><label>Your Selected File: </label>' . $uploadedfilename . '</div>';

            $html .= '<div class="col-xs-12"><div class="col-xs-12 alert alert-success">The best match to each field on the selected file have been auto-selected.</div></div>';
            //'<div class="col-xs-12">
            //    <div class="col-md text-muted">Import Tool Wizard v1.0</div>
            //    <div class="col-md text-muted">Imported File Headers</div>
            //</div>';
        } else {
            $html = '<div class="import_txt"><label>Map following fields before proceeding</label></div>';
        }
        $html .= '<form name="frmImportStep2" id="frmImportStep2" method="post" onsubmit="return false;">';
        if (!$screenaftermapping) {
            $html .= '<div class="col-xs-12 check"><div class="col-xs-3 text-muted"><span class="text check-active"><label>Import data from row :</label></span></div>
					<div class="col-xs-9"><input class="form-control" type="number" min="0" value="1" name="skiprows_toskip" id="skiprows" /></div></div>';
            $html .= '<div class="col-xs-12"><hr class="hr-responsive"></div>';
        }
        $html .= '<input type="hidden" value="' . $saveMappingForFuture . '" name="mappingsavedforfuture_toskip" id="mappingsavedforfuture" />
				<input type="hidden" value="" name="mapping_name_toskip" id="mapping_name" />
				<input type="hidden" name="import_table_name_toskip" value="' . $tablename . '" id="import_table_name" />
				<input type="hidden" name="ID_PROPERTY_toskip" id="propertyid2" value="' . $propertyid . '">
				<input type="hidden" name="uploaded_file_name_toskip" value="' . $uploadedfilename . '" id="uploaded_file_name" />
				<input type="hidden" name="file_delimiter_value_toskip" value="' . $delimitervalue . '" id="file_delimiter_value" />
				<input type="hidden" name="delete_previous_users_toskip" id="delete_previous_users2" value="' . $delete_previous_users . '">
				<input type="hidden" name="do_not_update_toskip" id="do_not_update2" value="' . $do_not_update . '">
				<input type="hidden" name="encoding_format_toskip" id="encoding_format2" value="' . $encoding_format . '">
				<input type="hidden" name="with_toskip" value="' . $level . '">';
        //echo '<pre>';
        //print_r($mysqltableData); die;

        if ($mysqltableData) {
            $field_type = '';
            $selected_text = '';
            //$visibility_text = '';
            $file_column_header = array();
            if (!empty($fileData)) {
                $file_column_header = array_keys($fileData[0]); //this contains header of the file
            }

            if ($file_column_header) {
                foreach ($file_column_header as $ckey => $cvalue) {
                    if (strtolower($cvalue) == 'company_name') {
                        $html .= '<input type="hidden" name="frm_company_name-bigint_20" value="company_name" />';
                    } elseif (strtolower($cvalue) == 'partner_name') {
                        $html .= '<input type="hidden" name="frm_partner_name-bigint_20" value="partner_name" />';
                    } elseif (strtolower($cvalue) == 'group_id') {
                        $html .= '<input type="hidden" name="frm_group_id-varchar_100" value="' . strtolower($cvalue) . '" />';
                    } elseif (strtolower($cvalue) == 'partner') {
                        $html .= '<input type="hidden" name="frm_partner-bigint_20" value="partner" />';
                    } elseif (strtolower($cvalue) == 'group') {
                        $html .= '<input type="hidden" name="frm_group-bigint_20" value="group" />';
                    } elseif (strtolower($cvalue) == 'merchant') {
                        $html .= '<input type="hidden" name="frm_merchant-bigint_20" value="merchant" />';
                    } else {
                        $html .= '<input type="hidden" name="frm_last_updated_by-datetime" value="last_updated_by" />';
                        if ($level == 'web_users') {
                            $html .= '<input type="hidden" name="frm_property_id-bigint_20" value="' . $propertyid . '" />';
                        } else {
                            $html .= '<input type="hidden" name="frm_property_id-bigint_20" value="property_id" />';
                        }
                    }
                }
            }
            if (!$screenaftermapping) {
                foreach ($mysqltableData as $key => $table_field) {
                    $table_field = (array) $table_field;
                    if (!in_array($table_field['Field'], $this->fields_to_skip)) {
                        if ($table_field['Field'] != 'id' && $table_field['Field'] != 'web_user_id') {
                            //echo $table_field['Type']; echo '<br/>';
                            $field_type = rtrim(str_replace('(', '_', $table_field['Type']), ')');
                            //echo $field_type; echo '<br/>';
                            $html .= '<div class="col-xs-12 check" style="margin-top:5px">';
                            if ($table_field['Null'] == 'NO') {
                                if ($table_field['Field'] == 'account_number') {
                                    //echo 'IN IF';
                                    $html .= '<div class="col-md-3 text-muted required"><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span></div>';
                                } elseif ($table_field['Field'] == 'first_name') {
                                    //echo 'IN IF';
                                    $html .= '<div class="col-md-3 text-muted required"><span class="text check-active">First Name</span><span style="color:red;">*</span></div>';
                                } else {
                                    if ($level == 'web_users' || $level == 'users' || $level == 'master') {
                                        if ($table_field['Field'] != 'property_id') {
                                            if ($table_field['Field'] == 'web_status') {
                                                $html .= '<div class="col-md-3 text-muted"><span class="text check-active">Action</span></div>';
                                            } elseif ($table_field['Field'] == 'companyname') {
                                                $html .= '<div class="col-md-3 text-muted"><span class="text check-active">Company Name</span></div>';
                                            } else {
                                                $html .= '<div class="col-md-3 text-muted"><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</div>';
                                            }
                                        }
                                    } else {
                                        if ($table_field['Field'] == 'web_status') {
                                            $html .= '<div class="col-md-3 text-muted"><span class="text check-active">Action</span></div>';
                                        } else {
                                            if ($table_field['Field'] == 'property_id') {
                                                $html .= '<div class="col-md-3 text-muted required"><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span><span style="color:red;">*</span></div>';
                                            } else {
                                                $html .= '<div class="col-md-3 text-muted "><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span></div>';
                                            }
                                        }
                                    }
                                }
                            } else {
                                if ($table_field['Field'] == 'account_number') {
                                    //echo 'IN ELSE';
                                    $html .= '<div class="col-md-3 text-muted required"><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span></div>';
                                } elseif ($table_field['Field'] == 'first_name') {
                                    //echo 'IN IF';
                                    $html .= '<div class="col-md-3 text-muted required"><span class="text check-active">First Name</span><span style="color:red;">*</span></div>';
                                } else {
                                    if ($level == 'web_users' || $level == 'users' || $level == 'master') {
                                        if ($table_field['Field'] != 'property_id') {
                                            if ($table_field['Field'] == 'web_status') {
                                                $html .= '<div class="col-md-3 text-muted"><span class="text check-active"> Action </span></div>';
                                            } elseif ($table_field['Field'] == 'companyname') {
                                                $html .= '<div class="col-md-3 text-muted"><span class="text check-active"> Company Name </span></div>';
                                            } else {
                                                $html .= '<div class="col-md-3 text-muted"><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span></div>';
                                            }
                                        }
                                    } else {
                                        if ($table_field['Field'] == 'web_status') {
                                            $html .= '<div class="col-md-3 text-muted"><span class="text check-active"> Action </span></div>';
                                        } else {
                                            if ($table_field['Field'] == 'property_id') {
                                                $html .= '<div class="col-md-3 text-muted required"><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span><span style="color:red;">*</span></div>';
                                            } else {
                                                $html .= '<div class="col-md-3 text-muted "><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span></div>';
                                            }
                                        }
                                    }
                                }
                            }
                            $html .= '<div class="col-md-9 text-muted">';
                            if ($file_column_header) {
                                if ($level == 'web_users' || $level == 'users' || $level == 'master') {
                                    if ($table_field['Field'] != 'property_id') {
                                        $html .= '<select class="form-control" name="frm_' . $table_field['Field'] . '-' . $field_type . '" id="frmHeader_' . $key . '">';
                                        $html .= '<option value="">--select--</option>';
                                        foreach ($file_column_header as $file_column_key => $file_column_value) {
                                            if ($table_field['Field'] == $file_column_value) {
                                                $selected_text = 'selected="selected"';
                                                //$visibility_text = 'style="display:block;"';
                                            } else {
                                                if ((strtolower($file_column_value) == 'action') && ($table_field['Field'] == 'web_status')) {
                                                    $selected_text = 'selected="selected"';
                                                    //$visibility_text = 'style="display:block;"';
                                                } else {
                                                    $selected_text = '';
                                                    //$visibility_text = 'style="display:block;"';
                                                }
                                            }
                                            $html .= '<option value="' . $file_column_value . '"' . $selected_text . ' >' . ucfirst(str_replace('_', ' ', $file_column_value)) . '</option>';
                                        }
                                        $html .= '</select>';
                                    }
                                } else {
                                    $html .= '<select class="form-control" name="frm_' . $table_field['Field'] . '-' . $field_type . '" id="frmHeader_' . $key . '">';
                                    $html .= '<option value="">--select--</option>';
                                    foreach ($file_column_header as $file_column_key => $file_column_value) {
                                        if ($table_field['Field'] == $file_column_value) {
                                            $selected_text = 'selected="selected"';
                                            //$visibility_text = 'style="display:block;"';
                                        } else {
                                            if ((strtolower($file_column_value) == 'action') && ($table_field['Field'] == 'web_status')) {
                                                $selected_text = 'selected="selected"';
                                                //$visibility_text = 'style="display:block;"';
                                            } else {
                                                $selected_text = '';
                                                //$visibility_text = 'style="display:block;"';
                                            }
                                        }
                                        $html .= '<option value="' . $file_column_value . '"' . $selected_text . ' >' . ucfirst(str_replace('_', ' ', $file_column_value)) . '</option>';
                                    }
                                    $html .= '</select>';
                                }
                            }

                            $html .= '</div>
							</div>';
                        }
                    }
                }
            } else {
                foreach ($mysqltableData as $key => $table_field) {
                    if (!in_array($table_field['Field'], $this->fields_to_skip)) {
                        if ($table_field['Field'] != 'id' && $table_field['Field'] != 'web_user_id') {
                            //echo $table_field['Type']; echo '<br/>';
                            $field_type = rtrim(str_replace('(', '_', $table_field['Type']), ')');
                            //echo $field_type; echo '<br/>';
                            if ($table_field['Field'] == 'property_id') {
                                $html .= '<div class="col-xs-12 check" style="margin-top:5px">';
                                if ($table_field['Null'] == 'NO') {
                                    $html .= '<div class="col-md-3 text-muted required"><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span><span style="color:red;">*</span></div>';
                                } else {
                                    $html .= '<div class="col-md-3 text-muted required"><span class="text check-active">' . ucfirst(str_replace('_', ' ', $table_field['Field'])) . '</span><span style="color:red;">*</span></div>';
                                }

                                $html .= '<div class="col-md-9 text-muted">';
                                if ($file_column_header) {
                                    $html .= '<select class="form-control" name="frm_' . $table_field['Field'] . '-' . $field_type . '" id="frmHeader_' . $key . '">';
                                    $html .= '<option value="">--select--</option>';
                                    foreach ($file_column_header as $file_column_key => $file_column_value) {
                                        if ($file_column_value == 'property_id') {
                                            $selected_text = 'selected="selected"';
                                            //echo 'IN IF';
                                            //$visibility_text = 'style="display:block;"';
                                        } else {
                                            $selected_text = '';
                                            //echo 'IN ELSE';
                                        }
                                        $html .= '<option value="' . $file_column_value . '"' . $selected_text . ' >' . ucfirst(str_replace('_', ' ', $file_column_value)) . '</option>';
                                    }
                                    $html .= '</select>';
                                }

                                $html .= '</div>';
                            }
                            $html .= '</div>';
                        }
                    }
                }
            }
        }
        if (!$screenaftermapping) {
            if (!empty($saveMappingForFuture)) {
                $html .= '<br><div class="col-xs-12"><div class="col-xs-12"><div class="alert alert-info checkbox checkbox-info col-xs-12">
                                                        <input type="checkbox" checked="checked" class="styled" name="frmSaveForFuture_toskip" onclick="openSaveMappingDialogue(this.id);" id="frmSaveForFuture_toskip" value="1" style="cursor:pointer; margin-left:0px; position:relative!important">
                                                        <label for="frmSaveForFuture_toskip" style="">
                                                         Save these selections for use during future imports.
                                                        </label>
                                                        </div></div></div>';
                //$html .= '<div><input type="checkbox" checked="checked" name="frmSaveForFuture_toskip" onclick="openSaveMappingDialogue(this.id);" id="frmSaveForFuture_toskip" value="1" class="topopup form-control" />&nbsp;&nbsp;Save these selections for use during future imports.</div>';
            } else {
                //$html .= '<div><input type="checkbox" name="frmSaveForFuture_toskip" id="frmSaveForFuture_toskip" onclick="openSaveMappingDialogue(this.id);" value="1" class="topopup form-control" />&nbsp;&nbsp;Would you like to save this mapping schema.</div>';
                $html .= '<br><div class="col-xs-12"><div class="col-xs-12"><div class="alert alert-info checkbox checkbox-info col-xs-12">
                                                        <input type="checkbox" class="styled" name="frmSaveForFuture_toskip" onclick="openSaveMappingDialogue(this.id);" id="frmSaveForFuture_toskip" value="1" style="cursor:pointer; margin-left:0px; position:relative!important">
                                                        <label for="frmSaveForFuture_toskip" style="">
                                                         Would you like to save this mapping schema.
                                                        </label>
                                                        </div></div></div>';
            }
            $html .= '<!--<p><strong>Note : </strong> Red colored fields are mandatory.</p></p><div class="row">-->
							<div class="col-xs-12">
                                                        <div class="col-xs-6" style="padding-bottom: 5%"><button id="previous_button_2" name="frmNextButton2" onclick="previous_step(\'2\');" class="previous form-control btn-md btn-primary" style="width:100%; height:40px"> Previous</button></div>
							<span class="loader-fix col-xs-6"><button disabled id="uploading_text_2" style="display:none;" name="frmUploadingTextTwo" class="loader_step2 uploading-text form-control btn-md btn-success" style="width:100%; height:40px">Loading...</button></span>
							<div class="col-xs-6"><input type="submit" id="frmImportDataButton" onclick="importData()" name="frmImportDataButton" value="Continue" class="continue_btn form-control btn-md btn-success" style="width:100%; height:40px" /></div>
							<!-- <div class="col-xs-2"><button id="" name="cancel_button_2" value="frmCancelButton2" onclick="cancel_process();" class="cancel form-control btn-md btn-primary">Cancel</button></div>-->
						</div></div>
				</form>';
        }
        return $html;
    }

    public function validationbeforeimport(Request $request) {
        //echo '<pre>';
        //print_r($this->data); die;
        $post_mapping_array = array();
        $post_data_array = array();
        $filename = '';
        $futuremappingdata = array();
        $post_mapping_data_array = array();
        $boolError = false;
        $current_value = '';
        $visitedHeaderArray = array();
        $skippedfields = array();
        $unmappedfields = array();
        $skiprows = '';
        $i = 0;
        $errorMsg = '';
        $mapped_file_data = array();
        $skipped_records = 0;
        $skipped_data_records = 0;
        $mapping_name = '';
        $delimiter_value = '';
        $encoding_format = '';
        //$unmappedfield = 0;
        //$unmappedFieldValue = '';
        $readytoimportRecords = 0;
        $saveMappingForFuture = 0;
        $ismappingSavedForFutureused = 0;
        $doupdate = $request->get('do_not_update_toskip');
        $webusers = new WebUsers();
        $level = $request->get('with_toskip');
        $idlevel = $request->get('ID_PROPERTY_toskip');
        $futuremappingdata = $webusers->getWebUserFutureMapping($request->get('import_table_name_toskip') . '_mapping', $level, $idlevel);
        //echo '<pre>';
        //print_r($futuremappingdata); die;
        $skiprows = 0;
        $with_t = 'web_users';
        $curr_uploaded_file_name = '';
        $curr_propertyid_toskip = 0;
        if ($request->all() !== null) {
            $post_data_array = $request->all();
        }
        if ($request->get('mapping_name_toskip') !== null) {
            $mapping_name = $request->get('mapping_name_toskip');
        }
        if ($request->get('frmSaveForFuture_toskip') !== null) {
            $saveMappingForFuture = $request->get('frmSaveForFuture_toskip');
        }
        if ($request->get('mappingsavedforfuture_toskip') !== null) {
            $ismappingSavedForFutureused = $request->get('mappingsavedforfuture_toskip');
        }
        if ($request->get('skiprows_toskip') !== null) {
            $skiprows = $request->get('skiprows_toskip');
        }
        if ($request->get('with_toskip') !== null) {
            $with_t = $request->get('with_toskip');
        }

        if ($request->get('uploaded_file_name_toskip') !== null) {
            $curr_uploaded_file_name = $request->get('uploaded_file_name_toskip');
        }
        if ($request->get('file_delimiter_value_toskip') !== null) {
            $delimiter_value = $request->get('file_delimiter_value_toskip');
        }
        if ($request->get('encoding_format_toskip') !== null) {
            $encoding_format = $request->get('encoding_format_toskip');
        }


        //echo '<pre>';
        //print_r($request->all()); die;

        if (!empty($futuremappingdata) && $ismappingSavedForFutureused) {
            $saved_mapping = (array) json_decode($futuremappingdata['mapped_file_data']);
            if (array_key_exists('ID_PROPERTY_toskip', $saved_mapping)) {
                $saved_mapping['ID_PROPERTY_toskip'] = $curr_propertyid_toskip;
            }
            if (array_key_exists('with_toskip', $saved_mapping)) {
                $saved_mapping['with_toskip'] = $with_t;
            }
            if (array_key_exists('encoding_format_toskip', $saved_mapping)) {
                $saved_mapping['encoding_format_toskip'] = $encoding_format;
            }
            //echo '<pre>';
            //print_r($saved_mapping); die;
            $post_data_array = $saved_mapping;
            //$this->data = (array)$future_mapping_arr;
            //print_r((array)$future_mapping_arr); die;
        }



        //echo '<pre>';
        //print_r($post_data_array); die;
        if (isset($post_data_array)) {
            foreach ($post_data_array as $post_key => $post_value) {
                if (!preg_match('/toskip/', $post_key)) {
                    //echo $post_key.'<br/>';
                    //var_dump($post_value);
                    if ($current_value == '' && empty($visitedHeaderArray)) {
                        //echo $post_key; die;
                        $post_key_array = explode('-', $post_key);
                        if ($post_value == '') {
                            //echo 'IN IF2';
                            $postinner = substr($post_key_array[0], 4, strlen($post_key_array[0]));
                            $post_mapping_array[$post_key_array[0]] = $postinner;
                            if (($postinner != 'property_id') && ($postinner != 'country') && ($postinner != 'entered') && ($postinner != 'entered') && ($postinner != 'last_updated_by') && ($postinner != 'balance_start_date') && ($postinner != 'company_name') && ($postinner != 'partner_name')) {
                                $skippedfields[] = $postinner;
                            }
                        } else {
                            //echo 'IN IF ELSE2';
                            if (($post_key_array[0] == 'frm_property_id') && ($with_t == 'groups' || $with_t == 'partners' || $with_t == 'web_users' || $with_t == 'users')) {
                                $post_mapping_array[$post_key_array[0]] = 'property_id';
                            } else {
                                $post_mapping_array[$post_key_array[0]] = $post_value;
                            }
                        }

                        $post_mapping_data_array[$post_key_array[0] . '_type'] = $post_key_array[1];
                        $visitedHeaderArray[$i] = $post_value;
                        $i++;
                    } elseif (!in_array($post_value, $visitedHeaderArray)) {
                        $post_key_array = explode('-', $post_key);
                        //var_dump($post_value);
                        if ($post_value == '') {
                            //echo 'IN IF2';
                            $postinner = substr($post_key_array[0], 4, strlen($post_key_array[0]));
                            $post_mapping_array[$post_key_array[0]] = $postinner;
                            if (($postinner != 'property_id') && ($postinner != 'country') && ($postinner != 'entered') && ($postinner != 'entered') && ($postinner != 'last_updated_by') && ($postinner != 'balance_start_date') && ($postinner != 'company_name') && ($postinner != 'partner_name')) {
                                $skippedfields[] = $postinner;
                            }
                        } else {
                            //echo 'IN IF ELSE2';
                            if (($post_key_array[0] == 'frm_property_id') && ($with_t == 'groups' || $with_t == 'partners' || $with_t == 'web_users' || $with_t == 'users')) {
                                $post_mapping_array[$post_key_array[0]] = 'property_id';
                            } else {
                                $post_mapping_array[$post_key_array[0]] = $post_value;
                            }
                        }
                        $post_mapping_data_array[$post_key_array[0] . '_type'] = $post_key_array[1];
                        $visitedHeaderArray[$i] = $post_value;
                        $i++;
                    } else {
                        //$visitedHeaderArray[$i] = $post_value;
                        $post_key_array = explode('-', $post_key);
                        //var_dump($post_value);
                        if ($post_value == '') {
                            //echo 'IN IF2';
                            $postinner = substr($post_key_array[0], 4, strlen($post_key_array[0]));
                            $post_mapping_array[$post_key_array[0]] = $postinner;
                            if (($postinner != 'property_id') && ($postinner != 'country') && ($postinner != 'entered') && ($postinner != 'entered') && ($postinner != 'last_updated_by') && ($postinner != 'balance_start_date')) {
                                $skippedfields[] = $postinner;
                            }
                        } else {
                            //echo 'IN IF ELSE2';
                            if (($post_key_array[0] == 'frm_property_id') && ($with_t == 'groups' || $with_t == 'partners' || $with_t == 'web_users' || $with_t == 'users')) {
                                $post_mapping_array[$post_key_array[0]] = 'property_id';
                            } else {
                                $post_mapping_array[$post_key_array[0]] = $post_value;
                            }
                        }
                        $post_mapping_data_array[$post_key_array[0] . '_type'] = $post_key_array[1];
                        $i++;
                        /* if($post_value != ''){
                          //$errorMsg = 'Columns can not have same header value';
                          //$boolError = true;
                          } */
                    }
                }
            }
        }

        //echo '<pre>';
        //print_r($post_mapping_data_array); die;
        $i = 0;
        $this->import_file_upload_directory = public_path() . '/uploads/importfiles/web_users/';
        //$file_data = array();
        $file_import_data = array();
        $ext = pathinfo($curr_uploaded_file_name, PATHINFO_EXTENSION);
        if ($curr_uploaded_file_name != '') {
            $filename = $this->import_file_upload_directory . $curr_uploaded_file_name;
        }
        $webusers = new WebUsers();
        $webusertabledata = $webusers->getTableStructure();
        $mysqlTableDataToList = $this->dataToList($webusertabledata);
        $datareadyformapping = array();
        //echo '<pre>';
        //print_r($ext);
        //die;
        //echo $this->data['with_toskip']; die;
        $delimiter = $delimiter_value;
        //$encoding_format = $this->data['encoding_format_toskip'];

        if ($ext == 'xls' || $ext == 'xlsx') {
            if ($request->get('with_toskip') == 'groups') {
                $file_import_data = $this->getFileDataInArray($filename, '', $encoding_format);
            } elseif ($request->get('with_toskip') == 'partners') {
                $file_import_data = $this->getFileDataInArray($filename, '', $encoding_format);
            } else {
                $file_import_data = $this->getFileDataInArray($filename, '', $encoding_format, 0);
            }
        } elseif ($ext == 'csv') {
            if ($delimiter == "\t") {
                if ($request->get('with_toskip') == 'groups') {
                    $file_import_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format);
                } elseif ($request->get('with_toskip') == 'partners') {
                    $file_import_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format);
                } else {
                    $file_import_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format, 0);
                }
            } else {
                if ($request->get('with_toskip') == 'groups') {
                    $file_import_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format);
                } elseif ($request->get('with_toskip') == 'partners') {
                    $file_import_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format);
                } else {
                    $file_import_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format, 0);
                }
            }
        }

        $total_number_of_records = count($file_import_data);

        //echo '<pre>';
        //print_r($file_import_data); die;
        //print_r($post_mapping_data_array); die;
        //echo $total_number_of_records; die;
        if ($file_import_data) {
            //var_dump($file_import_data); exit();
            foreach ($file_import_data as $file_data_ikey => $file_data_ivalue) {
                //$unmappedfield = 0;
                //$unmappedFieldValue = '';
                $j = 0;
                if ($file_data_ikey <= $skiprows - 2 && $skiprows != 0) {
                    continue;
                }
                if (is_array($post_mapping_array)) {
                    foreach ($post_mapping_array as $key => $value) {
                        //echo $_POST['frm_'.$key]; echo '<br/>';
                        //echo $csv_data_value[$_POST['frm_'.$key]]; echo '<br/>';
                        //echo $value.' == '.$csv_data[$csv_data_key][$value]; echo '<br/>';
                        //echo $value.' == ';
                        //echo $key.'<br/>';
                        $partial_key = substr($key, 4, strlen($key));
                        $file_headers = array_keys($file_data_ivalue);
                        $unmappedfields = array_diff($file_headers, $post_mapping_array);
                        //echo '<pre>';
                        //print_r($unmappedfields); die;
                        if (in_array(array('plid,partner,group,merchant'), $unmappedfields)) {
                            $key1 = array_search('plid', $unmappedfields);
                            if (false !== $key1) {
                                unset($unmappedfields[$key1]);
                            }
                            $key2 = array_search('partner', $unmappedfields);
                            if (false !== $key2) {
                                unset($unmappedfields[$key2]);
                            }
                            $key3 = array_search('group', $unmappedfields);
                            if (false !== $key3) {
                                unset($unmappedfields[$key3]);
                            }
                            $key4 = array_search('merchant', $unmappedfields);
                            if (false !== $key4) {
                                unset($unmappedfields[$key4]);
                            }
                        }
                        //removing property id from file header at merchant level
                        if (($with_t == 'web_users') || ($with_t == 'users')) {
                            if (in_array('property_id', $file_headers)) {
                                $mkey1 = array_search('property_id', $file_headers);
                                if (false !== $mkey1) {
                                    unset($file_headers[$mkey1]);
                                }
                            }
                        }
                        //echo '<pre>';
                        //print_r($skippedfields); die;
                        //echo $partial_key;
                        //echo $value;
                        //var_dump($mapped_file_data); exit();
                        if (in_array($value, $file_headers) && !in_array($value, $skippedfields)) {
                            $email_regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
                            //echo 'IN IF == '.substr($key, 4, strlen($key)).' == '.$key;
                            //echo strtolower(substr($key, 4, strlen($key))).' == '.$file_import_data[$file_data_ikey][$value];

                            if ((strtolower(substr($key, 4, strlen($key))) == 'first_name') && ($file_import_data[$file_data_ikey][$value] == '')) {
                                $skipped_data_records++;
                            } elseif ((strtolower(substr($key, 4, strlen($key))) == 'property_id') && (isset($file_import_data[$file_data_ikey][$value]) && $file_import_data[$file_data_ikey][$value] == '') && ($with_t == 'groups' || $with_t == 'partners')) {
                                $skipped_data_records++;
                            } elseif ((strtolower(substr($key, 4, strlen($key))) == 'property_id') && (isset($file_import_data[$file_data_ikey][$value]) && $file_import_data[$file_data_ikey][$value] == '') && ($with_t == 'groups' || $with_t == 'partners')) {
                                $skipped_data_records++;
                            }


                            if (isset($file_import_data[$file_data_ikey][$value]) && isset($post_mapping_data_array['frm_' . $partial_key . '_type'])) {
                                $mapped_file_data[$i][substr($key, 4, strlen($key))] = $file_import_data[$file_data_ikey][$value] . '||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];
                            }
                            //$mapped_csv_data[$i][$key.'_type'] = $_POST['frm_'.$key.'_type'];
                            $j++;
                        } elseif (in_array($value, $file_headers) && in_array($value, $skippedfields)) {
                            //echo strtolower(substr($key, 4, strlen($key))).' == ';
                            if (strtolower(substr($key, 4, strlen($key))) == 'first_name') {
                                $skipped_data_records++;
                            } elseif ((strtolower(substr($key, 4, strlen($key))) == 'property_id') && ($file_import_data[$file_data_ikey][$value] == '') && ($with_t == 'groups' || $with_t == 'partners')) {
                                $skipped_data_records++;
                            } elseif ((strtolower(substr($key, 4, strlen($key))) == 'property_id') && ($file_import_data[$file_data_ikey][$value] == '') && ($with_t == 'groups' || $with_t == 'partners')) {
                                $skipped_data_records++;
                            }
                            $mapped_file_data[$i][substr($key, 4, strlen($key))] = '||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];

                            $j++;
                        } else {
                            //echo 'IN ELSE == ';
                            //echo $db_table_fields_list[$j]['Type'];
                            if (in_array(strtolower($partial_key), $mysqlTableDataToList)) {
                                //echo $key.' == '.$db_table_fields_list[$j]['Field'];
                                if ($partial_key == 'property_id') {
                                    $mapped_file_data[$i][$partial_key] = '||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];


                                    foreach ($request->all() as $request_item => $request_item_key) {
                                        if (strpos($request_item, 'frm_' . $partial_key) === 0) {
                                            if (!empty($file_import_data[$file_data_ikey][$request_item_key])) {
                                                $mapped_file_data[$i][$partial_key] = $file_import_data[$file_data_ikey][$request_item_key] . '||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];
                                            }
                                        }
                                    }
                                } elseif ($partial_key == 'country') {
                                    $mapped_file_data[$i][$partial_key] = 'USA||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];
                                } elseif ($partial_key == 'entered') {
                                    $mapped_file_data[$i][$partial_key] = date('Y-m-d h:i:s') . '||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];
                                } elseif ($partial_key == 'last_updated_by') {
                                    $mapped_file_data[$i][$partial_key] = 'rosterimport||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];
                                } elseif ($partial_key == 'balance_start_date') {
                                    $mapped_file_data[$i][$partial_key] = date('Y-m-d') . '||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];
                                } else {
                                    if (strtolower($partial_key) == 'first_name') {
                                        $skipped_data_records++;
                                    } elseif ((strtolower($partial_key) == 'property_id') && ($with_t == 'groups' || $with_t == 'partners')) {
                                        $skipped_data_records++;
                                    } elseif ((strtolower($partial_key) == 'property_id') && ($with_t == 'groups' || $with_t == 'partners')) {
                                        $skipped_data_records++;
                                    }
                                    $mapped_file_data[$i][strtolower($partial_key)] = '||' . $post_mapping_data_array['frm_' . $partial_key . '_type'];
                                }
                                $j++;
                            }
                            //$unmappedFieldValue .= $value.',';
                            //$unmappedfield++;
                        }
                    }
                }
                $readytoimportRecords++;
                $i++;
            }
        }
        //die;
        //if(empty($futuremappingdata)){
        //echo '<pre>';
        //print_r($mapped_file_data); die;
        $previewfiledattobimported = $this->getPreviewFiledataImported($mapped_file_data);
        //echo '<pre>';
        //print_r($previewfiledattobimported); die;
        $readytoimportRecords = $readytoimportRecords - $skipped_data_records;
        $skipped_records = $total_number_of_records - $readytoimportRecords;
        //}
        //echo $this->data['do_not_update_toskip']; die;

        if ($saveMappingForFuture) {
            //saving mapped records for furure mapping in db
            $query = '';
            $importwizard_num = '';
            $webusers = new WebUsers();
            $level = $request->get('with_toskip');
            $idlevel = $request->get('ID_PROPERTY_toskip');
            $saveMappingExists = $webusers->getWebUserFutureMapping($request->get('import_table_name_toskip') . '_mapping', $level, $idlevel);
            if ($saveMappingExists) {
                $webusers->updateWebUserMapping(json_encode($post_data_array, true), $request->get('import_table_name_toskip') . '_mapping', $level, $idlevel);
            } else {
                $webusers->addToWebUserMapping(json_encode($post_data_array, true), $request->get('import_table_name_toskip') . '_mapping', $level, $idlevel);
            }
        } else {
            //    $webusers->deleteWebUserMapping($request->get('import_table_name_toskip').'_mapping');
        }

        //var_dump($mapped_file_data); exit();

        return array(
            'error' => '0',
            'readytoimportRecords' => (string) $readytoimportRecords,
            'unmappedfields' => (string) count($unmappedfields),
            'unmappedfieldsstr' => rtrim(implode('-', $unmappedfields), ','),
            'skippedrecords' => (string) $skipped_records,
            'uploadedfilename' => $request->get('uploaded_file_name_toskip'),
            'importtablename' => $request->get('import_table_name_toskip'),
            'skippedfieldscnt' => (string) count($skippedfields),
            'skippedfields' => rtrim(implode('-', $skippedfields), ','),
            'mapped_file_data' => json_encode($mapped_file_data),
            'previewfiledattobimported' => $previewfiledattobimported,
            'propertyid' => $request->get('ID_PROPERTY_toskip'),
            'with3' => $with_t,
            'do_not_update' => $doupdate,
            'delete_previous_users' => $request->get('delete_previous_users_toskip'),
            'encoding_format' => $encoding_format
        );
    }

    private function getPreviewFiledataImported($mappedfiledata) {

        $previewDataArray = array();
        $i = 1;
        if (!empty($mappedfiledata)) {
            $previewDataArray[0] = array_keys($mappedfiledata[0]);
            foreach ($mappedfiledata as $mappedfiledatakey => $mappedfiledatavalue) {
                $j = 0;
                if (is_array($mappedfiledatavalue)) {
                    foreach ($mappedfiledatavalue as $key => $value) {
                        $columnvalue = explode('||', $value);
                        $previewDataArray[$i][$j] = $columnvalue[0];
                        $j++;
                    }
                }
            }
        }
        return json_encode($previewDataArray);
    }

    private function dataToList($data = array()) {

        $datatolist = array();
        if ($data) {
            foreach ($data as $datakey => $dataValue) {
                $datatolist[] = strtolower($dataValue->Field);
            }
        }
        if (!empty($datatolist)) {
            return $datatolist;
        }
        return 0;
    }

    public function importFileDataToTable(Request $request) {

        $file_data = array();
        //echo '<pre>';
        //print_r($this->data); die;
        if ($request->get('mapped_file_data') !== null) {
            $file_data = (array) json_decode($request->get('mapped_file_data'));
        }

        //$acc_no = 0;
        $do_update2 = 0;
        $pl_id = 0;
        $with3 = 'web_users';
        if (($request->get('do_not_update') !== null) && $request->get('do_not_update') == 1) {
            $do_update2 = $request->get('do_not_update');
        }

        if ($request->get('ID_PROPERTY') !== null) {
            $pl_id = $request->get('ID_PROPERTY');
        }
        if ($request->get('with3') !== null) {
            $with3 = $request->get('with3');
        }
        //echo $insert_command; die;
        //echo '<pre>';
        //print_r($file_data); die;
        //echo $pre_insert_command; die;
        //echo $do_update2; die;
        //echo $pl_id; die;
        $webusers = new WebUsers();
        $result = $webusers->addDataToTable($file_data, $request->get('table_name'), $with3, $pl_id, $do_update2, $this->fields_to_not_to_import);
        return $result;
    }

    public function checkEmptyFieldsInDataSheet(Request $request) {

        $this->import_file_upload_directory = public_path() . '/uploads/importfiles/web_users/';
        $file_data = array();
        $isEmptyDataSheetField = false;
        $ext = pathinfo($request->get('uploaded_file_name'), PATHINFO_EXTENSION);
        $encoding_format = $request->get('encoding_format');
        $delimiter = $request->get('delimiter_value');
        $filename = $this->import_file_upload_directory . $request->get('uploaded_file_name');
        if ($ext == 'xls' || $ext == 'xlsx') {
            $file_data = $this->getFileDataInArray($filename, '', $encoding_format, 0);
        } elseif ($ext == 'csv') {
            if ($delimiter == "\t") {
                $file_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format, 0);
            } else {
                $file_data = $this->getFileDataInArray($filename, $delimiter, $encoding_format, 0);
            }
        }
        //echo '<pre>';
        //print_r($file_data); die;
        if ($file_data) {
            foreach ($file_data as $datasheetkey => $datasheetvalue) {
                if ($datasheetkey > 0) {
                    foreach ($datasheetvalue as $key => $dataValue) {
                        if ($dataValue == '') {
                            $isEmptyDataSheetField = true;
                        }
                    }
                    if ($isEmptyDataSheetField) {
                        break;
                    }
                }
            }
        }

        //echo $isEmptyDataSheetField; die;
        return array('isEmptyDataSheetField' => $isEmptyDataSheetField);
    }

    public function setMappingForFuture(Request $request) {

        //echo '<pre>';
        //print_r($this->data); die;
        if ($request->get('mapping_name') == '') {
            return array('error' => '1', 'message' => 'Please enter name for future mapping');
        } else {
            $webusers = new WebUsers();
            $level = $request->get('level');
            $idlevel = $request->get('idlevel');
            $saveMappingName = $webusers->getFutureMappingName('web_users_mapping', $level, $idlevel);

            if ($saveMappingName) {
                $webusers = new WebUsers();
                $webusers->updateFutureMappingName(addslashes($request->get('mapping_name')), $saveMappingName['web_users_mapping_id'], 'web_users_mapping');
            } else {
                $webusers = new WebUsers();
                $webusers->addFutureMappingName(addslashes($request->get('mapping_name')), 'web_users_mapping', $level, $idlevel);
            }
            return array('error' => '0', 'message' => 'Mapping name has been saved successfully.');
        }
    }

    public function deleteWebUser($id, $token) {
        $webusers = new WebUsers();
        $user = $webusers->getWebUserdetail($id);
        return view('manageuser.delete_webuser', ['details' => $user, 'token' => $token]);
    }

    public function deleteNewWebUser($token, $recurr_id) {
        $user = new WebUsers();
        $user->deleteWebUser($recurr_id);
        $web_user_id = $recurr_id;
        $objtx = new Transations();
        if (($objtx->getRecByUser($web_user_id) + $objtx->getRecByUser($web_user_id, 0)) > 0) {
            $dyn = $objtx->getRecListByUser($web_user_id);
            $ndyn = $objtx->getRecListByUser($web_user_id, 0);
            $idproperty = $user->get1UserInfo($web_user_id, 'property_id');
            \App\Providers\RevoPayAuditLogger::autopaymentDelete('admin', array('operation' => 'Deleting user', 'data' => array_merge($dyn, $ndyn)), 'M', $idproperty, \App\Model\WebUsers::getAuditData($web_user_id), Auth::user());
            $objtx->cancelRTxByUser($web_user_id);
        }
        return back()->with('success', 'User Deleted');
    }

    public function resetpasswordwu(Request $request) {
        $validator = Validator::make(
                        $request->all(), [
                    'xpassword' => 'required|min:8'
                        ]
        );
        if ($validator->fails()) {
            $validationMsg = '';
            $messages = $validator->messages();
            if (!empty($messages)) {
                foreach ($messages->all() as $key => $error) {
                    $validationMsg .= $error . '||';
                }
            }
            return json_encode(array('error' => 1, 'msg' => $validationMsg));
        } else {
            $webusers = new WebUsers();
            $npass = $request->get('xpassword');
            $webusers->setPasswordRaw($npass, $request->get('wuforgetpasswordid'));
            $webuserObj = WebUsers::find($request->get('wuforgetpasswordid'));
            event(new \App\Events\UserPasswordChanged($webuserObj));
            return json_encode(array('error' => -1, 'msg' => 'Password has been changed successfully.'));
        }
    }

    public function userinvoicehistory($token, $web_user_id, Request $request) {

        $atoken = decrypt($token);

        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $transactions = new Model\Invoices();
        $grid = \DataGrid::source($transactions->getInvoiceHistoryByUserId($idlevel, $level, $web_user_id));
        $grid->attributes(
                array(
                    "class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer",
                )
        );
        //print_r($grid); die;
        $grid->add($token, 'token')->style("display:none;");
        $grid->add('web_user_id', 'web_user_id')->style("display:none;");
        $grid->add('property_id', 'property_id')->style("display:none;");
        //$grid->add($idlevel,'idlevel')->style("display:none;");
        $grid->add('id', 'ID')->style("display:none;");
        //$grid->add('name','Name', true)->style("width:100px");
        $grid->add('invoice_number', 'Invoice#');
        $grid->add('amount', 'Amount')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('invoice_date', 'Date');
        $grid->add('status', 'Status');
        $grid->add('paid', 'Paid')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('invoice_due_date', 'Due Date');
        $grid->add('actionvalue', 'Action')->style("text-align:right");
        $grid->row(
                function ($row) {

            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;
            $invnumber = $row->cell('invoice_number')->value;
            $web_user_id = $row->cell('web_user_id')->value;
            $idlevel = $row->cell('property_id')->value;
            $xtoken = decrypt($token);
            $level = $xtoken['level'];
            $xtoken['level_id'] = $idlevel;
            $status = $row->cell('status')->value;

            $xtoken = encrypt($xtoken);

            // shows the button PAID if the status is different than closed
            if ('closed' != $status) {
                $row->cell('actionvalue')->value = '<div class="pull-right">
                                                        <form method="post" action="' . route('findEterm', ['token' => $token]) . '" class="nomargin">                                                        
                                                            <input type="hidden" name="_token" value="' . csrf_token() . '" >
                                                            <input type="hidden" name="xtoken" value="' . $xtoken . '" >
                                                            <input type="hidden" name="xtype" value="inv" >
                                                            <input type="hidden" name="xname_invnumber" value="' . $invnumber . '" >
                                                            <button type="submit" class="btn btn-xs btn-default" >Pay</button>
                                                        </form>
                                                    </div>';
            }

            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
            $row->cell('web_user_id')->style("display:none;");
            $row->cell('property_id')->style("display:none;");
        }
        );
        $grid->orderBy('id', 'DESC');
        $grid->paginate(5)->attributes(array("id" => "web-users-invoice-history-pg"));
        $userpaymenthistorylisthtml = view('manageuser.web_users_invoice_history', array('grid' => $grid, 'token' => $token, 'idlevel' => $idlevel))->render();
        return response()->json(array('errcode' => 0, 'msg' => $userpaymenthistorylisthtml));
    }

    public function wutickethistory($token, $wuid, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        //        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        //        list($idlevel, $level) = explode('|', $atoken);
        $webusers = new WebUsers();
        $grid = \DataGrid::source($webusers->getWebUserTicketHistory($idlevel, $level, $wuid));
        $grid->attributes(
                array(
                    "class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer",
                )
        );
        //print_r($grid); die;
        //$grid->add($token,'token')->style("display:none;");
        //$grid->add($idlevel,'idlevel')->style("display:none;");
        $grid->add('ticket_id', 'ID')->style("display:none;");
        //$grid->add('ticket_property','Ticket Prop.');
        //$grid->add('ticket_partner','Partner');

        $grid->add('ticket_name', 'Name');
        $grid->add('ticket_email', 'Email');
        $grid->add('ticket_phone','Phone');
        $grid->add('ticket_address', 'Address');
        $grid->add('ticket_type', 'Type', true)->cell(function($value) {
            switch ($value) {
                case 1:
                    return "Registration issue";
                    break;
                case 2:
                    return "Log in issue";
                    break;
                case 3:
                    return "One time payment issue";
                    break;
                case 4:
                    return "Auto pay issue";
                    break;
                case 5:
                    return "Question about already made payment";
                    break;
                case 6:
                    return "Balance due question";
                    break;
                case 101:
                    return "Increase payment limits";
                    break;
                case 100:
                    return "Bank account change";
                    break;
                case 99:
                    return "Cancel Merchant Account";
                    break;
                default:
                    return "Other";
                    break;
            }
        });

        $grid->add('ticket_date_submitted', 'Date Submitted')->cell(function ($value) {
            return date('m/d/Y, g:i a', strtotime($value));
        });
        $grid->add('ticket_notes', 'Content')->style("word-wrap: break-word");
        $grid->add('ticket_user_type','Request by', true)->cell(function ($value){
            switch ($value){
                case 0:
                    return "User";
                    break;
                case 1:
                    return "Admin";
                    break;
            }
        });
        $grid->add('ticket_status', 'Status')->cell(
                function ($value) {
            switch ($value) {
                case 0:
                    return '<span class = "label label-warning pull-left"> New </span>';
                case 1:
                    return '<span class = "label label-success pull-left"> Closed </span>';
                case 2:
                    return '<span class = "label label-warning2 pull-left"> Open </span>';
            }
        }
        );
        //$grid->add('actionvalue','Action');
        $grid->row(
                function ($row) {
            $row->cells[0]->style("display:none;");
        }
        );
        $grid->orderBy('ticket_id', 'DESC');
        $grid->paginate(5)->attributes(array("id" => "web-users-ticket-history-pg"));
        $webusertickgethistoryHtml = view('manageuser.web_users_ticket_history', array('grid' => $grid, 'token' => $token, 'idlevel' => $idlevel, 'web_user_id' => $wuid))->render();
        //        return view('manageuser.web_users_ticket_history', array('grid' => $grid, 'token' => $token, 'idlevel' => $idlevel, 'web_user_id' => $wuid));
        return response()->json(array('errcode' => 0, 'msg' => $webusertickgethistoryHtml));
    }

    public function addWebUser($token, Request $request) {
        //        list($data) = explode('|', Crypt::decrypt($token));
        //        $array_token = json_decode($data, 1);
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        //        $idadmin = $array_token['iduser'];
        //        $token = Crypt::encrypt($data . '|' . time() . '|' . config('app.appAPIkey'));

        $webusers = new WebUsers();
        $layouts = null;
        $property_id = $idlevel;
        $showcn = false;
        $acctext = 'Account Number';
        $accreq = 0;
        $obj_layout = new Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        
        if (!empty($property_id)) {
            $obj_prop = new Model\Properties();
            $idpartner = $obj_prop->get1PropertyInfo($property_id, 'id_partners');
            $idcompany = $obj_prop->get1PropertyInfo($property_id, 'id_companies');
            $ot = $obj_prop->getcredOneTimeCredentials($property_id);
            if (!empty($ot)) {
                $count = count($ot);
            }
            $ot = $obj_prop->getcredRecurringCredentials($property_id);
            if (!empty($ot)) {
                $countr = count($ot);
            }
            $obj_customize = new Model\Customize();
            $idgroup = $obj_customize->getPropertiesGroup($property_id);
            $ddf = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'SHOWCOMPANYNAME');
            if ($ddf == 1) {
                $showcn = true;
            }
            $acctext = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'PAYMENT_NUMBER_REG_NUMBER');
            $accreq = $obj_customize->getSettingValueProperty($idpartner, $idcompany, $idgroup, 'PAYMENT_NUMBERS');
            
        }
        $acctext=$obj_layout->extractLayoutValue('label_acc_number',$layouts);
        $user_payment_type = array();

        $partnerlist = $companylist = $merchantlist = array();

        if (strtoupper($level) == "B") {
            $partnerlist = $webusers->getPartnerList();
        }

        if (strtoupper($level) == "P") {
            $merchantlist = $webusers->getCompanyListByPartner($idlevel);
        }

        if (strtoupper($level) == "G") {
            $merchantlist = $webusers->getMerchantListByGroup($idlevel);
        }
        return view(
                'manageuser.webusernew', array(
            'pageTitle' => $obj_layout->extractLayoutValue('label_new_user',$layouts),
            'partnerlist' => $partnerlist,
            'companylist' => $companylist,
            'merchantlist' => $merchantlist,
            'token' => $token, 'idlevel' => $idlevel,
            'level' => $level, 'showcn' => $showcn,
            'layouts' => $layouts,
            'accreq' => $accreq,
            'acctext' => $acctext)
        );
    }

    public function SaveExportMapping(Request $request) {
        //        $atoken = decrypt($request->get('token'));
        $idlevel = $request->get('idlevel');
        $level = $request->get('level');
        $validator = Validator::make(
                        $request->all(), [
                    'frmDelimiter' => 'required'
                        ]
        );

        $querySelect = explode(",", $request->get('webuserfieldtoexport'));
        unset($querySelect[count($querySelect) - 1]);

        if ($validator->fails()) {
            $validationMsg = '';
            $messages = $validator->messages();

            if (!empty($messages)) {
                foreach ($messages->all() as $key => $error) {
                    $validationMsg .= $error;
                }
            }

            return response()->json(array('error' => 1, 'msg' => $validationMsg));
        } else {
            $delimiter = "";
            if ($request->get('frmDelimiter') == 1) {
                $delimiter = ",";
            } elseif ($request->get('frmDelimiter') == 2) {
                $delimiter = ";";
            } elseif ($request->get('frmDelimiter') == 3) {
                $delimiter = "\t";
            } else {
                $delimiter = "|";
            }
            if ($querySelect == '') {
                return response()->json(array('error' => 1, 'message' => 'Please select at least a field to export.'));
            }

            $mappingName = $request->get('mapping_name');
            $exportFormat = array();
            $exportFormat['delimiter'] = $delimiter;
            $exportFormat['fields'] = $querySelect;
            $jsonEncodeEF = json_encode($exportFormat);

            $obj_webUser = new WebUsers();
            $obj_webUser->StoreExportFormat($jsonEncodeEF, $level, $idlevel, $mappingName);
        }
        return response()->json(array('error' => 0, 'message' => "Mapping name has been saved successfully."));
    }

    public function ReadExportMapping(Request $request) {
        $atoken = decrypt($request->get('atoken'));
        list($idlevel, $level) = explode('|', $atoken);

        $obj_webUser = new WebUsers();
        $usrExport = $obj_webUser->GetUsrExportFormat($level, $idlevel);
        $MappingArray = (array) json_decode($usrExport['mapped_file_data']);

        if (empty($usrExport)) {
            return response()->json(array('error' => 1, 'msg' => "Mapping hasn't been found."));
        } else {
            return response()->json(array('error' => 0, 'name' => $usrExport['mapping_name'], 'mapping' => $MappingArray));
        }
    }

    public function getUserDetails($token, Request $request) {
        $id = $request->get('id');
        $webuser = new WebUsers();
        $webuser_db = $webuser->getWebUserdetail($id);

        //var_dump($webuser_db); exit();
        return view('manageuser.userdetails', array('user' => $webuser_db,'token'=>$token));
    }

    public function userpcategories($token, $id, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        //        list($idlevel, $level) = explode('|', $atoken);

        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        //security

        $user = new WebUsers();
        //$categories = $user->getCategByUser($id, 1);
        //var_dump($user->getCategByUser($id, 1,1)); exit();


        $grid = \DataGrid::source($user->getCategByUser($id, 1, 0));
        $grid->attributes(
                array(
                    "class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer",
                )
        );



        $grid->add('id', 'id')->style('display:none');
        ;
        $grid->add('code', 'Code');
        $grid->add('description', 'Description');
        $grid->add('amount', 'Amount')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });

        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(
                function ($row) {
            $row->cell('id')->style("display:none;");
            $id = $row->cell('id')->value;
            $code = $row->cell('code')->value;
            $description = $row->cell('description')->value;
            $amount = str_replace('$', '', $row->cell('amount')->value);
            $row->cell('actionvalue')->value('<div class="pull-right"><button onclick="editCatModal(' . $id . ',\'' . $code . '\',\'' . $description . '\', \'' . $amount . '\');" class="btn btn-xs btn-default">Edit</button></div>');
        }
        );
        $grid->paginate(15);


        $webusercategories = view('manageuser.web_users_categories', array('grid' => $grid))->render();

        return response()->json(array('errcode' => 0, 'msg' => $webusercategories));
    }

    public function userstatements($token, $id, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        //        list($idlevel, $level) = explode('|', $atoken);

        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        //security

        $user = new WebUsers();

        $grid = \DataGrid::source($user->getStatementByUser($id));
        $grid->attributes(
                array(
                    "class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer",
                )
        );
        $grid->add('ids', 'ids')->style("display:none;");
        $grid->add('billcycle', 'Period');
        $grid->add('amount', 'Amount')->cell(function ($value) {
            return '$' . number_format($value, 2);
        });
        $grid->add('sfile', 'Document');
        $grid->row(
                function ($row) use ($token) {
            $row->cell('ids')->style("display:none;");
            $id = $row->cell('ids')->value;
            $row->cell('sfile')->value = '<a href="' . route('getdocument', ['token' => $token, 'type' => 'S', 'id' => $id]) . '" target="_blank">' . $row->cell('sfile')->value . '</a>';
        }
        );
        $grid->paginate(12);
        $webusercategories = view('manageuser.web_users_statements', array('grid' => $grid))->render();

        return response()->json(array('errcode' => 0, 'msg' => $webusercategories));
    }

    function getdocument($token, $type, $id, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        switch ($type) {
            case 'S':
                $rs = DB::table('statements')->where('ids', $id)->select('sfile')->first();
                if (!empty($rs)) {
                    $rfile = $rs->sfile;
                    $sfilepath = env('statement_path');
                    if (!empty($sfilepath) && !empty($rfile)) {
                        if (file_exists($sfilepath . '/' . $rfile)) {
                            header('Content-type: application/pdf');
                            header('Content-Disposition: inline; filename="' . $rfile . '"');
                            header('Content-Transfer-Encoding: binary');
                            header('Content-Length: ' . filesize($sfilepath . '/' . $rfile));
                            header('Accept-Ranges: bytes');
                            @readfile($sfilepath . '/' . $rfile);
                        }
                    }
                }
                break;
        }
    }

    function getsdibill($token, $id, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $usr = new WebUsers();
        $usrdata = $usr->getUserData($id);
        $property_id = $usr->get1UserInfo($id, 'property_id');
        $objprop = new Model\Properties();
        $idpartner = $objprop->get1PropertyInfo($property_id, 'id_partners');
        $idcompany = $objprop->get1PropertyInfo($property_id, 'id_companies');
        $sdiformat = $objprop->getPropertySettings($property_id, $idcompany, $idpartner, 'SDIFORMAT');
        if (empty($sdiformat)) {
            //default is HA
            return view('viewbill.viewbill_ha', (array) $usrdata);
        } else {
            if ($sdiformat == 'WE') {
                //we format
                return view('viewbill.viewbill_we', (array) $usrdata);
            } else {
                //ha format
                return view('viewbill.viewbill_ha', (array) $usrdata);
            }
        }
    }

    public function usereditcategory($token, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        //        list($idlevel, $level) = explode('|', $atoken);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        //security

        $validator = Validator::make(
                        $request->all(), [
                    'editCatCode' => 'required|max:50',
                    'editCatDesc' => 'required|max:255',
                    'editCatAm' => 'required',
                    'editCatId' => 'required',
                        ]
        );
        if ($validator->fails()) {
            return redirect()->back()->with(array('error'=>'The form has errors', 'tabcategories'=>1));
        } else {
            $webuser = new WebUsers();

            $webuser->updateCategById($request->get('editCatId'), $request->all(), $idlevel);

            return redirect()->back()->with(array('success'=>'Saved successfully', 'tabcategories'=>1));
        }
    }

    public function usernewticket($token, Request $request) {
        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        //        list($idlevel, $level) = explode('|', $atoken);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        //security

        $validator = Validator::make(
                        $request->all(), [
                    'ticketcontent' => 'required|min:1',
                    'editTicketId' => 'required',
                    'editTicketType' => 'required',
                        ]
        );
        if ($validator->fails()) {
            return redirect()->back()->with('error', 'The form has errors');
        } else {
            $webuser = new WebUsers();
            $objprop = new Model\Properties();

            $web_user_id = $request->input('editTicketId');
            $id_property = $webuser->get1UserInfo($web_user_id, 'property_id');
            $id_partner = $objprop->get1PropertyInfo($id_property, 'id_partners');
            $id_company = $objprop->get1PropertyInfo($id_property, 'id_companies');
            $email = $webuser->get1UserInfo($web_user_id, 'email_address');
            $phone = $webuser->get1UserInfo($web_user_id, 'phone_number');
            $name = $webuser->get1UserInfo($web_user_id, 'first_name') . ' ' . $webuser->get1UserInfo($web_user_id, 'last_name');
            $type = $request->input('editTicketType');
            //$id_user= Auth::id();
            //$type_user=1;
            $notes = $request->input('ticketcontent');
            DB::table('tickets')->insert([
                'ticket_property' => $id_property,
                'ticket_partner' => $id_partner,
                'ticket_company' => $id_company,
                'ticket_email' => $email,
                'ticket_type' => $type,
                'ticket_name' => $name,
                'ticket_phone' => $phone,
                'ticket_notes' => $notes,
                'ticket_user_id' => $web_user_id
            ]);
            return redirect()->back()->with('success', 'Saved successfully');
        }
    }

    public function userupdateCategories($token, $id_user, $idprop, Request $request) {

        $atoken = \Illuminate\Support\Facades\Crypt::decrypt($token);
        //        list($idlevel, $level) = explode('|', $atoken);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $data = str_replace('"', '', $request->get('newcats'));
        $data = str_replace('[', '', $data);
        $data = str_replace(']', '', $data);
        $data_array = explode(',', $data);

        $datanew = str_replace('"', '', $request->get('createdcats'));
        $datanew = str_replace('[', '', $datanew);
        $datanew = str_replace(']', '', $datanew);
        $datanew_array = explode(',', $datanew);


        $wuser = new WebUsers();
        $wupid = $wuser->get1UserInfo($id_user, 'property_id');
        DB::table('web_users_category')->where('description', '!=', 'Payment')->where('web_user_id', $id_user)->delete();



        foreach ($data_array as $desc) {
            $desc = explode('|||', $desc);


            $wu_cat = $wuser->getPaymentTypeByPropDesc($idprop, $desc[0]);

            if ($wu_cat) {
                $wu_cat = (array) $wu_cat;



                $datactg = array();
                $datactg['web_user_id'] = $id_user;
                $datactg['property_id'] = $wu_cat['property_id'];
                $datactg['description'] = $wu_cat['payment_type_name'];
                if (isset($desc[1]))
                    $datactg['code'] = $desc[1];
                $datactg['amount'] = $wu_cat['amount'];
                $datactg['is_balance'] = $wu_cat['is_balance'];
                DB::table('web_users_category')->insert($datactg);
            }
        }



        if (is_array($datanew_array)) {
            foreach ($datanew_array as $item) {
                if ($item) {
                    $item_array = explode('|||', $item);
                    if (isset($item_array[0])) {
                        $datactg = array();
                        $datactg['web_user_id'] = $id_user;
                        $datactg['property_id'] = $wupid;
                        $datactg['description'] = $item_array[1];
                        $datactg['code'] = $item_array[0];
                        $datactg['amount'] = $item_array[2];
                        $datactg['added'] = 1;
                        DB::table('web_users_category')->insert($datactg);
                    }
                }
            }
        }

        return redirect()->back()->with(array('success'=>'Saved successfully', 'tabcategories'=>1));
    }

    public function confirmsso($token, Request $request) {
        $atoken = decrypt($token);
        $dfsso = explode('|', $atoken);
        if (count($dfsso) == 3) {
            $fg = json_decode($dfsso[0], true);
            if (!$fg) {
                return response()->json(array('response' => 261, 'responsetext' => 'Invalid Token'));
            }
            $web_user_id = $fg['web_user_id'];
            $property_id = $fg['id_property'];
            $time = 9501;
            $apikey = $dfsso[2];
        } else {
            $web_user_id = $dfsso[0];
            $property_id = $dfsso[1];
            $time = $dfsso[2];
            $apikey = $dfsso[3];
        }
        if ($time != 9501) {
            if (($time + 30) < time()) {
                return response()->json(array('response' => 261, 'responsetext' => 'Invalid Token'));
            }
        }
        if ($apikey != config('app.appAPIkey')) {
            return response()->json(array('response' => 261, 'responsetext' => 'Invalid Token'));
        }
        if ($web_user_id <= 0) {
            return response()->json(array('response' => 261, 'responsetext' => 'Invalid Token'));
        }
        $objuser = new WebUsers();
        $status = $objuser->get1UserInfo($web_user_id, 'web_status');
        if ($status == 0 || $status == 999 || $status >= 1000) {
            $property = new Model\Properties();
            $merchant = $property->getPropertyInfo($property_id);
            $idproperty = $merchant['id'];
            $idcompany = $merchant['id_companies'];
            $idpartner = $merchant['id_partners'];
            $setting_ftime = $property->getLoginSetting($idproperty, $idcompany, $idpartner);
            $setting_qp = 0;
            $regsetting = 1;
            $base_parts = explode('/', $request->url());
            array_pop($base_parts);
            $base_url = implode('/', $base_parts);
            $data = array('pageTitle' => 'Inactive', 'merchant' => $merchant, 'setting_ftime' => $setting_ftime, 'setting_qp' => $setting_qp, 'base_url' => $base_url);
            $data['regsetting'] = $regsetting;
            $data['nologin'] = 1;
            $data['textHdr'] = "Your account is Inactive!";
            $data['textBody'] = view('components.mail2accountinactive', array('base_url' => $base_url, 'nologin' => 1));
            $data['hidemerchantinfo'] = $property->getPropertySettings($idproperty, $idcompany, $idpartner, 'hidemerchantinfo');
            return view('openview_ext', $data);
        }
        $objuser->set1UserInfo($web_user_id, 'web_status', 1);
        $idproperty = $objuser->get1UserInfo($web_user_id, 'property_id');
        $backtoken = \Illuminate\Support\Facades\Crypt::encrypt($web_user_id . '|' . $property_id . '|' . time() . '|' . config('app.appAPIkey'));
        $payor_url = config('app.payor_portal_url') . '/api2/sso2/' . $backtoken;
        return redirect($payor_url);
    }

    function cleanString($string) {
        $string = str_replace(array('[\', \']'), '', $string);
        $string = preg_replace('/\[.*\]/U', '', $string);
        $string = preg_replace('/&(amp;)?#?[a-z0-9]+;/i', '-', $string);
        $string = htmlentities($string, ENT_COMPAT, 'utf-8');
        $string = preg_replace('/&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);/i', '\\1', $string);
        $string = preg_replace(array('/[^a-z0-9]/i', '/[-]+/'), '', $string);
        return strtolower(trim($string));
    }

}
