<?php

namespace App\Http\Controllers;

use App\Http\Models\Partners;
use App\Model;
use App\Model\Companies;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Image;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class ManageGroupController extends Controller {

    public function __construct()
    {
        $this->middleware('auth');
    }

    function managegroups($token, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'B' && $level != 'P' && $level != 'A') {
            return redirect(route('accessdenied'));
        }

        $group_obj = new Companies();
        $groups = $group_obj->getGroupByFilter($level, [$idlevel]);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $filter = \DataFilter::source($groups);

        $filter->add('compositeID_companies', $obj_layout->extractLayoutValue('label_group',$layouts).' ID', 'text');
        $filter->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts).' Name', 'text')->attributes(array('style' => 'max-width:140px;'));
        $filter->add('layout.lay_name', 'Layout', 'text');
        $filter->submit('Search');
        $filter->reset('Reset');
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add($token, $token)->style("display:none;");
        $grid->add('id', 'ID')->style("display:none;");
        if ($level == 'B' || $level=='A') {
            $grid->add('partner', 'Partner');
        }

        $grid->add('compositeID_companies', $obj_layout->extractLayoutValue('label_group',$layouts).' ID');
        $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts).' Name');
        $grid->add('contact_name', 'Contact Name');
        $grid->add('contact_email', 'Contact Email')->cell(
                function ($value) {
            if (strlen($value) > 10) {
                return '<a  data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 10) . '....</a>';
            } else {
                return $value;
            }
        }
        );
        $grid->add('phone_number', 'Phone number');
        $grid->add('layout', 'Layout');

//
        $grid->add('actionvalue', 'Action');

        $grid->row(
                function ($row) {
            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;
            $open_link = '<li><a href="" >Open</a></li>';
            $edit_link = '<li><a href="../groupedit/' . $token . '/' . $id . '" >Edit</a></li>';
            //$delete_link = '<li><a onclick="deletegroup(' . $id . ')" >Delete</a></li>';
                    $token_g = \Illuminate\Support\Facades\Crypt::encrypt(['level' => "G", 'level_id' => $id]);

            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret" ></span></button>
								<ul class="dropdown-menu">
								<li><a href="#" onclick="openg(\''.$token_g.'\');" >Open</a></li>
							<li><a data="' . $id . '" class="group_details_link">Detail</a></li>

							' . $edit_link . '
							<li><a onclick="javascript:showModalNotes('.$id.','."'G'".');">Notes</a></li>
														  </ul>
	 													</div>';
            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('manage.group.groups', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function addgroup($token) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        if ($level != 'B' && $level != 'P' && $level != 'A') {
            return redirect(route('accessdenied'));
        }
        $obj_partners = new Model\Partners();
        $partners = $obj_partners->getAllPartners();
        return view('manage.group.addgroup', array('token' => $token, 'partners'=>$partners));
    }

    function savegroup($token, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        $groups = $request->all();


        $request->validate([
            'txtcompid' => 'required|max:100',
            'txtcname' => 'required|max:255',
            'txtsdcname' => 'required|max:255',
            'txtemail' => 'max:100',
            'txtcity' => 'max:100',
            'ddlstate' => 'max:5',
            'txtzip' => 'max:25',
            'ddllayout' => 'max:11',

        ]);

        $objgroup = new Companies();

        $db_group_aux = $objgroup->getCompanyBySubdomain($groups['txtsdcname']);
        if($db_group_aux){
            return redirect()->back()->withErrors("The Sub domain is in use, please change it and try again.")->withInput();
        }


        if ($level == 'P') {
            $groups['ddlpartner'] = $idlevel;
        }
        if ($level == 'A'){
            $groups['ddlpartner'] = $request['ddlpartner'];
        }


        $groups['updated_by'] = Auth::user()->username;
        $groups['branch'] = $idlevel;

        if ($request->hasFile('logo')) {

            $newlogof = $idlevel . '_' . time() . '_logo.jpg';
            Image::make($request->file('logo')->getRealPath())->widen(255, function ($constraint) {
                $constraint->upsize();
            })->heighten(72, function ($constraint) {
                $constraint->upsize();
            })->resizeCanvas(255, 72, 'center', false, 'ffffff')->save('logos/companies/' . $newlogof, 100);

            $groups['logo'] = $newlogof;
        }
        if (empty($groups['txtcontactname'])) {
            $groups['txtcontactname'] = '';
        }
        if (empty($groups['txtemail'])) {
            $groups['txtemail'] = '';
        }
        if (empty($groups['txtaddress'])) {
            $groups['txtaddress'] = '';
        }
        if (empty($groups['txtcity'])) {
            $groups['txtcity'] = '';
        }
        if (empty($groups['ddlstate'])) {
            $groups['ddlstate'] = '';
        }
        if (empty($groups['txtzip'])) {
            $groups['txtzip'] = '';
        }
        if (empty($groups['txtphone'])) {
            $groups['txtphone'] = '';
        }
        if (empty($groups['logo'])) {
            $groups['logo'] = '';
        }

        if (empty($groups['ddllayout'])) {
            $groups['ddllayout'] = 0;
        }

        $objgroup->saveGroup($groups);
        return redirect()->route('groups', array('token' => $token))->with('success', 'Data saved successfully.');
    }

    function deletegroup($id) {

        $objgroup = new Companies();
        if ($objgroup->deleteGroup($id)) {
            return array('errcode' => '0', 'message' => 'Record deleted successfully.');
        } else {
            return array('errcode' => '1', 'message' => 'Error deleting record.');
        }
    }

    function getGroupDetails($token, Request $request) {
        $id = $request->get('id');
        $objgroup = new Companies();
        $group_db = $objgroup->getGroupdetail($id);

        return view('manage.group.groupdetails', array('group' => $group_db, 'token' => $token));
    }

    function editGroup($token, $id) {
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $objgroup = new Companies();
        $group_db = $objgroup->getGroupdetail($id);
        $grid=null;
        if($level=='A'){
            $apiobj=new \App\Http\Models\ApiUser();
            $keys=$apiobj->getByLevel($id, 'G');
            $grid = \DataGrid::source($keys);
            $grid->add($token, $token)->style("display:none;");
            $grid->add('idapi', 'id')->style("display:none;");
            $grid->add('apiusername', 'Legacy Username');
            $grid->add('lvcode', 'Token');
            $grid->add('created_on','Date Created');
            $grid->add('actionvalue', 'Action')->style("text-align:right;");
            $grid->row(
                    function ($row) {
                $id = $row->cell('idapi')->value;
                $edit_link = '';
                $delete_link = '<li><a onclick="deletekey(' . $id . ')" >Delete</a></li>';
                $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                                <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
                                                                            <span class="caret" ></span></button>
                                                                    <ul class="dropdown-menu">
                                                            ' . $edit_link . '
                                                            ' . $delete_link . '
                                                                                                                      </ul>
                                                                                                                    </div>';
                $row->cell('idapi')->style("display:none;");
                $row->cells[0]->style("display:none;");
            }
            );
            $grid->orderBy('idapi', 'ASC');
            $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));
        }
        
        return view('manage.group.editgroup', array('group' => $group_db, 'token' => $token,'grid'=>$grid,'idgroup'=>$id));
    }

    function updategroup(Request $request) {
        $id = $request['id'];
        $token = $request['token'];
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken ['level'];
        $groups = $request->all();

        $groups['updated_by'] = Auth::user()->username;

        $request->validate([
            'txtcompid' => 'required|max:100',
            'txtcname' => 'required|max:255',
            'txtsdcname' => 'required|max:255',
            'txtemail' => 'max:100',
            'txtcity' => 'max:100',
            'ddlstate' => 'max:5',
            'txtzip' => 'max:25',
            'ddllayout' => 'max:11',

        ]);

        $objgroup = new Companies();
        $db_group_aux = $objgroup->getCompanyBySubdomain($groups['txtsdcname']);

        if($db_group_aux && $db_group_aux->id != (int)$id ){
            return redirect()->back()->withErrors("The Sub domain is in use, please change it and try again.")->withInput();
        }


        $logof = $request['logof'];
        if ($request->hasFile('logo')) {
            if (trim($logof) != '') {
                if (file_exists('/logos/companies/' . $logof)) {
                    unlink('/logos/companies/' . $logof);
                }
            }
            $newlogof = $idlevel . '_' . time() . '_logo.jpg';
            Image::make($request->file('logo')->getRealPath())->widen(255, function ($constraint) {
                $constraint->upsize();
            })->heighten(72, function ($constraint) {
                $constraint->upsize();
            })->resizeCanvas(255, 72, 'center', false, 'ffffff')->save('logos/companies/' . $newlogof, 100);

            $groups['logo'] = $newlogof;
        } else {
            $groups['logo'] = $logof;
        }
        if (empty($groups['txtcontactname'])) {
            $groups['txtcontactname'] = '';
        }
        if (empty($groups['txtemail'])) {
            $groups['txtemail'] = '';
        }
        if (empty($groups['txtaddress'])) {
            $groups['txtaddress'] = '';
        }
        if (empty($groups['txtcity'])) {
            $groups['txtcity'] = '';
        }
        if (empty($groups['ddlstate'])) {
            $groups['ddlstate'] = '';
        }
        if (empty($groups['txtzip'])) {
            $groups['txtzip'] = '';
        }
        if (empty($groups['txtphone'])) {
            $groups['txtphone'] = '';
        }
        if (empty($groups['logo'])) {
            $groups['logo'] = '';
        }
        if (empty($groups['ddllayout'])) {
            $groups['ddllayout'] = '';
        }




        $objgroup->updateGroup($groups, $id);
        return redirect()->route('groups', array('token' => $token))->with('success', 'Data updated successfully');
    }
    
    public function groupapirevostore($token, $id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        if($level!='A'){
            return Redirect::back()->with('error', 'Invalid priviledges');
        }
        $data=$request->all();
        unset($data['_token']);
        $apiusr=trim($data['lusername']);
        $apipassw=trim($data['lpassword']);
        //verify username is unique
        $apiobj=new \App\Http\Models\ApiUser();
        if($apiobj->existsUsername($apiusr)){
            return Redirect::back()->with('error', 'This username exists already. Please change it and try again');
        }
        $newdata = array('usr' => $apiusr, 'psw' => $apipassw);
        $current_p = json_encode($newdata);
        $newtoken = \Illuminate\Support\Facades\Crypt::encrypt($current_p . "|" . time() . "|" . config('app.appAPIkey'));
        DB::table('api_user')->insert(['apiusername' => $apiusr, 'apipasswd' => sha1($apipassw), 'lvcode' => $newtoken, 'id_company' => $id]);
        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    public function newgapirevo($token,$id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        if($level!='A'){
            return Redirect::back()->with('error', 'Invalid priviledges');
        }
        $api_obj=new \App\Http\Models\ApiUser();
        $newusername = 'apix' . $id . $level . $idlevel . time();
        $newpassw = 'pwd' . $id . $level . $idlevel . time();
        if ($api_obj->existsUsername($newusername)) {
            $newusername.=time();
        }
        $apiusr=$newusername;
        $apipassw=$newpassw;
        $newdata = array('usr' => $apiusr, 'psw' => $apipassw);
        $current_p = json_encode($newdata);
        $newtoken = \Illuminate\Support\Facades\Crypt::encrypt($current_p . "|" . time() . "|" . config('app.appAPIkey'));
        DB::table('api_user')->insert(['apiusername' => $apiusr, 'apipasswd' => sha1($apipassw), 'lvcode' => $newtoken, 'id_company' => $id]);
        return Redirect::back()->with('success', 'The key was generated successfully');
    }
}
