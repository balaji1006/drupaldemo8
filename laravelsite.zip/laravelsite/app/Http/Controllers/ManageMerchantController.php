<?php

namespace App\Http\Controllers;

use App\Model;
use App\Model\Properties;
use App\Model\Ivr;
use App\Model\Layout;
use App\Model\Partners;
use App\Model\MerchantAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Image;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Validator;

class ManageMerchantController extends Controller {

    public function __construct()
    {
        $this->middleware('auth');
    }

    function managemerchant($token, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level == 'M') {
            return redirect(route('accessdenied'));
        }

        $merchant_obj = new Properties();
        $groups = $merchant_obj->getMerchantByFilter($level, [$idlevel]);
        $obj_layout = new \App\Model\Layout();
        $layouts = $obj_layout->getLayoutValues($idlevel,$level);
        $filter = \DataFilter::source($groups);

        if ($level == 'B' || $level=='A') {
            $filter->add('partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts), 'text')->attributes(array('style' => 'max-width:130px;'));
        }
        if ($level != 'G'){
            $filter->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts), 'text')->attributes(array('style' => 'max-width:130px;'));
        }
        $filter->add('properties.name_clients', $obj_layout->extractLayoutValue('label_merchant',$layouts), 'text')->attributes(array('style' => 'max-width:130px;'));
        $filter->add('compositeID_clients', 'PaypointID', 'text')->attributes(array('style' => 'max-width:150px;'));
        $filter->submit('Search');
        $filter->reset('Reset');
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add('id', 'id')->style("display:none;");
        if ($level == 'B' || $level=='A') {
            $grid->add('partner_title', $obj_layout->extractLayoutValue('label_partner',$layouts),true);
        }
        if ($level != 'G'){
            $grid->add('company_name', $obj_layout->extractLayoutValue('label_group',$layouts),true);
        }

        $grid->add('name_client', $obj_layout->extractLayoutValue('label_merchant',$layouts),true);
        $grid->add('compositeID_clients', 'PaypointID',true);
        $grid->add('status_pp', 'Payment Page');
        $grid->add('date_new', 'Created at',true);
        $grid->add('units', 'Units',true);

        $grid->add('actionvalue', 'Action');
        $grid->row(function ($row) use ($level, $idlevel, $token) {
            $id = $row->cell('id')->value;
            $mprofile_link='';
            if($idlevel=='A'){
                $mprofile_link='<li><a href=" ' . route('merchantprofile', array('token' => $token, 'id' => $id)) . '" >Profile</a></li>';
            }
            $status = $row->cell('status_pp')->value;
            if($status!=0){
                $row->cell('status_pp')->value='Active';
            }
            else {
                $row->cell('status_pp')->value='Inactive';
            }
            $merchants = new Properties();
            $token_m = \Illuminate\Support\Facades\Crypt::encrypt(['level' => "M", 'level_id' => $id]);
            $route_settings = '<li><a target="_blank" href=" ' .route('general', ['token' => $token_m]). '"  >Settings</a></li>';
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
													  <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
													  <span class="caret"></span></button>
													  <ul class="dropdown-menu">
													    <li><a href="#" onclick="openg(\''.$token_m.'\');" >Open</a></li>
														<li><a data="' . $id . '" class="merchant_details_link">Detail</a></li>
														'.$mprofile_link.'
														'.$route_settings.'
													  </ul>
													</div>';

            $row->cell('id')->style("display:none;");
        });

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('id', 'DESC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('manage.merchant.merchant', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }

    function deletemerchant($id) {

        $objmerchant = new Properties();
        if ($objmerchant->deleteMerchant($id)) {
            return array('errcode' => '0', 'message' => 'Record deleted successfully.');
        } else {
            return array('errcode' => '1', 'message' => 'Error deleting record.');
        }
    }

    function getMerchantDetails($token, Request $request) {
        $id = $request->get('id');
        $objmerchant = new Properties();
        $merchant_db = $objmerchant->getMerchantdetail1($id);
        return view('manage.merchant.merchantdetails', array('merchant' => $merchant_db, 'token' => $token));
    }

    public function merchantprofile($token, $merchantid, Request $request) {

        $array_token = decrypt($token);
        $idlevel = isset($array_token['level_id']) ? $array_token['level_id'] : null;
        $level = isset($array_token['level']) ? $array_token['level'] : null;
        $idadmin = isset($array_token['iduser']) ? $array_token['iduser'] : null;
       // $token = encrypt($array_token.'|'.time().'|'.config('app.appAPIkey'));
       // return 'redirect to payor portal';
        $partner_obj = new Partners();
        $merchant_account_obj = new Partners();
        $merchants = new Properties();
        $merchantdetail = $merchants->getMerchantProfile($idlevel, $merchantid, $level);
        $merchant_groups = $merchants->getGroupsfromProperty($merchantid);
        $contact['contact_name_clients'] = $merchants->get1PropertyInfo($merchantid, 'contact_name_clients');
        $merchantdetail['contract'] = $merchants->get1PropertyInfo($merchantid, 'app_contract');
        $Settings = $merchants->getPropertyInfo($merchantid);
        $subdomain = $Settings['subdomain_clients'];
        $Settings['partner'] = $merchant_account_obj->getDomain($Settings['id_partners']);
        $partner = $Settings['partner'];
        $idpartner = $merchants->get1PropertyInfo($merchantid, 'id_partners');
        $idcompany = $merchants->get1PropertyInfo($merchantid, 'id_companies');
        $qplogin = $merchants->getPropertySettings($merchantid, $idcompany, $idpartner, 'QPLOGIN');
        $token_m = \Illuminate\Support\Facades\Crypt::encrypt(['level' => "M", 'level_id' => $merchantid]);
        switch ($qplogin) {
            case 1:
                //quickpay
                $merchantdetail['clickroute'] = config('app.payor_portal_url').'/'.$partner.'/properties/'.$subdomain.'/qpay';
                break;
            case 2:
                $merchantdetail['clickroute'] = config('app.payor_portal_url').'/'.$partner.'/properties/'.$subdomain.'/registration';
                break;
            case 0:
            default:
            $merchantdetail['clickroute'] = config('app.payor_portal_url').'/'.$partner.'/properties/'.$subdomain.'/login';
        }
        $partners = $partner_obj->getAllPartners();
        $obj_layout=new Layout();
        $layouts=$obj_layout->getLayoutsObj()->get();
        return view('manage.merchant.merchantprofile', array('adminid'=>$idadmin,'ivr'=>$merchantid,'partners'=>$partners,'contact'=> $contact,'pageTitle'=>'Merchant Profile',
            'merchantdetail' => $merchantdetail, 'merchant_groups' => $merchant_groups,'level'=>$level,'idlevel'=>$idlevel, 'propertyId' => $merchantid,  'token' => $token, 'token_m'=>$token_m, 'layouts'=>$layouts));
    }

    public function merchantprofilestore($token, $merchantid, Request $request){



        //$atoken=\Illuminate\Support\Facades\Crypt::decrypt($token);
        $name_clients ="";if(null !==$request->input('name_clients'))$name_clients=trim($request->input('name_clients'));
        $compositeID_clients ="";if(null !==$request->input('compositeID_clients'))$compositeID_clients=trim($request->input('compositeID_clients'));
        $playout_id ="0";if(null !==$request->input('playout_id'))$playout_id=trim($request->input('playout_id'));
        $lockbox_id ="";if(null !==$request->input('lockbox_id'))$lockbox_id=trim($request->input('lockbox_id'));
        $bank_id ="";if(null !==$request->input('bank_id'))$bank_id=trim($request->input('bank_id'));
        $misc_id ="";if(null !==$request->input('misc_id'))$misc_id=trim($request->input('misc_id'));
        $contact_name_clients ="";if(null !==$request->input('contact_name_clients'))$contact_name_clients=trim($request->input('contact_name_clients'));
        $email_address_clients ="";if(null !==$request->input('email_address_clients'))$email_address_clients=trim($request->input('email_address_clients'));
        $accounting_email_address_clients ="";if(null !==$request->input('accounting_email_address_clients'))$accounting_email_address_clients=trim($request->input('accounting_email_address_clients'));
        $address_clients ="";if(null !==$request->input('address_clients'))$address_clients=trim($request->input('address_clients'));
        $city_clients ="";if(null !==$request->input('city_clients'))$city_clients=trim($request->input('city_clients'));
        $state_clients ="";if(null !==$request->input('state_clients'))$state_clients=trim($request->input('state_clients'));
        $zip_clients ="";if(null !==$request->input('zip_clients'))$zip_clients=trim($request->input('zip_clients'));
        $phone_clients ="";if(null !==$request->input('phone_clients'))$phone_clients=trim($request->input('phone_clients'));
        $units =0;if(null !==$request->input('units'))$units=trim($request->input('units'));
        $fqc = "";if(null !==$request->input('fqc'))$fqc=trim($request->input('fqc'));
        $statuspp = $request->input('statuspp')== "on" ? 1 : 0;
        $statusclients = $request->input('statusclients') == "on" ? 1 : 0;
        //$id_api_account =null;if(null !==$request->input('oldapiaccount'))$id_api_account=trim($request->input('oldapiaccount'));

        if($statusclients == 0){
            
                    $statuspp=0;

                    DB::table('merchant_account')
                        ->where('property_id', $merchantid)
                        ->where('payment_method', 'ec')->delete();
                    DB::table('merchant_account')
                        ->where('property_id', $merchantid)
                        ->where('payment_method', 'eterm-ec')->delete();
                    DB::table('merchant_account')
                        ->where('property_id', $merchantid)
                        ->where('payment_method', 'ebill')
                        ->delete();
                    DB::table('merchant_account')
                        ->where('property_id', $merchantid)
                        ->where('payment_method', 'cc')->delete();
                    DB::table('merchant_account')
                        ->where('property_id', $merchantid)
                        ->where('payment_method', 'eterm-cc')->delete();
                    DB::table('merchant_account')
                        ->where('property_id', $merchantid)
                        ->where('payment_method', 'amex')
                        ->delete();
                }
        //$newlogof ='';
        $data=array(	'name_clients'=>$name_clients,
            'compositeID_clients'=>$compositeID_clients,
            'playout_id'=>$playout_id,
            'lockbox_id'=>$lockbox_id,
            'bank_id'=>$bank_id,
            'misc_field'=>$misc_id,
            'contact_name_clients'=>$contact_name_clients,
            'email_address_clients'=>$email_address_clients,
            'accounting_email_address_clients'=>$accounting_email_address_clients,
            'address_clients'=>$address_clients,
            'city_clients'=>$city_clients,
            'state_clients'=>$state_clients,
            'zip_clients'=>$zip_clients,
            'phone_clients'=>$phone_clients,
            'units'=>$units,
            'fqc'=>$fqc,
            'status_clients'=>$statusclients,
            'status_pp'=>$statuspp
        );
        if($request->file('logo')){
            $newlogof=$merchantid.'_'.time().'_logo.jpg';
            Image::make($request->file('logo')->getRealPath())->widen(255, function ($constraint) {$constraint->upsize();})->heighten(72, function ($constraint) {$constraint->upsize();})->resizeCanvas(255, 72, 'center', false, 'ffffff')->save('logos/merchants/'.$newlogof,100);
            $data['logo']=$newlogof;
        }
        $last_update_units = DB::table('properties')->select('units','fqc')->where('id',$merchantid)->first();
        if($last_update_units->units != $units || $last_update_units->fqc != $fqc){
            $data['date_stored'] = date('Y-m-d H:i:s');
        }

        DB::table('properties')
            ->where('id', $merchantid)
            ->update($data);

        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    public function merchantpaymentcredentials($token, $merchantid, Request $request){

        //security
//		$objAdminAuth = new AuthAdminController();
//		$objAdminAuth->checkAuthPermissions($array_token['iduser']);

        //security
//        $objAdminAuth = new AuthAdminController();
//        $objAdminAuth->checkAuthPermissions($array_token['iduser']);

        $obj_ma = new MerchantAccount();
        $records = $obj_ma->getByProperty($merchantid);
        $data_all=array();
        $data_aux = array();

        foreach($records as $item){
            $data=array();
            if($item->payment_method=='ec' || $item->payment_method=='eterm-ec' || $item->payment_method=='ebill' || $item->payment_method=='ivr-ec'){
                $data['ecgateway']= $item->gateway;
                $data['ecmid']= $item->payment_source_merchant_id;
                $data['ecsourcekey']= $item->payment_source_key;
                $data['ecstoreid']= $item->payment_source_store_id;
                $data['eclocationid']= $item->payment_source_location_id;
            }

            if($item->payment_method=='ec' && $item->is_recurring=='0'){
                $data['ecwot']=true;
                $data['ecwotlow_pay_range']=$item->low_pay_range;
                $data['ecwothigh_pay_range']=$item->high_pay_range;
                $data['ecwothigh_ticket']=$item->high_ticket;
                $data['ecwotconvenience_fee']=$item->convenience_fee;
                $data['ecwotconvenience_fee_float']=$item->convenience_fee_float;
                $data['ecwot_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='ec' && $item->is_recurring=='1'){
                $data['ecwr']=true;
                $data['ecwrlow_pay_range']=$item->low_pay_range;
                $data['ecwrhigh_pay_range']=$item->high_pay_range;
                $data['ecwrhigh_ticket']=$item->high_ticket;
                $data['ecwrconvenience_fee']=$item->convenience_fee;
                $data['ecwrconvenience_fee_float']=$item->convenience_fee_float;
                $data['ecwrconvenience_fee_drp']=$item->convenience_fee_drp;
                $data['ecwrconvenience_fee_float_drp']=$item->convenience_fee_float_drp;
                $data['ecwr_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='eterm-ec' && $item->is_recurring=='0'){

                $data['eceot']=true;
                $data['eceotlow_pay_range']=$item->low_pay_range;
                $data['eceothigh_pay_range']=$item->high_pay_range;
                $data['eceothigh_ticket']=$item->high_ticket;
                $data['eceotconvenience_fee']=$item->convenience_fee;
                $data['eceotconvenience_fee_float']=$item->convenience_fee_float;
                $data['eceot_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='eterm-ec' && $item->is_recurring=='1'){

                $data['ecer']=true;
                $data['ecerlow_pay_range']=$item->low_pay_range;
                $data['ecerhigh_pay_range']=$item->high_pay_range;
                $data['ecerhigh_ticket']=$item->high_ticket;
                $data['ecerconvenience_fee']=$item->convenience_fee;
                $data['ecerconvenience_fee_float']=$item->convenience_fee_float;
                $data['ecerconvenience_fee_drp']=$item->convenience_fee_drp;
                $data['ecerconvenience_fee_float_drp']=$item->convenience_fee_float_drp;
                $data['ecer_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='ebill' && $item->is_recurring=='0'){
                $data['ecev']=true;
                $data['ecevlow_pay_range']=$item->low_pay_range;
                $data['ecevhigh_pay_range']=$item->high_pay_range;
                $data['ecevhigh_ticket']=$item->high_ticket;
                $data['ecevconvenience_fee']=$item->convenience_fee;
                $data['ecevconvenience_fee_float']=$item->convenience_fee_float;
                $data['ecev_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='ivr-ec' && $item->is_recurring=='0'){
                $data['ecivr']=true;
                $data['ecivrlow_pay_range']=$item->low_pay_range;
                $data['ecivrhigh_pay_range']=$item->high_pay_range;
                $data['ecivrhigh_ticket']=$item->high_ticket;
                $data['ecivrconvenience_fee']=$item->convenience_fee;
                $data['ecivrconvenience_fee_float']=$item->convenience_fee_float;
                $data['ecivr_ai']=$item->merchant_account_id;
            }

            //Money Center
            if($item->payment_method=='mbill'){
                $data['mcgateway']= $item->gateway;
                $data['mcmid']= $item->payment_source_merchant_id;
                $data['mcsourcekey']= $item->payment_source_key;
                $data['mcstoreid']= $item->payment_source_store_id;
                $data['mclocationid']= $item->payment_source_location_id;
            }

            //Money Center
            if($item->payment_method=='mbill' && $item->is_recurring=='0'){
                $data['mcev']=true;
                $data['mcevlow_pay_range']=$item->low_pay_range;
                $data['mcevhigh_pay_range']=$item->high_pay_range;
                $data['mcevhigh_ticket']=$item->high_ticket;
                $data['mcevconvenience_fee']=$item->convenience_fee;
                $data['mcevconvenience_fee_float']=$item->convenience_fee_float;
                $data['mcev_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='cc' || $item->payment_method=='eterm-cc' || $item->payment_method=='amex' || $item->payment_method=='ivr-cc' || $item->payment_method=='swipe' || $item->payment_method=='amex' || $item->payment_method=='eterm-amex'){
                $data['ccgateway']= $item->gateway;
                $data['ccmid']= $item->payment_source_merchant_id;
                $data['ccsourcekey']= $item->payment_source_key;
                $data['ccstoreid']= $item->payment_source_store_id;
                $data['cclocationid']= $item->payment_source_location_id;
                $data['ccdisabletoken']= $item->novault;

            }

            if($item->payment_method=='cc' && $item->is_recurring=='0'){
                $data['ccwot']=true;
                $data['ccwotlow_pay_range']=$item->low_pay_range;
                $data['ccwothigh_pay_range']=$item->high_pay_range;
                $data['ccwothigh_ticket']=$item->high_ticket;
                $data['ccwotconvenience_fee']=$item->convenience_fee;
                $data['ccwotconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccwot_ai']=$item->merchant_account_id;

            }

            if($item->payment_method=='cc' && $item->is_recurring=='1'){
                $data['ccwr']=true;
                $data['ccwrlow_pay_range']=$item->low_pay_range;
                $data['ccwrhigh_pay_range']=$item->high_pay_range;
                $data['ccwrhigh_ticket']=$item->high_ticket;
                $data['ccwrconvenience_fee']=$item->convenience_fee;
                $data['ccwrconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccwrconvenience_fee_drp']=$item->convenience_fee_drp;
                $data['ccwrconvenience_fee_float_drp']=$item->convenience_fee_float_drp;
                $data['ccwr_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='eterm-cc' && $item->is_recurring=='0'){
                $data['cceot']=true;
                $data['cceotlow_pay_range']=$item->low_pay_range;
                $data['cceothigh_pay_range']=$item->high_pay_range;
                $data['cceothigh_ticket']=$item->high_ticket;
                $data['cceotconvenience_fee']=$item->convenience_fee;
                $data['cceotconvenience_fee_float']=$item->convenience_fee_float;
                $data['cceot_ai']=$item->merchant_account_id;
            }


            if($item->payment_method=='eterm-cc' && $item->is_recurring=='1'){
                $data['ccer']=true;
                $data['ccerlow_pay_range']=$item->low_pay_range;
                $data['ccerhigh_pay_range']=$item->high_pay_range;
                $data['ccerhigh_ticket']=$item->high_ticket;
                $data['ccerconvenience_fee']=$item->convenience_fee;
                $data['ccerconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccerconvenience_fee_drp']=$item->convenience_fee_drp;
                $data['ccerconvenience_fee_float_drp']=$item->convenience_fee_float_drp;
                $data['ccer_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='amex' && $item->is_recurring=='0'){
                $data['ccamex']=true;
                $data['ccamexlow_pay_range']=$item->low_pay_range;
                $data['ccamexhigh_pay_range']=$item->high_pay_range;
                $data['ccamexhigh_ticket']=$item->high_ticket;
                $data['ccamexconvenience_fee']=$item->convenience_fee;
                $data['ccamexconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccamex_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='amex' && $item->is_recurring=='1'){
                $data['ccamexr']=true;
                $data['ccamexrlow_pay_range']=$item->low_pay_range;
                $data['ccamexrhigh_pay_range']=$item->high_pay_range;
                $data['ccamexrhigh_ticket']=$item->high_ticket;
                $data['ccamexrconvenience_fee']=$item->convenience_fee;
                $data['ccamexrconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccamexrconvenience_fee_drp']=$item->convenience_fee_drp;
                $data['ccamexrconvenience_fee_float_drp']=$item->convenience_fee_float_drp;
                $data['ccamexr_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='eterm-amex' && $item->is_recurring=='0'){
                $data['ccamexet']=true;
                $data['ccamexetlow_pay_range']=$item->low_pay_range;
                $data['ccamexethigh_pay_range']=$item->high_pay_range;
                $data['ccamexethigh_ticket']=$item->high_ticket;
                $data['ccamexetconvenience_fee']=$item->convenience_fee;
                $data['ccamexetconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccamexet_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='eterm-amex' && $item->is_recurring=='1'){
                $data['ccamexetr']=true;
                $data['ccamexetrlow_pay_range']=$item->low_pay_range;
                $data['ccamexetrhigh_pay_range']=$item->high_pay_range;
                $data['ccamexetrhigh_ticket']=$item->high_ticket;
                $data['ccamexetrconvenience_fee']=$item->convenience_fee;
                $data['ccamexetrconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccamexetrconvenience_fee_drp']=$item->convenience_fee_drp;
                $data['ccamexetrconvenience_fee_float_drp']=$item->convenience_fee_float_drp;
                $data['ccamexetr_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='ivr-cc' && $item->is_recurring=='0'){

                $data['ccivr']=true;
                $data['ccivrlow_pay_range']=$item->low_pay_range;
                $data['ccivrhigh_pay_range']=$item->high_pay_range;
                $data['ccivrhigh_ticket']=$item->high_ticket;
                $data['ccivrconvenience_fee']=$item->convenience_fee;
                $data['ccivrconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccivr_ai']=$item->merchant_account_id;
            }

            if($item->payment_method=='swipe' && $item->is_recurring=='0'){

                $data['ccsw']=true;
                $data['ccswlow_pay_range']=$item->low_pay_range;
                $data['ccswhigh_pay_range']=$item->high_pay_range;
                $data['ccswhigh_ticket']=$item->high_ticket;
                $data['ccswconvenience_fee']=$item->convenience_fee;
                $data['ccswconvenience_fee_float']=$item->convenience_fee_float;
                $data['ccswconvenience_fee_drp']=$item->convenience_fee_drp;
                $data['ccswconvenience_fee_float_drp']=$item->convenience_fee_float_drp;
                $data['ccsw_ai']=$item->merchant_account_id;
            }

            $data_all[]=$data;
            $data_aux = array_merge($data_aux, $data);
        }

        return view('manage.merchant.merchant_payment_credentials',array('dataaux'=>$data_aux,'data'=>$data_all,'pageTitle'=>'Payment Credentials', 'propertyId' => $merchantid, 'token' => $token));
    }

    public function merchantPCEcheckStore($token,$id,Request $request){

        $ecgateway ="";if(null !==$request->input('ecgateway'))$ecgateway=trim($request->input('ecgateway'));
        $ecmid ="";if(null !==$request->input('ecmid'))$ecmid=trim($request->input('ecmid'));
        $ecsourcekey ="";if(null !==$request->input('ecsourcekey'))$ecsourcekey=trim($request->input('ecsourcekey'));
        $ecstoreid ="";if(null !==$request->input('ecstoreid'))$ecstoreid=trim($request->input('ecstoreid'));
        $eclocationid ="";if(null !==$request->input('eclocationid'))$eclocationid=trim($request->input('eclocationid'));

        $ecwot ="";if(null !==$request->input('ecwot'))$ecwot=trim($request->input('ecwot'));
        $ecWOTlpr ="";if(null !==$request->input('ecWOTlpr'))$ecWOTlpr=trim($request->input('ecWOTlpr'));
        $ecWOThpr ="";if(null !==$request->input('ecWOThpr'))$ecWOThpr=trim($request->input('ecWOThpr'));
        $ecWOTht ="";if(null !==$request->input('ecWOTht'))$ecWOTht=trim($request->input('ecWOTht'));
        $ecWOTcf ="";if(null !==$request->input('ecWOTcf'))$ecWOTcf=trim($request->input('ecWOTcf'));
        $ecWOTlpcf ="";if(null !==$request->input('ecWOTlpcf'))$ecWOTlpcf=trim($request->input('ecWOTlpcf'));

        $ecwr ="";if(null !==$request->input('ecwr'))$ecwr=trim($request->input('ecwr'));
        $ecWRlpr ="";if(null !==$request->input('ecWRlpr'))$ecWRlpr=trim($request->input('ecWRlpr'));
        $ecWRhpr ="";if(null !==$request->input('ecWRhpr'))$ecWRhpr=trim($request->input('ecWRhpr'));
        $ecWRht ="";if(null !==$request->input('ecWRht'))$ecWRht=trim($request->input('ecWRht'));
        $ecWRcf ="";if(null !==$request->input('ecWRcf'))$ecWRcf=trim($request->input('ecWRcf'));
        $ecWRpcf ="";if(null !==$request->input('ecWRpcf'))$ecWRpcf=trim($request->input('ecWRpcf'));
        $ecWRcfDRP ="";if(null !==$request->input('ecWRcfDrp'))$ecWRcfDRP=trim($request->input('ecWRcfDrp'));
        $ecWRpcfDRP ="";if(null !==$request->input('ecWRpcfDrp'))$ecWRpcfDRP=trim($request->input('ecWRpcfDrp'));

        $eceot ="";if(null !==$request->input('eceot'))$eceot=trim($request->input('eceot'));
        $ecEOTlpr ="";if(null !==$request->input('ecEOTlpr'))$ecEOTlpr=trim($request->input('ecEOTlpr'));
        $ecEOThpr ="";if(null !==$request->input('ecEOThpr'))$ecEOThpr=trim($request->input('ecEOThpr'));
        $ecEOTht ="";if(null !==$request->input('ecEOTht'))$ecEOTht=trim($request->input('ecEOTht'));
        $ecEOTcf ="";if(null !==$request->input('ecEOTcf'))$ecEOTcf=trim($request->input('ecEOTcf'));
        $ecEOTpcf ="";if(null !==$request->input('ecEOTpcf'))$ecEOTpcf=trim($request->input('ecEOTpcf'));


        $ecer ="";if(null !==$request->input('ecer'))$ecer=trim($request->input('ecer'));
        $ecERlpr ="";if(null !==$request->input('ecERlpr'))$ecERlpr=trim($request->input('ecERlpr'));
        $ecERhpr ="";if(null !==$request->input('ecERhpr'))$ecERhpr=trim($request->input('ecERhpr'));
        $ecERht ="";if(null !==$request->input('ecERht'))$ecERht=trim($request->input('ecERht'));
        $ecERcf ="";if(null !==$request->input('ecERcf'))$ecERcf=trim($request->input('ecERcf'));
        $ecERpcf ="";if(null !==$request->input('ecERpcf'))$ecERpcf=trim($request->input('ecERpcf'));
        $ecERcfDrp ="";if(null !==$request->input('ecERcfDrp'))$ecERcfDrp=trim($request->input('ecERcfDrp'));
        $ecERpcfDrp ="";if(null !==$request->input('ecERpcfDrp'))$ecERpcfDrp=trim($request->input('ecERpcfDrp'));


        $ecev ="";if(null !==$request->input('ecev'))$ecev=trim($request->input('ecev'));
        $ecEVlpr ="";if(null !==$request->input('ecEVlpr'))$ecEVlpr=trim($request->input('ecEVlpr'));
        $ecEVhpr ="";if(null !==$request->input('ecEVhpr'))$ecEVhpr=trim($request->input('ecEVhpr'));
        $ecEVht ="";if(null !==$request->input('ecEVht'))$ecEVht=trim($request->input('ecEVht'));
        $ecEVcf ="";if(null !==$request->input('ecEVcf'))$ecEVcf=trim($request->input('ecEVcf'));
        $ecEVpcf ="";if(null !==$request->input('ecEVpcf'))$ecEVpcf=trim($request->input('ecEVpcf'));

        $ecivr ="";if(null !==$request->input('ecivr'))$ecivr=trim($request->input('ecivr'));
        $ecIVRlpr ="";if(null !==$request->input('ecIVRlpr'))$ecIVRlpr=trim($request->input('ecIVRlpr'));
        $ecIVRhpr ="";if(null !==$request->input('ecIVRhpr'))$ecIVRhpr=trim($request->input('ecIVRhpr'));
        $ecIVRht ="";if(null !==$request->input('ecIVRht'))$ecIVRht=trim($request->input('ecIVRht'));
        $ecIVRcf ="";if(null !==$request->input('ecIVRcf'))$ecIVRcf=trim($request->input('ecIVRcf'));
        $ecIVRpcf ="";if(null !==$request->input('ecIVRpcf'))$ecIVRpcf=trim($request->input('ecIVRpcf'));

        $obj_ma = new MerchantAccount();
        $records = $obj_ma->getByProperty($id);
        $all_submit = $request->all();


        if($records){
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'ec')->delete();
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'eterm-ec')->delete();
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'ebill')
                ->delete();
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'ivr-ec')
                ->delete();
        }

        if($ecwot){
            DB::table('merchant_account')->insert([
                'property_id' => $id,
                'gateway' => $ecgateway,
                'low_pay_range' => $ecWOTlpr,
                'high_pay_range' => $ecWOThpr,
                'high_ticket' => $ecWOTht,
                'convenience_fee' => $ecWOTcf,
                'payment_source_key' => $ecsourcekey,
                'payment_source_store_id' => $ecstoreid,
                'payment_source_merchant_id' => $ecmid,
                'payment_source_location_id' => $eclocationid,
                'convenience_fee_float' => $ecWOTlpcf,
                'payment_method' => 'ec',
                'is_recurring' => '0',
            ]);
        }

        if($ecwr){
            DB::table('merchant_account')->insert([
                'property_id' => $id,
                'gateway' => $ecgateway,
                'low_pay_range' => $ecWRlpr,
                'high_pay_range' => $ecWRhpr,
                'high_ticket' => $ecWRht,
                'convenience_fee' => $ecWRcf,
                'payment_source_key' => $ecsourcekey,
                'payment_source_store_id' => $ecstoreid,
                'payment_source_merchant_id' => $ecmid,
                'payment_source_location_id' => $eclocationid,
                'convenience_fee_float' => $ecWRpcf,
                'convenience_fee_drp' => $ecWRcfDRP,
                'convenience_fee_float_drp' => $ecWRpcfDRP,
                'payment_method' => 'ec',
                'is_recurring' => '1',
            ]);
        }

        if($eceot){
            DB::table('merchant_account')->insert([
                'property_id' => $id,
                'gateway' => $ecgateway,
                'low_pay_range' => $ecEOTlpr,
                'high_pay_range' => $ecEOThpr,
                'high_ticket' => $ecEOTht,
                'convenience_fee' => $ecEOTcf,
                'payment_source_key' => $ecsourcekey,
                'payment_source_store_id' => $ecstoreid,
                'payment_source_merchant_id' => $ecmid,
                'payment_source_location_id' => $eclocationid,
                'convenience_fee_float' => $ecEOTpcf,
                'payment_method' => 'eterm-ec',
                'is_recurring' => '0',
            ]);
        }

        if($ecer){
            DB::table('merchant_account')->insert([
                'property_id' => $id,
                'gateway' => $ecgateway,
                'low_pay_range' => $ecERlpr,
                'high_pay_range' => $ecERhpr,
                'high_ticket' => $ecERht,
                'convenience_fee' => $ecERcf,
                'payment_source_key' => $ecsourcekey,
                'payment_source_store_id' => $ecstoreid,
                'payment_source_merchant_id' => $ecmid,
                'payment_source_location_id' => $eclocationid,
                'convenience_fee_float' => $ecERpcf,
                'convenience_fee_drp' => $ecERcfDrp,
                'convenience_fee_float_drp' => $ecERpcfDrp,
                'payment_method' => 'eterm-ec',
                'is_recurring' => '1',
            ]);
        }

        if($ecev){
            DB::table('merchant_account')->insert([
                'property_id' => $id,
                'gateway' => $ecgateway,
                'low_pay_range' => $ecEVlpr,
                'high_pay_range' => $ecEVhpr,
                'high_ticket' => $ecEVht,
                'convenience_fee' => $ecEVcf,
                'payment_source_key' => $ecsourcekey,
                'payment_source_store_id' => $ecstoreid,
                'payment_source_merchant_id' => $ecmid,
                'payment_source_location_id' => $eclocationid,
                'convenience_fee_float' => $ecEVpcf,
                'payment_method' => 'ebill',
                'is_recurring' => '0',
            ]);
        }


        if($ecivr){
            DB::table('merchant_account')->insert([
                'property_id' => $id,
                'gateway' => $ecgateway,
                'low_pay_range' => $ecIVRlpr,
                'high_pay_range' => $ecIVRhpr,
                'high_ticket' => $ecIVRht,
                'convenience_fee' => $ecIVRcf,
                'payment_source_key' => $ecsourcekey,
                'payment_source_store_id' => $ecstoreid,
                'payment_source_merchant_id' => $ecmid,
                'payment_source_location_id' => $eclocationid,
                'convenience_fee_float' => $ecIVRpcf,
                'payment_method' => 'ivr-ec',
                'is_recurring' => '0',
            ]);
        }



        //dynamic form
        foreach ($all_submit as $field => $val){
            if(strpos($field,'ecWOTlprDYNAMIC')===0 && strpos($field,'ecWOTlprDYNAMIC|')===false ){
                $number = str_replace('ecWOTlprDYNAMIC','',$field);
                if($ecwot){
                    DB::table('merchant_account')->insert([
                        'property_id' => $id,
                        'payment_source_merchant_id' => $ecmid,
                        'gateway' => $ecgateway,
                        'payment_source_key' => $ecsourcekey,
                        'payment_source_store_id' => $ecstoreid,
                        'payment_source_location_id' => $eclocationid,
                        'low_pay_range' => $all_submit['ecWOTlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ecWOThprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ecWOThtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ecWOTcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ecWOTlpcfDYNAMIC'.$number],
                        'payment_method' => 'ec',
                        'is_recurring' => '0',
                    ]);
                }
            }

            if(strpos($field,'ecWRlprDYNAMIC')===0 && strpos($field,'ecWRlprDYNAMIC|')===false ){
                $number = str_replace('ecWRlprDYNAMIC','',$field);
                if($ecwr){
                    DB::table('merchant_account')->insert([
                        'property_id' => $id,
                        'gateway' => $ecgateway,
                        'low_pay_range' => $all_submit['ecWRlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ecWRhprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ecWRhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ecWRcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ecWRpcfDYNAMIC'.$number],
                        'convenience_fee_drp' => $all_submit['ecWRcfDrpDYNAMIC'.$number],
                        'convenience_fee_float_drp' => $all_submit['ecWRpcfDrpDYNAMIC'.$number],
                        'payment_source_key' => $ecsourcekey,
                        'payment_source_store_id' => $ecstoreid,
                        'payment_source_merchant_id' => $ecmid,
                        'payment_source_location_id' => $eclocationid,
                        'payment_method' => 'ec',
                        'is_recurring' => '1',
                    ]);
                }
            }

            if(strpos($field,'ecEOTlprDYNAMIC')===0 && strpos($field,'ecEOTlprDYNAMIC|')===false ){
                $number = str_replace('ecEOTlprDYNAMIC','',$field);
                if($eceot){
                    DB::table('merchant_account')->insert([
                        'property_id' => $id,
                        'gateway' => $ecgateway,
                        'low_pay_range' => $all_submit['ecEOTlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ecEOThprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ecEOThtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ecEOTcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ecEOTpcfDYNAMIC'.$number],
                        'payment_source_key' => $ecsourcekey,
                        'payment_source_store_id' => $ecstoreid,
                        'payment_source_merchant_id' => $ecmid,
                        'payment_source_location_id' => $eclocationid,
                        'payment_method' => 'eterm-ec',
                        'is_recurring' => '0',
                    ]);
                }
            }

            if(strpos($field,'ecEVlprDYNAMIC')===0 && strpos($field,'ecEVlprDYNAMIC|')===false ){
                $number = str_replace('ecEVlprDYNAMIC','',$field);
                if($ecev){
                    DB::table('merchant_account')->insert([
                        'property_id' => $id,
                        'gateway' => $ecgateway,
                        'low_pay_range' => $all_submit['ecEVlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ecEVhprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ecEVhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ecEVcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ecEVpcfDYNAMIC'.$number],
                        'payment_source_key' => $ecsourcekey,
                        'payment_source_store_id' => $ecstoreid,
                        'payment_source_merchant_id' => $ecmid,
                        'payment_source_location_id' => $eclocationid,
                        'payment_method' => 'ebill',
                        'is_recurring' => '0',
                    ]);
                }
            }

            if(strpos($field,'ecERlprDYNAMIC')===0 && strpos($field,'ecERlprDYNAMIC|')===false ){
                $number = str_replace('ecERlprDYNAMIC','',$field);
                if($ecer){
                    DB::table('merchant_account')->insert([
                        'property_id' => $id,
                        'gateway' => $ecgateway,
                        'low_pay_range' => $all_submit['ecERlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ecERhprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ecERhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ecERcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ecERpcfDYNAMIC'.$number],
                        'payment_source_key' => $ecsourcekey,
                        'payment_source_store_id' => $ecstoreid,
                        'payment_source_merchant_id' => $ecmid,
                        'payment_source_location_id' => $eclocationid,
                        'convenience_fee_drp' => $all_submit['ecERcfDrpDYNAMIC'.$number],
                        'convenience_fee_float_drp' => $all_submit['ecERpcfDrpDYNAMIC'.$number],
                        'payment_method' => 'eterm-ec',
                        'is_recurring' => '1',
                    ]);
                }
            }

            if(strpos($field,'ecIVRlprDYNAMIC')===0 && strpos($field,'ecIVRlprDYNAMIC|')===false ){
                $number = str_replace('ecIVRlprDYNAMIC','',$field);
                if($ecivr){
                    DB::table('merchant_account')->insert([
                        'property_id' => $id,
                        'gateway' => $ecgateway,
                        'low_pay_range' => $all_submit['ecIVRlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ecIVRhprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ecIVRhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ecIVRcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ecIVRpcfDYNAMIC'.$number],
                        'payment_source_key' => $ecsourcekey,
                        'payment_source_store_id' => $ecstoreid,
                        'payment_source_merchant_id' => $ecmid,
                        'payment_source_location_id' => $eclocationid,
                        'payment_method' => 'ivr-ec',
                        'is_recurring' => '0',
                    ]);
                }
            }

        }



        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    public function merchantPCMoneyCenterStore($token, $id, Request $request) {
        $mcgateway = "";
        $mcmid = "";
        $mcsourcekey = "";
        $mcstoreid = "";
        $mclocationid = "";

        if (null !== $request->input('mcgateway')) {
            $mcgateway = trim($request->input('mcgateway'));
        }

        if (null !== $request->input('mcmid')) {
            $mcmid = trim($request->input('mcmid'));
        }

        if (null !== $request->input('mcsourcekey')) {
            $mcsourcekey = trim($request->input('mcsourcekey'));
        }

        if (null !== $request->input('mcstoreid')) {
            $mcstoreid = trim($request->input('mcstoreid'));
        }

        if (null !== $request->input('mclocationid')) {
            $mclocationid = trim($request->input('mclocationid'));
        }

        $mcev = "";
        $mcEVlpr = "";
        $mcEVhpr = "";
        $mcEVht = "";
        $mcEVcf = "";
        $mcEVpcf = "";

        if (null !== $request->input('mcev')) {
            $mcev = trim($request->input('mcev'));
        }

        if (null !== $request->input('mcEVlpr')) {
            $mcEVlpr = trim($request->input('mcEVlpr'));
        }

        if (null !== $request->input('mcEVhpr')) {
            $mcEVhpr = trim($request->input('mcEVhpr'));
        }

        if (null !== $request->input('mcEVht')) {
            $mcEVht = trim($request->input('mcEVht'));
        }

        if (null !== $request->input('mcEVcf')) {
            $mcEVcf = trim($request->input('mcEVcf'));
        }

        if (null !== $request->input('mcEVpcf')) {
            $mcEVpcf = trim($request->input('mcEVpcf'));
        }

        $obj_ma = new MerchantAccount();
        $records = $obj_ma->getByProperty($id);
        $all_submit = $request->all();


        if($records){
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'mbill')
                ->delete();
        }

        if ($mcev) {
            DB::table('merchant_account')->insert([
                'property_id' => $id,
                'gateway' => $mcgateway,
                'low_pay_range' => $mcEVlpr,
                'high_pay_range' => $mcEVhpr,
                'high_ticket' => $mcEVht,
                'convenience_fee' => $mcEVcf,
                'payment_source_key' => $mcsourcekey,
                'payment_source_store_id' => $mcstoreid,
                'payment_source_merchant_id' => $mcmid,
                'payment_source_location_id' => $mclocationid,
                'convenience_fee_float' => $mcEVpcf,
                'payment_method' => 'mbill',
                'is_recurring' => '0',
            ]);
        }

        //dynamic form
        foreach ($all_submit as $field => $val) {
            if (strpos($field, 'mcEVlprDYNAMIC') === 0 && strpos($field, 'mcEVlprDYNAMIC|') === false) {
                $number = str_replace('mcEVlprDYNAMIC', '', $field);
                if ($mcev) {
                    DB::table('merchant_account')->insert([
                        'property_id' => $id,
                        'gateway' => $mcgateway,
                        'low_pay_range' => $all_submit['mcEVlprDYNAMIC' . $number],
                        'high_pay_range' => $all_submit['mcEVhprDYNAMIC' . $number],
                        'high_ticket' => $all_submit['mcEVhtDYNAMIC' . $number],
                        'convenience_fee' => $all_submit['mcEVcfDYNAMIC' . $number],
                        'convenience_fee_float' => $all_submit['mcEVpcfDYNAMIC' . $number],
                        'payment_source_key' => $mcsourcekey,
                        'payment_source_store_id' => $mcstoreid,
                        'payment_source_merchant_id' => $mcmid,
                        'payment_source_location_id' => $mclocationid,
                        'payment_method' => 'mbill',
                        'is_recurring' => '0',
                    ]);
                }
            }
        }

        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    public function merchantPCCCStore($token,$id,Request $request){


        $ccgateway ="";if(null !==$request->input('ccgateway'))$ccgateway=trim($request->input('ccgateway'));
        $ccmid ="";if(null !==$request->input('ccmid'))$ccmid=trim($request->input('ccmid'));
        $ccsourcekey ="";if(null !==$request->input('ccsourcekey'))$ccsourcekey=trim($request->input('ccsourcekey'));
        $ccstoreid ="";if(null !==$request->input('ccstoreid'))$ccstoreid=trim($request->input('ccstoreid'));
        $cclocationid ="";if(null !==$request->input('cclocationid'))$cclocationid=trim($request->input('cclocationid'));
        $ccdisabletoken ="";if(null !==$request->input('ccdisabletoken'))$ccdisabletoken=trim($request->input('ccdisabletoken'));


        $ccwot ="";if(null !==$request->input('ccwot'))$ccwot=trim($request->input('ccwot'));
        $ccWOTlpr ="";if(null !==$request->input('ccWOTlpr'))$ccWOTlpr=trim($request->input('ccWOTlpr'));
        $ccWOThpr ="";if(null !==$request->input('ccWOThpr'))$ccWOThpr=trim($request->input('ccWOThpr'));
        $ccWOTht ="";if(null !==$request->input('ccWOTht'))$ccWOTht=trim($request->input('ccWOTht'));
        $ccWOTcf ="";if(null !==$request->input('ccWOTcf'))$ccWOTcf=trim($request->input('ccWOTcf'));
        $ccWOTpcf ="";if(null !==$request->input('ccWOTpcf'))$ccWOTpcf=trim($request->input('ccWOTpcf'));

        $ccwr ="";if(null !==$request->input('ccwr'))$ccwr=trim($request->input('ccwr'));
        $ccWRlpr ="";if(null !==$request->input('ccWRlpr'))$ccWRlpr=trim($request->input('ccWRlpr'));
        $ccWRhpr ="";if(null !==$request->input('ccWRhpr'))$ccWRhpr=trim($request->input('ccWRhpr'));
        $ccWRht ="";if(null !==$request->input('ccWRht'))$ccWRht=trim($request->input('ccWRht'));
        $ccWRcf ="";if(null !==$request->input('ccWRcf'))$ccWRcf=trim($request->input('ccWRcf'));
        $ccWRpcf ="";if(null !==$request->input('ccWRpcf'))$ccWRpcf=trim($request->input('ccWRpcf'));
        $ccWRcfDrp ="";if(null !==$request->input('ccWRcfDrp'))$ccWRcfDrp=trim($request->input('ccWRcfDrp'));
        $ccWRpcfDrp ="";if(null !==$request->input('ccWRpcfDrp'))$ccWRpcfDrp=trim($request->input('ccWRpcfDrp'));

        $cceot ="";if(null !==$request->input('cceot'))$cceot=trim($request->input('cceot'));
        $ccEOTlpr ="";if(null !==$request->input('ccEOTlpr'))$ccEOTlpr=trim($request->input('ccEOTlpr'));
        $ccEOThpr ="";if(null !==$request->input('ccEOThpr'))$ccEOThpr=trim($request->input('ccEOThpr'));
        $ccEOTht ="";if(null !==$request->input('ccEOTht'))$ccEOTht=trim($request->input('ccEOTht'));
        $ccEOTcf ="";if(null !==$request->input('ccEOTcf'))$ccEOTcf=trim($request->input('ccEOTcf'));
        $ccEOTpcf ="";if(null !==$request->input('ccEOTpcf'))$ccEOTpcf=trim($request->input('ccEOTpcf'));

        $ccer ="";if(null !==$request->input('ccer'))$ccer=trim($request->input('ccer'));
        $ccERlpr ="";if(null !==$request->input('ccERlpr'))$ccERlpr=trim($request->input('ccERlpr'));
        $ccERhpr ="";if(null !==$request->input('ccERhpr'))$ccERhpr=trim($request->input('ccERhpr'));
        $ccERht ="";if(null !==$request->input('ccERht'))$ccERht=trim($request->input('ccERht'));
        $ccERcf ="";if(null !==$request->input('ccERcf'))$ccERcf=trim($request->input('ccERcf'));
        $ccERpcf ="";if(null !==$request->input('ccERpcf'))$ccERpcf=trim($request->input('ccERpcf'));
        $ccERcfDrp ="";if(null !==$request->input('ccERcfDrp'))$ccERcfDrp=trim($request->input('ccERcfDrp'));
        $ccERpcfDrp ="";if(null !==$request->input('ccERpcfDrp'))$ccERpcfDrp=trim($request->input('ccERpcfDrp'));

        $ccivr ="";if(null !==$request->input('ccivr'))$ccivr=trim($request->input('ccivr'));
        $ccIVRlpr ="";if(null !==$request->input('ccIVRlpr'))$ccIVRlpr=trim($request->input('ccIVRlpr'));
        $ccIVRhpr ="";if(null !==$request->input('ccIVRhpr'))$ccIVRhpr=trim($request->input('ccIVRhpr'));
        $ccIVRht ="";if(null !==$request->input('ccIVRht'))$ccIVRht=trim($request->input('ccIVRht'));
        $ccIVRcf ="";if(null !==$request->input('ccIVRcf'))$ccIVRcf=trim($request->input('ccIVRcf'));
        $ccIVRpcf ="";if(null !==$request->input('ccIVRpcf'))$ccIVRpcf=trim($request->input('ccIVRpcf'));

        $ccsw ="";if(null !==$request->input('ccsw'))$ccsw=trim($request->input('ccsw'));
        $ccSWlpr ="";if(null !==$request->input('ccSWlpr'))$ccSWlpr=trim($request->input('ccSWlpr'));
        $ccSWhpr ="";if(null !==$request->input('ccSWhpr'))$ccSWhpr=trim($request->input('ccSWhpr'));
        $ccSWht ="";if(null !==$request->input('ccSWht'))$ccSWht=trim($request->input('ccSWht'));
        $ccSWcf ="";if(null !==$request->input('ccSWcf'))$ccSWcf=trim($request->input('ccSWcf'));
        $ccSWpcf ="";if(null !==$request->input('ccSWpcf'))$ccSWpcf=trim($request->input('ccSWpcf'));
        $ccSWcfDrp ="";if(null !==$request->input('ccSWcfDrp'))$ccSWcfDrp=trim($request->input('ccSWcfDrp'));
        $ccSWpcfDrp ="";if(null !==$request->input('ccSWpcfDrp'))$ccSWpcfDrp=trim($request->input('ccSWpcfDrp'));

        //var_dump($ccERcfDrp); exit();



        $ccamex ="";if(null !==$request->input('ccamex'))$ccamex=trim($request->input('ccamex'));
        $ccAElpr ="";if(null !==$request->input('ccAElpr'))$ccAElpr=trim($request->input('ccAElpr'));
        $ccAEhpr ="";if(null !==$request->input('ccAEhpr'))$ccAEhpr=trim($request->input('ccAEhpr'));
        $ccAEht ="";if(null !==$request->input('ccAEht'))$ccAEht=trim($request->input('ccAEht'));
        $ccAEcf ="";if(null !==$request->input('ccAEcf'))$ccAEcf=trim($request->input('ccAEcf'));
        $ccAEpcf ="";if(null !==$request->input('ccAEpcf'))$ccAEpcf=trim($request->input('ccAEpcf'));


        $ccamexr ="";if(null !==$request->input('ccamexr'))$ccamexr=trim($request->input('ccamexr'));
        $ccAERlpr ="";if(null !==$request->input('ccAERlpr'))$ccAERlpr=trim($request->input('ccAERlpr'));
        $ccAERhpr ="";if(null !==$request->input('ccAERhpr'))$ccAERhpr=trim($request->input('ccAERhpr'));
        $ccAERht ="";if(null !==$request->input('ccAERht'))$ccAERht=trim($request->input('ccAERht'));
        $ccAERcf ="";if(null !==$request->input('ccAERcf'))$ccAERcf=trim($request->input('ccAERcf'));
        $ccAERpcf ="";if(null !==$request->input('ccAERpcf'))$ccAERpcf=trim($request->input('ccAERpcf'));
        $ccAERcfDrp ="";if(null !==$request->input('ccAERcfDrp'))$ccAERcfDrp=trim($request->input('ccAERcfDrp'));
        $ccAERpcfDrp ="";if(null !==$request->input('ccAERpcfDrp'))$ccAERpcfDrp=trim($request->input('ccAERpcfDrp'));


        $ccamexet ="";if(null !==$request->input('ccamexet'))$ccamexet=trim($request->input('ccamexet'));
        $ccAEETlpr ="";if(null !==$request->input('ccAEETlpr'))$ccAEETlpr=trim($request->input('ccAEETlpr'));
        $ccAEEThpr ="";if(null !==$request->input('ccAEEThpr'))$ccAEEThpr=trim($request->input('ccAEEThpr'));
        $ccAEETht ="";if(null !==$request->input('ccAEETht'))$ccAEETht=trim($request->input('ccAEETht'));
        $ccAEETcf ="";if(null !==$request->input('ccAEETcf'))$ccAEETcf=trim($request->input('ccAEETcf'));
        $ccAEETpcf ="";if(null !==$request->input('ccAEETpcf'))$ccAEETpcf=trim($request->input('ccAEETpcf'));


        $ccamexetr ="";if(null !==$request->input('ccamexetr'))$ccamexetr=trim($request->input('ccamexetr'));
        $ccAEETRlpr ="";if(null !==$request->input('ccAEETRlpr'))$ccAEETRlpr=trim($request->input('ccAEETRlpr'));
        $ccAEETRhpr ="";if(null !==$request->input('ccAEETRhpr'))$ccAEETRhpr=trim($request->input('ccAEETRhpr'));
        $ccAEETRht ="";if(null !==$request->input('ccAEETRht'))$ccAEETRht=trim($request->input('ccAEETRht'));
        $ccAEETRcf ="";if(null !==$request->input('ccAEETRcf'))$ccAEETRcf=trim($request->input('ccAEETRcf'));
        $ccAEETRpcf ="";if(null !==$request->input('ccAEETRpcf'))$ccAEETRpcf=trim($request->input('ccAEETRpcf'));
        $ccAEETRcfDrp ="";if(null !==$request->input('ccAEETRcfDrp'))$ccAEETRcfDrp=trim($request->input('ccAEETRcfDrp'));
        $ccAEETRpcfDrp ="";if(null !==$request->input('ccAEETRpcfDrp'))$ccAEETRpcfDrp=trim($request->input('ccAEETRpcfDrp'));



        $obj_ma = new MerchantAccount();
        $records = $obj_ma->getByProperty($id);
        $all_submit = $request->all();

        if($ccdisabletoken){
            $ccdisabletoken = 1;
        }
        else{
            $ccdisabletoken = 0;
        }


        if($records){
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'cc')->delete();
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'eterm-cc')->delete();
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'amex')->delete();
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'eterm-amex')->delete();
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'ivr-cc')->delete();
            DB::table('merchant_account')
                ->where('property_id', $id)
                ->where('payment_method', 'swipe')->delete();
        }

        if($ccwot){
            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccWOTlpr,
                'high_pay_range' => $ccWOThpr,
                'high_ticket' => $ccWOTht,
                'convenience_fee' => $ccWOTcf,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'convenience_fee_float' => $ccWOTpcf,
                'payment_method' => 'cc',
                'is_recurring' => '0',
            ]);

            DB::table('card_type_fee')
                ->where('tier_id', 'ccwot1')
                ->where('id_property', $id)
                ->update([
                    'id_merchant_account' => $idmacc
                ]);

        }

        if($ccwr){

            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccWRlpr,
                'high_pay_range' => $ccWRhpr,
                'high_ticket' => $ccWRht,
                'convenience_fee' => $ccWRcf,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'convenience_fee_float' => $ccWRpcf,
                'convenience_fee_float_drp' => $ccWRpcfDrp,
                'convenience_fee_drp' => $ccWRcfDrp,
                'payment_method' => 'cc',
                'is_recurring' => '1',
            ]);

            DB::table('card_type_fee')
                ->where('tier_id', 'ccwr1')
                ->where('id_property', $id)
                ->update([
                    'id_merchant_account' => $idmacc
                ]);
        }

        if($cceot){

            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccEOTlpr,
                'high_pay_range' => $ccEOThpr,
                'high_ticket' => $ccEOTht,
                'convenience_fee' => $ccEOTcf,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'convenience_fee_float' => $ccEOTpcf,
                'payment_method' => 'eterm-cc',
                'is_recurring' => '0',
            ]);

            DB::table('card_type_fee')
                ->where('tier_id', 'cceot1')
                ->where('id_property', $id)
                ->update([
                    'id_merchant_account' => $idmacc
                ]);
        }

        if($ccer){

            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccERlpr,
                'high_pay_range' => $ccERhpr,
                'high_ticket' => $ccERht,
                'convenience_fee' => $ccERcf,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'convenience_fee_float' => $ccERpcf,
                'convenience_fee_drp' => $ccERcfDrp,
                'convenience_fee_float_drp' => $ccERpcfDrp,
                'payment_method' => 'eterm-cc',
                'is_recurring' => '1',
            ]);

            DB::table('card_type_fee')
                ->where('tier_id', 'ccer1')
                ->where('id_property', $id)
                ->update([
                    'id_merchant_account' => $idmacc
                ]);
        }

        if($ccamex){
            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccAElpr,
                'high_pay_range' => $ccAEhpr,
                'high_ticket' => $ccAEht,
                'convenience_fee' => $ccAEcf,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'convenience_fee_float' => $ccAEpcf,
                'payment_method' => 'amex',
                'is_recurring' => '0',
            ]);

        }

        if($ccamexr){
            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccAERlpr,
                'high_pay_range' => $ccAERhpr,
                'high_ticket' => $ccAERht,
                'convenience_fee' => $ccAERcf,
                'convenience_fee_float' => $ccAERpcf,
                'convenience_fee_drp' => $ccAERcfDrp,
                'convenience_fee_float_drp' => $ccAERpcfDrp,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'payment_method' => 'amex',
                'is_recurring' => '1',
            ]);

        }

        if($ccamexet){
            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccAEETlpr,
                'high_pay_range' => $ccAEEThpr,
                'high_ticket' => $ccAEETht,
                'convenience_fee' => $ccAEETcf,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'convenience_fee_float' => $ccAEETpcf,
                'payment_method' => 'eterm-amex',
                'is_recurring' => '0',
            ]);

        }

        if($ccamexetr){
            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccAEETRlpr,
                'high_pay_range' => $ccAEETRhpr,
                'high_ticket' => $ccAEETRht,
                'convenience_fee' => $ccAEETRcf,
                'convenience_fee_float' => $ccAEETRpcf,
                'convenience_fee_drp' => $ccAEETRcfDrp,
                'convenience_fee_float_drp' => $ccAEETRpcfDrp,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'payment_method' => 'eterm-amex',
                'is_recurring' => '1',
            ]);

        }

        if($ccivr){
            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccIVRlpr,
                'high_pay_range' => $ccIVRhpr,
                'high_ticket' => $ccIVRht,
                'convenience_fee' => $ccIVRcf,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'convenience_fee_float' => $ccIVRpcf,
                'payment_method' => 'ivr-cc',
                'is_recurring' => '0',
            ]);

            DB::table('card_type_fee')
                ->where('tier_id', 'ccivr1')
                ->where('id_property', $id)
                ->update([
                    'id_merchant_account' => $idmacc
                ]);
        }

        if($ccsw){

            $idmacc = DB::table('merchant_account')->insertGetId([
                'property_id' => $id,
                'gateway' => $ccgateway,
                'low_pay_range' => $ccSWlpr,
                'high_pay_range' => $ccSWhpr,
                'high_ticket' => $ccSWht,
                'convenience_fee' => $ccSWcf,
                'payment_source_key' => $ccsourcekey,
                'payment_source_store_id' => $ccstoreid,
                'payment_source_location_id' => $cclocationid,
                'payment_source_merchant_id' => $ccmid,
                'novault' => $ccdisabletoken,
                'convenience_fee_float' => $ccSWpcf,
                'convenience_fee_drp' => $ccSWcfDrp,
                'convenience_fee_float_drp' => $ccSWpcfDrp,
                'payment_method' => 'swipe',
                'is_recurring' => '0',
            ]);

            DB::table('card_type_fee')
                ->where('tier_id', 'ccsw1')
                ->where('id_property', $id)
                ->update([
                    'id_merchant_account' => $idmacc
                ]);
        }


        //dynamic form
        foreach ($all_submit as $field => $val){

            if(strpos($field,'ccWOTlprDYNAMIC')===0 && strpos($field,'ccWOTlprDYNAMIC|')===false ){
                $number = str_replace('ccWOTlprDYNAMIC','',$field);
                if($ccwot){
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccWOTlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccWOThprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ccWOThtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccWOTcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccWOTlpcfDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'cc',
                        'is_recurring' => '0',
                    ]);

                    DB::table('card_type_fee')
                        ->where('tier_id', 'ccwot'.$number)
                        ->where('id_property', $id)
                        ->update([
                            'id_merchant_account' => $idmacc
                        ]);
                }
            }

            if(strpos($field,'ccWRlprDYNAMIC')===0 && strpos($field,'ccWRlprDYNAMIC|')===false ) {
                $number = str_replace('ccWRlprDYNAMIC', '', $field);
                if ($ccwr) {
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccWRlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccWRhprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ccWRhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccWRcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccWRpcfDYNAMIC'.$number],
                        'convenience_fee_drp' => $all_submit['ccWRcfDrpDYNAMIC'.$number],
                        'convenience_fee_float_drp' => $all_submit['ccWRpcfDrpDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'cc',
                        'is_recurring' => '1',
                    ]);

                    DB::table('card_type_fee')
                        ->where('tier_id', 'ccwr'.$number)
                        ->where('id_property', $id)
                        ->update([
                            'id_merchant_account' => $idmacc
                        ]);
                }
            }

            if(strpos($field,'ccEOTlprDYNAMIC')===0 && strpos($field,'ccEOTlprDYNAMIC|')===false ) {
                $number = str_replace('ccEOTlprDYNAMIC', '', $field);
                if ($cceot) {
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccEOTlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccEOThprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ccEOThtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccEOTcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccEOTpcfDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'eterm-cc',
                        'is_recurring' => '0',
                    ]);

                    DB::table('card_type_fee')
                        ->where('tier_id', 'cceot'.$number)
                        ->where('id_property', $id)
                        ->update([
                            'id_merchant_account' => $idmacc
                        ]);
                }
            }

            if(strpos($field,'ccERlprDYNAMIC')===0 && strpos($field,'ccERlprDYNAMIC|')===false ) {
                $number = str_replace('ccERlprDYNAMIC', '', $field);
                if ($ccer) {
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccERlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccERhprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ccERhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccERcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccERpcfDYNAMIC'.$number],
                        'convenience_fee_drp' => $all_submit['ccERcfDrpDYNAMIC'.$number],
                        'convenience_fee_float_drp' => $all_submit['ccERpcfDrpDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'eterm-cc',
                        'is_recurring' => '1',
                    ]);

                    DB::table('card_type_fee')
                        ->where('tier_id', 'ccer'.$number)
                        ->where('id_property', $id)
                        ->update([
                            'id_merchant_account' => $idmacc
                        ]);
                }
            }

            if(strpos($field,'ccAElprDYNAMIC')===0 && strpos($field,'ccAElprDYNAMIC|')===false ) {
                $number = str_replace('ccAElprDYNAMIC', '', $field);
                if($ccamex){
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccAElprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccAEhprDYNAMIC'.$number],
                        'high_ticket' =>$all_submit['ccAEhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccAEcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccAElpcfDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'amex',
                        'is_recurring' => '0',
                    ]);

                    DB::table('card_type_fee')
                        ->where('tier_id', 'idmacc'.$number)
                        ->where('id_property', $id)
                        ->update([
                            'id_merchant_account' => $idmacc
                        ]);
                }
            }

            if(strpos($field,'ccAERlprDYNAMIC')===0 && strpos($field,'ccAERlprDYNAMIC|')===false ) {
                $number = str_replace('ccAERlprDYNAMIC', '', $field);
                if($ccamexr){
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccAERlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccAERhprDYNAMIC'.$number],
                        'high_ticket' =>$all_submit['ccAERhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccAERcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccAERlpcfDYNAMIC'.$number],
                        'convenience_fee_drp' => $all_submit['ccAERcfDrpDYNAMIC'.$number],
                        'convenience_fee_float_drp' => $all_submit['ccAERlpcfDrpDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'amex',
                        'is_recurring' => '1',
                    ]);
                }
            }

            if(strpos($field,'ccAEETlprDYNAMIC')===0 && strpos($field,'ccAEETlprDYNAMIC|')===false ) {
                $number = str_replace('ccAEETlprDYNAMIC', '', $field);
                if($ccamexet){
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccAEETlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccAEEThprDYNAMIC'.$number],
                        'high_ticket' =>$all_submit['ccAEEThtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccAEETcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccAEETlpcfDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'eterm-amex',
                        'is_recurring' => '0',
                    ]);
                }
            }

            if(strpos($field,'ccAEETRlprDYNAMIC')===0 && strpos($field,'ccAEETRlprDYNAMIC|')===false ) {
                $number = str_replace('ccAEETRlprDYNAMIC', '', $field);
                if($ccamexetr){
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccAEETRlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccAEETRhprDYNAMIC'.$number],
                        'high_ticket' =>$all_submit['ccAEETRhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccAEETRcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccAEETRlpcfDYNAMIC'.$number],
                        'convenience_fee_drp' => $all_submit['ccAEETRcfDrpDYNAMIC'.$number],
                        'convenience_fee_float_drp' => $all_submit['ccAEETRlpcfDrpDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'eterm-amex',
                        'is_recurring' => '1',
                    ]);
                }
            }

            if(strpos($field,'ccIVRlprDYNAMIC')===0 && strpos($field,'ccIVRlprDYNAMIC|')===false ) {

                $number = str_replace('ccIVRlprDYNAMIC', '', $field);
                if($ccivr){

                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccIVRlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccIVRhprDYNAMIC'.$number],
                        'high_ticket' =>$all_submit['ccIVRhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccIVRcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccIVRpcfDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'ivr-cc',
                        'is_recurring' => '0',
                    ]);

                    DB::table('card_type_fee')
                        ->where('tier_id', 'ccivr'.$number)
                        ->where('id_property', $id)
                        ->update([
                            'id_merchant_account' => $idmacc
                        ]);
                }
            }

            if(strpos($field,'ccSWlprDYNAMIC')===0 && strpos($field,'ccSWlprDYNAMIC|')===false ) {
                $number = str_replace('ccSWlprDYNAMIC', '', $field);
                if ($ccsw) {
                    $idmacc = DB::table('merchant_account')->insertGetId([
                        'property_id' => $id,
                        'gateway' => $ccgateway,
                        'low_pay_range' => $all_submit['ccSWlprDYNAMIC'.$number],
                        'high_pay_range' => $all_submit['ccSWhprDYNAMIC'.$number],
                        'high_ticket' => $all_submit['ccSWhtDYNAMIC'.$number],
                        'convenience_fee' => $all_submit['ccSWcfDYNAMIC'.$number],
                        'convenience_fee_float' => $all_submit['ccSWpcfDYNAMIC'.$number],
                        //'convenience_fee_drp' => $all_submit['ccSWcfDrpDYNAMIC'.$number],
                        //'convenience_fee_float_drp' => $all_submit['ccSWpcfDrpDYNAMIC'.$number],
                        'payment_source_key' => $ccsourcekey,
                        'payment_source_store_id' => $ccstoreid,
                        'payment_source_location_id' => $cclocationid,
                        'payment_source_merchant_id' => $ccmid,
                        'novault' => $ccdisabletoken,
                        'payment_method' => 'swipe',
                        'is_recurring' => '0',
                    ]);

                    DB::table('card_type_fee')
                        ->where('tier_id', 'ccsw'.$number)
                        ->where('id_property', $id)
                        ->update([
                            'id_merchant_account' => $idmacc
                        ]);
                }
            }
        }



        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    function deletecardtype($token,Request $request){
       // list($data)=explode('|',Crypt::decrypt($token));
       // $array_token = json_decode($data,1);

        //security
        //$objAdminAuth = new AuthAdminController();
        //$objAdminAuth->checkAuthPermissions($array_token['iduser'], null, null, 'paymentcredentials');


        $submit = $request->all();
        if(isset($submit['idtier']) && isset($submit['idacc'])){
            DB::table('card_type_fee')->where('tier_id', $submit['idtier'])->where('id_merchant_account', $submit['idacc'])->delete();
            DB::table('merchant_account')->where('merchant_account_id', $submit['idacc'])->delete();
        }

        if(isset($submit['idacc']) && isset($submit['rmv_all_fees'])){
            DB::table('card_type_fee')->where('id_merchant_account', $submit['idacc'])->delete();
        }
        echo '1';
    }

    function getCardTypeFee($token,Request $request){

       // list($data)=explode('|',Crypt::decrypt($token));
        //$array_token = json_decode($data,1);

        //security
        //$objAdminAuth = new AuthAdminController();
        //$objAdminAuth->checkAuthPermissions($array_token['iduser'], null, null, 'paymentcredentials');

        $submit = $request->all();
        if($submit['idacc']){
            $data =  DB::table('card_type_fee')->where('id_merchant_account', $submit['idacc'])->get();
            return $data;
        }
    }

    function updatecardtype($token,$idproperty, Request $request){

       // $array_token_enc=explode('|',Crypt::decrypt($token));
       // list($data)=explode('|',Crypt::decrypt($token));
      //  $array_token = json_decode($data,1);

        //security
        //$objAdminAuth = new AuthAdminController();
        //$objAdminAuth->checkAuthPermissions($array_token['iduser'], null, null, 'paymentcredentials');
        $submit = $request->all();

        $validator = Validator::make($submit,[

         /*   'mcdb_cfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'mcdb_cfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            'mcdb_pcfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'mcdb_pcfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
           // 'mcc_cfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'mcc_cfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
           // 'mcc_pcfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'mcc_pcfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            //'vdb_cfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'vdb_cfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            //'vdb_pcfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'vdb_pcfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            //'vc_cfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'vc_cfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            //'vc_pcfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'vc_pcfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            //'ddb_cfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'ddb_cfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            //'ddb_pcfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'ddb_pcfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            //'dc_cfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'dc_cfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',
            //'dc_pcfee' => 'regex:/^\d*(\.\d{1,2})?$/',
            'dc_pcfeedrp' => 'regex:/^\d*(\.\d{1,2})?$/',*/

            'card_type' => 'required',
            'tier_id' => 'required',

        ]);
        if($validator->fails()){
            $str_errors = '';
            foreach ($validator->errors()->getMessages() as $field)
            {
                foreach ($field as $item){
                    $str_errors.=$item.'<br/>';
                }
            }
            return $str_errors;
        }
        else{
            DB::table('card_type_fee')->where('tier_id', $submit['tier_id'])->where('id_merchant_account', $submit['macc_id'])->delete();

            foreach ($submit['card_type'] as $field){

                $cfee_drp = $pcfee_drp = null;
                if(isset($submit[$field.'_cfeedrp'])){
                     $cfee_drp = $submit[$field.'_cfeedrp'];
                }
                if(isset($submit[$field.'_pcfeedrp'])){
                    $pcfee_drp = $submit[$field.'_pcfeedrp'];
                }
                
                $cfee = $submit[$field.'_cfee'] == null ? "0.00" : $submit[$field.'_cfee'];
                $pcfee = $submit[$field.'_pcfee'] == null ? "0.00" : $submit[$field.'_pcfee'];
                $cfee_drp = $cfee_drp == null ? "0.00" : $cfee_drp;
                $pcfee_drp = $pcfee_drp == null ? "0.00" : $pcfee_drp;
                    
                DB::table('card_type_fee')->insert([
                    'id_merchant_account' => $submit['macc_id'],
                    'tier_id' => $submit['tier_id'],
                    'type' => $field,
                    'convenience_fee' => $cfee,
                    'convenience_fee_float' => $pcfee,
                    'convenience_fee_drp' => $cfee_drp,
                    'convenience_fee_float_drp' => $pcfee_drp,
                    'id_property' => $idproperty
                ]);


            }
            return 1;
        }


    }

    public function merchantticketreport($token, $merchantid, Request $request){

        $array_token = json_decode($token,1);
        $idlevel = isset($array_token['id'])?$array_token['id']:null;
        $level = isset($array_token['type'])?$array_token['type']:null;
        //$token = Crypt::encrypt($array_token.'|'.time().'|'.config('app.appAPIkey'));

        //security
//		$objAdminAuth = new AuthAdminController();
//		$objAdminAuth->checkAuthPermissions($array_token['iduser']);

        //echo $idlevel.' == '.$level; die;
        $merchants = new Properties();
        $grid = \DataGrid::source($merchants->getTicketReportByPropertyId($idlevel, $merchantid, $level));
        //print_r($grid); die;
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));
        //print_r($grid); die;
        //$grid->add($idlevel,'idlevel')->style("display:none;");
        $grid->add('id','ID')->style("display:none;");
        $grid->add('date','Date')->cell(function ($value) {
            $value = strtotime($value);
            return date("m/d/Y, g:i a", $value);
        });
        $grid->add('name','Name');
        $grid->add('lastname','Lastname');
        $grid->add('email','Email');
        $grid->add('phone','Phone');
        $grid->add('type','Type')->cell(function($value){
            switch ($value){
                case 1:
                    return "Registration issue";
                    break;
                case 2:
                    return "Log in issue";
                    break;
                case 3:
                    return "One time payment issue";
                    break;
                case 4:
                    return "Auto pay issue";
                    break;
                case 5:
                    return "Question about already made payment";
                    break;
                case 6:
                    return "Balance due question";
                    break;
                case 101:
                    return "Increase payment limits";
                    break;
                case 100:
                    return "Bank account change";
                    break;
                case 99:
                    return "Cancel Merchant Account";
                    break;
                default:
                    return "Other";
                    break;
            }
        });
        $grid->add('status','Status')->cell( function($value){
            switch ($value){
                case 0:
                    return '<span class="label alert-danger">Open</span>';
                    break;
                case 1:
                    return '<span class="label alert-success">Closed</span>';
                    break;
                default:
                    return '<span class="label alert-warning">unknown</span>';
                    break;
            }
        });
        $grid->add('reqby','Request by')->cell( function($value){
            switch ($value){
                case 0:
                    return 'User';
                    break;
                case 1:
                    return 'Admin';
                    break;
            }
        });
  
        $grid->orderBy('id','DESC');
        $grid->paginate(10);
        $grid->row(function ($row){
            $row->cell('id')->style("display:none;");
        }
);


        return view('manage.merchant.merchant_ticket_report',array('pageTitle'=>'Ticket Report', 'grid' => $grid,'level'=>$level,'idlevel'=>$idlevel, 'propertyId' => $merchantid, 'token' => $token));

    }

    public function merchantfraudcontrol($token, $merchantid, Request $request){

        $array_token = decrypt($token);
        $idlevel = isset($array_token['level_id'])? $array_token['level_id']:null;
        $level = isset($array_token['level'])?$array_token['level']:null;
       // $token = Crypt::encrypt($array_token.'|'.time().'|'.config('app.appAPIkey'));

        //security
//		$objAdminAuth = new AuthAdminController();
//		$objAdminAuth->checkAuthPermissions($array_token['iduser']);
        $merchants = new Properties();
        $fraud_control_array = array();
        $fraud_control_config = $merchants->getFraudControlConfigByPropertyId($idlevel, $merchantid, $level);
        if(!empty($fraud_control_config)){
            if (isset($fraud_control_config->data)){
                $fraud_control_array = (array) json_decode($fraud_control_config->data,true);
            }
        }
        if(count($fraud_control_array)==0){
            $fraud_control_array = (array) json_decode('{"fraud1a":"checked","fraud2a":"checked","fraud3a":"checked","fraud4a":"checked","fraud5a":"checked","fraud6a":"checked","fraud7a":"checked","fraud8a":"checked","fraud9a":"checked","fraud10a":"unchecked","fraud1":"100","fraud2":"3","fraud3":"300","fraud4":"300","fraud5":"150","fraud7":"100","fraud8":"100","fraud9":"15.00","fraud10":"100"}',true);
        }
        return view('manage.merchant.merchant_fraud_alert_config',array('pageTitle'=>'Fraud Control Config',
            'fraud_control_config' => $fraud_control_array,'level'=>$level,'idlevel'=>$idlevel, 'propertyId' => $merchantid, 'token' => $token));
    }

    public function merchantfraudcontrolstore($token, $merchantid, Request $request){
        $array_token = decrypt($token);
        $idlevel = isset($array_token['level_id'])?$array_token['level_id']:null;
        $level = isset($array_token['level'])?$array_token['level']:null;
        $submit = $request->all();
        unset($submit['_token']);
        DB::table('fraud_control')->where('property_id','=',$merchantid)->delete();
        DB::table('fraud_control')->insert([
            'data' => json_encode($submit),
            'property_id' => $merchantid
        ]);
        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    public function movemerchantsubmit($token,$id, Request $request){
        $atoken = decrypt($token);
        $select_partner ="";if(null !==$request->input('select_partner'))$select_partner=trim($request->input('select_partner'));
        $select_companies ="";if(null !==$request->input('select_companies'))$select_companies=trim($request->input('select_companies'));
        if($select_partner && $select_companies){
            DB::table('properties')
                ->where('id', $id)
                ->update([
                    'id_partners' => $select_partner,
                    'id_companies' => $select_companies
                ]);

        }
        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    public function merchantapirevo($token, $id, Request $request){

        $array_token = decrypt($token);
        $idlevel = isset($array_token['level_id'])? $array_token['level_id']:null;
        $level = isset($array_token['level'])?$array_token['level']:null;
        $apiobj=new \App\Http\Models\ApiUser();
        $keys=$apiobj->getByLevel($id, 'M');
        $grid = \DataGrid::source($keys);
        $grid->add($token, $token)->style("display:none;");
        $grid->add('idapi', 'id')->style("display:none;");
        $grid->add('apiusername', 'Legacy Username');
        $grid->add('lvcode', 'Token');
        $grid->add('created_on','Date Created');
        $grid->add('actionvalue', 'Action')->style("text-align:right;");
        $grid->row(
                function ($row) {
            $id = $row->cell('idapi')->value;
            $edit_link = '';
            $delete_link = '<li><a onclick="deletekey(' . $id . ')" >Delete</a></li>';
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret" ></span></button>
								<ul class="dropdown-menu">
							' . $edit_link . '
							' . $delete_link . '
														  </ul>
	 													</div>';
            $row->cell('idapi')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $grid->orderBy('idapi', 'ASC');
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('manage.merchant.merchantapirevo', array(
            'token' => $token,
            'grid' => $grid,
            'propertyId'=>$id
        ));
    }

    public function merchantapirevostore($token, $id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        if($level!='A'){
            return Redirect::back()->with('error', 'Invalid priviledges');
        }
        $data=$request->all();
        unset($data['_token']);
        $apiusr=trim($data['lusername']);
        $apipassw=trim($data['lpassword']);
        //verify username is unique
        $apiobj=new \App\Http\Models\ApiUser();
        if($apiobj->existsUsername($apiusr)){
            return Redirect::back()->with('error', 'This username exists already. Please change it and try again');
        }
        $newdata = array('usr' => $apiusr, 'psw' => $apipassw);
        $current_p = json_encode($newdata);
        $newtoken = \Illuminate\Support\Facades\Crypt::encrypt($current_p . "|" . time() . "|" . config('app.appAPIkey'));
        DB::table('api_user')->insert(['apiusername' => $apiusr, 'apipasswd' => sha1($apipassw), 'lvcode' => $newtoken, 'id_property' => $id]);
        return Redirect::back()->with('success', 'The element was saved successfully');
    }

    public function deleteapirevo($token,$id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        if($level!='A'){
            return Redirect::back()->with('error', 'Invalid priviledges');
        }
        DB::table('api_user')->where('idapi',$id)->delete();
        return Redirect::back()->with('success', 'The key was deleted successfully');
    }
    
    public function newapirevo($token,$id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        if($level!='A'){
            return Redirect::back()->with('error', 'Invalid priviledges');
        }
        $api_obj=new \App\Http\Models\ApiUser();
        $newusername = 'apix' . $id . $level . $idlevel . time();
        $newpassw = 'pwd' . $id . $level . $idlevel . time();
        if ($api_obj->existsUsername($newusername)) {
            $newusername.=time();
        }
        $apiusr=$newusername;
        $apipassw=$newpassw;
        $newdata = array('usr' => $apiusr, 'psw' => $apipassw);
        $current_p = json_encode($newdata);
        $newtoken = \Illuminate\Support\Facades\Crypt::encrypt($current_p . "|" . time() . "|" . config('app.appAPIkey'));
        DB::table('api_user')->insert(['apiusername' => $apiusr, 'apipasswd' => sha1($apipassw), 'lvcode' => $newtoken, 'id_property' => $id]);
        return Redirect::back()->with('success', 'The key was generated successfully');
    }

    public function merchantgsb($token, $id, Request $request){
        $array_token = decrypt($token);
        $idlevel = isset($array_token['level_id'])? $array_token['level_id']:null;
        $level = isset($array_token['level'])?$array_token['level']:null;
        $shared= DB::table('shared_keys')->where('property_id',$id)->first();
        $idgsb=0;
        if(!empty($shared)){
            $idgsb=$shared->id;
        }
        return view('manage.merchant.merchantgsb', array(
            'token' => $token,
            'shared' => $shared,
            'propertyId'=>$id,
            'idgsb'=>$idgsb
        ));
    }

    public function merchantgsbstore($token, $id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];
        if($level!='A'){
            return Redirect::back()->with('error', 'Invalid priviledges');
        }
        $data=$request->all();
        $sk=trim($data['lshared']);
        $bd=trim(str_replace(' ','_',$data['lbiller']));
        if($data['idgsb']==0){
            DB::table('shared_keys')->insert(['sharedkey' => $sk, 'biller_domain' => $bd, 'property_id' => $id]);
        }
        else {
            DB::table('shared_keys')->where('id',$data['idgsb'])->update(['sharedkey' => $sk, 'biller_domain' => $bd, 'property_id' => $id]);
        }
        return Redirect::back()->with('success', 'The credentials were saved successfully');
    }

    public function merchantmdi($token, $id, Request $request){

        $mc_obj = new Model\MicroCredential();
        $data = $mc_obj->getDataFromProperty($id);

        if (isset($data->mapping_field)){
            $data->mapping_field =  json_decode($data->mapping_field,1);
        }

        return view('manage.merchant.merchantmdi', array(
            'id'=>$id,
            'token' => $token,
            'propertyId'=>$id,
            'data'=>$data
        ));
    }

    public function merchantmdistore($token, $id, Request $request){
        $array_token = decrypt($token);
        $idlevel = $array_token['level_id'];
        $level = $array_token['level'];

        $request->validate([
            'customerid' => 'required|string|max:50',
            'profilenumber' => 'required|numeric',
        ]);

        $array_data = array();
        $data_post = $request->all();
        foreach ($data_post as $key =>$item) {
            if (starts_with($key,'check_' )) {
                $check_field = explode('_',$key)[1];
                if(isset($data_post['field_'.$check_field])){
                    $array_data[$check_field] = $data_post['field_'.$check_field];
                }
            }
        }
        $array_data2['mapping_field']=$array_data;

        $data_save['property_id'] = $id;
        $data_save['customer_id'] = $data_post['customerid'];
        $data_save['profile_number'] = $data_post['profilenumber'];
        $data_save['mapping_field'] = json_encode($array_data2);

        $mc_obj = new Model\MicroCredential();
        $mc_obj->saveData($data_save);

        return Redirect::back()->with('success', 'The element was saved successfully');
    }
    
}
