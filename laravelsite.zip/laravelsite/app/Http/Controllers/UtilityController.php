<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Crypt;
use DB;

class UtilityController extends Controller
{
    function getfeedback($token){
        return view('utility.feedback',['token'=>$token]);
    }
    
    function savefeedback($token,Request $request){
        $atoken = decrypt($token);
        $level = strtolower($atoken['level']);
        $idlevel = $atoken['level_id'];
        $data=$request->all();
        $data['level']=$level;
        $data['idlevel']=$idlevel;

        $request->validate([
            'reference' => 'required|min:5',
            'describe' => 'required|min:10',
        ]);



        \Illuminate\Support\Facades\DB::table('feedback')->insert($data);
        return redirect(route('feedbackmessage'));
    }

    function savefeedmessage(){
        return view('utility.thanks');
    }
}