<?php
namespace App\Http\Controllers;

use App\Model\Partners;
use App\Model\Branch;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class BranchController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function managebranch($token, Request $request){
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if($level!='A'){
            return redirect(route('accessdenied'));
        }
        $catdb = new Branch();
        $filter = \DataFilter::source($catdb->getByFilter());


        $filter->add('name','Branch','text');
        $filter->add('subdomain_branch','Subdomain','text');
        $filter->submit('search');
        $filter->reset('reset');
        $filter->build();	

        $grid = \DataGrid::source($filter);		
        $grid->attributes(array("class"=>"table table-striped table-hover"));
        $grid->add($token, $token)->style("display:none;");
        $grid->add('id', 'id')->style("display:none;");
        $grid->add('name','Branch',true);
        $grid->add('subdomain_branch','SubDomain',true);
        $grid->add('npartners','Partners included');
	    $grid->add('actionvalue', 'Action')->style('text-align:right;');

        $grid->row(
        function ($row) {
            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;
            $token_b = \Illuminate\Support\Facades\Crypt::encrypt(['level' => "B", 'level_id' => $id]);
            $objbranch=new Branch();
            $row->cell('npartners')->value=$objbranch->getNPartners($id);
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret white-font-color" ></span></button>
								<ul class="dropdown-menu">
                                                                <li><a href="#" onclick="openg(\''.$token_b.'\');" >Open</a></li>
							<li><a href="'.route('editbranch',array('token'=>$token,'id'=>$id)).'" >Edit</a></li>
							<li><a onclick="deletebranch(' . $id . ')" >Delete</a></li>
                          </ul>
                        </div>';
            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );
        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('subdomain_branch', 'ASC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));

        return view('manage.branch.branch', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    
    }


    
    function deletebranch($token, $id) {
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];
        $catdb = new Branch();
        $catdb->deleteBranch($id);
        return redirect()->back()->with('success', 'Branch deleted successfully.');
    }

    function addbranch($token){

        $obj_partner = new Partners();
        $obj_manageAdminController = new ManageAdminController();
        $partners =  $obj_manageAdminController->objDBToArray($obj_partner->all(), 'id' , 'partner_title');

        return view('manage.branch.add', array(
            'token' => $token,
            'partners'=>$partners
        ));
    }

    function addbranchSave($token, Request $request){
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $validator = $request->validate([
            'name' => 'required|max:255',
            'subdomain' => 'required|max:255',
        ]);

        $ebranch=DB::table('branch')->where('subdomain_branch','like',$request->get('subdomain'))->count();
        if($ebranch>0){
            return \redirect()->back()->with('error', 'The subdomain provided exists already. Please input a different value and try again.');
        }
        $id_branch = DB::table('branch')->insertGetId([
            'name' => $request->get('name'),
            'subdomain_branch' => $request->get('subdomain'),
        ]);

        if($request->get('partners')){
            foreach ($request->get('partners') as $partner){
                DB::table('branch_partner')->insert(['branch_id' => $id_branch,'id_partners' => $partner]);
            }
        }else{
            return \redirect()->back()->with('error', 'You must select at least one Partner');
        }

        return redirect()->route('managebranch',array('token'=>$token))->with('success', 'Branch created successfully.');
    }

    function editbranch($token, $idbranch){
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $obj_partner = new Partners();
        $obj_manageAdminController = new ManageAdminController();
        $partners =  $obj_manageAdminController->objDBToArray($obj_partner->all(), 'id' , 'partner_title');

        $obj_branch = new Branch();
        $branch = $obj_branch->getById($idbranch);

        $partners_selected = $obj_manageAdminController->objDBToArray($obj_branch->getPartnersByBranchId($idbranch),'id_partners' , 'partner_title',true);

        if(!$branch){
            return redirect()->back()->with('error', 'We can\'t find the branch.');
        }

        return view('manage.branch.edit', array(
            'token' => $token,
            'partners'=>$partners,
            'branch'=>$branch,
            'partners_selected'=>$partners_selected,
            'idbranch'=>$idbranch
        ));
    }

    function editbranchSave($token, $idbranch, Request $request){

        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        $validator = $request->validate([
            'name' => 'required|max:255',
            'subdomain' => 'required|max:255',
        ]);

        $ebranch=DB::table('branch')->where('subdomain_branch','like',$request->get('subdomain'))->where('id','!=',$idbranch)->count();
        if($ebranch>0){
            return \redirect()->back()->with('error', 'The subdomain provided exists already. Please input a different value and try again.');
        }
        DB::table('branch')
            ->where('id', $idbranch)
            ->update([
                'name' => $request->get('name'),
                'subdomain_branch' => $request->get('subdomain'),
            ]);

        DB::table('branch_partner')->where('branch_id', $idbranch)->delete();
        if($request->get('partners')){
            foreach ($request->get('partners') as $partner){
                DB::table('branch_partner')->insert(['branch_id' => $idbranch,'id_partners' => $partner]);
            }
        }else{
            return \redirect()->back()->with('error', 'You must select at least one Partner');
        }
        return \redirect()->route('managebranch',['token'=>$token,'request'=>$request])->with('success', 'Branch updated successfully.');
        //return Redirect::back()->with('success', 'Branch updated successfully.');

    }
}