<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use App\Model\TaReports;
use Illuminate\Support\Facades\DB;


class TaReportController extends Controller
{
	
		function __construct()
		{
			$this->middleware('auth');
			$this->middleware('permission')->only('accountingtransactions');
		}
		
		public function getIndex($token = null, Request $request) {
			
			if (!validateToken($token)) {
				return redirect(route('accessdenied'));
			}
			
			$taReports = new TaReports();
			$firstDate = '';
			$lastDate = '';
			$taResults = $taReports->getUsersPaidByMonth();
			$filter = \DataFilter::source($taResults);
			$filter->add('partners.partner_title','Partner Title','text');//field name, label, sortable
			$filter->add('companies.company_name','Grpup','text'); //relation.fieldname 
			$filter->add('properties.name_clients','Merchant','text'); //relation.fieldname 
			$filter->add('fromdate','Start Date','date')->format('Y-m-d', 'en')->scope(function ($query, $value) {
				$fromDate = $value.' 00:00:00';
				return $query->where('accounting_transactions.trans_first_post_date', '>=', $fromDate);
			});
			$filter->add('todate','End Date','date')->format('Y-m-d', 'en')->scope(function ($query, $value) {
				$toDate = $value.' 23:59:59';
				return $query->where('accounting_transactions.trans_first_post_date', '<=', $toDate);
			});
			$filter->add('properties.units','Units','text'); //relation.fieldname
			$filter->submit('Search');
			$filter->reset('Reset', 'BL', ['class' => 'filterreset btn btn-default']);
			$filter->build();
			$firstDate = $request->input('fromdate');
			$lastDate = $request->input('todate');
			
			$grid = \DataGrid::source($filter);
			$grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer"));
			$grid->add('partner_title', 'Partner Title', true)->attributes(array("class" => "trans-column"));
			$grid->add('company_name', 'Group', true)->attributes(array("class" => "trans-column"));
			$grid->add('name_clients', 'Merchant', true)->attributes(array("class" => "trans-column"));
			$grid->add('units', 'Units', true)->attributes(array("class" => "trans-column"));
			$grid->add('fromdate','Date',true);
			$grid->add('id', 'ID')->style("display:none;");
			$grid->add('active_users', 'Active users')->style('text-align:center;');
			$grid->add('authorized_users', 'Authorized users')->style('text-align:center;');
			$grid->add('actual_users', 'Actual # of users')->style('text-align:center;');
			$grid->add('users_paid', '# of Users paid')->style('text-align:center;');
			$grid->add('tapaid', 'May 2018 TA %')->style('text-align:center;');
			$grid->row(function ($row) { 	// PRINTS THE GRID
				$id = $row->cell('id')->value;
				$row->cell('id')->style("display:none;");

			//Active users, with no empty account number
			$activeAccNum = DB::table('web_users')
					->where('property_id', $id)
					->where('web_status', 1)
					->where('account_number', '!=', '')
					->select('account_number')
					->groupBy('account_number')
					->get();
					
			//Active users, with empty account number
			$activeEmptyAccNum = DB::table('web_users')
					->where('property_id', $id)
					->where('web_status', 1)
					->where('account_number', '')
					->select('web_user_id')
					->get();

			$accountno = '';
			if ($activeAccNum) {
				foreach ($activeAccNum as $items) {
					$accountno = $accountno . "'".$items->account_number . "', ";
				}
			}		 
			$accountno = rtrim($accountno, ', '); 
			
			//Authorized users, with no empty account number
			$authorizedAccNum = DB::table('web_users')
					->where('property_id', $id)
					->where('web_status', 998)
					->select('account_number')
					->where('account_number', '!=', '')
					->whereNotIn('account_number', [$accountno]  )
					->groupBy('account_number')
					->get();
						
			//Authorized users, with empty account number
			$authorizedEmptyAccNum = DB::table('web_users')
					->where('property_id', $id)
					->where('web_status', 998)
					->where('account_number', '')
					->select('web_user_id')
					->get();
				
			$activeUsers = count($activeAccNum) + count($activeEmptyAccNum);
			$authorizedUsers = count($authorizedAccNum) + count($authorizedEmptyAccNum);
			$actual_users	= $activeUsers + $authorizedUsers;
			$from = '2018-05-18 00:00:00';
            $to = '2018-05-24 23:59:59';
			$tapaid = '';
			$numUserPaid = $this->userPaidDatesAux($from, $to, $id);
			if ($actual_users != 0) {
                $tapaid = $numUserPaid / $actual_users;
            }
			$row->cell('active_users')->value = $activeUsers; 
			$row->cell('authorized_users')->value = $authorizedUsers;
			$row->cell('actual_users')->value = $actual_users;
			$row->cell('users_paid')->value = $numUserPaid;			
			$row->cell('tapaid')->value = $tapaid;		
			});
			$itemsPerPage = 15;
			
			if ($request->get('itemspage')) {
				$itemsPerPage = $request->get('itemspage');
			}

			$grid->orderBy('partners.partner_title', 'Asc');
			$grid->orderBy('companies.company_name', 'Asc');
			$grid->orderBy('properties.name_clients', 'Asc');
			$grid->paginate($itemsPerPage);
			$grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));
			
			$sql = $filter->query->toSql();
			$bindings = $filter->query->getBindings();
			$sql_ready = $sql;		

			foreach ($bindings as $replace) {
				$sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
			}
			$grid->getGrid('rapyd::datagrid');
			return view('reports.tareport.transaction', array('sql' => $sql_ready, 'pageTitle' => 'TA Report', 'filter' => $filter, 'grid' => $grid, 'recordperpage' => $itemsPerPage, 'token' => $token,'sqlEncrypted' => encrypt($sql_ready)));		
		}
		
		
		function userPaidDatesAux($from, $to, $property_id) {
			$userPaid = DB::table('accounting_transactions')
                ->join('web_users', 'web_users.web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->where('accounting_transactions.property_id', $property_id)
                ->where('accounting_transactions.trans_status', 1)
                ->where('accounting_transactions.trans_type', '<', 2)
                ->where('accounting_transactions.trans_first_post_date', '>=', $from)
                ->where('accounting_transactions.trans_first_post_date', '<=', $to)
                ->where('accounting_transactions.is_convenience_fee_trans', 0)
                ->where('accounting_transactions.source', '!=', 'NACHA')
                ->where('web_users.account_number', '!=', '')
                ->select('web_users.account_number')
                ->groupBy('web_users.account_number')
                ->get();
				
			$userEmptyPaid = DB::table('accounting_transactions')
                ->join('web_users', 'web_users.web_user_id', '=', 'accounting_transactions.trans_web_user_id')
                ->where('accounting_transactions.property_id', $property_id)
                ->where('accounting_transactions.trans_status', 1)
                ->where('accounting_transactions.trans_type', '<', 2)
                ->where('accounting_transactions.trans_first_post_date', '>=', $from)
                ->where('accounting_transactions.trans_first_post_date', '<=', $to)
                ->where('accounting_transactions.is_convenience_fee_trans', 0)
                ->where('accounting_transactions.source', '!=', 'NACHA')
                ->where('web_users.account_number', '')
                ->select('web_users.web_user_id')
                ->groupBy('web_users.web_user_id')
                ->get();
        
			return count($userPaid) + count($userEmptyPaid);
		}
}
