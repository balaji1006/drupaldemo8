<?php
namespace App\Http\Controllers;

use App\Model\Layout;
use App\Model\Partners;
use App\Model\Branch;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class LayoutController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }


    public function manageLayout($token, Request $request){

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];

        if(strtoupper($level) != "A"){
            return redirect(route('accessdenied'));
        }

        $layout_obj = new Layout();
        $layouts =  $layout_obj->getLayoutsObj();


        $grid = \DataGrid::source($layouts);
        $grid->attributes(array("class"=>"table table-striped table-hover"));

        $grid->add('idl', 'idl')->style("display:none;");
        $grid->add('idl', 'id')->style("display:none;");
        $grid->add('lay_name','Description',true);
        $grid->add('actionvalue', 'Action')->style("text-align:right");


        $grid->row(
            function ($row) use ($token){
                $id = $row->cell('idl')->value;
                $row->cell('actionvalue')->value = '<a href="'.route('manageeditlayout',array('token'=>$token, 'id'=>$id)).'" class="btn btn-xs btn-default pull-right">Edit</a>';
                $row->cell('idl')->style("display:none;");
            }
        );

        $itemsPerPage = 15;
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));



        return view('layout.layoutList', array('token'=>$token, 'grid'=>$grid));
    }

    public function addLayout($token){

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];

        if(strtoupper($level) != "A"){
            return redirect(route('accessdenied'));
        }

        $layout_obj = new Layout();
        $layout =  $layout_obj->getDefaultLayout();
        return view('layout.layoutAdd', array('token'=>$token,'layout'=>$layout));
    }

    public function saveLayout($token,Request $request){

        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];

        if(strtoupper($level) != "A"){
            return redirect(route('accessdenied'));
        }

        $request->validate([
            'name' => 'required|max:50',
        ]);
        $layout_obj = new Layout();
        $layout_obj->saveNewLayout($request->all());

        return Redirect::route('managelayout',array('token'=>$token))->with('success', 'The Layout has been saved successfully');
    }

    public function editLayout($token, $id){

        if(!$id){
            return back()->with('error', 'Layout not found');
        }

        $layout_obj = new Layout();
        $data = $layout_obj->getLayoutValuesMaster($id);


        if($data->isEmpty()){
            return back()->with('error', 'Layout not found');
        }

        return view('layout.layoutEdit', array('token'=>$token,'data'=>$data, 'id'=>$id));
    }

    public function updateLayout($token, $id, Request $request){

        $request->validate([
            'name' => 'required|max:50',
        ]);

        $layout_obj = new Layout();
        $layout_obj->updateLayout($request->all(), $id);


        return Redirect::route('managelayout',array('token'=>$token))->with('success', 'The Layout has been saved successfully');

    }
}