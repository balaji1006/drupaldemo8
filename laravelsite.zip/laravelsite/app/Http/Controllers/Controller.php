<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function validateDecrypt($token, $return = 'json'){
        try{
            return  \Illuminate\Support\Facades\Crypt::decrypt($token);
        }catch (\Exception  $e) {
            if($return == 'view')
                echo view('apiviewerror', array('errcode' => '909', 'message' => 'Invalid API Token.'))->render();
            else
                echo response()->json(array('response' => 902, 'responsetxt' => 'Invalid API Token.'));
            exit();
        }
    }
}
