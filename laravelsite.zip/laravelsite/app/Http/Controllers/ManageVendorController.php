<?php

namespace App\Http\Controllers;

use App\Model;
use App\Model\Vendors;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ManageVendorController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    function managevendors($token, Request $request) {
        $atoken = decrypt($token);
        $level = $atoken['level'];
        $idlevel = $atoken['level_id'];
        if ($level != 'M' ) {
            return redirect(route('accessdenied'));
        }

        $group_obj = new Vendors();
        $groups = $group_obj->getVendorByFilter($idlevel);
        
        $filter = \DataFilter::source($groups);

        $filter->add('eid', 'VendorID', 'text');
        $filter->add('vname', 'Name', 'text')->attributes(array('style' => 'max-width:140px;'));
        $filter->add('contact', 'Contact', 'text');
        $filter->add('type', 'Type', 'text');
        $filter->submit('Search');
        $filter->reset('Reset');
        $filter->build();

        $grid = \DataGrid::source($filter);
        $grid->add($token, $token)->style("display:none;");
        $grid->add('id', 'id')->style("display:none;");
        $grid->add('eid', 'VID');
        $grid->add('vname', 'Name');
        $grid->add('contact', 'Contact');
        $grid->add('mail', 'Email')->cell(
                function ($value) {
            if (strlen($value) > 10) {
                return '<a  data-toggle="tooltip" title="' . $value . '" style="text-decoration:none;color:#000;">' . substr($value, 0, 10) . '....</a>';
            } else {
                return $value;
            }
        }
        );
        $grid->add('work_phone', 'Phone');
        $grid->add('work_fax', 'Fax');
        $grid->add('type', 'Type');
        $grid->add('status', 'Status')->cell(
                function($value){
                    if($value==0){
                        return '<span class="label label-danger pull-right">Inactive</span>';
                    }
                    if($value==1){
                        return '<span class="label label-success pull-right">Active</span>';
                    }
                }
                );
//
        $grid->add('actionvalue', 'Action')->style("text-align:right;");

        $grid->row(
                function ($row) {
            $id = $row->cell('id')->value;
            $token = $row->cells[0]->name;
            $edit_link = '<li><a href="'.route('editvendor',array('token'=>$token, 'id'=>$id)).'" >Edit</a></li>';
            $delete_link = '<li><a onclick="deletevendor(' . $id . ')" >Delete</a></li>';
            $row->cell('actionvalue')->value = ' <div class="dropdown pull-right">
                            <button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span>Actions</span>
									<span class="caret" ></span></button>
								<ul class="dropdown-menu">
							' . $edit_link . '
							' . $delete_link . '
														  </ul>
	 													</div>';
            $row->cell('id')->style("display:none;");
            $row->cells[0]->style("display:none;");
        }
        );

        $sql = $filter->query->toSql();
        $bindings = $filter->query->getBindings();
        $sql_ready = $sql;
        foreach ($bindings as $replace) {
            $sql_ready = preg_replace('/\?/', "'$replace'", $sql_ready, 1);
        }
        $sql_ready = encrypt($sql_ready);
        $itemsPerPage = 15;
        if ($request->get('itemspage')) {
            $itemsPerPage = $request->get('itemspage');
        }
        $grid->orderBy('eid', 'ASC');
        $grid->paginate($itemsPerPage);
        $grid->attributes(array("class" => "table table-responsive table-striped table-bordered table-hover dataTable no-footer reportaction"));

        return view('manage.vendors.vendors', array(
            'token' => $token,
            'grid' => $grid,
            'filter' => $filter,
            'sqlEncrypted' => $sql_ready,
            'itemspage' => $itemsPerPage
        ));
    }
    
    function addvendor($token) {
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken['level'];
        if ($level != 'M') {
            return redirect(route('accessdenied'));
        }
        return view('manage.vendors.addvendor', array('token' => $token));
    }
    
    function savevendor($token, Request $request) {

        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken = ['level'];

        $objvendors = new Vendors();

        $vid_available = $objvendors->getVendorByProperty($request['txteid'],$idlevel);
        if($vid_available){
            return redirect()->back()->withInput($request->all())->with('error', 'The Vendor ID is in use, please change it and try again.');
        }

        $messages = [
            'txteid.required' => 'The Vendor ID field is required. ',
            'txteid.min' => 'The Vendor ID must be at least 3 characters.',
            'txteid.max' => 'The Vendor ID may not be greater than 255 characters.',

            'txtname.required' => 'The Name field is required. ',
            'txtname.min' => 'The Name must be at least 3 characters.',
            'txtname.max' => 'The Name may not be greater than 255 characters.',

            'txtcontactname.required' => 'The Contact Name field is required. ',
            'txtcontactname.min' => 'The Contact Name must be at least 3 characters.',
            'txtcontactname.max' => 'The Contact Name may not be greater than 255 characters.',

            'txtrouting.required' => 'The Bank Routing Number field is required. ',
            'txtrouting.numeric' => 'The Bank Routing Number must be only numbers. ',

            'txtbank.required' => 'The Bank Account Number field is required. ',
            'txtbank.numeric' => 'The Bank Account Number must be only numbers. ',
        ];

        $validator = $request->validate([
           'txteid' => 'required|max:255|min:3',
           'txtname' => 'required|max:255|min:3',
           'txtcontactname' => 'required|max:255|min:3',
           'ddlstatus' => 'required|max:10',
           'txtrouting' => 'required|numeric',
           'txtbank' => 'required|numeric',
           'ddltype' => 'required',
       ],$messages);
        
        $vendors = array();
        $vendors['property_id'] = $idlevel;
        $vendors['vname'] = $request['txtname'];
        $vendors['eid'] = $request['txteid'];
        $vendors['contact'] = $request['txtcontactname'];
        if($request['txtemail']!==null)$vendors['mail'] = $request['txtemail'];
        if($request['txtaddress']!==null)$vendors['address'] = $request['txtaddress'];
        if($request['txtcity']!==null)$vendors['city'] = $request['txtcity'];
        if($request['txtzip']!==null)$vendors['zip'] = $request['txtzip'];
        if($request['txtstate']!==null)$vendors['state'] = $request['ddlstate'];
        if($request['txtphone']!==null)$vendors['work_phone'] = $request['txtphone'];
        if($request['txtfax']!==null)$vendors['work_fax'] = $request['txtfax'];
        if($request['txttype']!==null)$vendors['type'] = $request['txttype'];
        if($request['txtbank']!==null)$vendors['account'] = $request['txtbank'];
        if($request['txtrouting']!==null)$vendors['routing'] = $request['txtrouting'];
        if($request['ddltype']!==null)$vendors['account_type'] = $request['ddltype'];
        $vendors['status'] = $request['ddlstatus'];
        $vendors['updated_by'] = Auth::user()->username;
        $vendors['updated_at'] = date('Y-m-d H:i:s');

        $objvendors->saveVendor($vendors);
        return redirect()->route('vendors', array('token' => $token))->with('success', 'The Vendor was saved successfully');
    }
    
    function deletevendor($token ,$id) {
        $dtoken = decrypt($token);
        $idlevel = $dtoken['level_id'];
        $level = $dtoken['level'];

        // security


        $objvendors = new Vendors();
        $objvendors->deleteVendor($id);
        return redirect()->back()->with('success', 'Vendor deleted successfully.');
    }
    
    function editVendor($token, $id) {
        $objvendors = new Vendors();
        $vendors_db = $objvendors->getVendordetail($id);
        return view('manage.vendors.editvendor', array('vendor' => $vendors_db, 'token' => $token));
    }
    
    function updatevendor($token,Request $request) {
        $id = $request['id'];
        if(empty($id)){
            return redirect()->route('vendors', array('token' => $token));
        }
        $token = $request['token'];
        $atoken = decrypt($token);
        $idlevel = $atoken['level_id'];
        $level = $atoken = ['level'];

        $messages = [
            'txteid.required' => 'The Vendor ID field is required. ',
            'txteid.min' => 'The Vendor ID must be at least 3 characters.',
            'txteid.max' => 'The Vendor ID may not be greater than 255 characters.',

            'txtname.required' => 'The Name field is required. ',
            'txtname.min' => 'The Name must be at least 3 characters.',
            'txtname.max' => 'The Name may not be greater than 255 characters.',

            'txtcontactname.required' => 'The Contact Name field is required. ',
            'txtcontactname.min' => 'The Contact Name must be at least 3 characters.',
            'txtcontactname.max' => 'The Contact Name may not be greater than 255 characters.',

            'txtrouting.required' => 'The Bank Routing Number field is required. ',
            'txtrouting.numeric' => 'The Bank Routing Number must be only numbers. ',
            'txtrouting.digits' => 'The Bank Routing Number may not be greater than 9 digits . ',

            'txtbank.required' => 'The Bank Account Number field is required. ',
            'txtbank.numeric' => 'The Bank Account Number must be only numbers. ',
            'txtbank.digits_between' => 'The Bank Account Number may not be greater than 17 digits. ',
        ];

        $validator = $request->validate([
            'txteid' => 'required|max:255|min:3',
            'txtname' => 'required|max:255|min:3',
            'txtcontactname' => 'required|max:255|min:3',
            'ddlstatus' => 'required|max:10',
            'txtrouting' => 'required|numeric|digits:9',
            'txtbank' => 'required|numeric|digits_between:1,17',
            'ddltype' => 'required',
        ],$messages);

        $objvendors = new Vendors();


        $vid_available = $objvendors->getVendorByProperty($request['txteid'],$idlevel);
        if($vid_available && $vid_available->id != $id){
            return redirect()->back()->withInput($request->all())->with('error', 'The Vendor ID is in use, please change it and try again.');
        }

        $vendors = array();
        $vendors['property_id'] = $idlevel;
        $vendors['vname'] = $request['txtname'];
        $vendors['eid'] = $request['txteid'];
        $vendors['contact'] = $request['txtcontactname'];
        if($request['txtemail']!==null)$vendors['mail'] = $request['txtemail'];
        if($request['txtaddress']!==null)$vendors['address'] = $request['txtaddress'];
        if($request['txtcity']!==null)$vendors['city'] = $request['txtcity'];
        if($request['txtzip']!==null)$vendors['zip'] = $request['txtzip'];
        if($request['txtstate']!==null)$vendors['state'] = $request['ddlstate'];
        if($request['txtphone']!==null)$vendors['work_phone'] = $request['txtphone'];
        if($request['txtfax']!==null)$vendors['work_fax'] = $request['txtfax'];
        if($request['txttype']!==null)$vendors['type'] = $request['txttype'];
        if($request['txtbank']!==null)$vendors['account'] = $request['txtbank'];
        if($request['txtrouting']!==null)$vendors['routing'] = $request['txtrouting'];
        if($request['ddltype']!==null)$vendors['account_type'] = $request['ddltype'];
        $vendors['status'] = $request['ddlstatus'];
        $vendors['updated_by'] = Auth::user()->username;
        $vendors['updated_at'] = date('Y-m-d H:i:s');

        $objvendors->updateVendor($vendors, $id);
        return redirect()->route('vendors', array('token' => $token))->with('success', 'The Vendor was updated successfully');
    }
}