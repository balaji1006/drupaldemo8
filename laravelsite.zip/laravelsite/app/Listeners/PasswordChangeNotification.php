<?php

namespace App\Listeners;

use App\Events\UserPasswordChanged;
use Illuminate\Support\Facades\Mail;

class PasswordChangeNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserPasswordChanged  $event
     * @return void
     */
    public function handle(UserPasswordChanged $event)
    {
        $user = $event->user->toArray();        
//        dd($user);
         Mail::send(
            'mail.passwordChangeNotification',
            $user,
            function ($message) {
            }
        );
    }
}
