function checkAccountExistence() {
    resetParentCounters();
    var acc = $("#xeacc").val();
    var address = $("#xeaddress").val();
    var fname = $("#xefname").val();
    var lname = $("#xelname").val();

    if ($.trim(acc + address + fname + lname) == "") {
        /*$("#xpopupheader").html("Information");
        $("#xpopupcontent").html("<label>" + "Please Select a Customer to Pay" + "</label>");
        $('#myModal_success').modal();*/
        swal({
            title: "Information",
            text: "Please Select a Customer to Pay!",
            type: "error",
            confirmButtonColor: "#DD6B55",
        });
        return false;
    }





    $("#xidaccount").val(acc);
    $("#xidfirstname").val(fname);
    $("#xidlastname").val(lname);
    $("#xidaddress").val(address);


    $("#form_user").submit();
}

function checkInvExistence() {
    resetParentCounters();
    var pinv = $("#xeinv").val();

    if ($.trim(pinv) == "") {
        /*$("#xpopupheader").html("Alert");
        $("#xpopupcontent").html("<label>" + "Please Input an Invoice to Pay" + "</label>");
        $('#myModal_success').modal();*/
        swal({
            title: "Information",
            text: "Please Input an Invoice to Pay!",
            type: "error",
            confirmButtonColor: "#DD6B55",
        });
        return false;
    }



    $("#xidinvnumber").val(pinv);
    $("#xtype").val("inv");

    $("#form_user").submit();

}

function SelectOneUser() {
    resetParentCounters();
    var xtoken2 = $('input:radio[name=radioInlineC]:checked').val();

    if ($.trim(xtoken2) == "") {
        /*$("#xpopupheader").html("Information");
        $("#xpopupcontent").html("<label>" + "Please Select a Customer to Pay" + "</label>");
        $('#myModal_success').modal();*/
        swal({
            title: "Information",
            text: "Please Select a Customer to Pay!",
            type: "error",
            confirmButtonColor: "#DD6B55",
        });
        return false;
    }


    $("#xtoken2").val(xtoken2);
    $("#form_user1").submit();
}
function resetParentCounters() {
    //window.parent.resetCounters();
    window.parent.parent.scrollTo(0, 0);
}

function ShowSearch() {
    $("#xmultiple").hide();
    $("#step1_wayp").show();
}


$('.collapse-action3').click(function () {
    $('#collapse4').collapse('hide');
    $('#payinv').attr('checked', false);
    $("#step3a").hide();
    $("#step3b").show();
    type = "usr";
});

$('.collapse-action4').click(function () {
    $('#collapse3').collapse('hide');
    $('#paycustomer').attr('checked', false);
    $("#step3b").hide();
    $("#step3a").show();
    type = "inv";

});

function GoBack() {
//    resetParentCounters();

    window.history.back();
}

function showNUser() {
    resetParentCounters();
    cleanacc();
    $("#myModal_NUeterm").modal();
}

////////////////////////////////////////////////////////////////////////////////

function cleanData() {

    cleanacc();
    cleaninv();
    xutoken = "";
}

function cleanacc() {
    $("#xotherinfo").hide();
    $("#xsearch_usr").show();
    $("#xnext_step").hide();
}

function cleaninv() {
    $("#xsearch_inv").show();
    $("#xnext_step_inv").hide();
    $("#xotherinfoinv").hide();
}

function selectOneCustomer() {
    resetParentCounters();
    var xuix = $('input:radio[name=radioInlineC]:checked').val();

    if (xuix == null) {
        $("#xerrorEterm").show();
        return false;
    }
    $("#myModal_eterm").modal("hide");

    var xcontent = {'xuix': xuix};
    $.ajax({
        url: xurls + "/eterm/validate1/" + xatoken + "/" + JSON.stringify(xcontent)
    }).done(function (data) {

        if (data.errcode == 0) {
            $("#xeacc").val(data.pacc);
            $("#xeacc").val(data.pacc);
            $("#xefname").val(data.pfirst_name);
            $("#xelname").val(data.plast_name);
            $("#xeaddress").val(data.paddress);
            xutoken = data.utoken;
            $(".selectpicker").selectpicker();
            $("#xotherinfo").show();
            $("#xpayorinfo").html(data.strcust);
            $("#xpayorinfo3a").html(data.strcust);
            $("#xpayorinfo3b").html(data.strcust);
            $("#xppayorinfo").html(data.strcust);
            $("#xcontent").html(data.content);
            $("#xsearch_usr").hide();
            $("#xnext_step").show();
        } else {
            swal({
                title: "Error",
                text: data.msg,
                type: "error",
                confirmButtonColor: "#DD6B55",
            });
        }
    });

}

function createOneCustomer() {
    resetParentCounters();
    if (!validate_nForm())
        return false;

    cleanData();

    var nacc = $("#nacc").val();
    var nfname = $("#nfirstname").val();
    var nlname = $("#nlastname").val();
    var naddress = $("#naddress").val();
    var naddressunit = $("#naddressunit").val();
    var ncity = $("#ncity").val();
    var nstate = $("#nstate").val();
    var nzip = $("#nzip").val();
    var nphone = $("#nphone").val();
    var nemail = $("#nemail").val();
    //var ncompanyN=$("#xcompanyname").val();


    $("#pidaccount").val(nacc);
    $("#pidfirstname").val(nfname);
    $("#pidlastname").val(nlname);
    $("#pidaddress").val(naddress);
    $("#pidaddress_unit").val(naddressunit);
    $("#pidcity").val(ncity);
    $("#pidstate").val(nstate);
    $("#pidzip").val(nzip);
    $("#pidphone").val(nphone);
    $("#pidemail").val(nemail);
    //$("#pidcompanyName").val(ncompanyN);

    $("#form_newuser").submit();
}



function eterm_calculateFee(type, amount) {
    resetParentCounters();
    amount = parseFloat(amount);
    $("#xservice_fee2").show();
    $("#xservice_fee").show();
    $("#xservice_fee_inv").show();

    var fee = 0;
    var flat_fee = 0
    var porcent_fee = 0


    var select_date = currentDate.getFullYear() + "-" + (currentDate.getMonth() + 1) + "-" + currentDate.getDate();
    var onetimefuture = 0;
    if (select_date > xnowday) {
        var onetimefuture = 1;
    }

    if (!isrecurring && !onetimefuture) {
        //is one time
        if (type == 'ec') {
            if (ot_fee_ec.length == 1) {
                fee += parseFloat(ot_fee_ec[0]['convenience_fee']);
                flat_fee = parseFloat(ot_fee_ec[0]['convenience_fee']);
                porcent_fee = ot_fee_ec[0]['convenience_fee_float'];
                if (ot_fee_ec[0]['convenience_fee_float'] > 0) {
                    var ffee = (amount * ot_fee_ec[0]['convenience_fee_float']) / 100;
                    fee = fee + parseFloat(ffee);
                }
            } else if (ot_fee_ec.length > 1) {
                for (var i = 0; i < ot_fee_ec.length; i++) {
                    if (ot_fee_ec[i]['low_pay_range'] <= amount && ot_fee_ec[i]['high_pay_range'] >= amount) {
                        fee += parseFloat(ot_fee_ec[i]['convenience_fee']);
                        flat_fee = parseFloat(ot_fee_ec[i]['convenience_fee']);
                        porcent_fee = ot_fee_ec[i]['convenience_fee_float'];
                        if (ot_fee_ec[i]['convenience_fee_float'] > 0) {
                            var ffee = (amount * ot_fee_ec[i]['convenience_fee_float']) / 100;
                            fee = fee + parseFloat(ffee);
                        }
                        break;
                    }
                }
            }

        } else if (type == 'cc') {
            if (ot_fee_cc.length == 1) {
                fee += parseFloat(ot_fee_cc[0]['convenience_fee']);
                flat_fee = parseFloat(ot_fee_cc[0]['convenience_fee']);
                porcent_fee = ot_fee_cc[0]['convenience_fee_float'];
                if (ot_fee_cc[0]['convenience_fee_float'] > 0) {
                    var ffee = (amount * ot_fee_cc[0]['convenience_fee_float']) / 100;
                    fee = fee + parseFloat(ffee);
                }
            } else if (ot_fee_cc.length > 1) {
                for (var i = 0; i < ot_fee_cc.length; i++) {
                    if (ot_fee_cc[i]['low_pay_range'] <= amount && ot_fee_cc[i]['high_pay_range'] >= amount) {
                        flat_fee = parseFloat(ot_fee_cc[i]['convenience_fee']);
                        porcent_fee = ot_fee_cc[i]['convenience_fee_float'];
                        fee += parseFloat(ot_fee_cc[i]['convenience_fee']);
                        if (ot_fee_cc[i]['convenience_fee_float'] > 0) {
                            var ffee = (amount * ot_fee_cc[i]['convenience_fee_float']) / 100;
                            fee = fee + parseFloat(ffee);
                        }
                        break;
                    }
                }
            }
        } else if (type == 'am') {
            if (ot_fee_amex.length == 1) {
                fee += parseFloat(ot_fee_amex[0]['convenience_fee']);
                flat_fee = parseFloat(ot_fee_amex[0]['convenience_fee']);
                porcent_fee = ot_fee_amex[0]['convenience_fee_float'];
                if (ot_fee_amex[0]['convenience_fee_float'] > 0) {
                    var ffee = (amount * ot_fee_amex[0]['convenience_fee_float']) / 100;
                    fee = fee + parseFloat(ffee);
                }
            } else if (ot_fee_amex.length > 1) {
                for (var i = 0; i < ot_fee_amex.length; i++) {
                    if (ot_fee_amex[i]['low_pay_range'] <= amount && ot_fee_amex[i]['high_pay_range'] >= amount) {
                        fee += parseFloat(ot_fee_amex[i]['convenience_fee']);
                        flat_fee = parseFloat(ot_fee_amex[i]['convenience_fee']);
                        porcent_fee = ot_fee_amex[i]['convenience_fee_float'];
                        if (ot_fee_amex[i]['convenience_fee_float'] > 0) {
                            var ffee = (amount * ot_fee_amex[i]['convenience_fee_float']) / 100;
                            fee = fee + parseFloat(ffee);
                        }
                        break;
                    }
                }
            }
        }
    }
    if (isrecurring || onetimefuture) {
        //is recurring
        if (type == 'ec') {
            if (rc_fee_ec.length == 1) {
                fee += parseFloat(rc_fee_ec[0]['convenience_fee']);
                flat_fee = parseFloat(rc_fee_ec[0]['convenience_fee']);
                porcent_fee = rc_fee_ec[0]['convenience_fee_float'];
                if (rc_fee_ec[0]['convenience_fee_float_drp'] > 0) {
                    if (amount > 0) {
                        var ffee = (amount * rc_fee_ec[0]['convenience_fee_float_drp']) / 100;
                    } else {
                        var ffee = (rc_fee_ec[0]['convenience_fee_float_drp']) / 100;
                    }
                    fee = fee + parseFloat(ffee);
                }
            } else if (rc_fee_ec.length > 1) {
                for (var i = 0; i < rc_fee_ec.length; i++) {
                    if (rc_fee_ec[i]['low_pay_range'] <= amount && rc_fee_ec[i]['high_pay_range'] >= amount) {
                        fee += parseFloat(rc_fee_ec[i]['convenience_fee']);
                        flat_fee = parseFloat(rc_fee_ec[i]['convenience_fee']);
                        porcent_fee = rc_fee_ec[i]['convenience_fee_float'];
                        if (rc_fee_ec[i]['convenience_fee_float'] > 0) {
                            var ffee = (amount * rc_fee_ec[i]['convenience_fee_float']) / 100;
                            fee = fee + parseFloat(ffee);
                        }
                        break;
                    }
                }
            }

        } else if (type == 'cc') {
            if (rc_fee_cc.length == 1) {
                fee += parseFloat(rc_fee_cc[0]['convenience_fee']);
                flat_fee = parseFloat(rc_fee_cc[0]['convenience_fee']);
                porcent_fee = rc_fee_cc[0]['convenience_fee_float'];
                if (rc_fee_ec[0]['convenience_fee_float_drp'] > 0) {
                    if (amount > 0) {
                        var ffee = (amount * rc_fee_ec[0]['convenience_fee_float_drp']) / 100;
                    } else {
                        var ffee = (rc_fee_ec[0]['convenience_fee_float_drp']) / 100;
                    }
                    fee = fee + parseFloat(ffee);
                }
            } else if (rc_fee_cc.length > 1) {
                for (var i = 0; i < rc_fee_cc.length; i++) {
                    if (rc_fee_cc[i]['low_pay_range'] <= amount && rc_fee_cc[i]['high_pay_range'] >= amount) {
                        fee += parseFloat(rc_fee_cc[i]['convenience_fee']);
                        flat_fee = parseFloat(rc_fee_cc[i]['convenience_fee']);
                        porcent_fee = rc_fee_cc[i]['convenience_fee_float'];
                        if (rc_fee_cc[i]['convenience_fee_float'] > 0) {
                            var ffee = (amount * rc_fee_cc[i]['convenience_fee_float']) / 100;
                            fee = fee + parseFloat(ffee);
                        }
                        break;
                    }
                }
            }
        } else if (type == 'am') {
            if (rc_fee_amex.length == 1) {
                fee += parseFloat(rc_fee_amex[0]['convenience_fee']);
                flat_fee = parseFloat(rc_fee_amex[0]['convenience_fee']);
                porcent_fee = rc_fee_amex[0]['convenience_fee_float'];
                if (rc_fee_ec[0]['convenience_fee_float_drp'] > 0) {
                    if (amount > 0) {
                        var ffee = (amount * rc_fee_ec[0]['convenience_fee_float_drp']) / 100;
                    } else {
                        var ffee = (rc_fee_ec[0]['convenience_fee_float_drp']) / 100;
                    }
                    fee = fee + parseFloat(ffee);
                }
            } else if (rc_fee_amex.length > 1) {
                for (var i = 0; i < rc_fee_amex.length; i++) {
                    if (rc_fee_amex[i]['low_pay_range'] <= amount && rc_fee_amex[i]['high_pay_range'] >= amount) {
                        fee += parseFloat(rc_fee_amex[i]['convenience_fee']);
                        flat_fee = parseFloat(rc_fee_amex[i]['convenience_fee']);
                        porcent_fee = rc_fee_amex[i]['convenience_fee_float'];
                        if (rc_fee_amex[i]['convenience_fee_float'] > 0) {
                            var ffee = (amount * rc_fee_amex[i]['convenience_fee_float']) / 100;
                            fee = fee + parseFloat(ffee);
                        }
                        break;
                    }
                }
            }
        }
    }
    $("#xdiv_paymentamount").show();
    if (fee == 0) {
        $("#xmodalservice_fee").hide();
        $("#xservice_fee").hide();
        $("#xservice_fee2").hide();
        $("#xservice_fee_inv").hide();
        if ($("#inlineRadio1").is(":checked") && isrecurring) {
            $("#xdiv_paymentamount").hide();
            $("#xgrandtotal2").html("Balance Owed");
            $("#xgrandtotal").html("Balance Owed");

        } else {
            $("#xgrandtotal_inv").html("$" + (parseFloat(fee) + parseFloat(amount)).toFixed(2));
            $("#xgrandtotal").html("$" + (parseFloat(fee) + parseFloat(amount)).toFixed(2));
            $("#xgrandtotal2").html("$" + (parseFloat(fee) + parseFloat(amount)).toFixed(2));

        }

    } else {
        $("#xmodalservice_fee").show();
        $("#xservice_fee").show();
        $("#xservice_fee2").show();
        $("#xservice_fee_inv").show();
        $("#xgrandtotal_inv").html("$" + (parseFloat(fee) + parseFloat(amount)).toFixed(2));
        $("#xgrandtotal").html("$" + (parseFloat(fee) + parseFloat(amount)).toFixed(2));
        $("#xgrandtotal2").html("$" + (parseFloat(fee) + parseFloat(amount)).toFixed(2));
        if ($("#inlineRadio1").is(":checked") && isrecurring) {
            $("#xdiv_paymentamount").hide();
            if (flat_fee > 0 && porcent_fee > 0) {
                $("#xcfee2").html("$" + parseFloat(flat_fee).toFixed(2) + " + " + porcent_fee.toFixed(2) + "%");
                $("#xcfee").html("$" + parseFloat(flat_fee).toFixed(2) + " + " + porcent_fee.toFixed(2) + "%");
            } else if (flat_fee > 0) {
                $("#xcfee2").html("$" + parseFloat(flat_fee).toFixed(2));
                $("#xcfee").html("$" + parseFloat(flat_fee).toFixed(2));
            } else if (porcent_fee > 0) {
                $("#xcfee2").html(porcent_fee.toFixed(2) + "%");
                $("#xcfee").html(porcent_fee.toFixed(2) + "%");
            }
            $("#xhr").hide();
            $("#xgrandtotal2").html("Balance Owed");
            $("#xgrandtotal").html("Balance Owed");

        } else {
            $("#xcfee2").html("$" + parseFloat(fee).toFixed(2));
            $("#xcfee").html("$" + parseFloat(fee).toFixed(2));
            $("#xcfee_inv").html("$" + parseFloat(fee).toFixed(2));
            $("#xgrandtotal2").html("$" + (parseFloat(fee) + parseFloat(amount)).toFixed(2));
        }
    }
    if (!$("#payinv").is(":checked")) {
        drawCatPopup();
    }

}


function CalculateINVAmount() {
    var amount = $("#xinvoice_amount").val();
    if (amount > inv_amount) {
        amount = inv_amount;
        $("#xinvoice_amount").val(amount);
    }
    if (type == "") {

    } else {
        eterm_calculateFee(type, amount);
    }

    $("#xprevtotal2").html("$" + parseFloat(amount).toFixed(2));

}

function showconvFee() {
    var select_date = currentDate.getFullYear() + "-" + (currentDate.getMonth() + 1) + "-" + currentDate.getDate();
    var onetimefuture = 0;
    if (select_date > xnowday) {
        var onetimefuture = 1;
    }

    var xshowmodalfee = 0;
    if (isrecurring || onetimefuture) {
        $("#xcfee_ot").hide();
        $("#xcfee_rc").show();
        checkPType(2);
        if (rc_fee_ec.length > 0) {
            for (var i = 0; i < rc_fee_ec.length; i++) {
                if (parseFloat(rc_fee_ec[i]["convenience_fee"]) > 0 || parseFloat(rc_fee_ec[i]["convenience_fee_float"]) > 0) {
                    xshowmodalfee = 1;
                    break;
                }
            }
        }
        if (rc_fee_cc.length > 0 && xshowmodalfee == 0) {
            for (var i = 0; i < rc_fee_cc.length; i++) {
                if (parseFloat(rc_fee_cc[i]["convenience_fee"]) > 0 || parseFloat(rc_fee_cc[i]["convenience_fee_float"]) > 0) {
                    xshowmodalfee = 1;
                    break;
                }
            }
        }
        if (rc_fee_amex.length > 0 && xshowmodalfee == 0) {
            for (var i = 0; i < rc_fee_amex.length; i++) {
                if (parseFloat(rc_fee_amex[i]["convenience_fee"]) > 0 || parseFloat(rc_fee_amex[i]["convenience_fee_float"]) > 0) {
                    xshowmodalfee = 1;
                    break;
                }
            }
        }
    } else {
        $("#xcfee_ot").show();
        $("#xcfee_rc").hide();
        checkPType(1);
        if (ot_fee_ec.length > 0) {
            for (var i = 0; i < ot_fee_ec.length; i++) {
                if (parseFloat(ot_fee_ec[i]["convenience_fee"]) > 0 || parseFloat(ot_fee_ec[i]["convenience_fee_float"]) > 0) {
                    xshowmodalfee = 1;
                    break;
                }
            }
        }
        if (ot_fee_cc.length > 0 && xshowmodalfee == 0) {
            for (var i = 0; i < ot_fee_cc.length; i++) {
                if (parseFloat(ot_fee_cc[i]["convenience_fee"]) > 0 || parseFloat(ot_fee_cc[i]["convenience_fee_float"]) > 0) {
                    xshowmodalfee = 1;
                    break;
                }
            }
        }
        if (ot_fee_amex.length > 0 && xshowmodalfee == 0) {
            for (var i = 0; i < ot_fee_amex.length; i++) {
                if (parseFloat(ot_fee_amex[i]["convenience_fee"]) > 0 || parseFloat(ot_fee_amex[i]["convenience_fee_float"]) > 0) {
                    xshowmodalfee = 1;
                    break;
                }
            }
        }
    }

    eterm_calculateFee(type, xamount);
}

function CalculateEtermAmount() {
    var tmp_obj;
    var amount = 0;
    var tmp;

    for (var i = 0; tmp_obj = document.getElementById("xcheckpay_" + i); i++) {
        if (tmp_obj.checked) {
            tmp_obj = document.getElementById("xinputpay_" + i);
            tmp_dd_obj = document.getElementById("qtypay_" + i);
            tmp_dd_obj_val = 1;
            if (tmp_dd_obj) {
                tmp_dd_obj_val = tmp_dd_obj.value;
            }
            tmp = tmp_obj.value.replace(/,/g, "");
            tmp = parseFloat(tmp);
            if (!isNaN(tmp) && tmp > 0) {
                amount += tmp * tmp_dd_obj_val;
                tmp_obj.value = tmp.toFixed(2);
            }
        }
    }
    amount = parseFloat(amount).toFixed(2);

    $("#xprevtotal").html("$" + amount);
    $("#xprevtotal2").html("$" + amount);
    xamount = amount;
    eterm_calculateFee(type, xamount);
    return amount;
}

function changetext(text_type) {
    if (text_type == 1) {
        $("#xtextlabel").html('<h4 class="no-margin"><p><b class="small-font-2">Select Payment Date:</b></p></h4>');

    } else {
        $("#xtextlabel").html('<h4 class="no-margin"><p><b class="small-font-2">Select Start Date:</b></p></h4>');
    }
    showconvFee();

}


$('#inlineRadio1').click(function () {
    if (!$(this).attr('checked'))
    {
        $(this).prop('checked', true);
        $('#payment-details').collapse('hide');
    }
    $('#inlineRadio2').attr('checked', false);
    refreshRecurringDate();
    eterm_calculateFee(type, xamount);

});

$('#inlineRadio2').click(function () {
    if (!$(this).attr('checked'))
    {
        $(this).attr('checked', true);
        $('#payment-details').collapse('show');
    }
    $('#inlineRadio1').attr('checked', false);
    refreshRecurringDate();
    eterm_calculateFee(type, xamount);
});


function cleanECandCC() {
    //ec
    $("#xppec_name").val("");
    $("#xppec_routing").val("");
    $("#xppec_acc").val("");
    $("#xppec_confirm_acc").val("");
    //cc
    $("#xcardname").val("");
    $("#xcardnumber").val("");
    $("#xexpdate").val("");
    $("#xcvv").val("");
    $("#xzip1").val("");
}

function drawCatPopup() {
    $("#xshowcat_pay").show();
    $("#xdiv_paymentamount2").show();
    $("#xhideonrecurring").show();
    var popup_freq = $("#xfreq option:selected").text();
    $("#xpop_freq").html(popup_freq);
    var popup_edate = $("#xrenddate option:selected").text();
    $("#xpop_enddate").html(popup_edate);

    var result = "";
    for (var i = 0; tmp_obj = document.getElementById("xcheckpay_" + i); i++) {
        if (tmp_obj.checked) {
            tmp_obj = document.getElementById("xinputpay_" + i);
            tmp = tmp_obj.value.replace(/,/g, "");

            tmp = parseFloat(tmp);
            if (!isNaN(tmp) && tmp > 0) {
                var xname = $("#xinputpay_" + i).attr("xname");
                var xid = tmp_obj.name;
                var xam = parseFloat($("#xinputpay_" + i).val()).toFixed(2);
            }
            result += '<div class="col-xs-7"><b>' + xname + '</b></div><div class="col-xs-5 text-right">$' + xam + '</div>';

        }
    }
    $("#xshowcat_pay").html(result);
    if ($("#inlineRadio1").is(':checked') && isrecurring) {
        $("#xdiv_paymentamount2").hide();
        $("#xhideonrecurring").hide();
        $("#xshowcat_pay").hide();
    }
}

function clean2() {
    $("#checkbox4").prop("checked", false);
    $("#checkbox5").prop("checked", false);
    $("#xsaveprofile_id").prop("checked", false);
}

