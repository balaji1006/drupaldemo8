function responsiveJS() {

    if ($(window).width() > 1460 ){
        export_btn = $('#exportBtnDropDown');
        export_btn.html('Export <span class="caret"></span>');
        export_btn_a = $('#exportDropdownDiv a.btn-outline');
        export_btn_a.html('<span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span> Import');
    }


    if ($(window).width() <= 1460 && $(window).width() > 1025 ){


        $('#filtersAndExportDiv').removeClass('col-md-9');
        $('#filtersAndExportDiv').removeClass('text-center');
        $('#filtersAndExportDiv').addClass('col-md-10');
        export_btn_cont = $('#exportDropdownDiv');
        export_btn_a = $('#exportDropdownDiv a.btn-outline');
        export_btn = $('#exportBtnDropDown');
        export_btn.html('<span class="fa fa-download"></span> <span class="caret"></span>')
        export_btn_a.html('&nbsp;<span class="fa fa-upload"></span>&nbsp;');
        export_btn_cont.removeClass('col-md-2');
        export_btn_cont.addClass('col-md-1');


    }
    else{


        $('#filtersAndExportDiv').addClass('col-md-9');
        $('#filtersAndExportDiv').addClass('text-center');
        $('#filtersAndExportDiv').removeClass('col-md-10');
        export_btn_cont = $('#exportDropdownDiv');
        export_btn_cont.addClass('col-md-2');
        export_btn_cont.removeClass('col-md-1');

    }

    if ($(window).width() <= 1366){
        $('.reportaction').parent().parent().css('margin-right','81px');
    }
    else{
        $('.reportaction').parent().parent().css('margin-right','0');
    }

    if ($(window).width() <= 1290){
        $('.normalheader').addClass('small-header');
        export_btn = $('#exportBtnDropDown');
        export_btn.html('<span class="fa fa-download"></span> <span class="caret"></span>')

        export_btn_a = $('#exportDropdownDiv a.btn-outline');
        export_btn_a.html('&nbsp;<span class="fa fa-upload"></span>&nbsp;');
    }
    else{
        $('.normalheader').removeClass('small-header');
    }

    if ($(window).width() <= 1025){

        $('#advancedFiltersBtn').text('Filters');
        ipp = $('select.items-per-page');
        ipp.parent().removeClass('col-md-1');
        ipp.parent().addClass('col-md-2 col-xs-3');
        faed = $('#filtersAndExportDiv');
        faed.addClass('col-md-8');
        faed.removeClass('col-md-9');

    }
    else{
        $('#advancedFiltersBtn').text('Advanced Filters');

    }

}
$(window).resize(function () {
    responsiveJS();
});

responsiveJS();