var currentDate = new Date(xtoday.year, xtoday.month, xtoday.day);

$('#autodatep').datepicker({
    todayHighLight: true,
    toggleActive: false,
    defaultViewDate: xatoday,
    datesDisabled: DateDisabledAutopay,
    format: "MM d, yyyy",
    startDate: "now",
    endDate: "+2y",
    autoclose: true
}).on('changeDate', function (e) {
    $('#date-label').html($(this).data('datepicker').getFormattedDate('MM d, yyyy'));
    $("#xpop_startdate").html($(this).data('datepicker').getFormattedDate('MM d, yyyy'));
    currentDate = $('#autodatep').datepicker('getDate');
    showconvFee();
});
$('#autodatep').datepicker('setDate', new Date(xatoday.year, xatoday.month, xatoday.day));

if (existsDrp == 1) {
    $('#drpdatep').datepicker({
        todayHighLight: true,
        toggleActive: false,
        defaultViewDate: xdtoday,
        datesDisabled: DateDisabledDRP,
        format: "MM d, yyyy",
        startDate: "now",
        endDate: "+2y",
        autoclose: true
    }).on('changeDate', function (e) {
        $('#date-label').html($(this).data('datepicker').getFormattedDate('MM d, yyyy'));
        $("#xpop_startdate").html($(this).data('datepicker').getFormattedDate('MM d, yyyy'));
        currentDate = $('#drpdatep').datepicker('getDate');
        showconvFee();
    });
    $('#drpdatep').datepicker('setDate', new Date(xdtoday.year, xdtoday.month, xdtoday.day));

}

$('#onedatep').datepicker({
    todayHighLight: true,
    toggleActive: false,
    defaultViewDate: xtoday,
    datesDisabled: DateDisabled,
    format: "MM d, yyyy",
    startDate: "now",
    endDate: "+2y",
    autoclose: true
}).on('changeDate', function (e) {
    $('#date-label').html($(this).data('datepicker').getFormattedDate('MM d, yyyy'));
    $("#xpop_startdate").html($(this).data('datepicker').getFormattedDate('MM d, yyyy'));
    currentDate = $('#onedatep').datepicker('getDate');
    showconvFee();
});
$('#onedatep').datepicker('setDate', new Date(xtoday.year, xtoday.month, xtoday.day));
currentDate = $('#onedatep').datepicker('getDate');

function refreshOneTimeDate() {
    $("#autodatep").hide();
    if (existsDrp == 1) {
        $("#drpdatep").hide();
    }
    $("#onedatep").datepicker('update', currentDate);
    $("#onedatep").show();
    $("#xpop_startdate").html($("#onedatep").data('datepicker').getFormattedDate('MM d, yyyy'));
}

function refreshRecurringDate() {
    $("#onedatep").hide();
    if (existsDrp == 1) {
        if (document.getElementById("inlineRadio1").checked === true) {
            $("#autodatep").hide();
            if (currentDate.getDate() < xdrprange.start) {
                currentDate.setDate(xdrprange.start);
            } else {
                if (currentDate.getDate() > xdrprange.end) {
                    currentDate.setDate(xdrprange.start);
                    currentDate.setMonth(currentDate.getMonth() + 1);
                }
            }
            if (ndtoday != null) {
                if (currentDate.getTime() === ndtoday.getTime()) {
                    currentDate = new Date(xdtoday.year, xdtoday.month, xdtoday.day);
                }
            }
            if ($.inArray(currentDate.getMonth() - 1, mmdtoday) == -1) {
                currentDate = new Date(xdtoday.year, xdtoday.month, xdtoday.day);
            }
            $("#xfreq").empty();
            $(".selectpicker").selectpicker('refresh');
            for (i = 0; i < frqDrp.length; i++) {
                $("#xfreq").append('<option value="' + frqDrp[i].valr + '" >' + frqDrp[i].opt + '</option>');
            }
            $(".selectpicker").selectpicker('refresh');
            $("#drpdatep").datepicker('update', currentDate);
            $('#date-label').html($("#drpdatep").data('datepicker').getFormattedDate('MM d, yyyy'));
            $("#drpdatep").show();
            $("#xpop_startdate").html($("#drpdatep").data('datepicker').getFormattedDate('MM d, yyyy'));
        } else {
            $("#drpdatep").hide();
            if (currentDate.getDate() < xautorange.start) {
                currentDate.setDate(xautorange.start);
            } else {
                if (currentDate.getDate() > xautorange.end) {
                    currentDate.setDate(xautorange.start);
                    currentDate.setMonth(currentDate.getMonth() + 1);
                }
            }
            if (natoday != null) {
                if (currentDate.getTime() === natoday.getTime()) {
                    currentDate = new Date(xatoday.year, xatoday.month, xatoday.day);
                }
            }
            if ($.inArray(currentDate.getMonth() + 1, madtoday) == -1) {
                currentDate = new Date(xatoday.year, xatoday.month, xatoday.day);
            }
            $("#xfreq").empty();
            $(".selectpicker").selectpicker('refresh');
            for (i = 0; i < frqauto.length; i++) {
                $("#xfreq").append('<option value="' + frqauto[i].valr + '" >' + frqauto[i].opt + '</option>');
            }
            $(".selectpicker").selectpicker('refresh');
            $("#autodatep").datepicker('update', currentDate);
            $('#date-label').html($("#autodatep").data('datepicker').getFormattedDate('MM d, yyyy'));
            $("#autodatep").show();
            $("#xpop_startdate").html($("#autodatep").data('datepicker').getFormattedDate('MM d, yyyy'));
        }
    } else {
        if (currentDate.getDate() < xautorange.start) {
            currentDate.setDate(xautorange.start);
        } else {
            if (currentDate.getDate() > xautorange.end) {
                currentDate.setDate(xautorange.start);
                currentDate.setMonth(currentDate.getMonth() + 1);
            }
        }

        if (natoday != null) {
            if (currentDate.getTime() === natoday.getTime()) {
                currentDate = new Date(xatoday.year, xatoday.month, xatoday.day);
            }
        }
        if ($.inArray(currentDate.getMonth() + 1, madtoday) == -1) {
            currentDate = new Date(xatoday.year, xatoday.month, xatoday.day);
        }
        $("#autodatep").datepicker('update', currentDate);
        $('#date-label').html($("#autodatep").data('datepicker').getFormattedDate('MM d, yyyy'));
        $("#autodatep").show();
        $("#xpop_startdate").html($("#autodatep").data('datepicker').getFormattedDate('MM d, yyyy'));
    }
    return false;
}

