
$('#inputModes input[type=radio]').click(function(){
    if($(this).attr('id')!='im1'){
        $('#fileModeNachaCont').hide();
        $('#fileModeCSV').trigger("click");
        if($(this).attr('id')=='im3'){
            $('#fileTypeACHCont').hide();
        }
        else {
            $('#fileTypeACHCont').show();
        }
    }
    else{
        $('#fileModeNachaCont').show();
    }
});

$('#fileModes input[type=radio]').click(function(){
    if($(this).attr('id')!='fileModeCSV'){
        $('#fileTypeCont').hide();
    }
    else{
        $('#fileTypeCont').show();
    }
});

$('#inputFq').change(function(){
    if($(this).val()!='now'){
        showScheduleSelects();
        if($(this).val()!='onetime'){
            $('#inputDynamicCont').removeClass('hide');
        }
        else{
            $('#inputDynamicCont').addClass('hide');
        }
    }
    else{
        hideScheduleSelects();
    }
});

function resetInterface(){
    $("#im1").trigger("click");
    $("#inputFq").val("now").trigger("click");
}

function showScheduleSelects(){
    $('#inputSdCont').removeClass('hide');
    $('#inputSminputSyCont').removeClass('hide');
}

function hideScheduleSelects(){
    $('#inputSdCont').addClass('hide');
    $('#inputSminputSyCont').addClass('hide');
}

$('#termslink').click(function () {
    $('#modalterm').modal('show');
});

$('.glyphicon-info-sign').click(function () {
    $('#'+$(this).attr('data')).modal('show');
});

$('#link_read_instructions').click(function () {
    $('#modalall').modal('show');
});

resetInterface();