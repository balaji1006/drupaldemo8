function sendFileToServer(formData, status)
{
//    var uploadURL ="/master/index.php/webuser/uploadfile"; //Upload URL
    var extraData = {}; //Extra Data.
    var jqXHR = $.ajax({
        xhr: function () {
            var xhrobj = $.ajaxSettings.xhr();
            if (xhrobj.upload) {
                xhrobj.upload.addEventListener('progress', function (event) {
                    var percent = 0;
                    var position = event.loaded || event.position;
                    var total = event.total;
                    if (event.lengthComputable) {
                        percent = Math.ceil(position / total * 100);
                    }
                    //Set progress
                    status.setProgress(percent);
                }, false);
            }
            return xhrobj;
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: uploadURL,
        type: "POST",
        contentType: false,
        processData: false,
        cache: false,
        data: formData,
        dataType: 'json',
        success: function (data) {
            status.setProgress(100);
            //alert('pp'); return false;
            var result = data;
            //alert(result.error); return false;
            if (parseInt(result.error) == -1) {

                //var displayResult = result[0].split('||');
                $("#msg").css('display', 'block');
                $('#next_button_1').css('display', 'block');
                $('#uploading_text_1').css('display', 'none');
                $("#msg").removeClass("alert-success");
                $("#msg").removeClass("alert-danger");
                $("#msg").addClass("alert-success");
                $("#msg").html(result.msg);
                $("#current_uploaded_file_name").val(result.uploadedFile);
                $('#impo_filename_1').css('display', 'none');
                $('#impdnd_filename_1').css('display', 'block');
                $('#impdnd_filename_1').html("<label>" + result.uploadedFile + "</label>");
                //$('#non-swf-uploader').val(displayResult[1]);
                $('#delimiter-div').css('display', 'block');
                $("#msg").fadeOut(5000);

                $('#frmuploadfile').show(); //hide submit button
                $('#loading-img').hide(); //hide submit button
                $('#progressbox').delay(1000).fadeOut(); //hide progress bar
                return false;

            } else if (parseInt(result.error) == 1) {

                //alert('pp');
                $("#msg").removeClass("alert-success");
                $("#msg").removeClass("alert-danger");
                $("#msg").addClass("alert-danger");
                $("#msg").css('display', 'block');
                $("#msg").html(result.msg);
                $('#next_button_1').css('display', 'block');
                $('#uploading_text_1').css('display', 'none');
                $("#current_uploaded_file_name").val('');
                $('#impo_filename_1').css('display', 'none');
                $('#impdnd_filename_1').css('display', 'none');
                $('#impdnd_filename_1').html('');
                //$('#non-swf-uploader').val('');
                $('#delimiter-div').css('display', 'none');
                $("#msg").fadeOut(10000);
                return false;

            }
        }
    });

    status.setAbort(jqXHR);
}

var rowCount = 0;
function createStatusbar(obj)
{
    rowCount++;
    var row = "odd";
    if (rowCount % 2 == 0)
        row = "even";
    this.statusbar = $("<div class='statusbar'></div>");
    this.filename = $("<div class='filename' style='display:none;' ></div>");
    this.size = $("<div class='filesize' style='display:none;'></div>");
    //this.progressBar = $("<div class='progressBar' id='dnd-progressbar' style='text-align:center;'><div></div></div>").appendTo(this.statusbar);
    this.progressBar = $('<div class="progress" id="dnd-progressbar"><div class="progress-bar" role="progressbar" id="dnd-progressbar_1" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:0%"></div></div>').appendTo(this.statusbar);
    this.abort = $("<div class='abort' style='display:none;'>Abort</div>");
    obj.after(this.statusbar);

    this.setFileNameSize = function (name, size)
    {
        var sizeStr = "";
        var sizeKB = size / 1024;
        if (parseInt(sizeKB) > 1024)
        {
            var sizeMB = sizeKB / 1024;
            sizeStr = sizeMB.toFixed(2) + " MB";
        } else
        {
            sizeStr = sizeKB.toFixed(2) + " KB";
        }

        this.filename.html(name);
        this.size.html(sizeStr);
    }
    this.setProgress = function (progress)
    {
        var progressBarWidth = progress * this.progressBar.width() / 100;
        this.progressBar.find('div').animate({width: progressBarWidth}, 10).html(progress + "% ");
        if (parseInt(progress) >= 100)
        {
            this.abort.hide();
        }
    }
    this.setAbort = function (jqxhr)
    {
        var sb = this.statusbar;
        this.abort.click(function ()
        {
            jqxhr.abort();
            sb.hide();
        });
    }
}
function handleFileUpload(files, obj)
{
    var fd = new FormData();
    fd.append('_token', "{{ csrf_token() }}");
    for (var i = 0; i < files.length; i++)
    {
        var fd = new FormData();
        fd.append('upfile', files[i]);

        var status = new createStatusbar(obj); //Using this we can set progress.
        status.setFileNameSize(files[i].name, files[i].size);
        sendFileToServer(fd, status);

    }
}
$(document).ready(function ()
{

    var obj = $("#drag-n-drop-area");
    obj.on('dragenter', function (e)
    {
        e.stopPropagation();
        e.preventDefault();
        $(this).css('border', '2px solid #0B85A1');
    });
    obj.on('dragover', function (e)
    {
        e.stopPropagation();
        e.preventDefault();
    });
    obj.on('drop', function (e)
    {

        $('#next_button_1').css('display', 'none');
        $('#uploading_text_1').css('display', 'block');
        $(this).css('border', '2px dotted #0B85A1');
        e.preventDefault();
        var files = e.originalEvent.dataTransfer.files;
        $('#loadingbox').css('display', 'block');
        if (typeof ($('#dnd-progressbar')) != 'undefined') {
            $('#dnd-progressbar').remove();
        }
        $('#impdnd_filename_1').css('display', 'none');
        //We need to send dropped files to Server
        handleFileUpload(files, obj);
    });
    $(document).on('dragenter', function (e)
    {
        e.stopPropagation();
        e.preventDefault();
    });
    $(document).on('dragover', function (e)
    {
        e.stopPropagation();
        e.preventDefault();
        obj.css('border', '2px dotted #0B85A1');
    });
    $(document).on('drop', function (e)
    {
        e.stopPropagation();
        e.preventDefault();
    });

});
