
function showModal(id){
    var modal="#"+id;
    $(modal).modal();
}

function hideModal(id){
    var modal="#"+id;
    $(modal).modal("hide");
}

function cleanEcshowModal(id){
    $("#xppec_name").val("");
    $("#xppec_routing").val("");
    $("#xppec_acc").val("");
    $("#xppec_confirm_acc").val("");
    showModal(id);
}

function cleanCcshowModal(id){
    $("#xcardname").val("");
    $("#xcardnumber").val("");
    $("#xexpdate").val("");
    $("#xcvv").val("");
    $("#xzip").val("");
    showModal(id);
}

