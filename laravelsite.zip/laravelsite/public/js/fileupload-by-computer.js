$('document').ready(function () {


    $('#do_not_update').click(function () {

        if ($('#' + $(this).attr('id')).is(":checked")) {
            $('#do_not_update3').val(1);
        }

    });
    var isFutureMappingIsEnable = 0

    //ajax file uploading
    var options = {

        target: '#msg', // target element(s) to be updated with server response
        beforeSubmit: beforeSubmit, // pre-submit callback
        success: afterSuccess, // post-submit callback
        uploadProgress: OnProgress, //upload progress callback
        resetForm: true, // reset the form after successful submit,
        dataType: 'json'


    };
    $('#upfile').change(function () {

//alert('ok');
        if ($("#current_uploaded_file_name").val() != '') {

            var result = confirm("You have already uploaded a file , Do you want to replace it?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
            if (result) {
//alert(result);
                $('#impdnd_filename_1').css('display', 'none');
                $('#dnd-progressbar').css('display', 'none');
                $("#uploadImageByComp").ajaxSubmit(options);
                // always return false to prevent standard browser submit and page navigation
                return false;
            } else {
//$("#upfile").val("");
                return false;
            }


        } else {

            $('#impdnd_filename_1').css('display', 'none');
            $('#dnd-progressbar').css('display', 'none');
            $('#uploadImageByComp').ajaxSubmit(options);
            // always return false to prevent standard browser submit and page navigation
            return false;
        }


    });
    //function after succesful file upload (when server response)
    function afterSuccess(data) {

        var result = data;
        //alert(result.error); return false;
        if (parseInt(result.error) == -1) {

            //var displayResult = result[0].split('||');
            $("#msg").css('display', 'block');
            $('#next_button_1').css('display', 'block');
            $('#uploading_text_1').css('display', 'none');
            $("#msg").removeClass("alert-success");
            $("#msg").removeClass("alert-danger");
            $("#msg").addClass("alert-success");
            $("#msg").html(result.msg);
            $("#current_uploaded_file_name").val(result.uploadedFile);
            $('#impdnd_filename_1').css('display', 'none');
            $('#impo_filename_1').css('display', 'block');
            $('#impo_filename_1').html("<label>" + result.uploadedFile + "</label>");
            //$('#non-swf-uploader').val(displayResult[1]);
            $('#delimiter-div').css('display', 'block');
            $("#msg").fadeOut(5000);
            $('#frmuploadfile').show(); //hide submit button
            $('#loading-img').hide(); //hide submit button
            $('#progressbar1').delay(1000).fadeOut(); //hide progress bar
            return false;
        } else if (parseInt(result.error) == 1) {

            //alert('pp');
            $("#msg").css('display', 'block');
            $("#msg").removeClass("alert-success");
            $("#msg").removeClass("alert-danger");
            $("#msg").addClass("alert-danger");
            $("#msg").html(result.msg);
            $('#next_button_1').css('display', 'block');
            $('#impdnd_filename_1').css('display', 'none');
            $('#uploading_text_1').css('display', 'none');
            $('#impo_filename_1').css('display', 'none');
            $('#impo_filename_1').html('');
            $("#current_uploaded_file_name").val('');
            //$('#non-swf-uploader').val('');
            $('#delimiter-div').css('display', 'none');
            $("#msg").fadeOut(10000);
            return false;
        }

        //return false;

    }

    //function to check file size before uploading.
    function beforeSubmit() {
        //check whether browser fully supports all File API

        if (window.File && window.FileReader && window.FileList && window.Blob)
        {



            if (!$('#upfile').val() && !$("#current_uploaded_file_name").val()) //check empty input filed
            {

                alert('Please enter the file name.');
                return false;
            }
            //if(typeof($('#upfile')[0].files[0].size) != 'undefined'){
            var fsize = $('#upfile')[0].files[0].size; //get file size
            //}
            //if(typeof($('#upfile')[0].files[0].type) != 'undefined'){
            var ftype = $('#upfile')[0].files[0].type; // get file type
            //}
            //if(typeof($('#upfile')[0].files[0].name) != 'undefined'){
            var fbname = $('#upfile')[0].files[0].name; // get file name
            ///}
            $('#upload_b_file small').html(fbname);
            //allow file types
            //alert(ftype); return false;
            switch (ftype) {

                case 'text/comma-separated-values':
                case 'text/csv':
                case 'application/vnd.ms-excel':
                case 'application/vnd.ms-csv':

                    break;
                default:
                    $("#msg").css('display', 'block');
                    $("#msg").removeClass("alert-success");
                    $("#msg").removeClass("alert-danger");
                    $("#msg").addClass("alert-danger");
                    $("#msg").html("Please add CSV, TSV or XLS file for importing it into database!");
                    $("#msg").fadeOut(10000);
                    return false

            }
            //Allowed file size is less than 5 MB (1048576)
            if (fsize > 2097152) {
                $("#msg").removeClass("alert-success");
                $("#msg").removeClass("alert-danger");
                $("#msg").addClass("alert-danger");
                $("#msg").html("<b>" + bytesToSize(fsize) + "</b> Too big file! <br />File is too big, it should be less than 2 MB.");
                $("#msg").fadeOut(10000);
                return false

            }
            $('#frmuploadfile').hide(); //hide submit button
            $('#loading-img').show(); //hide submit button
            $("#msg").html("");
        } else {

            //Output error to older unsupported browsers that doesn't support HTML5 File API
            $("#msg").removeClass("alert-success");
            $("#msg").removeClass("alert-danger");
            $("#msg").addClass("alert-danger");
            $("#msg").html("Please upgrade your browser, because your current browser lacks some new features we need!");
            $("#msg").fadeOut(10000);
            return false;
        }

    }

    //progress bar function
    function OnProgress(event, position, total, percentComplete) {

        //Progress bar
        $('#uploading_text_1').css('display', 'block');
        $('#next_button_1').css('display', 'none');
        $('#progressbar1').show();
        $('#progressbar1').width(percentComplete + '%') //update progressbar percent complete
        $('#statustxt').html('<div class="progress" id="dnd-progressbar"><div class="progress-bar" role="progressbar" id="dnd-progressbar1" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:' + percentComplete + '%">' + percentComplete + '%</div></div>'); //update status text
        //$('#statustxt').html(percentComplete + '%'); //update status text
        if (percentComplete > 50) {

            $('#statustxt').css('color', '#000'); //change status text to white after 50%

        }

    }



    //function to format bites bit.ly/19yoIPO
    function bytesToSize(bytes) {

        var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0)
            return '0 Bytes';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }


});
//retrieve data into array from csv file
$('.prepare-to-import').click(function () {
    window.parent.scrollTo(0, 0);
    if ($('#current_uploaded_file_name').val() == '') {

//alert('Please upload data file to import');
        alert('Please upload data file to import.');
        return false;
    }
    $('#myModal_loading').modal();
    $('#next_button_1').css('display', 'none');
    $('#uploading_text_1').css('display', 'block');
    var doupdate = 0;
    if ($('#do_not_update').is(":checked")) {
        doupdate = 1;
    }
    $("#do_not_update3").val(doupdate);
    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type: "POST",
        url: "/manageuser/retrievedataintoarray/",
        data: {ID_PROPERTY: $('#ID_PROPERTY').val(), level: $('#with').val(), table_name: $('#current_db_table').val(),
            file_name: $('#current_uploaded_file_name').val(),
            utf_encoding: $('#frmEncodingFormat').val(), delimiter_value: $('#frmDelimiter').val(),
            do_not_update: doupdate, delete_previous_users: $("input[name=delete_previous_users]").val(),
            idlevel: $("#ID_PROPERTY").val()

        },
        success: function (data) {
            $('#myModal_loading').modal('hide');
            //alert(data); return false;
            var result = data;
            if (!parseInt(result.error)) {
                //alert(result.datareadyformapping);
                $('#importw_step_2').css('display', 'block');
                $('#importw_step_1').css('display', 'none');
                $('#importw_step_2b').html(result.datareadyformapping);
                $('#next_button_1').css('display', 'block');
                $('#uploading_text_1').css('display', 'none');
                //$('#uploading_text_2').css('display', 'block');
                //alert(result.mapping_name);
                isFutureMappingIsEnable = result.boolsavedmapping;
                dialogueBoxSavedMapping(result.boolsavedmapping, result.mapping_name);
                return false;
            } else {

                alert(result.datareadyformapping);
                return false;
            }
        }
    });
});
//this third step of the import tool
function importData() {
    window.parent.scrollTo(0, 0);
    //alert($('#frmImportStep2 .row .col-md').hasClass('required')); return false;
    var boolError = false;
    var errorMsg = '';
    var messagetoappend = 'Please map the required field to continue.\n';
    $('#frmImportStep2 select').each(
            function (index) {

                //alert($(this).val()+' == == '+$(this).parent().parent().children().hasClass('required'));
                if ($(this).parent().parent().children().hasClass('required') && $(this).val() == '') {

                    if ($(this).parent().parent().children().hasClass('required') && $(this).val() == '' && boolError) {

                        errorMsg = 'Please select a value from header column for mendatory field.';
                        boolError = true;
                    }

                }
            }


    );
    if (!boolError) {

        $('#frmImportDataButton').css('display', 'none');
        $('#uploading_text_2').css('display', 'block');
        //var doupdate = 0;

        //to check for empty fields in csv, xls and tsv files

        $.ajax({
            url: "/manageuser/checkforemptyfieldsindatasheet/",
            type: "POST",
            data: {uploaded_file_name: $('#uploaded_file_name').val(), encoding_format: $('#encoding_format2').val(), delimiter_value: $('#file_delimiter_value').val(), uploaddirectory: 'merchant'},
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function (data) {
                var result = data;
                if (result.isEmptyDataSheetField) {

                    var boot_result = confirm("Your uploaded file contains empty fields. Continue with import wizard?");
                    if (!boot_result) {

                        $('#importw_step_1').css('display', 'block');
                        $('#importw_step_2').css('display', 'none');
                        $('#importw_step_3').css('display', 'none');
                        $('#uploading_text_2').css('display', 'none');
                        $('#uploading_text_2').css('display', 'none');
                        $('#frmImportDataButton').css('display', 'block');
                        return false;
                    } else {

                        $("#file-data-preview-loading").css('display', 'block');
                        $.ajax({

                            url: "/manageuser/validationbeforeimport/",
                            type: "POST",
                            data: $('#frmImportStep2').serialize(),
                            dataType: "json",
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        }).done(function (data) {

                            var result = data;
                            //alert(result.error); return false;
                            if (!parseInt(result.error)) {

                                //alert(dataArray[0]);
                                //var result = dataArray[0].split('||');
                                //alert(result[2]);
                                //alert(result.mapped_file_data); return false;
                                $("#file-data-preview-loading").css('display', 'none');
                                var unmappedfields = result.unmappedfieldsstr.split('-');
                                var unmappedFieldResultHtml = '<table>';
                                for (var i = 0; i < unmappedfields.length; i++) {
                                    unmappedFieldResultHtml += '<tr><td>' + unmappedfields[i] + '</td></tr>';
                                }
                                var skippedfields = result.skippedfields.split('-');
                                //alert(skipped_array);
                                unmappedFieldResultHtml += '</table>';
                                var skippedFieldResultHtml = '<table>';
                                for (var j = 0; j < skippedfields.length; j++) {
                                    skippedFieldResultHtml += '<tr><td>' + skippedfields[j] + '</td></tr>';
                                }
                                skippedFieldResultHtml += '</table><p style="border-bottom:solid 1px #ccc; padding:10px 0px;" id="skippedfields"></p>';
                                var previewfiledattobimportedObj = $.parseJSON(result.previewfiledattobimported);
                                var previewfiledataimportedHtml = '<table class="table table-striped">';
                                for (var l = 0; l < previewfiledattobimportedObj.length; l++) {

                                    previewfiledataimportedHtml += '<tr>';
                                    for (var key in previewfiledattobimportedObj[l]) {

                                        previewfiledataimportedHtml += '<td>' + previewfiledattobimportedObj[l][key] + '</td>';
                                    }

                                    previewfiledataimportedHtml += '</tr>';
                                }

                                previewfiledataimportedHtml += '</table>';
                                $("#user-file-data-preview").html(previewfiledataimportedHtml);
                                $('#umappedFieldResult').html(unmappedFieldResultHtml);
                                $('#skippedFieldResult').html(skippedFieldResultHtml);
                                $('#skippedFieldResult').css('display', 'block');
                                $('#umappedFieldResult').css('display', 'block');
                                $('#uploaded_file_name_3').val(result.uploadedfilename);
                                $('#import_table_name_3').val(result.importtablename);
                                $('#readytoimportdata').html('Contacts that are ready to be imported (' + result.readytoimportRecords + ')');
                                $('#skippeddatanumber').html('<a href="#"> No. of Records skipped (' + result.skippedrecords + ' )</a>');
                                $('#unmappedfields').html('<a href="#">> Unmapped Fields (' + result.unmappedfields + ' )</a>');
                                $('#skippedfields').html('<a href="#">> Skipped Fields (' + result.skippedfieldscnt + ' )</a>');
                                $('#warning-inner-div').html(result.readytoimportRecords + ' Contacts in your file are ready to be imported.');
                                $('#alert-warning-div').css('display', 'block');
                                $('#importw_step_2').css('display', 'none');
                                $('#loadingbox').css('display', 'none');
                                $('#importw_step_3').css('display', 'block');
                                $('#frmImportDataButton').css('display', 'block');
                                $('#uploading_text_2').css('display', 'none');
                                $('#propertyid3').val(result.propertyid);
                                $('#adminid3').val(result.adminid);
                                $('#token3').val(result.with3);
                                $('#mapped_file_data').val(result.mapped_file_data);
                                $('#sdi_format3').val(result.sdi_format);
                                $('#do_not_update3').val(result.do_not_update);
                                $('#delete_previous_users3').val(result.delete_previous_users);
                                $('#encoding_format3').val(result.encoding_format);
                                return false;
                            } else {

                                //alert(result.error);
                                alert(result.error);
                                $('#frmImportDataButton').css('display', 'block');
                                $('#uploading_text_2').css('display', 'none');
                                $('#mapped_file_data').html('');
                                return false;
                            }

                        });
                    }


                } else {

                    $("#file-data-preview-loading").css('display', 'block');
                    $.ajax({

                        url: "/manageuser/validationbeforeimport/",
                        type: "POST",
                        data: $('#frmImportStep2').serialize(),
                        dataType: "json",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    }).done(function (data) {

                        var result = data;
                        //alert(result.error); return false;
                        if (!parseInt(result.error)) {

                            //alert(dataArray[0]);
                            //var result = dataArray[0].split('||');
                            //alert(result[2]);
                            //alert(result.mapped_file_data); return false;
                            $("#file-data-preview-loading").css('display', 'none');
                            var unmappedfields = result.unmappedfieldsstr.split('-');
                            var unmappedFieldResultHtml = '<table>';
                            for (var i = 0; i < unmappedfields.length; i++) {
                                unmappedFieldResultHtml += '<tr><td>' + unmappedfields[i] + '</td></tr>';
                            }
                            var skippedfields = result.skippedfields.split('-');
                            //alert(skipped_array);
                            unmappedFieldResultHtml += '</table>';
                            var skippedFieldResultHtml = '<table>';
                            for (var j = 0; j < skippedfields.length; j++) {
                                skippedFieldResultHtml += '<tr><td>' + skippedfields[j] + '</td></tr>';
                            }
                            skippedFieldResultHtml += '</table><p style="border-bottom:solid 1px #ccc; padding:10px 0px;" id="skippedfields"></p>';
                            var previewfiledattobimportedObj = $.parseJSON(result.previewfiledattobimported);
                            var previewfiledataimportedHtml = '<table>';
                            for (var l = 0; l < previewfiledattobimportedObj.length; l++) {

                                previewfiledataimportedHtml += '<tr>';
                                for (var key in previewfiledattobimportedObj[l]) {

                                    previewfiledataimportedHtml += '<td>' + previewfiledattobimportedObj[l][key] + '</td>';
                                }

                                previewfiledataimportedHtml += '</tr>';
                            }

                            previewfiledataimportedHtml += '</table>';
                            $("#user-file-data-preview").html(previewfiledataimportedHtml);
                            $('#umappedFieldResult').html(unmappedFieldResultHtml);
                            $('#skippedFieldResult').html(skippedFieldResultHtml);
                            $('#skippedFieldResult').css('display', 'block');
                            $('#umappedFieldResult').css('display', 'block');
                            $('#uploaded_file_name_3').val(result.uploadedfilename);
                            $('#import_table_name_3').val(result.importtablename);
                            $('#readytoimportdata').html('Contacts that are ready to be imported (' + result.readytoimportRecords + ')');
                            $('#skippeddatanumber').html('<a href="#"> No. of Records skipped (' + result.skippedrecords + ' )</a>');
                            $('#unmappedfields').html('<a href="#">> Unmapped Fields (' + result.unmappedfields + ' )</a>');
                            $('#skippedfields').html('<a href="#">> Skipped Fields (' + result.skippedfieldscnt + ' )</a>');
                            $('#warning-inner-div').html(result.readytoimportRecords + ' Contacts in your file are ready to be imported.');
                            $('#alert-warning-div').css('display', 'block');
                            $('#importw_step_2').css('display', 'none');
                            $('#loadingbox').css('display', 'none');
                            $('#importw_step_3').css('display', 'block');
                            $('#frmImportDataButton').css('display', 'block');
                            $('#uploading_text_2').css('display', 'none');
                            $('#propertyid3').val(result.propertyid);
                            $('#adminid3').val(result.adminid);
                            $('#token3').val(result.with3);
                            $('#mapped_file_data').val(result.mapped_file_data);
                            $('#sdi_format3').val(result.sdi_format);
                            $('#do_not_update3').val(result.do_not_update);
                            $('#delete_previous_users3').val(result.delete_previous_users);
                            $('#encoding_format3').val(result.encoding_format);
                            return false;
                        } else {
                            //alert(result.error);
                            $("#xpopupheader").html('');
                            $("#xpopupcontent").html(result.error);
                            $('#myModal_success').modal();
                            $('#frmImportDataButton').css('display', 'block');
                            $('#uploading_text_2').css('display', 'none');
                            $('#mapped_file_data').html('');
                            return false;
                        }

                    });
                }

            }
        });
    } else {
        //alert(errorMsg+messagetoappend);
        alert(result.datareadyformapping);
        return false;
    }

}

$('#frmImportDataButton3').click(function () {
//$('#loadingbox').css('display', 'block');
    $('#frmImportDataButton3').css('display', 'none');
    $('#uploading_text_3').css('display', 'block');
    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type: "POST",
        url: "/manageuser/importfiledatatotable/",
        data: {ID_PROPERTY: $('#propertyid2').val(), with3: $('#token3').val(), table_name: $('#import_table_name_3').val(), mapped_file_data: $('#mapped_file_data').val(), delete_previous_users: $('#delete_previous_users3').val(), do_not_update: $('#do_not_update3').val()},
        success: function (data) {
            var result = data;
            if (!parseInt(result.error)) {

                //alert(result.message);
                $('#frmImportDataButton3').css('display', 'block');
                $('#uploading_text_3').css('display', 'none');
                $('#loadingbox').css('display', 'none');
                $('#msg4').css('display', 'block');
                $('#msg4').html(result.message);
                $('#msg4').fadeOut(10000);
                //$('#table_data').html(result[0]);
                return false;
            } else {
                $('#frmImportDataButton3').css('display', 'block');
                $('#uploading_text_3').css('display', 'none');
                $('#loadingbox').css('display', 'none');
                //$('#table_data').html(result[0]);
                return false;
            }
        }
    });
});
$('.cancel').on('click', function () {

    $('#importw_step_1').css('display', 'block');
    $('#importw_step_3').css('display', 'none');
    return false;
});
function previous_step(step) {
    window.parent.scrollTo(0, 0);
    var previous_step = 0;
    if (parseInt(isFutureMappingIsEnable) && step == 3) {
        previous_step = parseInt(step) - 2; //skip the mapping step
    } else {
        previous_step = parseInt(step) - 1;
    }
    $('#importw_step_' + previous_step).css('display', 'block');
    $('#importw_step_' + step).css('display', 'none');
}

function cancel_process() {
    $('#importw_step_1').css('display', 'block');
    $('#importw_step_3').css('display', 'none');
    return false;
}

function dialogueBoxSavedMapping(mappingsavedforfuture, mapping_name) {

//alert(futuremapping.boolmappingsavedforfuture);
    var mappingforfutureuse = mappingsavedforfuture;
    var mapping_name = mapping_name;
    if (parseInt(mappingforfutureuse)) {
        var result = confirm('Would you like to use the "' + mapping_name + '" mapping for this import?');
        if (result) {
            mappingsavedforfuture = 1;
            $('#mappingsavedforfuture').val(1);
            //to check for empty fields in csv, xls and tsv files
            $.ajax({
                url: "/manageuser/checkforemptyfieldsindatasheet/",
                type: "POST",
                data: {uploaded_file_name: $('#uploaded_file_name').val(), encoding_format: $('#encoding_format2').val(), delimiter_value: $('#file_delimiter_value').val(), uploaddirectory: 'web_users'},
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: (function (data) {

                    var result = data;
                    if (result.isEmptyDataSheetField) {
                        var boot_result = confirm("Your uploaded file contains empty fields. Continue with import wizard?");
                        if (!boot_result) {

                            $('#importw_step_1').css('display', 'block');
                            $('#importw_step_2').css('display', 'none');
                            $('#importw_step_3').css('display', 'none');
                            $('#uploading_text_2').css('display', 'none');
                            $('#uploading_text_2').css('display', 'none');
                            $('#frmImportDataButton').css('display', 'block');
                            return false;
                        } else {

                            $('#file-data-preview-loading').css('display', 'block');
                            $.ajax({
                                url: "/manageuser/validationbeforeimport/",
                                type: "POST",
                                data: $('#frmImportStep2').serialize(),
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                dataType: "json"
                            }).done(function (data) {

                                var result = data;
                                //alert(result.error); return false;
                                if (!parseInt(result.error)) {

                                    //alert(dataArray[0]);
                                    //var result = dataArray[0].split('||');
                                    //alert(result[2]);
                                    //alert(result.mapped_file_data); return false;
                                    $('#file-data-preview-loading').css('display', 'none');
                                    var unmappedfields = result.unmappedfieldsstr.split('-');
                                    var unmappedFieldResultHtml = '<table>';
                                    for (var i = 0; i < unmappedfields.length; i++) {
                                        unmappedFieldResultHtml += '<tr><td class="importw-table">' + unmappedfields[i] + '</td></tr>';
                                    }
                                    var skippedfields = result.skippedfields.split('-');
                                    //alert(skipped_array);
                                    unmappedFieldResultHtml += '</table>';
                                    var skippedFieldResultHtml = '<table>';
                                    for (var j = 0; j < skippedfields.length; j++) {
                                        skippedFieldResultHtml += '<tr><td class="importw-table">' + skippedfields[j] + '</td></tr>';
                                    }
                                    skippedFieldResultHtml += '</table><p style="border-bottom:solid 1px #ccc; padding:10px 0px;" id="skippedfields"></p>';
                                    var previewfiledattobimportedObj = $.parseJSON(result.previewfiledattobimported);
                                    var previewfiledataimportedHtml = '<table>';
                                    for (var l = 0; l < previewfiledattobimportedObj.length; l++) {

                                        previewfiledataimportedHtml += '<tr>';
                                        for (var key in previewfiledattobimportedObj[l]) {

                                            previewfiledataimportedHtml += '<td>' + previewfiledattobimportedObj[l][key] + '</td>';
                                        }

                                        previewfiledataimportedHtml += '</tr>';
                                    }

                                    previewfiledataimportedHtml += '</table>';
                                    $("#user-file-data-preview").html(previewfiledataimportedHtml);
                                    $('#umappedFieldResult').html(unmappedFieldResultHtml);
                                    $('#skippedFieldResult').html(skippedFieldResultHtml);
                                    $('#skippedFieldResult').css('display', 'block');
                                    $('#umappedFieldResult').css('display', 'block');
                                    $('#uploaded_file_name_3').val(result.uploadedfilename);
                                    $('#import_table_name_3').val(result.importtablename);
                                    $('#readytoimportdata').html('Contacts that are ready to be imported (' + result.readytoimportRecords + ')');
                                    $('#skippeddatanumber').html('<a href="#"> No. of Records skipped (' + result.skippedrecords + ' )</a>');
                                    $('#unmappedfields').html('<a href="#">> Unmapped Fields (' + result.unmappedfields + ' )</a>');
                                    $('#skippedfields').html('<a href="#">> Skipped Fields (' + result.skippedfieldscnt + ' )</a>');
                                    $('#warning-inner-div').html(result.readytoimportRecords + ' Contacts in your file are ready to be imported.');
                                    $('#alert-warning-div').css('display', 'block');
                                    $('#importw_step_2').css('display', 'none');
                                    $('#loadingbox').css('display', 'none');
                                    $('#importw_step_3').css('display', 'block');
                                    $('#frmImportDataButton').css('display', 'block');
                                    $('#uploading_text_2').css('display', 'none');
                                    $('#propertyid3').val(result.propertyid);
                                    $('#adminid3').val(result.adminid);
                                    $('#token3').val(result.with3);
                                    $('#mapped_file_data').val(result.mapped_file_data);
                                    $('#sdi_format3').val(result.sdi_format);
                                    $('#do_not_update3').val(result.do_not_update);
                                    $('#delete_previous_users3').val(result.delete_previous_users);
                                    $('#encoding_format3').val(result.encoding_format);
                                    return false;
                                } else {
                                    //alert(result.error);
                                    alert(result.error);
                                    $('#myModal1').modal({"backdrop": "static"});
                                    $('#frmImportDataButton').css('display', 'block');
                                    $('#uploading_text_2').css('display', 'none');
                                    $('#mapped_file_data').html('');
                                    return false;
                                }

                            });
                        }


                    } else {

                        $('#file-data-preview-loading').css('display', 'block');
                        $.ajax({
                            url: "/manageuser/validationbeforeimport/",
                            type: "POST",
                            data: $('#frmImportStep2').serialize(),
                            dataType: "json",
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        }).done(function (data) {

                            var result = data;
                            //alert(result.error); return false;
                            if (!parseInt(result.error)) {

                                //alert(dataArray[0]);
                                //var result = dataArray[0].split('||');
                                //alert(result[2]);
                                //alert(result.mapped_file_data); return false;
                                $('#file-data-preview-loading').css('display', 'none');
                                var unmappedfields = result.unmappedfieldsstr.split('-');
                                var unmappedFieldResultHtml = '<table>';
                                for (var i = 0; i < unmappedfields.length; i++) {
                                    unmappedFieldResultHtml += '<tr><td class="importw-table">' + unmappedfields[i] + '</td></tr>';
                                }
                                var skippedfields = result.skippedfields.split('-');
                                //alert(skipped_array);
                                unmappedFieldResultHtml += '</table>';
                                var skippedFieldResultHtml = '<table>';
                                for (var j = 0; j < skippedfields.length; j++) {
                                    skippedFieldResultHtml += '<tr><td class="importw-table">' + skippedfields[j] + '</td></tr>';
                                }
                                skippedFieldResultHtml += '</table><p style="border-bottom:solid 1px #ccc; padding:10px 0px;" id="skippedfields"></p>';
                                var previewfiledattobimportedObj = $.parseJSON(result.previewfiledattobimported);
                                var previewfiledataimportedHtml = '<table>';
                                for (var l = 0; l < previewfiledattobimportedObj.length; l++) {

                                    previewfiledataimportedHtml += '<tr>';
                                    for (var key in previewfiledattobimportedObj[l]) {

                                        previewfiledataimportedHtml += '<td>' + previewfiledattobimportedObj[l][key] + '</td>';
                                    }

                                    previewfiledataimportedHtml += '</tr>';
                                }

                                previewfiledataimportedHtml += '</table>';
                                $("#user-file-data-preview").html(previewfiledataimportedHtml);
                                $('#umappedFieldResult').html(unmappedFieldResultHtml);
                                $('#skippedFieldResult').html(skippedFieldResultHtml);
                                $('#skippedFieldResult').css('display', 'block');
                                $('#umappedFieldResult').css('display', 'block');
                                $('#uploaded_file_name_3').val(result.uploadedfilename);
                                $('#import_table_name_3').val(result.importtablename);
                                $('#readytoimportdata').html('Contacts that are ready to be imported (' + result.readytoimportRecords + ')');
                                $('#skippeddatanumber').html('<a href="#"> No. of Records skipped (' + result.skippedrecords + ' )</a>');
                                $('#unmappedfields').html('<a href="#">> Unmapped Fields (' + result.unmappedfields + ' )</a>');
                                $('#skippedfields').html('<a href="#">> Skipped Fields (' + result.skippedfieldscnt + ' )</a>');
                                $('#warning-inner-div').html(result.readytoimportRecords + ' Contacts in your file are ready to be imported.');
                                $('#alert-warning-div').css('display', 'block');
                                $('#importw_step_2').css('display', 'none');
                                $('#loadingbox').css('display', 'none');
                                $('#importw_step_3').css('display', 'block');
                                $('#frmImportDataButton').css('display', 'block');
                                $('#uploading_text_2').css('display', 'none');
                                $('#propertyid3').val(result.propertyid);
                                $('#adminid3').val(result.adminid);
                                $('#token3').val(result.with3);
                                $('#mapped_file_data').val(result.mapped_file_data);
                                $('#sdi_format3').val(result.sdi_format);
                                $('#do_not_update3').val(result.do_not_update);
                                $('#delete_previous_users3').val(result.delete_previous_users);
                                $('#encoding_format3').val(result.encoding_format);
                                return false;
                            } else {
                                //alert(result.error);
                                alert(result.error);
                                $('#myModal1').modal({"backdrop": "static"});
                                $('#frmImportDataButton').css('display', 'block');
                                $('#uploading_text_2').css('display', 'none');
                                $('#mapped_file_data').html('');
                                return false;
                            }

                        });
                    }

                })
            });
            return false;
        } else {

            mappingsavedforfuture = 0;
            $('#mappingsavedforfuture').val(0);
            return false;
        }



    }



}

function saveMappingNameForFuture() {

    $('#mapping_name').val($('#future_mapping_name').val());
    $('#myModal_success').modal();
    $.ajax({
        url: $('#frmSaveFutureMappingName').attr('action'),
        type: "POST",
        data: {
            mapping_name: $('#future_mapping_name').val(),
            level: $('#with').val(),
            idlevel: $('#ID_PROPERTY').val(),
            frmDelimiter: $('#frmDelimiter').val()
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function (data) {
//alert(data);
            var result = data;
            if (!parseInt(result.error)) {

                $('#myModal_savemapping').modal('hide');
                $('#myModal_success').modal();
                $('#xpopupheader').html("Success");
                $('#xpopupcontent').html(result.message);
            } else {
                $('#myModal_savemapping').modal('hide');
                $('#myModal_success').modal();
                $('#xpopupheader').html("Error");
                $('#xpopupcontent').html(result.message);
            }
        }
    });
}

function openSaveMappingDialogue(checkbox_id) {
    if ($("#frmSaveForFuture_toskip").is(":checked")) {
        window.parent.scrollTo(0, 0);
    }

    if ($('#' + checkbox_id).is(":checked")) {

        $('#myModal_savemapping').modal();
    } else {
        $('#myModal_savemapping').css('display', 'none');
    }
}

$('.close').click(function () {

    $('#toPopup').css('display', 'none');
});


