array_echeck  = [10,11,4,5,6,7,8,9,16,32];
array_ccard   = [3,31,10,12,19,20];
array_evendor = [18,22,24,30];

pricing_selected = 0;

checks = $('#pricing .pricing_services_check');
radios = $('#pricing .pricing_services_radio');

checks.click(function(){
    checkAction(this);
});

radios.click(function(){
    radioAction(this);
});

$('#btn-save').click(function(){

    var validator = $( "#form" ).validate();
    if(!validator.element( "#vcheck" )
        || !validator.element( "#bstatement" )
        || !validator.element( "#bsheet" )
        || !validator.element( "#taxreturn" )
        || !validator.element( "#driver" )
        || !validator.element( "#ccstatement" )
    ){
        $('html, body').animate({
            scrollTop: $("#vcheck").offset().top - 50
        }, 1);
    }
    else {
        $('#loading_modal').modal('show');
        $('#default-pricing').html('');
        form = $('#form');
        $('#form-action-input').val('save');
        form.attr('novalidate', 'novalidate');
        $("#form")[0].submit();
    }


});

function checkAction(obj){
    if($(obj).prop('checked')){
        data = parseInt($(obj).attr('data'));
        pos_array_echeck = array_echeck.indexOf(data);
        pos_array_ccard = array_ccard.indexOf(data);
        pos_array_evendor = array_evendor.indexOf(data);
        if(pos_array_echeck>-1){
            $("#payment_information_ec input.ignore").removeClass('ignore');
            $("#payment_information_ec").collapse('show');

        }
        else if(pos_array_ccard>-1){
            $("#payment_information_cc input.ignore").removeClass('ignore');
            $("#payment_information_cc").collapse('show');
        }
        else if(pos_array_evendor>-1){
            $("#e_vendor input.ignore").removeClass('ignore');
            $("#e_vendor").collapse('show');
        }

    }
    else{

        data = parseInt($(obj).attr('data'));
        pos_array_echeck = array_echeck.indexOf(data);
        pos_array_ccard = array_ccard.indexOf(data);
        pos_array_evendor = array_evendor.indexOf(data);

        if(pos_array_echeck>-1){
            checked = false;
            checks.each(function(){
                if(array_echeck.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).prop('checked')){
                    checked = true;
                }
            });

            radios.each(function () {
                if(array_echeck.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).is(':checked'))
                {
                    checked = true;
                }
            });

            if(!checked){
                $("#payment_information_ec input").addClass('ignore');
                $("#payment_information_ec").collapse('hide');
            }

        }
        else if(pos_array_ccard>-1){
            checked = false;
            checks.each(function(){
                if(array_ccard.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).prop('checked')){
                    checked = true;
                }
            });

            radios.each(function () {
                if(array_ccard.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).is(':checked'))
                {
                    checked = true;
                }
            });

            if(!checked){
                $("#payment_information_cc input").addClass('ignore');
                $("#payment_information_cc").collapse('hide');
            }
        }
        else if(pos_array_evendor>-1){
            checked = false;
            checks.each(function(){
                if(array_evendor.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).prop('checked')){
                    checked = true;
                }
            });

            radios.each(function () {
                if(array_evendor.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).is(':checked'))
                {
                    checked = true;
                }
            });

            if(!checked)
            {
                $("#e_vendor input").addClass('ignore');
                $("#e_vendor").collapse('hide');
            }

        }

    }
}

function radioAction(obj){
    data = parseInt($(obj).attr('data'));
    pos_array_echeck = array_echeck.indexOf(data);
    pos_array_ccard = array_ccard.indexOf(data);
    pos_array_evendor = array_evendor.indexOf(data);
    if(pos_array_echeck>-1){
        $("#payment_information_ec input.ignore").removeClass('ignore');
        $("#payment_information_ec").collapse('show');
    }
    else if(pos_array_ccard>-1){
        $("#payment_information_cc input.ignore").removeClass('ignore');
        $("#payment_information_cc").collapse('show');
    }
    else if(pos_array_evendor>-1){
        $("#e_vendor input.ignore").removeClass('ignore');
        $("#e_vendor").collapse('show');
    }
}

checks.each(function(){
    if($(this).prop('checked')){
        checkAction(this);
    }
});

radios.each(function(){
    if($(this).prop('checked')){
        radioAction(this);
    }
});