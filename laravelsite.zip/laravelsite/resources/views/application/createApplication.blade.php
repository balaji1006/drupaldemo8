@extends('layouts.master')
@section('title','Application')

@section('content')

<?php
//var_dump($data); exit();
$app = (array) $app;
?>

<?php
if (isset($app['id'])) {
    echo Form::open(['route' => ['applicationstore', $token, $partner, $company, $app['id']], 'files' => true, 'method' => 'POST', 'id' => 'form', 'class' => 'form_validate_loading']);
} else {
    echo Form::open(['route' => ['applicationstore', $token, $partner, $company], 'files' => true, 'method' => 'POST', 'id' => 'form', 'class' => 'form_validate_loading']);
}
?>



<input type="hidden" name="appsaved" value="<?php
if (isset($app['id'])) {
    echo $app['id'];
}
?>">
<script>
    var import_flag = false;</script>
@php
$atoken=decrypt($token);
@endphp



<div class="normalheader ">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <div>
                <h2 class="font-light m-b-xs">
                    {{$title}}
                </h2>
                <small>
                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                        <li><a href="<?php echo route('application', array('token' => $token)); ?>">Applications</a></li>
                        <li class="active">
                            <span>{{$title}}</span>
                        </li>

                    </ol>
                </small>
            </div>
        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">
        <div class="panel-body">

            @if($atoken['level'] == 'P')
            @include('application.partnersGroupSelects')
            <br/>
            <br/>
            @endif
            @if($atoken['level'] == 'B' || $atoken['level'] == 'A')
            @include('application.partnersGroupMerchantSelects')
            <br/>
            <br/>
            @endif
            <section class="">
                <h4 class="header">Contact/Officer Information</h4>
                <hr/>
                <div class="row">
                    <div class="col-sm-3 form-group">
                        <label>Title</label>
                        <select name="ttname" class="form-control">
                            <?php
                            $string = '<option value="">Select Title</option><option value="Mr">Mr</option><option value="Mrs">Mrs</option><option value="Ms">Ms</option>';
                            $replace = '';
                            if (Input::old('ttname')) {
                                $replace = Input::old('ttname');
                            } else {
                                if (isset($data['ttname']))
                                    $replace = $data['ttname'];
                            }
                            $string = str_replace('value="' . $replace . '"', 'value="' . $replace . '" selected="selected"', $string);
                            echo $string;
                            ?>
                        </select>
                    </div>
                    <div class="col-sm-9 form-group">
                        <label>Contact Name </label>
                        <input @if(Input::old('pname')) value="{{Input::old('pname')}}" @else @if(isset($data['pname'])) value="{{$data['pname']}}" @endif @endif type="text" name="pname" class="form-control" required>
                    </div>

                </div>

                <div class="row">

                    <div class="col-sm-3 form-group">
                        <label>Contact Address </label>
                        <input @if(Input::old('cadr1')) value="{{Input::old('cadr1')}}" @else @if(isset($data['cadr1'])) value="{{$data['cadr1']}}" @endif @endif type="text" name="cadr1" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Suite/Apt</label>
                        <input @if(Input::old('cadr1_apt')) value="{{Input::old('cadr1_apt')}}" @else @if(isset($data['cadr1_apt'])) value="{{$data['cadr1_apt']}}" @endif @endif type="text" name="cadr1_apt" class="form-control">
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>Contact City </label>
                        <input @if(Input::old('ccty1')) value="{{Input::old('ccty1')}}" @else @if(isset($data['ccty1'])) value="{{$data['ccty1']}}" @endif @endif type="text" name="ccty1" class="form-control" required>
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>Contact State </label>
                        <?php
                        if (Input::old('cstate1')) {
                            $replace = Input::old('cstate1');
                        } else {
                            if (isset($data['cstate1']))
                                $replace = $data['cstate1'];
                        }
                        ?>
                        @include('application.states', ['name' => 'cstate1','required'=>true,'selected'=>strtoupper($replace)])

                    </div>
                    <div class="col-sm-2 form-group">
                        <label>Zip Code </label>
                        <input @if(Input::old('czip1')) value="{{Input::old('czip1')}}" @else @if(isset($data['czip1'])) value="{{$data['czip1']}}" @endif @endif type="text" name="czip1" class="form-control" required maxlength="5">
                    </div>

                </div>

                <div class="row">
                    <div class="col-sm-3 form-group">
                        <label>Contact Phone </label>
                        <input @if(Input::old('pphone')) value="{{Input::old('pphone')}}" @else @if(isset($data['pphone'])) value="{{$data['pphone']}}" @endif @endif type="text" name="pphone" class="form-control" maxlength="10"  required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Birth Date</label>
                        <input @if(Input::old('bdate')) value="{{Input::old('bdate')}}" @else @if(isset($data['bdate'])) value="{{$data['bdate']}}" @endif @endif type="text" name="bdate" class="form-control datepicker" required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Title or Position </label>
                        <input @if(Input::old('title')) value="{{Input::old('title')}}" @else @if(isset($data['title'])) value="{{$data['title']}}" @endif @endif type="text" name="title" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Contact Email </label>
                        <input @if(Input::old('email')) value="{{Input::old('email')}}" @else @if(isset($data['email'])) value="{{$data['email']}}" @endif @endif type="text" name="email" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>SSN </label>
                        <input @if(Input::old('ssn')) value="{{Input::old('ssn')}}" @else @if(isset($data['ssn'])) value="{{$data['ssn']}}" @endif @endif type="text" name="ssn" class="form-control" required maxlength="9">
                    </div>
                </div>
            </section>
            <br/>
            <br/>
            <section>
                <h4 class="header">Business Information</h4>
                <hr/>
                <div class="row">
                    <div class="col-sm-4 form-group">
                        <label>Business ID</label>
                        <input @if(Input::old('ppid')) value="{{Input::old('ppid')}}" @else @if(isset($data['ppid'])) value="{{$data['ppid']}}" @endif @endif type="text" name="ppid" class="form-control">
                    </div>
                    <div class="col-sm-4 form-group">
                        <label>Corporate Legal Name </label>
                        <input @if(Input::old('legal')) value="{{Input::old('legal')}}" @else @if(isset($data['legal'])) value="{{$data['legal']}}" @endif @endif type="text" name="legal" class="form-control" required>
                    </div>
                    <div class="col-sm-4 form-group">
                        <label>DBA Name </label>
                        <input @if(Input::old('dba')) value="{{Input::old('dba')}}" @else @if(isset($data['dba'])) value="{{$data['dba']}}" @endif @endif type="text" name="dba" class="form-control" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-4 form-group">
                        <label>Address </label>
                        <input @if(Input::old('adr1')) value="{{Input::old('adr1')}}" @else @if(isset($data['adr1'])) value="{{$data['adr1']}}" @endif @endif type="text" name="adr1" class="form-control" required>
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>Suite/Apt</label>
                        <input @if(Input::old('adr1_apt')) value="{{Input::old('adr1_apt')}}" @else @if(isset($data['adr1_apt'])) value="{{$data['adr1_apt']}}" @endif @endif type="text" name="adr1_apt" class="form-control">
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>City </label>
                        <input @if(Input::old('cty1')) value="{{Input::old('cty1')}}" @else @if(isset($data['cty1'])) value="{{$data['cty1']}}" @endif @endif type="text" name="cty1" class="form-control" required>
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>State </label>
                        <?php
                        if (Input::old('state1')) {
                            $replace = Input::old('state1');
                        } else {
                            if (isset($data['state1']))
                                $replace = $data['state1'];
                        }
                        ?>
                        @include('application.states', ['name' => 'state1','required'=>true,'selected'=>strtoupper($replace)])
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>Zip Code </label>
                        <input @if(Input::old('zip1')) value="{{Input::old('zip1')}}" @else @if(isset($data['zip1'])) value="{{$data['zip1']}}" @endif @endif type="text" name="zip1" class="form-control" required maxlength="5">
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-4 form-group">
                        <label>Phone </label>
                        <input @if(Input::old('phone1')) value="{{Input::old('phone1')}}" @else @if(isset($data['phone1'])) value="{{$data['phone1']}}" @endif @endif type="text" name="phone1" class="form-control" required maxlength="10">
                    </div>
                    <div class="col-sm-4 form-group">
                        <label>Business Description </label>
                        <input @if(Input::old('bdesc')) value="{{Input::old('bdesc')}}" @else @if(isset($data['bdesc'])) value="{{$data['bdesc']}}" @endif @endif type="text" name="bdesc" class="form-control" required>
                    </div>
                    <div class="col-sm-4 form-group">
                        <label>Business Structure</label>
                        <select name="bstruct" class="form-control">
                            <?php
                            $string = '<option value="">Select Business Structure</option><option value="1">SoleProprietor</option><option value="2">Partnership</option><option value="3">LLP</option><option value="4">Corporation</option><option value="5">LLC</option><option value="6">SCorporation</option><option value="7">NonProfit</option><option value="8">Government</option><option value="9">Other</option>';
                            $replace = '';
                            if (Input::old('bstruct')) {
                                $replace = Input::old('bstruct');
                            } else {
                                if (isset($data['bstruct']))
                                    $replace = $data['bstruct'];
                            }
                            $string = str_replace('value="' . $replace . '"', 'value="' . $replace . '" selected="selected"', $string);
                            if (!Input::old('bstruct') and isset($data['bstruct'])) {
                                $struct = strtolower($data['bstruct']);
                                switch ($struct) {
                                    case 'soleproprietor':
                                        $string = str_replace('value="1"', 'value="1" selected="selected"', $string);
                                        break;
                                    case 'partnership':
                                        $string = str_replace('value="2"', 'value="2" selected="selected"', $string);
                                        break;
                                    case 'llp':
                                        $string = str_replace('value="3"', 'value="3" selected="selected"', $string);
                                        break;
                                    case 'corporation':
                                        $string = str_replace('value="4"', 'value="4" selected="selected"', $string);
                                        break;
                                    case 'llc':
                                        $string = str_replace('value="5"', 'value="5" selected="selected"', $string);
                                        break;
                                    case 'scorporation':
                                        $string = str_replace('value="6"', 'value="6" selected="selected"', $string);
                                        break;
                                    case 'nonprofit':
                                        $string = str_replace('value="7"', 'value="7" selected="selected"', $string);
                                        break;
                                    case 'government':
                                        $string = str_replace('value="8"', 'value="8" selected="selected"', $string);
                                        break;
                                    case 'other':
                                        $string = str_replace('value="9"', 'value="9" selected="selected"', $string);
                                        break;
                                }
                            }
                            echo $string;
                            ?>
                        </select>
                    </div>

                </div>

                <div class="row">
                    <div class="col-sm-4 form-group">
                        <label>Date formed </label>
                        <input @if(Input::old('date')) value="{{Input::old('date')}}" @else @if(isset($data['date'])) value="{{$data['date']}}" @endif @endif type="text" name="date" class="form-control datepicker" required>
                    </div>
                    <div class="col-sm-4 form-group">
                        <label>Current Ownership Date</label>
                        <input @if(Input::old('cdate')) value="{{Input::old('cdate')}}" @else @if(isset($data['cdate'])) value="{{$data['cdate']}}" @endif @endif type="text" name="cdate" class="form-control datepicker">
                    </div>
                    <div class="col-sm-4 form-group">
                        <label>Federal Tax ID </label>
                        <input @if(Input::old('fti')) value="{{Input::old('fti')}}" @else @if(isset($data['fti'])) value="{{$data['fti']}}" @endif @endif type="text" name="fti" class="form-control" maxlength="9" required>
                    </div>

                </div>

                <div class="row">
                    <div class="col-sm-3 form-group">
                        <label>Billing Address </label>
                        <input @if(Input::old('adr2')) value="{{Input::old('adr2')}}" @else @if(isset($data['adr2'])) value="{{$data['adr2']}}" @endif @endif type="text" name="adr2" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Suite/Apt</label>
                        <input @if(Input::old('adr2_apt')) value="{{Input::old('adr2_apt')}}" @else @if(isset($data['adr2_apt'])) value="{{$data['adr2_apt']}}" @endif @endif type="text" name="adr2_apt" class="form-control">
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>City </label>
                        <input @if(Input::old('cty2')) value="{{Input::old('cty2')}}" @else @if(isset($data['cty2'])) value="{{$data['cty2']}}" @endif @endif type="text" name="cty2" class="form-control" required>
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>State </label>
                        <?php
                        if (Input::old('state2')) {
                            $replace = Input::old('state2');
                        } else {
                            if (isset($data['state2']))
                                $replace = $data['state2'];
                        }
                        ?>
                        @include('application.states', ['name' => 'state2','required'=>true,'selected'=>strtoupper($replace)])
                    </div>
                    <div class="col-sm-2 form-group">
                        <label>Zip Code </label>
                        <input @if(Input::old('zip2')) value="{{Input::old('zip2')}}" @else @if(isset($data['zip2'])) value="{{$data['zip2']}}" @endif @endif type="text" name="zip2" class="form-control" required maxlength="5">
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-4 form-group">
                        <label>Frequency of scheduled payments</label>
                        <select name="freq" class="form-control" required>
                            <?php
                            $string = '<option value="">Select One</option><option value="Monthly">Monthly</option><option value="Quarterly">Quarterly</option><option value="Every 6 Months">Every 6 Months</option><option value="Annually">Annually</option> ';
                            $replace = '';
                            if (Input::old('freq')) {
                                $replace = Input::old('freq');
                            } else {
                                if (isset($data['freq']))
                                    $replace = $data['freq'];
                            }
                            $string = str_replace('value="' . $replace . '"', 'value="' . $replace . '" selected="selected"', $string);

                            if (!Input::old('freq') and isset($data['freq'])) {
                                $freq = strtolower($data['freq']);
                                switch ($freq) {
                                    case 'm':
                                        $string = str_replace('value="Monthly"', 'value="Monthly" selected="selected"', $string);
                                        break;
                                    case 'q':
                                        $string = str_replace('value="Quarterly"', 'value="Quarterly" selected="selected"', $string);
                                        break;
                                    case 'b':
                                        $string = str_replace('value="Every 6 Months"', 'value="Every 6 Months" selected="selected"', $string);
                                        break;
                                    case 'a':
                                        $string = str_replace('value="Annually"', 'value="Annually" selected="selected"', $string);
                                        break;
                                }
                            }
                            echo $string;
                            ?>
                        </select>
                    </div>
                    <div class="col-sm-4 form-group">
                        <label><?php
                            switch ($layout) {
                                case 2:
                                    echo 'Students';
                                    break;
                                case 6:
                                    echo 'Customers';
                                    break;
                                case 13:
                                    echo 'Donors';
                                    break;
                                default:
                                    echo 'Units';
                            }
                            ?> </label>
                        <input @if(Input::old('donor')) value="{{Input::old('donor')}}" @else @if(isset($data['donor'])) value="{{$data['donor']}}" @endif @endif type="text" name="donor" class="form-control" required>
                    </div>
                    <div class="col-sm-4 form-group">
                        <label>Payment due on what day of the month </label>
                        <select name="duedate" class="form-control" required>
                            <?php
                            $string = '<option value="" selected="selected">Select due day</option><option value="1">1st day of the Month</option><option value="2">2nd day of the Month</option><option value="3">3rd day of the Month</option><option value="4">4th day of the Month</option><option value="5">5th day of the Month</option><option value="6">6th day of the Month</option><option value="7">7th day of the Month</option><option value="8">8th day of the Month</option><option value="9">9th day of the Month</option><option value="10">10th day of the Month</option><option value="11">11th day of the Month</option><option value="12">12th day of the Month</option><option value="13">13th day of the Month</option><option value="14">14th day of the Month</option><option value="15">15th day of the Month</option><option value="16">16th day of the Month</option><option value="17">17th day of the Month</option><option value="18">18th day of the Month</option><option value="19">19th day of the Month</option><option value="20">20th day of the Month</option><option value="21">21th day of the Month</option><option value="22">22th day of the Month</option><option value="23">23th day of the Month</option><option value="24">24th day of the Month</option><option value="25">25th day of the Month</option><option value="26">26th day of the Month</option><option value="27">27th day of the Month</option><option value="28">28th day of the Month</option><option value="29">29th day of the Month</option><option value="30">30th day of the Month</option><option value="31">31th day of the Month</option>';
                            $replace = '';
                            if (Input::old('duedate')) {
                                $replace = Input::old('duedate');
                            } else {
                                if (isset($data['duedate']))
                                    $replace = $data['duedate'];
                            }
                            $string = str_replace('value="' . $replace . '"', 'value="' . $replace . '" selected="selected"', $string);
                            echo $string;
                            ?>
                        </select>
                    </div>
                </div>
            </section>
            <br/><br/>
            <section>
                <h4 class="header">Banking Information (Whole numbers only. No punctuation.) </h4>
                <hr/>
                <div class="row">
                    <div class="col-sm-3 form-group">
                        <label>Name on Deposit Bank Account </label>
                        <input @if(Input::old('bankname')) value="{{Input::old('bankname')}}" @else @if(isset($data['bankname'])) value="{{$data['bankname']}}" @endif @endif type="text" name="bankname" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Deposit ABA Routing Number </label>
                        <input @if(Input::old('bankrouting')) value="{{Input::old('bankrouting')}}" @else @if(isset($data['bankrouting'])) value="{{$data['bankrouting']}}" @endif @endif type="text" name="bankrouting" id="bankrouting" class="form-control" required maxlength="9">
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Deposit Bank Account Number </label>
                        <input @if(Input::old('banknumber')) value="{{Input::old('banknumber')}}" @else @if(isset($data['banknumber'])) value="{{$data['banknumber']}}" @endif @endif type="text" name="banknumber" class="form-control" required maxlength="17">
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Account Type</label>
                        <select name="banktype" class="form-control" required>
                            <?php
                            $string = '<option value="0">Checking</option><option value="1">Savings</option>';
                            $replace = '';
                            if (Input::old('banktype')) {
                                $replace = Input::old('banktype');
                            } else {
                                if (isset($data['banktype']))
                                    $replace = $data['banktype'];
                            }
                            $string = str_replace('value="' . $replace . '"', 'value="' . $replace . '" selected="selected"', $string);
                            if (!Input::old('banktype') and isset($data['banktype'])) {
                                $type = strtolower($data['banktype']);
                                switch ($type) {
                                    case 'c':
                                        $string = str_replace('value="0"', 'value="0" selected="selected"', $string);
                                        break;
                                    case 's':
                                        $string = str_replace('value="1"', 'value="1" selected="selected"', $string);
                                        break;
                                }
                            }

                            echo $string;
                            ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-3 form-group">
                        <label>Name on Return Account </label>
                        <input @if(Input::old('bankname_re')) value="{{Input::old('bankname_re')}}" @else @if(isset($data['bankname_re'])) value="{{$data['bankname_re']}}" @endif @endif type="text" name="bankname_re" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>ABA Routing Number </label>
                        <input @if(Input::old('bankrouting_re')) value="{{Input::old('bankrouting_re')}}" @else @if(isset($data['bankrouting_re'])) value="{{$data['bankrouting_re']}}" @endif @endif type="text" name="bankrouting_re" id="bankrouting_re" class="form-control" required maxlength="9">
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Return Account Number </label>
                        <input @if(Input::old('banknumber_re')) value="{{Input::old('banknumber_re')}}" @else @if(isset($data['banknumber_re'])) value="{{$data['banknumber_re']}}" @endif @endif type="text" name="banknumber_re" class="form-control" required>
                    </div>
                    <div class="col-sm-3 form-group">
                        <label>Account Type</label>
                        <select name="banktype_re" class="form-control" required>
                            <?php
                            $string = '<option value="0">Checking</option><option value="1">Savings</option>';
                            $replace = '';
                            if (Input::old('banktype_re')) {
                                $replace = Input::old('banktype_re');
                            } else {
                                if (isset($data['banktype_re']))
                                    $replace = $data['banktype_re'];
                            }
                            $string = str_replace('value="' . $replace . '"', 'value="' . $replace . '" selected="selected"', $string);

                            if (!Input::old('banktype_re') and isset($data['banktype_re'])) {
                                $type = strtolower($data['banktype_re']);
                                switch ($type) {
                                    case 'c':
                                        $string = str_replace('value="0"', 'value="0" selected="selected"', $string);
                                        break;
                                    case 's':
                                        $string = str_replace('value="1"', 'value="1" selected="selected"', $string);
                                        break;
                                }
                            }
                            echo $string;
                            ?>
                        </select>
                    </div>
                </div>
            </section>
            <section>
                <br/>

                <div class="panel panel-default" style="border: none; box-shadow: none; background-color: #F4F4F4; padding: 15px">
                    <div class="panel-body" style="font-size: 12px">
                        <h4>Instructions and Requirements</h4>
                        <span>At least a Voided Check or Bank letter and a Bank Statement or Balance Sheet is required to save the application</span>
                    </div>
                </div>

                <h4 class="header">Required Documents (only pdf and jpg) less than 12 Mb</h4>
                <hr/>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="row form-group">
                            <div class="col-sm-12">
                                <label>Voided Check or Bank letter  <span class="errorspan" id="vcheck_spanerror"></span></label>
                                <input type="file" id="vcheck" name="vcheck" accept="image/jpeg,application/pdf" @if(!isset($data['vcheck']))required @endif />
                                       @if(isset($data['vcheck']))<a href="{{ route('downloadfile',['file' => $data['vcheck']]) }}">Voided Check or Bank letter</a> <input type="hidden" name="vcheck_saved" value="{{$data['vcheck']}}"/> @endif
                            </div>
                        </div>

                    </div>

                    <div class="col-sm-6">
                        <div class="row form-group">
                            <div class="col-sm-12">
                                <label>1st Bank Statement or Balance Sheet  <span class="errorspan" id="bstatement_spanerror"></span></label>
                                <input type="file" id="bstatement" name="bstatement" accept="image/jpeg,application/pdf" @if(!isset($data['bstatement'])) required @endif />
                                       @if(isset($data['bstatement']))<a href="{{ route('downloadfile',['file' => $data['bstatement']]) }}">1st Bank Statement or Balance Sheet</a> <input type="hidden" name="bstatement_saved" value="{{$data['bstatement']}}"/> @endif
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="row form-group">
                            <div class="col-sm-12">
                                <label>2nd Bank Statement or Balance Sheet <span class="errorspan" id="bstatement2_spanerror"></span></label>
                                <input type="file" id="bsheet" name="bsheet" accept="image/jpeg,application/pdf"/>
                                @if(isset($data['bsheet']))<a href="{{ route('downloadfile',['file' => $data['bsheet']]) }}">2nd Bank Statement or Balance Sheet</a> <input type="hidden" name="bsheet_saved" value="{{$data['bsheet']}}"/>@endif
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row form-group">
                            <div class="col-sm-12">
                                <label>3rd Bank Statement or Balance Sheet <span class="errorspan" id="bstatement3_spanerror"></span></label>
                                <input type="file" id="taxreturn" name="taxreturn" accept="image/jpeg,application/pdf"/>
                                @if(isset($data['taxreturn']))<a href="{{ route('downloadfile',['file' => $data['taxreturn']]) }}">3rd Bank Statement or Balance Sheet</a> <input type="hidden" name="taxreturn_saved" value="{{$data['taxreturn']}}"/>@endif
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="row form-group">
                            <div class="col-sm-12">
                                <label>Driver License <span class="errorspan" id="driver_spanerror"></span></label>
                                <input type="file" id="driver" name="driver" accept="image/jpeg,application/pdf"/>
                                @if(isset($data['driver']))<a href="{{ route('downloadfile',['file' => $data['driver']]) }}">Driver License</a> <input type="hidden" name="driver_saved" value="{{$data['driver']}}"/>@endif
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row form-group">
                            <div class="col-sm-12">
                                <label>CC Statement <span class="errorspan" id="ccstatement_spanerror"></span></label>
                                <input type="file" id="ccstatement" name="ccstatement" accept="image/jpeg,application/pdf"/>
                                @if(isset($data['ccstatement']))<a href="{{ route('downloadfile',['file' => $data['ccstatement']]) }}">CC Statement</a> <input type="hidden" name="ccstatement_saved" value="{{$data['ccstatement']}}"/>@endif
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <br/>
            <br/>
            <section>
                <h4 class="header">Pricing and Services</h4>
                <hr/>
                <div class="row">
                    <div class="col-sm-6">

                    </div>
                    <div class="col-sm-4 ">
                        <small id="message-pricing"></small>
                    </div>

                </div>
                <div class="row">
                    <div class="col-sm-6">

                    </div>
                    <div class="col-sm-4 form-group">
                        <input @if (isset($data['pricing_code']) && $data['pricing_code']) value="{{$data['pricing_code']}}" @endif name="pricing_code" type="text" id="pricing_code" class="hidden">
                                <div class="input-group">
                            <input @if (isset($data['pricing_code']) && $data['pricing_code']) value="{{$data['pricing_code']}}" @endif type="text" id="pricing_code_view" placeholder="Pricing Code" class="form-control">
                                    <span class="input-group-btn">
                                <span class="btn btn-default btn-file" id="apply_pricing">
                                    Apply
                                </span>
                            </span>
                        </div>
                    </div>
                    <div class="col-sm-2 form-group">
                        <div id="default-pricing" class="hidden">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Items</th>
                                        <th class="text-center">Select</th>
                                        <th class="text-right">Pricing</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($ps as $p)
                                    <tr>
                                        <td>{{ $p->description }}<br/><span class="small_text">{{ $p->toptips }}</span></td>
                                        <td class="text-center">
                                            @if($p->select==1) <input type="checkbox" name="pricing_services_check_{{ $p->id_p }}" class="pricing_services_check" data="{{$p->service}}" value="{{$p->id_p}}"> @endif
                                            @if($p->select==2) <input type="radio" name="{{ $p->nameinput }}" class="pricing_services_radio " data="{{$p->service}}" value="{{$p->id_p}}"> @endif
                                        </td>
                                        <td class="text-right">{{ $p->cost }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <script src="{{ asset('js/pricing.js') }}"></script>
                        </div>
                        <button type="button" class="btn btn-default btn-block" id="btn_default_pricing">Default Pricing</button>
                    </div>
                </div>
                <div id="pricing">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Items</th>
                                <th class="text-center">Select</th>
                                <th class="text-right">Pricing</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($ps as $p)
                            <tr>
                                <td>{{ $p->description }}<br/><span class="small_text">{{ $p->toptips }}</span></td>
                                <td class="text-center">
                                    @if($p->select==1) <input @if(Input::old('pricing_services_check_'.$p->id_p)) checked="checked" @endif  type="checkbox" name="pricing_services_check_{{ $p->id_p }}" class="pricing_services_check @if(isset($data["pricing_services_check_".$p->id_p])) radiocheck @endif @if(isset($data["array_service_import"]["check_service".$p->service])) radiocheck @endif" data="{{$p->service}}" value="{{$p->id_p}}"> @endif
                                                               @if($p->select==2) <input @if(Input::old($p->nameinput) && Input::old($p->nameinput) == $p->service) checked="checked" @endif type="radio" name="{{ $p->nameinput }}" class="pricing_services_radio @if(isset($data['array_service']['check_service'.$p->id_p])) radiocheck @endif @if(isset($data["array_service_import"]["check_service".$p->service])) radiocheck @endif @if(isset($data['pricing_services_radio_ev']) && $data['pricing_services_radio_ev'] == $p->id_p) radiocheck @endif" data="{{$p->service}}" value="{{$p->id_p}}"> @endif
                                </td>
                                <td class="text-right">{{ $p->cost }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="collapse" id="payment_information_ec">
                    <p><b>Payment information for eCheck (Whole numbers only. No punctuation.)</b></p>
                    <div class="row form-group">
                        <div class="col-sm-6">
                            <label>What is the largest payment you will ever process?</label>
                            <input @if(Input::old('hticket')) value="{{Input::old('hticket')}}" @else @if(isset($data['hticket'])) value="{{$data['hticket']}}" @endif @endif type="text" name="hticket" class="form-control ignore">
                        </div>
                        <div class="col-sm-6">
                            <label>How many payments will your process per day?</label>
                            <input @if(Input::old('cticket')) value="{{Input::old('cticket')}}" @else @if(isset($data['cticket'])) value="{{$data['cticket']}}" @endif @endif type="text" name="cticket" class="form-control ignore">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-sm-6">
                            <label>How many payments will your process per month?</label>
                            <input @if(Input::old('avticket')) value="{{Input::old('avticket')}}" @else @if(isset($data['avticket'])) value="{{$data['avticket']}}" @endif @endif type="text" name="avticket" class="form-control ignore">
                        </div>
                        <div class="col-sm-6">
                            <label>What is your estimated monthly volume?</label>
                            <input @if(Input::old('mticket')) value="{{Input::old('mticket')}}" @else @if(isset($data['mticket'])) value="{{$data['mticket']}}" @endif @endif type="text" name="mticket" class="form-control ignore">
                        </div>
                    </div>
                </div>

                <div class="collapse" id="payment_information_cc">
                    <p><b>Payment information for Credit Card (Whole numbers only. No punctuation.)</b></p>
                    <div class="row form-group">
                        <div class="col-sm-6">
                            <label>What is the largest payment you will ever process?</label>
                            <input @if(Input::old('cchticket')) value="{{Input::old('cchticket')}}" @else @if(isset($data['cchticket'])) value="{{$data['cchticket']}}" @endif @endif type="text" name="cchticket" class="form-control ignore">
                        </div>
                        <div class="col-sm-6">
                            <label>What is your estimated monthly volume?</label>
                            <input @if(Input::old('ccmticket')) value="{{Input::old('ccmticket')}}" @else @if(isset($data['ccmticket'])) value="{{$data['ccmticket']}}" @endif @endif type="text" name="ccmticket" class="form-control ignore">
                        </div>
                    </div>
                </div>

                <div class="collapse" id="e_vendor">
                    <p><b>E-Vendor (Please complete the section below if you have selected this service)</b></p>
                    <div class="row form-group">
                        <div class="col-sm-6">
                            <label>What is the largest outbound transaction you will ever process?</label>
                            <input @if(Input::old('vhticket')) value="{{Input::old('vhticket')}}" @else @if(isset($data['vhticket'])) value="{{$data['vhticket']}}" @endif @endif type="text" name="vhticket" class="form-control ignore">
                        </div>
                        <div class="col-sm-6">
                            <label>How many outbound transactions will your process per day?</label>
                            <input @if(Input::old('vcticket')) value="{{Input::old('vcticket')}}" @else @if(isset($data['vcticket'])) value="{{$data['vcticket']}}" @endif @endif type="text" name="vcticket" class="form-control ignore">
                        </div>
                    </div>
                </div>

            </section>
            <br/>
            <br/>
            <section>

                <h4 class="header"><br/> Sign on behalf of the merchant  </h4>
                <hr/>
                <label>

                    <div class="checkbox checkbox-success">
                        <input id="behalf_merchants" @if(isset($data['behalf_merchants'])) checked @endif type="checkbox" name="behalf_merchants">
                               <label for="behalf_merchants">
                            Signing in behalf of the merchant
                        </label>
                    </div>

                </label>

                <div class="collapse @if(isset($data['behalf_merchants'])) in @endif" id="email_behalf_cont">
                    <div class="row">
                        <div class="col-xs-4">
                            <input value="@if(isset($data['email_behalf'])){{$data['email_behalf']}}@endif" type="text" @if(isset($data['behalf_merchants'])) required @endif id="email_behalf" name="email_behalf" class="form-control" placeholder="E-mail">
                        </div>
                    </div>
                </div>

            </section>
            <br/>
            <br/>
            <section>
                <h4 class="header">Agree to Terms of Use and eSign below</h4>
                <hr/>
                <div class="row form-group">
                    <div class="col-sm-4">
                        <p><b>Terms of Use and Privacy Policy</b></p>
                        <div class="">
                            <label>

                                <div class="checkbox checkbox-success">
                                    <input @if(isset($data['term_of_use'])) checked="checked" @endif type="checkbox" id="term_of_use" name="term_of_use" required/>
                                            <label for="term_of_use">
                                        I accept the <a href="http://www.revopay.com/revopay-service-agreement/" target="_blank">Terms of Use</a>
                                    </label>
                                </div>

                            </label>
                        </div>
                    </div>

                </div>

            </section>
            <section>
                <div class="hr-line-dashed"></div>
                <div class="form-group">
                    <a class="btn btn-default" href="<?php echo route('application', array('token' => $token)); ?>">Cancel</a>
                    <input id="btn-save" class="btn btn-default" type="button" value="Save"/>
                    <?php
                    if (!isset($app['status']) || (isset($app['status']) && $app['status'] < 4)) {
                        ?>
                        <input id="btn-submit" class="btn btn-primary" type="submit" value="Submit"/>
                        <?php
                    }
                    ?>
                </div>

            </section>
            <input name="action" class="hidden" id="form-action-input" value="">
        </div>
    </div>
</div>

{!! Form::close() !!}
@endsection
@section('footer1')
<script src="{{ asset('js/pricing.js') }}"></script>
<script src="{{ asset('js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('js/additional-methods.min.js') }}"></script>

<script>



    $('.datepicker').datepicker({
    format: 'mm/dd/yyyy',
            autoclose:true,
            setDate: '<?php echo date('mm/dd/yyyy'); ?>',
            endDate: '-1d'
    });
    $.validator.addMethod("ValidarEVvhticket", function(value, element){
    var array_evendor = [18, 22, 24, 30];
    var flagev = 0;
    for (var i = 0; i < array_evendor.length; i++){
    var evname = 'pricing_services_check_' + array_evendor[i];
    if ($("input:checkbox[name=" + evname + "]").is(':checked')){
    flagev++; break;
    }
    }

    if (flagev > 0){
    if ($.trim($("input[name=vhticket]").val()) == ""){
    return false;
    }
    return true;
    }
    else {
    return true;
    }
    }, "This field is required.");
    $.validator.addMethod("ValidarEVvcticket", function(value, element){
    var array_evendor = [18, 22, 24, 30];
    var flagev = 0;
    for (var i = 0; i < array_evendor.length; i++){
    var ecname = 'pricing_services_check_' + array_evendor[i];
    if ($("input:checkbox[name=" + ecname + "]").is(':checked')){
    flagev++; break; }
    }

    if (flagev > 0){
    if ($.trim($("input[name=vcticket]").val()) == ""){return false; }
    return true; }
    else{return true; }
    }, "This field is required.");
    $.validator.addMethod("ValidarEChticket", function(value, element){
    var array_echeck = [10, 11, 4, 5, 6, 7, 8, 9, 16, 32];
    var flagec = 0;
    for (var i = 0; i < array_echeck.length; i++){
    var ecname = 'pricing_services_check_' + array_echeck[i];
    if ($("input:checkbox[name=" + ecname + "]").is(':checked')){
    flagec++; break; }
    }

    if (flagec > 0){
    if ($.trim($("input[name=hticket]").val()) == ""){return false; }
    return true; }
    else{return true; }
    }, "This field is required.");
    $.validator.addMethod("ValidarECavticket", function(value, element){
    var array_echeck = [10, 11, 4, 5, 6, 7, 8, 9, 16, 32];
    var flagec = 0;
    for (var i = 0; i < array_echeck.length; i++){
    var ecname = 'pricing_services_check_' + array_echeck[i];
    if ($("input:checkbox[name=" + ecname + "]").is(':checked')){
    flagec++; break; }
    }

    if (flagec > 0){
    if ($.trim($("input[name=avticket]").val()) == ""){return false; }
    return true; }
    else{return true; }
    }, "This field is required.");
    $.validator.addMethod("ValidarECcticket", function(value, element){
    var array_echeck = [10, 11, 4, 5, 6, 7, 8, 9, 16, 32];
    var flagec = 0;
    for (var i = 0; i < array_echeck.length; i++){
    var ecname = 'pricing_services_check_' + array_echeck[i];
    if ($("input:checkbox[name=" + ecname + "]").is(':checked')){
    flagec++; break; }
    }

    if (flagec > 0){
    if ($.trim($("input[name=cticket]").val()) == ""){return false; }
    return true; }
    else{return true; }
    }, "This field is required.");
    $.validator.addMethod("ValidarECmticket", function(value, element){
    var array_echeck = [10, 11, 4, 5, 6, 7, 8, 9, 16, 32];
    var flagec = 0;
    for (var i = 0; i < array_echeck.length; i++){
    var ecname = 'pricing_services_check_' + array_echeck[i];
    if ($("input:checkbox[name=" + ecname + "]").is(':checked')){
    flagec++; break; }
    }

    if (flagec > 0){
    if ($.trim($("input[name=mticket]").val()) == ""){return false; }
    return true; }
    else{return true; }
    }, "This field is required.");
    $.validator.addMethod("ValidarCCcchticket", function(value, element){
    var array_ccard = [3, 31, 10, 12, 19, 20];
    var flagcc = 0;
    for (var i = 0; i < array_ccard.length; i++){
    var ccname = 'pricing_services_check_' + array_ccard[i];
    if ($("input:checkbox[name=" + ccname + "]").is(':checked')){
    flagcc++; break; }
    }
    if (flagcc > 0){
    if ($.trim($("input[name=cchticket]").val()) == ""){return false; }
    return true; }
    else{return true; }

    }, "This field is required.");
    $.validator.addMethod("ValidarCCccmticket", function(value, element){
    var array_ccard = [3, 31, 10, 12, 19, 20];
    var flagcc = 0;
    for (var i = 0; i < array_ccard.length; i++){
    var ccname = 'pricing_services_check_' + array_ccard[i];
    if ($("input:checkbox[name=" + ccname + "]").is(':checked')){
    flagcc++; break; }
    }

    if (flagcc > 0){
    if ($.trim($("input[name=ccmticket]").val()) == ""){return false; }
    return true; }
    else{return true; }
    }, "This field is required.");
    $.validator.addMethod("ValidateAbA_re", function ValidateAbA_re()
    { n = 0; $('#bankrouting_re').text(''); var t = $('#bankrouting_re').val();
    for (i = 0; i < t.length; i += 3) {
    n += parseInt(t.charAt(i), 10) * 3
            + parseInt(t.charAt(i + 1), 10) * 7
            + parseInt(t.charAt(i + 2), 10); }
    if (n != 0 && n % 10 == 0)
    {return true; } else{return false; }}, "routing number is invalid !");
    $.validator.addMethod("ValidateAbA", function ValidateAbA()
    { n = 0; $('#bankrouting').text(''); var t = $('#bankrouting').val();
    for (i = 0; i < t.length; i += 3) {
    n += parseInt(t.charAt(i), 10) * 3
            + parseInt(t.charAt(i + 1), 10) * 7
            + parseInt(t.charAt(i + 2), 10); }
    if (n != 0 && n % 10 == 0)
    {return true; } else{return false; }}, "routing number is invalid !");
    $.validator.addMethod("ValidarECVolumen", function(value, element){
    if (parseInt($.trim($("input[name=hticket]").val())) > parseInt($.trim($("input[name=mticket]").val()))){
    return false;
    } else return true;
    }, "Your estimated monthly volume is lesser than your largest payment.");
    $.validator.addMethod("ValidarCCVolumen", function(value, element){
    if (parseInt($.trim($("input[name=cchticket]").val())) > parseInt($.trim($("input[name=ccmticket]").val()))){
    return false;
    } else return true;
    }, "Your estimated monthly volume is lesser than your largest payment.");

    $.validator.addMethod('filesize', function (value, element, param) {
        return this.optional(element) || (element.files[0].size <= param)
    }, 'File size must be less than 20 mb');

    $("#form").validate({
    ignore: '*:not([name]), .ignore',
            rules: {
            zip1: {
            maxlength: 5,
                    minlength: 5,
                    digits: true
            },
                    zip2: {
                    maxlength: 5,
                            minlength: 5,
                            digits: true
                    },
                    czip1:{
                    maxlength: 5,
                            minlength: 5,
                            digits: true
                    },
                    fti:{
                    maxlength: 9,
                            minlength: 9,
                    },
                    banknumber: {
                    maxlength: 17,
                            minlength: 4,
                    },
                    email: {
                    email:true
                    },
                    hticket: {
                    number:true,
                            ValidarEChticket:true,
                    },
                    cticket: {
                    number:true,
                            ValidarECcticket:true,
                    },
                    avticket: {
                    number:true,
                            ValidarECavticket:true,
                    },
                    mticket: {
                    number:true,
                            ValidarECmticket:true,
                            ValidarECVolumen:true,
                    },
                    cchticket: {
                    number:true,
                            ValidarCCcchticket:true,
                    },
                    ccmticket: {
                    number:true,
                            ValidarCCccmticket:true,
                            ValidarCCVolumen:true,
                    },
                    vhticket: {
                    number:true,
                            ValidarEVvhticket:true,
                    },
                    vcticket: {
                    ValidarEVvcticket:true,
                            number:true,
                    },
                    pphone:{
                    digits:true,
                            minlength: 10,
                            maxlength: 10
                    },
                    ssn:{
                    minlength: 9,
                            maxlength: 9,
                            digits: true,
                    },
                    bankrouting:{
                    minlength: 9,
                            maxlength: 9,
                            ValidateAbA:true
                    },
                    bankrouting_re:{
                    minlength: 9,
                            maxlength: 9,
                            ValidateAbA_re:true
                    },
                    phone1:{
                    digits:true,
                            minlength: 10,
                            maxlength: 10
                    },
                    vcheck: {
                    @if (!isset($data['vcheck']))required: true, @endif
                            accept: "image/jpeg,image/jpg,application/pdf",
                            filesize: 20000000
                    },
                    bstatement: {
                    @if (!isset($data['bstatement']))required: true, @endif
                        accept: "image/jpeg,image/jpg,application/pdf",
                        filesize: 20000000
                    },
                    bsheet: {
                    required: false,
                        accept: "image/jpeg,image/jpg,application/pdf",
                        filesize: 20000000
                    },
                    taxreturn: {
                    required: false,
                        accept: "image/jpeg,image/jpg,application/pdf",
                        filesize: 20000000
                    },
                    driver: {
                    required: false,
                        accept: "image/jpeg,image/jpg,application/pdf",
                        filesize: 20000000
                    },
                    ccstatement: {
                    required: false,
                        accept: "image/jpeg,image/jpg,application/pdf",
                        filesize: 20000000
                    },
            },
            messages: {
            zip1: 'Please enter 5 numbers',
                    zip2: 'Please enter 5 numbers',
                    czip1: 'Please enter 5 numbers',
                    fti: 'Please enter 9 characters'

            },
            errorPlacement: function(error, element) {
            if (element.attr("name") == "hticket" || element.attr("name") == "cticket" || element.attr("name") == "avticket" || element.attr("name") == "mticket") {
            $("#payment_information_ec").collapse('show');
            }

            if (element.attr("name") == "cchticket" || element.attr("name") == "ccmticket") {
            $("#payment_information_cc").collapse('show');
            }

            if (element.attr("name") == "vhticket" || element.attr("name") == "vcticket") {
            $("#e_vendor").collapse('show');
            }

            if (element.attr("name") == "vcheck") {
            $("#vcheck_spanerror").html(error);
            }

            if (element.attr("name") == "bstatement") {
            $("#bstatement_spanerror").html(error);
            }

            if (element.attr("name") == "bsheet") {
            $("#bstatement2_spanerror").html(error);
            }

            if (element.attr("name") == "taxreturn") {
            $("#bstatement3_spanerror").html(error);
            }

            if (element.attr("name") == "driver") {
            $("#driver_spanerror").html(error);
            }

            if (element.attr("name") == "ccstatement") {
            $("#ccstatement_spanerror").html(error);
            }
            name = element.attr("name");
            if (name != "vcheck" && name != "bstatement" && name != "bsheet" && name != "taxreturn"
                    && name != "driver" && name != "ccstatement"
                    )
                    element.after(error);
            error.insertBefore(element);
            },
            submitHandler: function(form) {
            total_p = $('#pricing input:checked').length;
            if (total_p){
            $('#default-pricing').html(' ');
            $('#loading_modal').modal('show');
            form.submit();
            }
            else{
            alert('You need to select at least a service (Pricing and Services)');
            }
            },
            errorElement: "span",
    });
    $('.btn').click(function(){
        if ($('#bstatement').hasClass('valid')){
            $('#bstatement_spanerror').html('');
        }

        if ($('#vcheck').hasClass('valid')){
            $('#vcheck_spanerror').html('');
        }
    });
    $('#apply_pricing').click(function(){
    val = $('#pricing_code_view').val();
    applyPricing(val);
    });
    function applyPricing(val){
    if (val){
    url = "{{ route('apppricingbycode',['code'=>'000','option'=>1]) }}";
    url = url.replace('/000/', '/' + val + '/');
    $.ajax({
    method: "GET",
            url: url
    })
            .success(function(msg) {
            if (msg){
            collapseAll();
            $('#message-pricing').html('');
            $('#pricing').html(msg);
            $('#pricing_code').val(val);
            }
            else{
            $('#message-pricing').html('Sorry! That pricing code does not exist. Please try again.');
            }
            });
    }

    }

    var dpcode = "@if (isset($data['pricing_code']) && $data['pricing_code']){{$data['pricing_code']}}@endif";
    $('#btn_default_pricing').click(function(){

    if (dpcode){
    $('#pricing_code').val(dpcode);
    $('#pricing_code_view').val(dpcode);
    }
    else{
    $('#pricing_code').val('');
    $('#pricing_code_view').val('');
    }
    $('#message-pricing').html('');
    p_html = $('#default-pricing').html();
    while (p_html.indexOf('checked="checked"') != - 1){
    p_html = p_html.replace('checked="checked"', "");
    }

    $('#pricing').html(p_html);
    collapseAll();
    $("#payment_information_ec input").addClass('ignore');
    $("#payment_information_cc input").addClass('ignore');
    $("#e_vendor input").addClass('ignore');
    });
    function collapseAll(){
    $("#payment_information_ec").collapse('hide');
    $("#payment_information_cc").collapse('hide');
    $("#e_vendor").collapse('hide');
    }


    $('#behalf_merchants').click(function(){
    collapseEmailBehalf();
    });
    function collapseEmailBehalf(){
    obj = $('#email_behalf_cont');
    check = $('#behalf_merchants');
    inputbh = $('#email_behalf');
    if (check.prop('checked')) {
    obj.collapse('show');
    inputbh.prop('required', true);
    }
    else{
    obj.collapse('hide');
    inputbh.prop('required', false);
    }
    }


    @if (isset($data['pricing_code']) && $data['pricing_code'])
            //applyPricing($('#pricing_code').val());
            @endif

            $('.radiocheck').trigger('click');


</script>
@endsection