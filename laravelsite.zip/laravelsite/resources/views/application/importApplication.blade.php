@extends('layouts.master')
@section('title','Application')

@section('content')
    <div class="normalheader ">
        <div class="hpanel">
            <div class="panel-body">
                <a class="small-header-action" href="">
                    <div class="clip-header">
                        <i class="fa fa-arrow-up"></i>
                    </div>
                </a>
                <div>
                    <h2 class="font-light m-b-xs">
                        Import Applications
                    </h2>
                    <small>
                        <ol class="hbreadcrumb breadcrumb">
                            <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                            <li><a href="<?php echo route('application', array('token' => $token)); ?>">Applications</a></li>
                            <li class="active">
                                <span>Import Applications </span>
                            </li>

                        </ol>
                    </small>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="hpanel">
            <div class="panel-body">

                <div class="panel panel-default" style="border: none; box-shadow: none; background-color: #F4F4F4; padding: 15px">
                    <div class="panel-body" style="font-size: 12px">
                        <h4>Instructions and Requirements</h4>
                        <span>1. Please download this Excel file template: {!! link_to('/onlineapplication/batch_import_spreadsheet.xls','Batch_import_spreadsheet.xls',['target'=>'_blank']) !!} <i class="grey">(Please skip this step if you already have this spreadsheet on your computer.)</i></span>
                        <br/>
                        <span>2. After you complete this spreadsheet (properties section), save it and then use the browse button to find it on your computer.</span>
                        <br/>
                        <span>3. Required Management Company Documents <b>(only pdf and jpg) less than 12 Mb.</b></span>
                        <br/>
                        <span>4. Confirm Pricing.</span>
                        <br/>
                        <span>5. Sign on behalf of the merchants.</span>
                        <br/>
                        <span>6. Terms of Use and Privacy Policy.</span>
                        <br/>
                        <span>7. After you have chosen your files above, please click on the 'Import Properties' button to import your property applications.</span>
                        <br/>
                    </div>
                </div>


@if($errors->any())
<ul class="alert alert-danger">
    @foreach($errors->all() as $error)
    <li>{{$error}}</li>
    @endforeach
</ul>
@endif

@if(session('array_errors'))
    <ul class="alert alert-danger">
    <?php
         foreach (session('array_errors') as $a_err){
                foreach ($a_err->all() as $oerr)
                {
                    ?> <li>{{$oerr}}</li><?php
                }
    }
    ?>
</ul>
@endif
{!! Form::open(['route'=>['applicationimportstore',$token,$partner,$company],'files' => true,'method'=>'POST','id'=>'form']) !!}
@php
$atoken=decrypt($token);
@endphp
@if($atoken['level'] == 'P' || $atoken['level'] == 'B' || $atoken['level'] == 'A')
<script>
    var import_flag = true;
</script>
@include('application.partnersGroupSelects')
    <br/>
@endif

<div class="row form-group">
    <div class="col-sm-12">
        <label>Applications <span class="errorspan" id="spreadsheet_spanerror"></span></label>
        <input type="file" id="spreadsheet" name="spreadsheet" />
    </div>
</div>

<hr/>

<div class="row">
    <div class="col-sm-6">
        <div class="row form-group">
            <div class="col-sm-12">
                <label>Voided Check or Bank letter <span class="errorspan" id="voided_check_or_bank_letter_spanerror"></span></label>
                <input type="file" id="voided_check_or_bank_letter" name="vcheck" required />
            </div>
        </div>

    </div>

    <div class="col-sm-6">
        <div class="row form-group">
            <div class="col-sm-12">
                <label>Bank Statement or Balance Sheet <span class="errorspan" id="bank_statement_or_balance_sheet_spanerror"></span></label>
                <input type="file" id="bank_statement_or_balance_sheet" name="bstatement" required />
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-6">
        <div class="row form-group">
            <div class="col-sm-12">
                <label>Bank Statement or Balance Sheet <span class="errorspan" id="bank_statement_or_balance_sheet_spanerror2"></span></label>
                <input type="file" id="bsheet" name="bsheet" />
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="row form-group">
            <div class="col-sm-12">
                <label>Bank Statement or Balance Sheet <span class="errorspan" id="bank_statement_or_balance_sheet_spanerror3"></span></label>
                <input type="file" id="taxreturn" name="taxreturn" />
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-6">

    </div>
    <div class="col-sm-4 ">
        <label class="small" id="message-pricing"></label>
    </div>

</div>
<br/>
<br/>
<div class="row">
    <div class="col-sm-6">

    </div>
    <div class="col-sm-4 form-group">
        <input name="pricing_code" type="text" id="pricing_code" class="hidden">
        <div class="input-group">
            <input type="text" id="pricing_code_view" placeholder="Pricing Code" class="form-control">
            <span class="input-group-btn">
                <span class="btn btn-default btn-file" id="apply_pricing">
                    Apply
                </span>
            </span>
        </div>
    </div>
    <div class="col-sm-2 form-group">
        <div id="default-pricing" class="hidden">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Items</th>
                        <th class="text-right">Pricing</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($ps as $p)
                    <tr>
                        <td>{{ $p->description }}<br/><span class="small_text">{{ $p->toptips }}</span></td>
                        <td class="text-right">{{ $p->cost }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <button type="button" class="btn btn-default btn-block" id="btn_default_pricing">Default Pricing</button>
    </div>
</div>

<div id="pricing">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Items</th>
                <th class="text-right">Pricing</th>
            </tr>
        </thead>
        <tbody>
            @foreach($ps as $p)
            <tr>
                <td>{{ $p->description }}<br/><span class="small_text">{{ $p->toptips }}</span></td>
                <td class="text-right">{{ $p->cost }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<hr/>
<div class="row">
    <div class="col-sm-4">
        <div class="checkbox checkbox-success">
            <input id="behalf_merchants" type="checkbox" name="behalf_merchants">
            <label for="behalf_merchants">
                Signing on behalf of the merchants
            </label>
        </div>
        <div class="collapse" id="email_behalf_cont">
            <input id="email_behalf" name="email_behalf" class="form-control" placeholder="E-mail">
        </div>
    </div>
    <div class="col-sm-4">

        <div class="checkbox checkbox-success">
            <input type="checkbox" id="import_incomplete" name="import_incomplete">
            <label for="import_incomplete">
                Import Incomplete application
            </label>
        </div>
    </div>
    <div class="col-sm-4">
        <div id="term_of_use_cont"></div>
        <div class="checkbox checkbox-success">
            <input type="checkbox" required="" id="term_of_use" name="term_of_use" aria-required="true">
            <label for="term_of_use">
                I accept the <a target="_blank" href="http://www.revopay.com/revopay-service-agreement/">Terms of Use</a>
            </label>
        </div>
    </div>
</div>


<div class="hr-line-dashed"></div>
<div class="form-group">
    <a class="btn btn-default" href="<?php echo route('application', array('token'=>$token));?>">Cancel</a>
    <input id="btn-submit" class="btn btn-primary" type="submit" value="Import properties"/>
</div>

{!! Form::close() !!}

</div>
</div>
</div>

@endsection
@section('footer1')
<script src="{{ asset('js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('js/additional-methods.min.js') }}"></script>
<script>

    $(document).ready(function () {

        $.validator.addMethod('filesize', function (value, element, param) {
            return this.optional(element) || (element.files[0].size <= param)
        }, 'File size must be less than 20 mb');

        $('#form').validate({
            rules: {
                spreadsheet: {
                    required: true,
                    accept: "application/vnd.ms-excel",
                    filesize: 20000000
                },
                vcheck: {
                    required: true,
                    accept: "image/jpeg,image/jpg,application/pdf",
                    filesize: 20000000
                },
                bstatement: {
                    required: true,
                    accept: "image/jpeg,image/jpg,application/pdf",
                    filesize: 20000000
                },
                bsheet: {
                    accept: "image/jpeg,image/jpg,application/pdf",
                    filesize: 20000000
                },
                taxreturn: {
                    accept: "image/jpeg,image/jpg,application/pdf",
                    filesize: 20000000
                }
            },
            errorPlacement: function (error, element) {
                if (element.attr("name") == "spreadsheet") {
                    $("#spreadsheet_spanerror").html(error);
                }
                if (element.attr("name") == "vcheck") {
                    $("#voided_check_or_bank_letter_spanerror").html(error);
                }
                if (element.attr("name") == "bstatement") {
                    $("#bank_statement_or_balance_sheet_spanerror").html(error);
                }
                if (element.attr("name") == "bsheet") {
                    $("#bank_statement_or_balance_sheet_spanerror2").html(error);
                }
                if (element.attr("name") == "taxreturn") {
                    $("#bank_statement_or_balance_sheet_spanerror3").html(error);
                }

                if (element.attr("name") == "term_of_use") {
                    $("#term_of_use_cont").html(error);
                }

            }, submitHandler: function (form) {
                $('#loading_modal').modal('show');
                form.submit();
            },
            errorElement: "span",


        });

    });

    $('#spreadsheet').click(function () {
        $("#spreadsheet_spanerror").html('');
    });

    $('#voided_check_or_bank_letter').click(function () {
        $("#voided_check_or_bank_letter_spanerror").html('');
    });

    $('#bank_statement_or_balance_sheet').click(function () {
        $("#bank_statement_or_balance_sheet_spanerror").html('');
    });

    $('#bsheet').click(function () {
        $("#bank_statement_or_balance_sheet_spanerror2").html('');
    });

    $('#taxreturn').click(function () {
        $("#bank_statement_or_balance_sheet_spanerror3").html('');
    });

    $('#apply_pricing').click(function () {
        val = $('#pricing_code_view').val();
        if (val) {
            url = "{{ route('apppricingbycode',['code'=>'000','option'=>2]) }}";
            url = url.replace('/000/', '/' + val + '/');
            $.ajax({
                method: "GET",
                url: url
            })
                    .success(function (msg) {
                        if (msg) {
                            $('#message-pricing').html('');
                            $('#pricing').html(msg);
                            $('#pricing_code').val(val);
                        } else {
                            $('#message-pricing').html('Sorry! That pricing code does not exist. Please try again.');
                        }
                    });
        }
    });

    $('#btn_default_pricing').click(function () {
        $('#message-pricing').html('');
        $('#pricing_code').val('');
        $('#pricing_code_view').val('');
        $('#pricing').html($('#default-pricing').html());
    });

    $('#behalf_merchants').click(function () {
        collapseEmailBehalf();
    });

    function collapseEmailBehalf() {
        obj = $('#email_behalf_cont');
        check = $('#behalf_merchants');
        input = $('#email_behalf');
        if (check.prop('checked')) {
            obj.collapse('show');
            input.prop('required', true);
        } else {
            obj.collapse('hide');
            input.prop('required', false);
        }
    }

    collapseEmailBehalf();


</script>

@endsection
@if (session('success'))
@component('components.toastr',['type' => 'success','msg' => session('success')])
@endcomponent
@endif
@component('components.toastr',['type' => 'error','msg' => session('array_errors')])
