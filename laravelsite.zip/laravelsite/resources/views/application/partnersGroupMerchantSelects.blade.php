
<section>
    <h4 class="header">Admin Information</h4>
    <hr/>
    <div class="row">
        <div class="@if(isset($edit)) col-sm-4  @else col-sm-6 @endif form-group">
            <label>Applications under partner</label>
            @if(!isset($edit))
            <select required name="select_partner" data="select_companies" class="form-control select_p">
                @foreach($partners as $p)
                    <option <?php if($p->partner_name == $partner){ ?>selected<?php }?> value="{{ $p->id }}">{{ $p->partner_title }}</option>
                @endforeach
            </select>
            @else
                <br/>
                @if(isset($app_property->partner_name))
                    {{ $app_property->partner_name }}
                @endif
            @endif
        </div>
        <div class="@if(isset($edit)) col-sm-4  @else col-sm-6 @endif form-group">
            <label>Applications under group</label>
            @if(!isset($edit))
            <select required name="select_companies" class="form-control" id="select_companies"></select>
            @else
                <br/>
                @if(isset($app_property->company_name))
                {{ $app_property->company_name }}
                @endif
            @endif
        </div>
        @if(isset($edit))
        <div class="col-sm-4">
            <label>Application Status</label>

            <div class="row">
                <div class="col-sm-6 form-group">
                    <select class="form-control" id="nstatus" name="nstatus">
                        <?php if($app['status']==2 || $app['status']==-1 || $app['status']==-2){
                            $options = '
                        <option value="-2">Cancelled</option>
                        <option value="-1">Deleted</option>
                        <option value="2">Incomplete</option>';
                            $options = str_replace('value="'.$app['status'].'"','value="'.$app['status'].'" selected="selected"',$options);
                            echo $options;
                        }else{
                            $options = '
                        <option value="-2">Cancelled</option>
                        <option value="-1">Deleted</option>
                        <option value="1">Live</option>
                        <option value="2">Incomplete</option>
                        <option value="4">Pending</option>
                        <option value="5">Underwriting</option>
                        <option value="6">Approved</option>';
                            $options = str_replace('value="'.$app['status'].'"','value="'.$app['status'].'" selected="selected"',$options);
                            echo $options;
                        }?>
                    </select>
                </div>
                <div class="col-sm-6 form-group">
                    <a class="btn btn-block btn-success btn-outline" href="#" id="change_status_action"><span class="fa fa-edit"></span> Change status</a>
                </div>
            </div>
        </div>
        @endif
    </div>
    @if(isset($edit))
        <div class="row">
            <div class="col-sm-6 ">
                <label>Merchant</label>
                <div class="row">
                    <div class="col-sm-8 form-group">
                        <?php
                            if(isset($app_property->name_clients)){
                                echo $app_property->name_clients;
                            }
                            else{
                                if(isset($data['dba'])){
                                    echo $data['dba'];
                                }
                            }
                        ?>
                        <!--select id="select_merchant" class="form-control" name="merchantdb">
                            <option value="">All merchants</option>
                        </select-->
                    </div>
                    <div class="col-sm-4 form-group">
                        <!--a class="btn btn-block btn-primary" href="#" id="change_merchant_action">Link to this merchant</a-->
                    </div>
                </div>
            </div>

        </div>
    @endif
    <div class="row form-group">
        <div class="col-sm-12">
            <label>Notes</label>
            <textarea class="form-control" name="general_notes">@if(isset($data['general_notes'])){{$data['general_notes']}} @endif</textarea>
        </div>
    </div>


    <script>

        function ajax_request(p_url,id_obj_response,call_function){
            $.ajax({
                method: "GET",
                url: p_url
            })
            .success(function( msg ) {
                $('#'+id_obj_response).html(msg);
                $('#loading_layer').fadeOut();
                if(call_function){
                    setTimeout(call_function, 1);
                }
            });
        }


        $('.select_p').change(function(){
            id_ref = $(this).attr('data');
            url = "{{ route('companiesbypartner',['id_partner'=>'0']) }}";
            url = url.replace('/0','/'+$(this).val());
            $.ajax({
                method: "GET",
                url: url
            })
                    .success(function( msg ) {
                        $('#'+id_ref).html(msg);
                        refreshMerchants();
                        refresh_pricing();
                    });

        });

        $('#select_companies').change(function(){
            refreshMerchants();
            refresh_pricing();
            if($('option:selected', this).attr('data')){
                $('#email_behalf').val($('option:selected', this).attr('data'));
            }


        });

        $('#change_status_action').click(function(){
            status = $('#nstatus').val();
            <?php if(isset($edit)): ?>
            url = "{{ route('appstatus',['token'=>$token,'ida'=>$idappsession,'status'=>'000']) }}";
            url = url.replace('/000','/'+status);

            $('#loading_layer').fadeIn();
            ajax_request(url,'none',function () {
                swal({
                    title: "Success",
                    text: "The information has been saved successfully!",
                    type: "success"
                });
            });
            <?php endif; ?>
        });

        $('#change_merchant_action').click(function(){
            partner = $('.select_p').val();
            company = $('#select_companies').val();
            merchant = $('#select_merchant').val();
            <?php if(isset($edit)): ?>
            url = "{{ route('appmerchant',['token'=>$token,'ida'=>$app_property->id,'partner'=>'PARTNER','company'=>'COMPANY','merchant'=>'MERCHANT']) }}";
            url = url.replace('PARTNER',partner);
            url = url.replace('COMPANY',company);
            url = url.replace('MERCHANT',merchant);
            if(merchant){
                $('#loading_layer').fadeIn();
                ajax_request(url,'none');
            }
            <?php endif; ?>
        });

        function refresh_pricing(){

            pricing_code = $('#pricing_code').val();
            if(!pricing_code) {

            @if (isset($data['pricing_code']) && $data['pricing_code'])
            @else
            id_partner = $('.select_p').val();
            id_company = $('#select_companies').val();
            if(import_flag)
                url = "{{ route('apppricing',['token'=>$token,'partner'=>'000','company'=>'111','option'=>1,'ida'=>-1]) }}";
            else
                url = "{{ route('apppricing',['token'=>$token,'partner'=>'000','company'=>'111','option'=>2,'ida'=>-1]) }}";
            url = url.replace('/000/','/'+id_partner+'/');
            url = url.replace('/111/','/'+id_company+'/');
            <?php if(isset($edit)): ?>
            url = url.replace('/-1/','/'+{{$app_property->id}}+'/');            
            <?php endif; ?>            
            if(id_partner){
                $.ajax({
                    method: "GET",
                    url: url
                })
                        .success(function( msg ) {
                            $('#pricing').html(msg);
                            $('#default-pricing').html(msg);
                            $('.radiocheck').trigger('click');
                        });
            }
            @endif
             }
        }

        function refreshMerchants(){
            id_company = $('#select_companies').val();
            if(id_company){
                url = "{{ route('merchantsbycompany',['id_company'=>'0']) }}";
                url = url.replace('/0','/'+id_company);
                ajax_request(url,'select_merchant');
            }
        }


        id_partner = $( ".select_p option:selected").val();
        url = "{{ route('companiesbypartner',['id_partner'=>'0']) }}";
        url = url.replace('/0','/'+id_partner);
        $.ajax({
            method: "GET",
            url: url
        })
                .success(function( msg ) {
                    $('#select_companies').html(msg);
                    refresh_pricing();
                    refreshMerchants();
                    if($('option:selected', $('#select_companies')).attr('data')){
                        $('#email_behalf').val($('option:selected', $('#select_companies')).attr('data'));
                    }
                });
    </script>

</section>