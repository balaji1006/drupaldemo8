@extends('layouts.master')
@section('title','Application')

@section('content')
<div id="content-register" class="text-center">
    <h1>Online Application</h1>
    <h4></h4>
    <div class="row">
        <div class="col-xs-12 text-center">
            <div class="alert alert-success">
                Your data has been saved successfully. We sent an email to continue the process
            </div>
        </div>
    </div>
</div>
@endsection

