@extends('layouts.master')
@section('title','Application')

@section('content')
@if($errors->any())
<ul class="alert alert-danger">
    @foreach($errors->all() as $error)
    <li>{{$error}}</li>
    @endforeach
</ul>
@endif

<div class="normalheader ">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>


            <h2 class="font-light m-b-xs">
                View Application
            </h2>
            <small>
                <ol class="hbreadcrumb breadcrumb">
                    <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                    <li><a href="<?php echo route('application', array('token' => $token)); ?>">Applications</a></li>
                    <li class="active">
                        <span>View Application</span>
                    </li>

                </ol>
            </small>

        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">
        <div class="panel-body">
        <section>
            <!--            <form>-->
            <div>
                <h4 >Information</h4>
                <hr>
                <div>
                    <div class="row form-group">
                        <div class="col-sm-3">
                            <label style="">Title :</label>
                            <br/>
                            {{ $data['ttname'] }}
                        </div>
                        <div class="col-sm-9">
                            <label style="">Contact Name :</label>
                            <br/>
                            {{ $data['pname'] }}
                        </div>

                    </div>

                    <div class="row form-group">
                        <div class="col-sm-3">
                            <label style="">Contact Address</label>
                            <br/>
                            {{ $data['cadr1'] }}
                        </div>
                        <div class="col-sm-3">
                            <label style="">Suite/Apt</label>
                            <br/>
                            <?php if (isset($data['cadr1_apt'])) echo $data['cadr1_apt'] ?>
                        </div>
                        <div class="col-sm-2">
                            <label style="">Contact City</label>
                            <br/>
                            {{ $data['ccty1'] }}
                        </div>
                        <div class="col-sm-2">
                            <label style="">Contact State</label>
                            <br/>
                            <?php echo strtoupper($data['cstate1']) ?>

                        </div>
                        <div class="col-sm-2">
                            <label style="">Zip Code </label>
                            <br/>
                            {{ $data['czip1'] }}
                        </div>

                    </div>

                    <div class="row form-group">
                        <div class="col-sm-3">
                            <label style="">Contact Phone </label>
                            <br/>
                            {{ $data['pphone'] }}
                        </div>
                        <div class="col-sm-3">
                            <label style="">Title or Position </label>
                            <br/>
                            {{ $data['title'] }}
                        </div>
                        <div class="col-sm-3">
                            <label style="">Contact Email </label>
                            <br/>
                            {{ $data['email'] }}
                        </div>
                        <div class="col-sm-3">
                            <label style="">SSN </label>
                            <br/>
                            {{ $data['ssn'] }}
                        </div>
                    </div>
                </div>
            </div>

        </section>
        <section>
            <div>
                <br/><h4>Business Information</h4>
                <hr>
                <div>
                    <div class="row form-group">
                        <div class="col-sm-4">
                            <label style="">Business ID</label>
                            <br/>
                            @if(isset($data['ppid'])){{ $data['ppid'] }}@endif
                        </div>
                        <div class="col-sm-4">
                            <label style="">Corporate Legal Name </label>
                            <br/>
                            {{ $data['legal'] }}
                        </div>
                        <div class="col-sm-4">
                            <label style="">DBA Name </label>
                            <br/>
                            {{ $data['dba'] }}
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-sm-4">
                            <label style="">Address </label>
                            <br/>
                            {{ $data['adr1'] }}
                        </div>
                        <div class="col-sm-2">
                            <label style="">Suite/Apt</label>
                            <br/>
                            @if(isset($data['adr1_apt'])){{ $data['adr1_apt'] }}@endif
                        </div>
                        <div class="col-sm-2">
                            <label style="">City </label>
                            <br/>
                            {{ $data['cty1'] }}
                        </div>
                        <div class="col-sm-2">
                            <label style="">State </label>
                            <br/>
                            {{ $data['state1'] }}
                        </div>
                        <div class="col-sm-2">
                            <label style="">Zip Code </label>
                            <br/>
                            {{ $data['zip1'] }}
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-sm-4">
                            <label style="">Phone </label>
                            <br/>
                            {{ $data['phone1'] }}
                        </div>
                        <div class="col-sm-4">
                            <label style="">Business Description </label>
                            <br/>
                            {{ $data['bdesc'] }}
                        </div>
                        <div class="col-sm-4">
                            <label style="">Business Structure</label>
                            <br/>
                            
                                <?php
                                switch ($data['bstruct']) {
                                    case 1:
                                        echo 'SoleProprietor';
                                        break;
                                    case 2:
                                        echo 'Partnership';
                                        break;
                                    case 3:
                                        echo 'LLP';
                                        break;
                                    case 4:
                                        echo 'Corporation';
                                        break;
                                    case 5:
                                        echo 'LLC';
                                        break;
                                    case 6:
                                        echo 'SCorporation';
                                        break;
                                    case 7:
                                        echo 'NonProfit';
                                        break;
                                    case 8:
                                        echo 'Government';
                                        break;
                                    case 9:
                                        echo 'Other';
                                        break;
                                }
                                ?>
                            

                        </div>

                    </div>

                    <div class="row form-group">
                        <div class="col-sm-4">
                            <label style="">Date formed </label>
                            <br/>
                            {{ $data['date'] }}
                        </div>
                        <div class="col-sm-4">
                            <label style="">Current Ownership Date</label>
                            <br/>
                            {{ $data['cdate'] }}
                        </div>
                        <div class="col-sm-4">
                            <label style="">Federal Tax ID </label>
                            <br/>
                            {{ $data['fti'] }}
                        </div>

                    </div>

                    <div class="row form-group">
                        <div class="col-sm-3">
                            <label style="">Billing Address </label>
                            <br/>
                            {{ $data['adr2'] }}
                        </div>
                        <div class="col-sm-3">
                            <label style="">Suite/Apt</label>
                            <br/>
                            @if(isset($data['adr2_apt'])){{ $data['adr2_apt'] }}@endif
                        </div>
                        <div class="col-sm-2">
                            <label style="">City </label>
                            <br/>
                            {{ $data['cty2'] }}
                        </div>
                        <div class="col-sm-2">
                            <label style="">State </label>
                            <br/>
                            {{ $data['state2'] }}
                        </div>
                        <div class="col-sm-2">
                            <label style="">Zip Code </label>
                            <br/>
                            {{ $data['zip2'] }}
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-sm-4">
                            <label style="">Frequency of scheduled payments</label>
                            <br/>
                            {{ $data['freq'] }}
                        </div>
                        <div class="col-sm-4">
                            <label style="">Donor </label>
                            <br/>
                            @if(isset($data['donor'])){{ $data['donor'] }}@endif
                        </div>
                        <div class="col-sm-4">
                            <label style="">Payment due on what day of the month </label>
                            <br/>

                                <?php
                                $p = 'th';
                                switch ($data['duedate']) {
                                    case 1:
                                        $p = 'st';
                                        break;
                                    case 2:
                                        $p = 'nd';
                                        break;
                                    case 3:
                                        $p = 'rd';
                                        break;
                                }
                                if ($data['duedate'] == 1) {

                                }
                                echo $data['duedate'] . $p . ' day of the Month';
                                ?>



                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div>
                <br/><h4>Banking Information</h4>
                <hr/>
                <div>
                    <div class="row form-group">
                        <div class="col-sm-3">
                            <label style=";">Name on Deposit Bank Account </label>
                            <br/>
                            {{ $data['bankname'] }}
                        </div>
                        <div class="col-sm-3">
                            <label  style=";">Deposit ABA Routing Number </label>
                            <br/>
                            {{ $data['bankrouting'] }}
                        </div>
                        <div class="col-sm-3">
                            <label  style=";">Deposit Bank Account Number </label>
                            <br/>
                            {{ $data['banknumber'] }}
                        </div>
                        <div class="col-sm-3">
                            <label  style=";">Account Type</label>
                            <br/>

                                <?php
                                switch ($data['banktype']) {
                                    case 0:
                                        echo 'Checking';
                                        break;
                                    case 1:
                                        echo 'Savings';
                                        break;
                                }
                                ?>

                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-sm-3">
                            <label  style=";">Name on Return Account </label>
                            <br/>
                            {{ $data['bankname_re'] }}
                        </div>
                        <div class="col-sm-3">
                            <label  style=";">ABA Routing Number </label>
                            <br/>
                            {{ $data['bankrouting_re'] }}
                        </div>
                        <div class="col-sm-3">
                            <label  style=";"> Return Account Number </label>
                            <br/>
                            {{ $data['banknumber_re'] }}
                        </div>
                        <div class="col-sm-3">
                            <label  style=";">Account Type</label>
                            <br/>

                                <?php
                                switch ($data['banktype_re']) {
                                    case 0:
                                        echo 'Checking';
                                        break;
                                    case 1:
                                        echo 'Savings';
                                        break;
                                }
                                ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div>
                <br/><h4>Required Documents</h4>
                <hr/>
                <div>
                    <div class="row">
                        @if(isset($data['vcheck']) && $data['vcheck']!='')
                        <div class="col-sm-6">
                            <div class="row form-group">
                                <div class="col-sm-12">
                                    <label  style=";">Voided Check or Bank letter  <span class="errorspan" id="vcheck_spanerror"></span></label>
                                    <br/>
                                    {!! link_to('/uploads/onlineapplication/create/'.$data['vcheck'],'Voided Check or Bank letter',['target'=>'_blank']) !!} <input type="hidden" name="vcheck_saved" value="{{$data['vcheck']}}"/>
                                </div>
                            </div>
                        </div>
                        @endif
                        @if(isset($data['bstatement']) && $data['bstatement']!='')
                        <div class="col-sm-6">
                            <div class="row form-group">
                                <div class="col-sm-12">
                                    <label  style=";">1st Bank Statement or Balance Sheet  <span class="errorspan" id="bstatement_spanerror"></span></label>
                                    <br/>
                                    {!! link_to('/uploads/onlineapplication/create/'.$data['bstatement'],'1st Bank Statement or Balance Sheet',['target'=>'_blank']) !!} <input type="hidden" name="bstatement_saved" value="{{$data['bstatement']}}"/>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>

                    <div class="row">
                        @if(isset($data['bsheet']) && $data['bsheet']!='')
                        <div class="col-sm-6">
                            <div class="row form-group">
                                <div class="col-sm-12">
                                    <label  style=";">2nd Bank Statement or Balance Sheet</label>
                                    {!! link_to('/uploads/onlineapplication/create/'.$data['bsheet'],'2nd Bank Statement or Balance Sheet',['target'=>'_blank']) !!}
                                </div>
                            </div>
                        </div>
                        @endif
                        @if(isset($data['taxreturn']) && $data['taxreturn']!='')
                        <div class="col-sm-6">
                            <div class="row form-group">
                                <div class="col-sm-12">
                                    <label  style=";">3rd Bank Statement or Balance Sheet</label>
                                    {!! link_to('/uploads/onlineapplication/create/'.$data['taxreturn'],'3rd Bank Statement or Balance Sheet',['target'=>'_blank']) !!}
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>

                    <div class="row">
                        @if(isset($data['driver']) && $data['driver']!='')
                        <div class="col-sm-6">
                            <div class="row form-group">
                                <div class="col-sm-12">
                                    <label  style=";">Driver License</label>
                                    {!! link_to('/uploads/onlineapplication/create/'.$data['driver'],'Driver License',['target'=>'_blank']) !!}
                                </div>
                            </div>
                        </div>
                        @endif
                        @if(isset($data['ccstatement']) && $data['ccstatement']!='')
                        <div class="col-sm-6">
                            <div class="row form-group">
                                <div class="col-sm-12">
                                    <label  style=";">CC Statement</label>
                                    {!! link_to('/uploads/onlineapplication/create/'.$data['ccstatement'],'CC Statement',['target'=>'_blank']) !!}
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div>
                <br/><h4>Pricing and Services</h4>
                <hr/>
                <div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Items</th>
                                <th></th>
                                <th class="text-right">Pricing</th>
                            </tr>
                        </thead>
                        <tbody>

                            @foreach($ps as $p)

                            <tr>
                                <td>{{ $p->description }}<br/><span class="small_text">{{ $p->toptips }}</span></td>
                                <td> @if( isset($data['array_service']['check_service'.$p->id_p]) ) X @endif</td>
                                <td class="text-right">{{ $p->cost }}</td>
                            </tr>

                            @endforeach
                        </tbody>
                    </table>

                    <div class="collapse" id="payment_information_ec">
                        <p><b>Payment information for eCheck (Whole numbers only. No punctuation.)</b></p>
                        <div class="row form-group">
                            <div class="col-sm-6">
                                <label  style=";">What is the largest payment you will ever process?</label>
                                <br/>
                                {{ $data['hticket'] }}
                            </div>
                            <div class="col-sm-6">
                                <label  style=";">How many payments will your process per day?</label>
                                <br/>
                                {{ $data['cticket'] }}
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-sm-6">
                                <label  style=";">How many payments will your process per month?</label>
                                <br/>
                                {{ $data['avticket'] }}

                            </div>
                            <div class="col-sm-6">
                                <label  style=";">What is your estimated monthly volume?</label>
                                <br/>
                                {{ $data['mticket'] }}
                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="payment_information_cc">
                        <p><b>Payment information for Credit Card (Whole numbers only. No punctuation.)</b></p>
                        <div class="row form-group">
                            <div class="col-sm-6">
                                <label  style=";">What is the largest payment you will ever process?</label>
                                <br/>
                                {{ $data['cchticket'] }}
                            </div>
                            <div class="col-sm-6">
                                <label  style=";">What is your estimated monthly volume?</label>
                                <br/>
                                {{ $data['ccmticket'] }}
                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="e_vendor">
                        <p><b>E-Vendor (Please complete the section below if you have selected this service)</b></p>
                        <div class="row form-group">
                            <div class="col-sm-6">
                                <label  style=";">What is the largest outbound transaction you will ever process?</label>
                                <br/>
                                {{ $data['vhticket'] }}
                            </div>
                            <div class="col-sm-6">
                                <label  style=";">How many outbound transactions will your process per day?</label>
                                <br/>
                                {{ $data['vcticket'] }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="hr-line-dashed"></div>
           <a class="btn btn-default" href="{{ route('application', array('token'=>$token)) }}">Go back to Application List</a>
        </section>

        <input name="action" class="hidden" id="form-action-input">
        {!! Form::close() !!}
    </div>
</div>
</div>
@endsection
@section('footers')
<script>

    array_echeck = [10, 11, 4, 5, 6, 7, 8, 9, 16, 32];
    array_ccard = [3, 31, 10, 12, 19, 20];
    array_evendor = [18, 22, 24, 30];

    checks = $('.pricing_services_check');
    radios = $('.pricing_services_radio');



    function checkAction(obj) {
        if ($(obj).prop('checked')) {
            data = parseInt($(obj).attr('data'));
            pos_array_echeck = array_echeck.indexOf(data);
            pos_array_ccard = array_ccard.indexOf(data);
            pos_array_evendor = array_evendor.indexOf(data);
            if (pos_array_echeck > -1) {
                $("#payment_information_ec").collapse('show');
            } else if (pos_array_ccard > -1) {
                $("#payment_information_cc").collapse('show');
            } else if (pos_array_evendor > -1) {
                $("#e_vendor").collapse('show');
            }

        } else {
            data = parseInt($(obj).attr('data'));
            pos_array_echeck = array_echeck.indexOf(data);
            pos_array_ccard = array_ccard.indexOf(data);
            pos_array_evendor = array_evendor.indexOf(data);

            if (pos_array_echeck > -1) {
                checked = false;
                checks.each(function () {
                    if (array_echeck.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).prop('checked')) {
                        checked = true;
                    }
                });
                if (!checked)
                    $("#payment_information_ec").collapse('hide');
            } else if (pos_array_ccard > -1) {
                checked = false;
                checks.each(function () {
                    if (array_ccard.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).prop('checked')) {
                        checked = true;
                    }
                });
                if (!checked)
                    $("#payment_information_cc").collapse('hide');
            } else if (pos_array_evendor > -1) {
                checked = false;
                checks.each(function () {
                    if (array_evendor.indexOf(parseInt($(this).attr('data'))) > -1 && $(this).prop('checked')) {
                        checked = true;
                    }
                });
                if (!checked)
                    $("#e_vendor").collapse('hide');
            }

        }
    }

    function radioAction(obj) {
        data = parseInt($(obj).attr('data'));
        pos_array_echeck = array_echeck.indexOf(data);
        pos_array_ccard = array_ccard.indexOf(data);
        pos_array_evendor = array_evendor.indexOf(data);
        if (pos_array_echeck > -1) {
            $("#payment_information_ec").collapse('show');
        } else if (pos_array_ccard > -1) {
            $("#payment_information_cc").collapse('show');
        } else if (pos_array_evendor > -1) {
            $("#e_vendor").collapse('show');
        }
    }

    checks.each(function () {
        if ($(this).prop('checked')) {
            checkAction(this);
        }
    });

    radios.each(function () {
        if ($(this).prop('checked')) {
            radioAction(this);
        }
    });



</script>

@endsection