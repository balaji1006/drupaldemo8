<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <style>
            body {
                font-family: 'Arial';
                font-size: 9px;
            }

            .underline{
                text-decoration: underline;
            }
            @page {
                margin-top: 1em;
                margin-left: 1em;
                margin-bottom: 1em;
                margin-right: 1em;
            }

            hr{
                border-top: transparent;
                border-left: transparent;
                border-right: transparent;
                border-bottom: solid 1px #cccccc;
                margin-bottom: 20px;
            }

            table .head td{
                background-color: #EEEEEE;
                border-bottom: solid 1px #cccccc;
                font-weight: bold;
            }

            .small_text
            {
                font-size: 8px;
            }

            .text-right{
                text-align: right;
            }
            .text-center{
                text-align: center;
            }

            .p{
                margin: 0;
                font-size: 7px;
                text-align: justify;
            }

            .black{
                background-color: #000000;
                color: #ffffff;
                border: solid 1px #000000;
            }

            div.endpage {
                page-break-after: always;
                border-style: solid;
                border-width: 1px;
                border-color: #ffffff;

            }

        </style>
    </head>
    <body>

        <table cellpadding="4px" style="width: 100%; font-size: 8px">
            <tr>
                <td style="width: 50%; text-align: justify; vertical-align: top">
                    <b>1.SOFTWARE PRODUCT AND PAYMENT SERVICES</b><br/>
                    <span class="underline">Software Product.</span> Is the Revo Payments Page and supporting software comprised of the
                    following components: (i) the HTML and core file components, (ii) Database Scripts, (iii)
                    Database Schema, (iv) Database Stored Procedures, (v) Image Files, (vi) Documentation,
                    (vii) "Online" Documentation, (viii) and any other associated files or any media. The primary
                    business purpose of the Software Product is to present a payment platform for Customer to
                    accept Electronic Payments from Payors or make outbound payments to Payees. The
                    Software Product is also marketed under the name of Paago Invoice, Revo Non-Profit, Revo
                    Academic, Revo Utilities, or other industry-specific brands.<br/>
                    <span class="underline">Payment and eInvoicing Services</span> �Electronic Payments� or �Payment Services� includes
                    the acceptance of any form of non-cash payment, including but not limited to: electronic
                    checks/ACH, credit/debit card payments, paypal, billmelater, or any other non-cash payment,
                    where payments are made by any possible channel or means, including but not limited to inperson,
                    online, phone, fax, mobile device, or other mode of payment. �Electronic Invoicing�
                    consists of sending a bill through any non-paper channels, our software allows for invoices to
                    be created and sent out via email and received on all electronic platforms.<br/>
                    <span class="underline">Limited License Grant.</span> The Software Product is licensed for use only and is not sold to
                    Customer. REVO hereby grants, and Customer accepts, a non-exclusive, non-assignable,
                    non-transferable, non-sub-licensable, limited license to use the Software Product only as
                    approved herein by REVO. The license grant may be terminated at any time by REVO. The
                    license grant is conditioned upon Customer�s timely payment of the applicable fees and
                    strict abidance by this Agreement. Customer may use the Software Product and Payment
                    Services only subject to the terms and conditions contained herein, and any use shall always
                    remain subject to this Agreement. The License Grant extends only to Licensee and shall not
                    be loaned, assigned, sold, sublicensed, or otherwise made available to or used by any thirdparty.<br/>
                    <span class="underline">Software Restrictions.</span>Customer shall (i) not attempt to reverse engineer, decompile,
                    disassemble, or attempt to derive the source code of the Software Product or any portion
                    thereof, or otherwise derive its source code; (ii) not modify, port, translate, localize or create
                    derivative works of the Software Product; (iii) not disclose the results of any performance
                    tests or qualitative analysis on the Software Products(s) to any third party without the prior
                    written consent of REVO; (iv) not use the Software Product in a way that (a) infringes on the
                    intellectual property rights of any third party or any rights of publicity or privacy; (b) violates
                    any law, statute, ordinance or regulation (including but not limited to the laws and regulations
                    governing export/import control, unfair competition, anti-discrimination and/or false
                    advertising); (c) is defamatory, trade libelous, unlawfully threatening, or unlawfully harassing;
                    (d) is obscene, pornographic or indecent in violation of applicable law; or (e) to propagate
                    any virus, worms, Trojan horses or other programming routine intended to damage any
                    system or data.<br/>
                    <span class="underline">Pricing and Fees</span> Depending on the choice of the customer, Transaction Fees can either be
                    paid by the customer or passed on to the payors. Any fee that is not a direct transaction cost
                    that is depicted in Schedule A must be paid by the Customer. Payors who desire to initiate
                    Online Payments to Customer by Electronic Payment through the Software agree to the fees
                    listed in Schedule of Fees attached hereto and where such fees are disclosed in the software
                    and Payor agrees to those fees in the payment process. Customer is responsible for
                    disclosing all Revo fees to Payor. In the event Payor fails to pay fees due to Revo, Customer
                    agrees to reimburse Revo for unpaid Payor fees and any disputed transaction amount<br/>
                    <span class="underline">Payor Information.</span> Customer shall provide REVO such information as REVO may require in
                    order to promptly and accurately perform the Payment Services contemplated by this
                    Agreement. Upon execution of this Agreement, if Customer desires to enable a roster or
                    other list of authorized Payors, Customer shall supply REVO with an electronic document
                    containing Payor information required by REVO to setup and manage the Software and
                    Payment Services. REVO shall in no event be liable for not being provided by Customer with
                    current and correct information. REVO will not be responsible for unauthorized use of
                    Payor�s credit card or credit card information by Customer, Customer�s employees, or any
                    other party associated with Customer as a vendor, consultant, or contractor, including but not
                    limited to Payor�s name, billing address, credit card number, and credit card expiration date.<br/>
                    <span class="underline">Payor/Customer Disputes and Chargebacks</span> REVO follows the payment instructions
                    authorized by Customer in this Agreement and authorized by Payors when using the
                    Software and Payment Services. Customer shall indemnify and hold REVO harmless from
                    disputes between Customer and Payors, including but not limited to returned payments,
                    disputed payments, NSFs, inaccurate Payor bank account information, or any other Payor
                    attempt to dispute or reverse a payment regardless of payment type (i.e. credit card or ACH).
                    REVO will provide commercially reasonable efforts to have chargebacks investigated
                    following the initial deduction from Customer�s bank account. Customer will ultimately be
                    solely liable for all chargeback liability derived from Online Payments processed by REVO,
                    including Chargeback Recovery Fees listed in Schedule of Fees.<br/>
                    <span class="underline">Modification of Software and Payment Services.</span> REVO may, and reserves the right to,
                    modify the features and functionality of the Software and Payment Services, at any time and
                    without notice; provided, however, that REVO will not modify the Software or Payment
                    Services in a manner that would, in its sole discretion, significantly adversely affect the use
                    thereof, without providing at least ten (10) days prior notice to Customer of such modification.<br/>
                    <span class="underline">Cooperation Regarding Payor Adoption.</span> Customer agrees to support all reasonable efforts
                    requested by REVO to encourage and improve the use of the Software and Payment
                    Services by Payors.<br/>
                    <span class="underline">Payment for Services and Fees</span> Customer agrees to pay REVO the Fees as defined and set
                    forth in the Schedule of Fees attached to this Agreement. REVO reserves the right to modify
                    all fees, subject to 90 days notice to Customer. If Customer rejects any fee increase,
                    Customer is permitted to cancel this Agreement without penalty.<br/><br/><br/>
                    <b>2.IP RIGHTS AND CONFIDENTIALITY</b><br/>
                    <span class="underline">Intellectual Property.</span> All intellectual property rights in and to the Software Product or
                    Payment Services shall remain the exclusive property of REVO (and/or its suppliers if
                    applicable). Customer or Payors shall have no right in or to the Software Product or Payment
                    Services except as expressly set forth in this Agreement. Intellectual property includes, but is
                    not limited to, patents, inventions, invention disclosures, Marks (as defined below), trade
                    secrets, know-how, formulae and processes, software programs, proprietary data and.
                </td>
                <td style="width: 50%; text-align: justify; vertical-align: top">
                    databases, copyrights and all other similar items of intellectual property, whether registered or
                    unregistered, including any rights created thereof, all proceeds thereto, and the right to sue for
                    past, present and future infringements. All rights not expressly granted hereunder by REVO
                    are reserved for REVO (and/or its suppliers if applicable). REVO retains the rights in and title
                    to its respective trade names, trademarks, service marks, logos, domain names and other
                    branding elements and identifiers (the "Marks"), and any other intellectual property previously
                    or generally developed by REVO or its affiliates. Customer shall not copy, use, display,
                    distribute or transfer the Marks or other Intellectual Property of REVO, except as expressly
                    provided by this Agreement<br/>

                    <span class="underline">Modifications to Intellectual Property.</span> Modifications to the Software Product or Payment
                    Services is prohibited except by express written consent of REVO. Any changes or
                    modifications that may occur (whether permitted or not), including adjustments,
                    customizations, or integrations, shall be deemed "works for hire" and are deemed and agreed
                    to be the exclusive intellectual property of REVO.
                    <br/>
                    <span class="underline">Confidentiality and Non-Disclosure.</span> Each party agrees to keep confidential and to use only for
                    purposes of performing under this Agreement, any proprietary or confidential information of
                    the other party disclosed pursuant to this Agreement which is appropriately marked as
                    confidential or which could reasonably be considered of a proprietary or confidential nature
                    ("Confidential Information"), and, except as otherwise permitted by this Agreement, the terms
                    of this Agreement and all negotiations relating thereto (but not the existence of this Agreement
                    generally). The obligation of confidentiality does not apply to information which is publicly
                    available through authorized disclosure, is known by the receiving party at the time of
                    disclosure, is rightfully obtained from a third party who has the right to disclose it, or which is
                    required by law to be disclosed. All Confidential Information will remain the property of the
                    disclosing party and shall be returned to the disclosing party upon request or upon termination
                    of this Agreement.<br/><br/><br/><br/>
                    <b>3.DISCLAIMER OF WARRANTIES</b><br/>
                    NO WARRANTIES AND GENERAL DISCLAIMER. REVO MAKES NO WARRANTY OF ANY
                    KIND, WHETHER EXPRESSED OR IMPLIED, WRITTEN OR ORAL, EXCEPT AS
                    EXPRESSLY STATED HEREIN. ADDITIONALLY, REVO DISCLAIMS ALL OTHER
                    WARRANTIES, EXPRESS AND IMPLIED, INCLUDING WITHOUT LIMITATION, THE
                    IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
                    PURPOSE AND FREEDOM FROM INFRINGEMENT WITH RESPECT TO ALL SOFTWARE
                    PRODUCTS, PAYMENT SERVICES, UPDATES, UPGRADES, NEW RELEASES AND ALL
                    OTHER PRODUCTS, SERVICES, MATERIALS AND OTHER ITEMS FURNISHED UNDER,
                    OR IN CONNECTION WITH, THIS AGREEMENT. PROPERTY MANAGER
                    ACKNOWLEDGES THAT ITS USE OF THE SOFTWARE AND PAYMENT SERVICES IS
                    SUBJECT TO AND CONDITIONED UPON ACCEPTANCE OF THIS DISCLAIMER
                    <br/>
                    <span class="underline"> Software Product Limited Warranty.</span> REVO warrants that the Licensed Product(s) will conform
                    substantially in accordance with its documentation and stated purpose. If REVO confirms a
                    defect in the unaltered Software Product, REVO will use commercially reasonable efforts to
                    remedy the nonconformance. REVO does not warrant that the operation or utilization of any
                    Software Product or Payment Service will be uninterrupted or error free, nor does it guarantee
                    that its remedial efforts will correct any nonconformance. If Software Product or Payment
                    Service fails to comply with any warranty set forth in this Section and REVO does not remedy
                    such failure as required by this Agreement, REVO�s obligation and liability, and Customer�s
                    exclusive remedy, for such failure shall be limited to written termination of this Agreement, in
                    which event this Agreement shall terminate. Customer shall not be entitled to fees related to
                    Payment Services or any other damages or costs under any circumstances. You expressly
                    recognize and acknowledge that such limitation of liability is an essential part of this
                    Agreement and is an essential factor in establishing the price of the Software Product and
                    Services. THIS SHALL BE YOUR SOLE AND EXCLUSIVE REMEDY FOR ANY BREACH OF
                    WARRANTY OR BREACH OF THIS AGREEMENT.<br/>
                    <span class="underline">WORLD WIDE WEB, INTERNET AND TELEPHONE USAGE.</span> REVO AND ITS SUPPLIERS
                    MAKE NO WARRANTIES REGARDING THE QUALITY, RELIABILITY, TIMELINESS OR
                    SECURITY OF THE WORLD WIDE WEB OR TELEPHONE LINES, THE INTERNET OR THE
                    WEBSITES ESTABLISHED THEREON INCLUDING THE SOFTWARE OR PAYMENT
                    SERVICES RELIANCE ON THE INTERNET.<br/>
                    <span class="underline">DATA CONTENT DISCLAIMER</span> YOU EXPRESSLY RECOGNIZE THAT REVO DOES NOT
                    CREATE, OPERATE, CONTROL OR ENDORSE ANY DATA OR THIRD PARTY PAYMENT
                    SERVICES, INFORMATION, THIRD-PARTY PRODUCTS, PROCESSED BY THE
                    SOFTWARE PRODUCTS OR SERVICES PROVIDED VIA ANY SOFTWARE PRODUCTS
                    HEREUNDER, INCLUDING BUT NOT LIMITED TO, INFORMATION OBTAINED AS PART
                    OF PROVIDING THE SOFTWARE AND PAYMENT SERVICES. REVO DISCLAIMS ALL
                    WARRANTIES AND SHALL NOT BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY
                    COST OR DAMAGE ARISING, EITHER DIRECTLY OR INDIRECTLY, FROM ANY LOSS OF
                    DATA OR OTHERWISE.<br/><br/><br/><br/>
                    <b>4.LIMITATION OF LIABILITY</b>
                    <span class="underline">EXCLUSION OF DAMAGES.</span> REVO SHALL NOT BE LIABLE FOR DAMAGES RESULTING
                    FROM LOSS OF DATA, LOST PROFITS, BUSINESS INTERRUPTION, LOST REVENUE,
                    OR LOST BUSINESS, IN CONNECTION WITH THE SOFTWARE PRODUCT OR PAYMENT
                    SERVICE, NOR FOR COSTS OF PROCUREMENT OF SUBSTITUTE GOODS, NOR FOR
                    ANY SPECIAL, INDIRECT, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT
                    OF, OR IN CONNECTION WITH, THIS AGREEMENT, WHETHER IN BREACH OF
                    WARRANTY, CONTRACT, TORT, STRICT LIABILITY OR OTHERWISE (INCLUDING
                    NEGLIGENCE), EVEN IF REVO HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
                    DAMAGES.<br/>
                    <span class="underline">NO CONSEQUENTIAL DAMAGES</span> IN NO EVENT WILL REVO, OR ITS SUPPLIERS, BE
                    LIABLE TO CUSTOMER, OR TO ANY THIRD PARTY, FOR CONSEQUENTIAL,
                    EXEMPLARY, INDIRECT, SPECIAL OR INCIDENTAL DAMAGES, INCLUDING, WITHOUT
                    LIMITATION, LOST PROFITS, EVEN IF THE REVO HAS BEEN ADVISED OF THE
                    POSSIBILITY OF SUCH DAMAGES<br/>
                    <span class="underline">FORCE MAJEURE.</span> REVO WILL NOT BE RESPONSIBLE FOR ANY DELAYS, ERRORS,
                    FAILURES TO PERFORM, INTERRUPTIONS OR DISRUPTIONS IN THE SOFTWARE OR
                    PAYMENT SERVICES RESULTING FROM ANY ACT, OMISSION OR CONDITION

                </td>
            </tr>
            <tr>
                <td style="width: 50%; text-align: justify; vertical-align: top">
                    <b>BEYOND REVO�S REASONABLE CONTROL, WHETHER OR NOT FORESEEABLE OR
                        IDENTIFIED.</b><br/>
                    <span class="underline">INDEMNIFICATION.</span> EXCEPT AS OTHERWISE PROVIDED IN THIS AGREEMENT,
                    CUSTOMER SHALL DEFEND, INDEMNIFY, AND HOLD HARMLESS, REVO FOR ANY
                    CLAIMS BROUGHT BY PAYORS OR ANY OTHER THIRD PARTY BASED ON THE
                    PRODUCT OR PAYMENT SERVICES.<br/><br/><br/>
                    <b>5.TERM AND TERMINATION</b>
                    <!--
                    Agreement Term The term of this agreement is for three (3) years from the date that this
                    Agreement is executed (�Effective Date�) by the Customer. The Effective Date is upon
                    execution of this Agreement; regardless of when Customer actually begins accepting
                    electronic payments. The agreement shall automatically renew for successive two year terms
                    unless cancelled in writing at least 30 days prior to the renewal date.--> <br/>
                    <span class="underline">Fee Increase Right of Cancellation.</span> REVO may increase or otherwise change its Fees at any
                    time, subject to 90 day notice to Customer. Customer may cancel this Agreement without
                    penalty if REVO notifies Customer of a fee increase, and Customer does not accept that Fee
                    increase. Cancellation must be sent via email to support@revopayments.com. If Customer
                    does not cancel within 90 days of notice of a Fee increase or change, Customers continued
                    use of the system shall constitute acceptance of the new Fees.<br/>
                    <span class="underline">Breach, Cure, and Termination</span> Either party may terminate this Agreement in the event of an uncured breach of a
                    material clause of this Agreement. If a party determines that a breach has occurred then
                    written notice of such breach, including sufficient detail to allow the breaching party to effect a
                    cure, shall be provided to the breaching party. If the breach has not been cured within 30 days
                    of written notice (the "cure period"), then the notifying party shall be entitled to terminate this
                    Agreement by providing a written notice of termination within 10 days of the conclusion of the
                    cure period.<br/>
                    <span class="underline">Effect of Termination.</span> Termination of this Agreement will not relieve either party of any
                    obligation to pay the other party any amounts, Fees or other compensation due and owing to
                    the other party prior to such termination. In the event Customer cancels this agreement or
                    otherwise stops using Services prior to the conclusion of the initial or any renewal term.
                    <!--Customer authorizes an early termination fee equal to $375. REVO is authorized to bill and
                    collect this amount via ACH or credit card charge to Customer with no further authorization
                    required from Customer. Customer agrees to waive any rights to dispute or reject the early
                    termination fee as described herein.--> <br/><br/><br/>

                    <b>6.GENERAL PROVISIONS</b>
                    <span class="underline">Exclusive Provision of Payment Services.</span> Customer agrees that REVO shall be its exclusive
                    provider of payment-related software and Payment Services as defined herein, during the
                    Agreement Term, including any renewals thereof.<br/>
                    <span class="underline">Agree to Pay Fees</span> Customer agrees to pay fees when due to REVO or underlying service
                    Providers, as set forth in this Agreement and additional services agreements that are
                    provided. Customer authorizes REVO to debit or charge Customer�s bank account or credit
                    card account on file.<br/>
                    <span class="underline">Assignment.</span> Customer rights or obligations under this Agreement may not be assigned or
                    transferred without the prior written consent of REVO.<br/>
                    <span class="underline">No Waiver</span> If either party fails to perform any of its obligations hereunder and the other party
                    fails to enforce the provisions relating thereto, such party's failure to enforce this Agreement
                    shall not prevent its later enforcement.<br/>
                    <span class="underline">Modifications & Severability.</span> No modification of this Agreement shall be binding upon either
                    party unless made in writing and signed by an authorized representative of REVO and
                    Customer. If any provision of this Agreement is determined by a court to be, or becomes,
                    invalid, unenforceable or illegal, such provision shall be (a) modified to be made valid,
                    enforceable and legal in such a manner as to best effectuate the intent of the parties on the
                    date hereof or (b) deemed eliminated where such modification is not practicable; the
                    remainder of this Agreement shall remain in effect in accordance with its terms as modified by
                    such modification or deletion.<br/>
                    <span class="underline">Notices.</span> All notices and correspondence under this Agreement shall be in writing and shall be
                    delivered by express courier, or certified mail, return receipt requested, to the addresses first
                    set forth herein, or at such different address as may be designated by such party by written
                    notice to the other party from time to time.<br/>
                    <span class="underline">Governing Law.</span> This Agreement shall be governed by the laws of the State of California. The
                    parties mutually agree and submit to jurisdiction in the federal or state courts of Los Angeles
                    County, California. Each party hereby agrees that such courts shall have exclusive personal
                    jurisdiction and venue with respect to such party.<br/>
                    <span class="underline">Irreparable Harm; Right to Injunctive Relief.</span> Customer acknowledges that its breach of this
                    Agreement may cause irreparable harm to REVO, and Customer agrees that REVO shall be
                    entitled to injunctive relief in the event of such a breach.<br/>
                    <span class="underline">Facsimile Signature and Counterparts</span> This Agreement may be executed by facsimile, by
                    electronic signatures, or in any number of counterparts, each of which shall be an original as
                    against any party whose signature appears thereon and all of which together shall constitute
                    one and the same instrument.<br/>
                    <br/>
                </td>
            </tr>
        </table>
        <br/>
        <br/>
        <br/>
        <table cellpadding="10px" style="width: 100%">
            <tr>
                <td style="width: 50%">Sign here</td>
                <td style="width: 25%">@if(isset($external_app)){{ $external_app['first_name'].' ' .$external_app['last_name'] }}@else @if(isset($dba_name)){{ $dba_name }} @endif @endif</td>
                <td style="width: 25%">{{ date('d/m/Y') }}</td>
            </tr>
            <tr>
                <td>Customer Signature</td>
                <td>Print Name</td>
                <td>Date</td>
            </tr>
        </table>
        <br/>
        <br/>
        <div class="endpage">&nbsp;</div>
        <?php $loop_index = 0; ?>
        @foreach($data as $d)
        @if(!isset($errors_importing[$loop_index]))
        <b>EXHIBIT A: Services and Pricing</b>
        <br/>
        <br/>
        <table style="width: 100%" cellpadding="5px" cellspacing="0">
            <tr class="head">
                <td>Service description</td>
                <td style="text-align: center">Select</td>
                <td style="text-align: right">Pricing</td>
            </tr>
            <?php $color = 0; ?>
            @foreach($ps as $p)
            <tr <?php if ($color % 2 != 0) { ?>style="background-color: #F8F8F8" <?php } ?>>
                <td>{{ $p->description }}<br/><span class="small_text">{{ $p->toptips }}</span></td>
                <td class="text-center">
                    @if(isset($d['array_service']['check_service'.$p->id_p]) || isset($d['array_service_import']['check_service'.$p->service])) <b>x</b> @endif
                </td>
                <td class="text-right">{{ $p->cost }}</td>
            </tr>
            <?php $color++; ?>
            @endforeach
        </table>
        <br/>
        <br/>
        <b>Service Fees payment information</b><br/>
        <p style="font-size: 10px">The setup, transaction, and monthly fees will begin when this Agreement is signed. All fee charges to the Licensee will be automatically debited or charged at the beginning of the month to
            the account specified below, if the appropriate option is selected above, transaction Fees can be billed directly to each Payor at the time a transaction is made. If customer chooses to have
            each payee automatically debited individually, please indicate by checking the appropriate billing method below. There is a $20 fee for rejected transactions. Revo requires electronic check
            payment processing for the total set-up fee payment and for monthly hosting.</p>
        <br/>
        <br/>
        <b>Name on Account:</b>{{ $d['legal'] }}t<br/>
        <b>Address:</b> {{$d['adr1']}}<br/>
        <b>City:</b> {{$d['cty1']}}<br/>
        <b>State:</b> {{$d['state1']}}<br/>
        <b>Zip:</b> {{$d['zip1']}}<br/>
        <b>Account Type:</b> @if($d['banktype'] == 1) Savings @else Checking @endif<br/>
        <b>Routing Number:</b> {{$d['bankrouting']}}<br/>
        <b>Account Number:</b> {{$d['banknumber']}}<br/>
        <br/>
        <br/>
        @endif
        <?php $loop_index++; ?>
        @endforeach
        <b>By signing below, I have authorized Revo to setup and bill all services as requested:</b><br/>
        <br/>
        <br/>
        <br/>
        <table cellpadding="10px" style="width: 100%">
            <tr>
                <td style="width: 50%">Sign here</td>
                <td style="width: 25%">@if(isset($external_app)){{ $external_app['first_name'].' ' .$external_app['last_name'] }}@else @if(isset($dba_name)) {{$dba_name}} @endif @endif</td>
                <td style="width: 25%">{{ date('d/m/Y') }}</td>
            </tr>
            <tr>
                <td>Customer Signature</td>
                <td>Print Name</td>
                <td>Date</td>
            </tr>
        </table>
        <br/>
        <br/>

        @if(isset($pdf_generate['cc']))
        <div class="endpage">&nbsp;</div>
        <table style="width: 100%" cellspacing="0">
            <tr>
                <td>
                </td>
                <td class="text-right">
                    <b>EXHIBIT B: Credit Card Processing Application</b>
                </td>
            </tr>
        </table>
        @foreach($data as $d)
        @if(!isset($errors_importing[$loop_index]))
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td colspan="3" class="black" >Section 1 VISA/MASTERCARD/DISCOVER NETWORK SCHEDULE OF FEES</td>
                <td colspan="6"></td>
            </tr>
            <tr>
                <td colspan="1">Convenience Fee </td>
                <td colspan="1">{{ $convenience_fee }}</td>
                <td colspan="1">Card Acceptance Options</td>
                <td colspan="6"><span class="underline">X</span> All Cards - Visa / MasterCard / Discover</td>
            </tr>

            <tr>
                <td>SUB-BUSINESS TYPE</td>
                <td colspan="6"><span class="underline">X</span> Emerging Markets</td>
            </tr>
            <tr>
                <td colspan="9">
                    <span class="p" style="text-align: justify">
                        The Convenience Fee listed above (the Access Fee) to cover the Merchant customers access to and use of the website to pay bills shall be collected solely from Merchant customers who utilize the services. Any interchange or per item fees owed to REVO as a result of the Merchant Agreement shall be collectable from the Access Fee. Merchant remains liable for all other fees. Merchant acknowledges and understands that to be eligible for this pricing structure, Merchant business must fall into one of the accepted business categories (MCC Codes) for emerging markets, and the Merchant must meet the requirements under the Rules for the assessment of an access fee/convenience fee. Merchant has represented that it has identified its business category and completed its Merchant Application accurately. Merchant acknowledges that REVO has relied upon the business category and business environment information that Merchant has provided. If Merchant business category or business environment is ever modified, Merchant agrees to promptly contact REVO regarding such modification. Merchant further understands that this Merchant Agreement may be terminated as a result of such modification, or if Merchant MCC Code is no longer eligible for this fee structure. In addition if it is determined that the assessment of the Access Fee to Merchant customers violates or may violate any Rule, regulation or law, REVO may immediately terminate this Merchant Agreement.
                    </span>
                </td>
            </tr>
            <tr>
                <td colspan="4" class="black">Section 2 OCCURRENCE FEES</td>
                <td colspan="5">* Fees are assessed for every occurrence of the event. Please refer to the Merchant Processing Agreement for more information on each charge.</td>
            </tr>
            <tr>
                <td>ACH/DBA Change Fee</td>
                <td>$20.00</td>
                <td>/each</td>
                <td>Return ACH*</td>
                <td>$20.00</td>
                <td>/each</td>
                <td>Retrieval/Chargeback</td>
                <td>$20.00</td>
                <td>/each</td>
            </tr>
            <tr>
                <td colspan="9" class="black">
                    Section 3 PATRIOT ACT REQUIREMENTS, PERSONAL GUARANTEE, AND IMPORTANT DISCLOSURES
                </td>
            </tr>
            <tr>
                <td colspan="9">
                    <span class="p" style="text-align: justify">
                        To help the government fight the funding of terrorism and money laundering activities, the USA Patriot Act requires all financial institutions to obtain, verify and record information that identifies each person (including business entities) who opens an account. What this means for you: When you open an account, we will ask for your name, physical address, date of birth, taxpayer identification number and other information that will allow us to identify you. We may also ask to see your ssn or other identifying document. The undersigned entity(ies) and individuals hereby unconditionally authorize REVO and its agents to (i) investigate the information and references contained herein, and to obtain additional information about the Merchant and such individual(s) by pulling credit bureau and criminal background checks on the Merchant and its principals, including obtaining reports from consumer reporting agencies on individuals signing below as an owner or general partner of Merchant, or providing their Social Security Number on the Application (if such individual asks REVO whether or not a consumer report was requested, REVO will tell such individual and, if REVO received a report, REVO will give the individual the name and address of the agency that furnished it) and (ii) update such information periodically throughout the terms of service of the Merchant Agreement. By providing your Federal Tax ID number and signing this Application, you, in your individual capacity, unconditionally authorize REVO to obtain your credit report.
                    </span>
                </td>
            </tr>
            <tr>
                <td class="black" colspan="9">
                    Section 4. BUSINESS INFORMATION
                </td>
            </tr>
            <tr>
                <td colspan="7">Business Legal Name: {{ $d['legal'] }}</td>
                <td colspan="2">#Customers: @if(isset($d['donor'])){{ $d['donor'] }}@endif</td>
            </tr>
            <tr>
                <td colspan="9">
                    Business Name (DBA): {{ $d['dba'] }}
                </td>
            </tr>
            <tr>
                <td colspan="5">
                    Business Website:
                </td>
                <td colspan="4">
                    Contact E-mail: {{ $d['email'] }}
                </td>
            </tr>
            <tr>
                <td colspan="5">
                    Business Location Address:<br/>
                    {{ $d['adr1'] }}
                </td>
                <td colspan="4">
                    Contact Name:<br/>
                    {{ $d['pname'] }}
                </td>
            </tr>
            <tr>
                <td colspan="2">City: {{ $d['cty1'] }}</td>
                <td>State: {{ $d['state1'] }}</td>
                <td  colspan="2">Zip: {{ $d['zip1'] }}</td>
                <td colspan="2">Phone: {{ $d['phone1'] }}</td>
                <td colspan="2">Fax:</td>
            </tr>
            <tr>
                <td colspan="9">
                    Business Billing Address:<br/>
                    {{ $d['adr2'] }}
                </td>
            </tr>
            <tr>
                <td colspan="2">City: {{ $d['cty2'] }}</td>
                <td>State: {{ $d['state2'] }}</td>
                <td  colspan="2">Zip: {{ $d['zip2'] }}</td>
                <td colspan="2">Phone: {{ $d['phone1'] }}</td>
                <td colspan="2">Fax:</td>
            </tr>
            <tr>
                <td class="black" colspan="9">
                    Section 5. OWNERSHIP INFORMATION
                </td>
            </tr>
            <tr>
                <td colspan="2">Ownership: {{ $d['bstruct'] }}</td>
                <td>Title: {{ $d['title'] }}</td>
                <td  colspan="2">Tax ID: {{ $d['fti'] }}</td>
                <td colspan="4">D & B#</td>
            </tr>
            <tr>
                <td colspan="2">Owner/Officer/Principal Name: {{ $d['pname'] }}</td>
                <td>DOB: N/A</td>
                <td  colspan="2">Phone: {{ $d['pphone'] }}</td>
                <td colspan="4">Social Security Number: XXX-XX-{{ substr($d['ssn'], -4) }}</td>
            </tr>
            <tr>
                <td colspan="2">Home Address: {{ $d['cadr1'] }}</td>
                <td>City: {{ $d['ccty1'] }}</td>
                <td  colspan="2">State: {{ $d['cstate1'] }}</td>
                <td colspan="4">Zip: {{ $d['czip1'] }}</td>
            </tr>
            <tr>
                <td class="black" colspan="3">Section 6 BUSINESS PROFILE AND ASSUMPTIONS</td>
                <td colspan="6"></td>
            </tr>
            <tr>
                <td colspan="2">Estimated monthly Volume (Visa/MC/DN): {{ $d['ccmticket'] }}</td>
                <td colspan="3">Average Ticket:</td>
                <td colspan="4">Highest Ticket: {{ $d['cchticket'] }}</td>
            </tr>
            <tr>
                <td class="black" colspan="3">Section 7 COMPLIANCE INFORMATION</td>
                <td colspan="6"></td>
            </tr>
            <tr>
                <td colspan="9">
                    Are you compliant with the Payment Card Industry Data Security Standards? <span class="underline">X</span> Yes __No <br/>
                    Have you been notified by Visa, MasterCard, or Discover that you may have been a victim of a compromise of cardholder data? ___Yes  <span class="underline">X</span>No<br/>
                    If yes, have you completed remediation? ___Yes ___No<br/>
                    Do you store cardholder data? Paper - ? ___Yes <span class="underline">X</span>No Electronic - ? ___Yes <span class="underline">X</span>No<br/>
                    Identify all third parties that have access to cardholder data on your behalf:<br/>
                </td>
            </tr>
            <tr>
                <td colspan="9"><p>All merchants must comply with the Payment Card Industry Data Security Standard (PCI DSS). Merchant is required to maintain the security of card data and to comply with the requirements of the PCI DSS. Revo may at any time require that Merchant
                        validate its compliance with the PCI DSS, and if requested, Merchant will provide evidence that Merchant has successfully completed a Self Assessment Questionnaire and scan(s), if applicable, and (b) is compliant with the PCI DSS</p></td>
            </tr>
            <tr>
                <td class="black" colspan="3">Section 8 FUNDS TRANSFER INFORMATION</td>
                <td colspan="6"><b>24 Hour Funding</b> Please supply voided check or preprinted bank letter</td>
            </tr>
            <tr>
                <td colspan="3">Routing # {{ $d['bankrouting'] }}</td>
                <td colspan="6">ACH can be performed by the following entities: REVO or any authorized agent of REVO</td>
            </tr>
            <tr>
                <td colspan="3">Routing # {{ $d['banknumber'] }}</td>
                <td colspan="6">The ACCOUNT NUMBER indicated must be a valid account number for handling ACH deposits and withdrawals</td>
            </tr>
            <tr>
                <td class="black" colspan="3">Section 9 CONTRACT SIGNATURES</td>
                <td colspan="6"></td>
            </tr>
            <tr>
                <td colspan="9">
                    IN WITNESS WHEREOF the parties have caused this Agreement to be executed by their duly authorized representatives effective on the date signed by NPC. The Agreement shall be binding upon Merchant upon the earlier of Merchant's execution below or Merchant's first processed electronic transaction.
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>MERCHANT</b></td>
                <td colspan="3" rowspan="4"></td>
                <td colspan="4"><b>REVO</b></td>
            </tr>
            <tr>
                <td colspan="2">
                    <br/>
                    <br/>

                </td>

                <td colspan="4" style="vertical-align: bottom" class="text-center">
                    <br/>
                    <br/>
                    Sign here</td>
            </tr>
            <tr>
                <td colspan="2">Name: {{ $merchant  }}</td>

                <td colspan="4">Name (please print):</td>
            </tr>
            <tr>
                <td colspan="2">Date: {{ date('d/m/Y') }} Last Four Digits SSN/DL: 1111</td>

                <td colspan="4">Date: {{ substr($d['ssn'], -4) }}</td>
            </tr>
        </table>@if ($d != end($data))<div class="endpage"></div>@endif
        @endif
        @endforeach
        @endif

        @if(isset($pdf_generate['ec']))
        <div class="endpage">&nbsp;</div>
        <table style="width: 100%" cellspacing="0">
            <tr>
                <td>
                </td>
                <td class="text-right">
                    <b>EXHIBIT C : Electronic Check Processing Application</b>
                </td>
            </tr>
        </table>

        @foreach($data as $d)
        @if(!isset($errors_importing[$loop_index]))
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td colspan="6" class="black">BUSINESS & CONTACT INFORMATION</td>
            </tr>
            <tr>
                <td colspan="3"><b>Legal Name:</b></td>
                <td colspan="3"><b>DBA Name:</b></td>
            </tr>
            <tr>
                <td colspan="3">{{ $d['legal'] }}</td>
                <td colspan="3">{{ $d['dba'] }}</td>
            </tr>
            <tr>
                <td colspan="2"><b>Physical Address:</b></td>
                <td colspan="2"><b>City:</b></td>
                <td colspan="1"><b>State:</b></td>
                <td colspan="1"><b>Zip:</b></td>
            </tr>
            <tr>
                <td colspan="2">{{ $d['adr1'] }}</td>
                <td colspan="2">{{ $d['cty1'] }}</td>
                <td colspan="1">{{ $d['state1'] }}</td>
                <td colspan="1">{{ $d['zip1'] }}</td>
            </tr>
            <tr>
                <td colspan="2"><b>Billing Address:(if different)</b></td>
                <td colspan="2"><b>City:</b></td>
                <td colspan="1"><b>State:</b></td>
                <td colspan="1"><b>Zip:</b></td>
            </tr>
            <tr>
                <td colspan="2">{{ $d['adr2'] }}</td>
                <td colspan="2">{{ $d['cty2'] }}</td>
                <td colspan="1">{{ $d['state2'] }}</td>
                <td colspan="1">{{ $d['zip2'] }}</td>
            </tr>
            <tr>
                <td colspan="2"><b>Phone:</b></td>
                <td colspan="2"><b>Fax:</b></td>
                <td colspan="1"><b>Customer Service Phone:</b></td>
                <td colspan="1"><b>Website Address/UR:</b></td>
            </tr>
            <tr>
                <td colspan="2">{{ $d['phone1'] }}</td>
                <td colspan="2"></td>
                <td colspan="1"></td>
                <td colspan="1"></td>
            </tr>
            <tr>
                <td colspan="2"><b>Primary Contact Name:</b></td>
                <td colspan="2"><b>Title:</b></td>
                <td colspan="1"><b>Phone:</b></td>
                <td colspan="1"><b>Email Address:</b></td>
            </tr>
            <tr>
                <td colspan="2">{{ $d['pname'] }}</td>
                <td colspan="2">{{ $d['ttname'] }}</td>
                <td colspan="1">{{ $d['pphone'] }}</td>
                <td colspan="1">{{ $d['email'] }}</td>
            </tr>
            <tr>
                <td colspan="2"><b>Secondary Contact Name:</b></td>
                <td colspan="2"><b>Title:</b></td>
                <td colspan="1"><b>Phone:</b></td>
                <td colspan="1"><b>Email Address:</b></td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
                <td colspan="2"></td>
                <td colspan="1"></td>
                <td colspan="1"></td>
            </tr>
        </table>
        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td colspan="6" class="black">BUSINESS PROFILE</td>
            </tr>
            <tr>
                <td colspan="2"><b>Business Structure:</b></td>
                <td colspan="2"><b>Stock Symbol:</b></td>
                <td colspan="1"><b>Federal Tax ID # / EIN:</b></td>
                <td colspan="1"><b>Date Formed:</b></td>
            </tr>
            <tr>
                <td colspan="2">{{ $d['bstruct'] }}</td>
                <td colspan="2"></td>
                <td colspan="1">{{ $d['fti'] }}</td>
                <td colspan="1">{{ $d['date'] }}</td>
            </tr>
            <tr>
                <td colspan="4"><b>Length of Current Ownership:</b></td>
                <td colspan="2"><b>Business Type/Industry:(include NAICS or SIC Code if available)</b></td>
            </tr>
            <tr>
                <td colspan="4">TO PRESENT</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="6"><b>Provide a detailed description of the products/services that you provide:</b></td>
            </tr>
            <tr>
                <td colspan="6">{{ $d['bdesc'] }}</td>
            </tr>
            <tr>
                <td colspan="5"><b>Describe the primary method of marketing your products/services:</b></td>
                <td colspan="1"><b>Refund Policy:</b></td>
            </tr>
            <tr>
                <td colspan="5">N/A</td>
                <td colspan="1">N/A</td>
            </tr>

        </table>

        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td colspan="6" class="black">OFFICER/OFFICER INFORMATION</td>
            </tr>
            <tr>
                <td colspan="2"><b>Primary Officer Name:</b></td>
                <td colspan="1"><b>Title:</b></td>
                <td colspan="1"><b>Ownership %:</b></td>
                <td colspan="1"><b>Date of Birth:</b></td>
                <td colspan="1"><b>Social Security Number:</b></td>
            </tr>
            <tr>
                <td colspan="2">{{ $d['pname'] }}</td>
                <td colspan="1">{{ $d['ttname'] }}</td>
                <td colspan="1">N/A</td>
                <td colspan="1">N/A</td>
                <td colspan="1">XXX-XX-{{ substr($d['ssn'], -4) }}</td>
            </tr>
            <tr>
                <td colspan="2"><b>Home Address:</b></td>
                <td colspan="2"><b>City:</b></td>
                <td colspan="1"><b>State:</b></td>
                <td colspan="1"><b>Zip:</b></td>
            </tr>
            <tr>
                <td colspan="2">{{ $d['cadr1'] }}</td>
                <td colspan="2">{{ $d['cadr1'] }}</td>
                <td colspan="1">{{ $d['cstate1'] }}</td>
                <td colspan="1">{{ $d['czip1'] }}</td>
            </tr>
        </table>

        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td colspan="2" class="black">SERVICES / TRANSACTION SUBMISSION OPTIONS</td>
            </tr>
            <tr>
                <td style="width: 50%"><b>EPS Online Merchant Portal Options:</b>(Select all that apply)</td>
                <td><b>Other Options:</b>(Select all that apply)</td>
            </tr>
            <tr>
                <td> _ Remote Deposit Capture (Check Conversion - CAR/LAR)<br/>
                    _ Merchant Capture (Check Conversion - Scan Check/Key Entry)<br/>
                    <span class="underline">X</span> ACH Services<br/>
                    _ File Upload (Tab-delimited, Comma-delimited or Excel file format)<br/>
                    _ Fed-Ready File Upload
                </td>
                <td>
                    <span class="underline">X</span> Real-Time Gateway (XML file format)<br/>
                    _ Web Services<br/>
                    _ Hosted Pay Page<br/>
                    _ Remit Plus<br/>
                    _ Credit Card Gateway
                </td>
            </tr>
        </table>

        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td class="black">TRANSACTION TYPES (Select all that apply)</td>
            </tr>
            <tr>
                <td><b>Check Conversion:</b></td>
            </tr>
            <tr>
                <td>
                    _ Check 21<br/>
                    _ ARC - Accounts Receivable Conversion<br/>
                    _ BOC<br/>
                    _ Back Office Conversion<br/>
                    _ POP - Point of Purchase Conversion<br/><br/>
                    <i><span class="underline">Virtual Endorsement</span> - All converted items are virtually endorsed by ProfitStars. Please do not endorse items that you process through the ProfitStars system.</i>
                </td>
            </tr>
            <tr>
                <td><b>Preauthorized Payments CCD/PPD:</b></td>
            </tr>
            <tr>
                <td>
                    _ ACH Debit<br/>
                    _ ACH Recurring Debit<br/>
                    _ ACH Credit<br/>
                    _ ACH Recurring Credit<br/>
                    _ ACH Refund<br/>
                    <i>Please include sample authorization language.</i>
                </td>
            </tr>
            <tr>
                <td>
                    <b>Other ACH:</b> (Select all that apply)
                </td>
            </tr>
            <tr>
                <td>

                    <span class="underline">X</span> WEB - Internet Check <br/>
                    _ TEL - Telephone Check<br/>
                    <i>Please include sample authorization language</i>
                </td>
            </tr>
            <tr>
                <td><b>Credit Card Processor Options:</b></td>
            </tr>
            <tr>
                <td>
                    _ Revo Payments <i>Requires a separate processing agreement with the selected card service provider</i>
                </td>
            </tr>
        </table>

        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td class="black" colspan="5">TRANSACTION PROFILE & VELOCITY INFORMATION</td>
            </tr>
            <tr>
                <td colspan="5">Please provide accurate estimates of your expected ACH andor Check21 activity. This information will be used during underwriting as a guide to establish your transaction limits (velocities). Requested amounts below are subject to approval by EPS Risk Management. Transaction counts and/or amounts that fall outside of your approved limits are subject to be declined</td>
            </tr>
            <tr>
                <td class="black" colspan="2" style="text-align: left">Description</td>
                <td class="black">Debits</td>
                <td class="black">Credits</td>
                <td class="black" >Refunds</td>
            </tr>
            <tr>
                <td colspan="2"><b>Average Dollar Amount per Single Transaction</b><br/>Please provide your average transaction amount.</td>
                <td class="text-center">{{ $d['hticket'] }}</td>
                <td class="text-center">{{ $d['vhticket'] }}</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2"><b>Maximum Dollar Amount per Single Transaction</b><br/>The largest allowable dollar amount ($) per individual transaction.</td>
                <td class="text-center">{{ $d['hticket'] }}</td>
                <td class="text-center">{{ $d['vhticket'] }}</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2"><b>Maximum Dollar Amount per Day</b><br/>The largest allowable amount ($) total for any given day.</td>
                <td class="text-center">{{ $d['mticket'] }}</td>
                <td class="text-center">{{ $d['vhticket'] }}</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2"><b>Maximum Number of Transactions per Day</b><br/>The largest allowable number (#) of transactions on any given day.</td>
                <td class="text-center">{{ $d['cticket'] }}</td>
                <td class="text-center">{{ $d['vcticket'] }}</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2"><b>Maximum Dollar Amount per Month</b><br/>The largest allowable amount ($) total during a month.</td>
                <td class="text-center">{{ $d['mticket'] }}</td>
                <td class="text-center">{{ $d['vhticket']  }}</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2"><b>Maximum Number of Transactions per 14-Day Period</b><br/>The largest allowable number (#) of transactions during a month.</td>
                <td class="text-center">{{ $d['cticket'] }}</td>
                <td class="text-center">{{ $d['vcticket']  }}</td>
                <td colspan="2"></td>
            </tr>
        </table>

        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td class="black" colspan="3">SCANNER INFORMATION</td>
            </tr>
            <tr>
                <td><b>Scanner Make:</b></td>
                <td><b>Model:</b></td>
                <td><b>Serial Number:</b></td>
            </tr>
            <tr>
                <td>N/A</td>
                <td>N/A</td>
                <td>N/A</td>
            </tr>
            <tr>
                <td><b>Scanner Make:</b></td>
                <td><b>Model:</b></td>
                <td><b>Serial Number:</b></td>
            </tr>
            <tr>
                <td>N/A</td>
                <td>N/A</td>
                <td>N/A</td>
            </tr>
        </table>
        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td class="black" colspan="4">ACH COLLECTION & RE-PRESENTMENT OPTIONS</td>
            </tr>
            <tr>
                <td colspan="4">In the event of a return, EPS can automatically re-present the item to the check writers bank in order to attempt collection on the face amount, as well as a returned-check fee.</td>
            </tr>
            <tr>
                <td colspan="4">
                    <b>
                        Face Amount: Maximum Number of Re-Presentments:
                    </b>
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    If an ACH item returns, attempt collection on the <span class="underline">Face Amount</span> up to how many times (select one)?   _2   _1 <span class="underline">X</span>None
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <b>Timing of First Re-Presentment:</b>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    First ACH re-presentment will occur how many days following 1st return?<br/>
                    Please specify the number of days (0=immediately):
                </td>
                <td colspan="2">
                    N/A
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <b>Timing of Final Re-Presentment:</b>
                </td>
            </tr>
            <tr>
                <td colspan="3">
                    _ Final ACH re-presentment will coincide with common paydays (i.e., 1st & 15th).<br/>
                    _ Final ACH re-presentment will occur after a fixed number of days. Please specify the number of days (0=immediately):
                </td>
                <td>
                    N/A
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <b>Returned-Check Fee: Maximum Number of Re-Presentments:</b>
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    f an ACH item returns, attempt collection on the Returned-Check fee up to how many times (select one)?   _3   _2 <span class="underline">X</span>1 _None
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <b>Returned-Check Fee Amount:</b>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    If you selected one or more Returned-Check Fee collection attempts, enter the amount to be charged to the check writer
                </td>
                <td>$</td>
                <td>20</td>
            </tr>
            <tr>
                <td colspan="4">
                    <b>Returned-Check Fee Settlement:</b>
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <span>X</span> Deposit collected fees into other bank account. RPP
                </td>
            </tr>
        </table>
        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td class="black" colspan="4">BUSINESS BANKING INFORMATION</td>
            </tr>
            <tr>
                <td colspan="4">Enter your primary settlement account information here. Please include a voided check for account verification.</td>
            </tr>
            <tr>
                <td><b>Bank Name:</b></td>
                <td colspan="2"><b>Bank Officer/Contact Name:</b></td>
                <td><b>Phone:</b></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td colspan="2"></td>
                <td></td>
            </tr>

            <tr>
                <td><b>Bank Address:</b></td>
                <td><b>City:</b></td>
                <td><b>State:</b></td>
                <td><b>Zip:</b></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="4">
                    <b>Name on Account/Location Display Name:</b>
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    {{ $d['dba'] }}
                </td>
            </tr>
            <tr>
                <td colspan="2"><b>ABA Routing/Transit Number:</b></td>
                <td><b>Bank Account Number:</b></td>
                <td><b>Account Type:</b></td>
            </tr>
            <tr>
                <td colspan="2">{{ $d['bankrouting'] }}</td>
                <td>{{ $d['banknumber'] }}</td>
                <td>@if ($d['banktype']=='0'){{'Checking'}}@else{{'Savings'}}@endif</td>
            </tr>
        </table>
        <br/>
        <br/>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td class="black">ADDITIONAL BANK ACCOUNTS</td>
            </tr>
            <tr>
                <td>Additional location information to be supplied in the format requested in Exhibit B for each Customer. Please include a voided check for each merchant with the corresponding depository account information.</td>
            </tr>
        </table>
        <br/>
        <br/>
        @if ($d != end($data)) <div class="endpage">&nbsp;</div> @endif
        @endif
        @endforeach
        <div class="endpage">&nbsp;</div>
        <table cellspacing="0" cellpadding="1" border="1" style="font-size: 8px">
            <tr>
                <td class="black" colspan="4">SIGNATURES</td>
            </tr>
            <tr>
                <td colspan="4">
                    On behalf of the foregoing legal business ("Merchant"), to induce Jack Henry & Associates, Inc., acting through its ProfitStars division("JHA") reliance
                    thereon, the undersigned certifies the accuracy of all the foregoing information and authorizes JHA, Bank, Credit Bureau, or other investigative agency
                    contracted by JHA to investigate any and all references, statements or other data contained herein or obtained from Merchant, other persons, companies or
                    agencies pertaining to Merchants and/or Guarantors credit, financial responsibility and accuracy of any of the foregoing information. The undersigned further
                    agrees to notify JHA of any and all changes which may occur from time to time in the information and statements contained herein. The person(s) signing
                    this agreement certifies that he/she is authorized to enter into this agreement on behalf of Merchant.<br/>
                    <span class="underline">WARRANTY OF APPLICATION</span>
                    : In connection with this Agreement, Merchant has executed and delivered an application to JHA containing, among other
                    things, information describing the nature of Merchant's business and, where applicable, the individuals who are Merchant's principal owners. Merchant
                    warrants to JHA that all information and statements contained in such application are true, correct, and complete. Merchant further agrees to notify JHA
                    promptly of any changes which may occur from time to time regarding any information contained in such application, including, but not limited to, the identity
                    of the principal owners, type of goods and services provided and how sales are completed. Merchant and principal owner(s) identified on approved
                    applications shall be jointly and severally liable to JHA and remain liable for any and all loss, costs and expense suffered or incurred by JHA.<br/>
                    <span class="underline">CHECK / DEBIT AUTHORIZATION</span>
                    : I authorize JHA to electronically debit my (select one) Checking account / Savings account for a non-refundable, one-
                    time application fee in the amount listed below. If this item is dishonored for any reason, I authorize JHA to initiate an additional electronic debit to the same
                    Account for a returned check fee in the amount of $30. My signature on this agreement below shall be my authorization to execute this transaction. This
                    authorization shall remain in full force and effect until JHA has received written notification from me of its termination in such a time and manner as to afford
                    JHA a reasonable opportunity to act on it.
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <b>Application Fee:</b>
                </td>
                <td colspan="2">
                    <b>Name on Bank Account:</b>
                </td>
            </tr>
            <tr>
                <td>$</td>
                <td>N/A</td>
                <td colspan="2">N/A</td>
            </tr>
            <tr>
                <td colspan="2">
                    <b>ABA Routing/Transit Number:</b>
                </td>
                <td colspan="2">
                    <b>Bank Account Number:</b>
                </td>
            </tr>
            <tr>
                <td colspan="2">N/A</td>
                <td colspan="2">N/A</td>
            </tr>
            <tr>
                <td colspan="4" class="text-center">
                    MERCHANT CERTIFICATION<br/>
                    Merchant certifies that the merchants for which they send transactions for processing meet the following criteria:<br/><br/>
                    They are merchants legally registered with the Secretary of State and any other required agency.<br/>
                    The merchants all have federal tax IDs which will be provided.<br/>
                    The transactions sent to for processing are for legitimate merchants fees<br/>
                </td>
            </tr>
            <tr>
                <td colspan="2" class="black text-left">Primary Signature:</td>
                <td colspan="2" class="black text-left">Secondary Signature:</td>
            </tr>
            <tr>
                <td colspan="2"><b>Name:</b>(please print)</td>
                <td colspan="2"><b>Name:</b>(please print)</td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2"><b>Title:</b><br/><br/><br/></td>
                <td colspan="2"><b>Title:</b><br/><br/><br/></td>
            </tr>
            <tr>
                <td colspan="2"><b>Last Four Digits SSN/DL: @if(!isset($multiple)){{ substr($d['ssn'], -4) }}@endif</b></td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td><b>Signature:</b></td>
                <td><b>Date: {{ date('d/m/Y') }}</b></td>
                <td><b>Signature:</b></td>
                <td><b>Date: {{ date('d/m/Y') }}</b></td>
            </tr>
            <tr>
                <td colspan="2"><br/><br/><br/><br/><br/></td>
                <td colspan="2"><br/><br/><br/>Sign here</td>
            </tr>
        </table>
        @endif
    </body>
</html>