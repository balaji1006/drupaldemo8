@extends('layouts.master')
@section('title','Application')
@section('export-excel-url',route('export', array('sqlEncrypted' => $sqlEncrypted, 'type' => 'excel', 'sheetname' => 'applicationList')))
@section('export-csv-url',route('export', array('sqlEncrypted' => $sqlEncrypted, 'type' => 'csv', 'sheetname' => 'applicationList')))
@section('content')
<div class="normalheader ">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <div class="pull-right">

                <?php
                $new_link = '';
                $new_link = '<a class="btn btn-success margint-10" href="' . route('applicationcreate', array('token' => $token, 'partner' => 0, 'group' => 0)) . '"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> New</a>';
                echo $new_link . ' ';

                $import_link = '';
                $import_link = '<a class="btn btn-success margint-10" href="' . route('applicationimport', array('token' => $token, 'partner' => 0, 'group' => 0)) . '"><span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span> Import</a>';

                echo $import_link;
                ?>

            </div>

            <div class="">
                <h2 class="font-light m-b-xs">
                    Applications
                </h2>
                <small>
                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                        <li class="active">
                            <span>Applications</span>
                        </li>
                    </ol>
                </small>
            </div>

        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">
        <div class="panel-body">
            <div class="row">
                @include('components.itemspage')
                <div class="col-md-9 col-xs-4 text-center rapyd-filters" id="filtersAndExportDiv">
                    {!! $filter !!}
                </div>
                <div class="col-md-2 col-xs-5 text-right" id="exportDropdownDiv">
                    @include('components.exportDropdown')
                </div>
            </div>
            {!! $grid !!}
        </div>
        <div class="panel-footer">
        </div>
    </div>
</div>
<div id="mail_modal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">
        {!! Form::open(['route'=>['applicationadminemail'],'method'=>'POST','id'=>'form']) !!}
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Send application</h4>
            </div>
            <div class="modal-body">
                <input required name="email" placeholder="Email" class="form-control" type="email">
                <input id="id_app" name="id_app" type="hidden">
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-xs-6"><button type="submit" class="btn btn-primary btn-block">Send</button></div>
                    <div class="col-xs-6"><button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button></div>
                </div>


            </div>
        </div>
        </form>
    </div>
</div>

<div class="modal fade" id="sendmbfModal" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="color-line"></div>
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Send Mbf</h4>
            </div>
            <div class="modal-body " >
                <h5 class="text-center" id="mbfdetails"></h5>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('footer1')

<script>
//$("#form").validate({
//    //debug: true,
//    ignore: '*:not([name])',
//    rules: {
//        email: {
//            email: true,
//        }
//    }
//});
var id_app = null;
function showMailPopup(p_idapp) {
    id_app = p_idapp;
    $('#id_app').val(p_idapp);
    $('#mail_modal').modal('show');
}

function openApp(p_idapp) {
    route = "{{route('applicationadminopen', ['token'=>$token,'id_app' => 0])}}";
    route = route.replace('/0', '/' + p_idapp);
    window.location = route;
}

function deleteApp(p_idapp) {
    route = "{{route('applicationadmindelete', ['id_app' => 0])}}";
    route = route.replace('/0', '/' + p_idapp);

    swal({
                title: "Are you sure?",
                text: "You will not be able to recover this application!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!"
            },
            function () {

                window.location.href = route;
            });

}

function sendMBFApp(p_idapp) {
    route = "{{route('applicationadminmbf', ['id_app' => 0])}}";
    route = route.replace('/0', '/' + p_idapp);

    $.ajax({
        url: route
    }).done(function (data) {
        $('#mbfdetails').html(data.msg);
        $('#sendmbfModal').modal();

    });
}

function exportApp(p_idapp) {
    route = "{{--route('applicationadminexport', ['id_app' => 0])--}}";
    route = route.replace('/0', '/' + p_idapp);
    window.location = route;
}
window.parent.$("body").scrollTop(0);

$(function () {
    $('#datenew').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
    });
});

</script>

@endsection
