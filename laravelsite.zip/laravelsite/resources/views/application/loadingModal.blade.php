<div id="loading_modal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm" style="width: 250px">
        <div class="modal-content text-center">
            <div class="modal-body">
                <img src="/img/loading.gif"><br/><br/>
                Loading. Please wait
            </div>
        </div>
    </div>
</div>