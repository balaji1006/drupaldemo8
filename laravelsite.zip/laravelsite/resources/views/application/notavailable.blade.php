@extends('layouts.master')
@section('title','Application')

@section('content')
<div id="content-register" class="text-center">
    <h1>Online Application</h1>
    <div class="row">
        <div class="col-xs-12 text-center">
            <div class="alert alert-danger">
                We're sorry! This page is not available. Please contact your Administrator for further assistance.
            </div>
        </div>
    </div>
</div>
@endsection
