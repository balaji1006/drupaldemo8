@extends('layouts.master')
@section('title','Online Application')

@section('content')


<div id="content-register" class="text-center">
    <h1>Online Application</h1>
    <h4>Please set your password to access our system</h4>
    <div class="row panels">
        <div class="col-sm-6 text-center"><img class="img-responsive" src="/img/application/devices.png"></div>
        <div class="col-sm-6">
            {!! Form::open(['route'=>['applicationcreateuserstore','partner'=>$partner,'company'=>$company],'method'=>'POST','id'=>'form']) !!}
            <div class="panel-shadow">
                <div class="panel panel-default">
                    <div class="panel-body formuser">
                        @if($errors->any())
                        <ul class="alert alert-danger">
                            @foreach($errors->all() as $error)
                            <li>{{$error}}</li>
                            @endforeach
                        </ul>
                        @endif

                        {!! Form::text('user',null,['class'=>'form-control form-group','required'=>true,'placeholder'=>'User']) !!}
                        {!! Form::password('password',['class'=>'form-control form-group','placeholder'=>'Password','id'=>'password']) !!}
                        {!! Form::password('password_confirmation',['class'=>'form-control form-group','required'=>true,'placeholder'=>'Repeat password']) !!}
                        <div class="popover-cont">
                            <div class="popover top">
                                <div class="arrow"></div>

                                <div class="popover-content validators">
                                    <div class="bad_validator" id='val5'>- Contain between 8 - 20 characters</div>
                                    <div class="bad_validator" id='val1'>- Include at least 1 UPPERCASE letter</div>
                                    <div class="bad_validator" id='val6'>- Include at least 1 lowercase letter</div>
                                    <div class="bad_validator" id='val2'>- Include at least one of the following allowable special characters: # $ @ _ !</div>
                                    <div class="bad_validator" id='val3'>- Include at least 1 number</div>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-lg">Set your password</button>
            </div>
            </form>
        </div>
    </div>
</div>
@stop
@section('footer1')
<script>
    $('#password').focus(function () {
        $('.popover-cont').fadeIn();
    });

    $('#password').keypress(function () {
        $("#form").valid();
    });

    $('#password').focusout(function () {
        $('.popover-cont').fadeOut();
    });

    $.validator.addMethod(
            "regex",
            function (value, element, regexp) {
                ok = true;
                re = new RegExp('[A-Z]');
                if (!re.test(value)) {
                    $('#val1').removeClass('good_validator');
                    ok = false;
                } else {
                    $('#val1').addClass('good_validator');
                }

                re = new RegExp('[a-z]');
                if (!re.test(value)) {
                    $('#val6').removeClass('good_validator');
                    ok = false;
                } else {
                    $('#val6').addClass('good_validator');
                }

                re = new RegExp('[@,#,!,_,$]');
                re2 = new RegExp('[&,%,^,*,?,~,.,?,/,+,-,|,<,>]');
                if (re.test(value) && !re2.test(value)) {
                    $('#val2').addClass('good_validator');

                } else {
                    $('#val2').removeClass('good_validator');
                    ok = false;
                }

                re = new RegExp('[0-9]');
                if (!re.test(value)) {
                    $('#val3').removeClass('good_validator');
                    ok = false;
                } else {
                    $('#val3').addClass('good_validator');
                }

                if (value.length < 8 || value.length > 20) {
                    $('#val5').removeClass('good_validator');
                    ok = false;
                } else {
                    $('#val5').addClass('good_validator');
                }

                if (!value)
                    ok = false;

                return ok;
            },
            "Please check your password."
            );

    $("#form").validate({
        //debug: true,
        ignore: '*:not([name])',
        rules: {
            user: {
                required: true,
            },
            password: {
                regex: '',
            },
            password_confirmation: {
                equalTo: "#password",
                minlength: 8
            }
        }
    });
</script>
@stop