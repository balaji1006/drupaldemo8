<table class="table table-striped">
    <thead>
        <tr>
            <th>Items</th>
            <th class="text-right">Pricing</th>
        </tr>
    </thead>
    <tbody>
        @foreach($ps as $p)
        <?php $p = get_object_vars($p); ?>
        <tr>
            <td>{{ $p['description'] }}<br/><span class="small_text">{{ $p['toptips'] }}</span></td>
            <td class="text-right">{{ $p['cost'] }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
<script src="{{ asset('js/pricing.js') }}"></script>