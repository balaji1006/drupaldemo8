
<section>
    <h4 class="header">Admin Information</h4>
    <hr/>
    <div class="row">
        <div class="col-sm-6 form-group">
            <label>Applications under partner</label>
            <select required name="select_partner" data="select_companies" class="form-control select_p">
                @foreach($partners as $p)
                <option <?php if ($p->partner_name == $partner) { ?>selected<?php } ?> value="{{ $p->id }}">{{ $p->partner_title }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-sm-6 form-group">
            <label>Applications under group</label>
            <select required name="select_companies" class="form-control" id="select_companies"></select>
        </div>
    </div>


    <script>

        function ajax_request(p_url, id_obj_response) {
            $.ajax({
                method: "GET",
                url: p_url
            })
                    .success(function (msg) {
                        $('#' + id_obj_response).html(msg);

                    });
        }


        $('.select_p').change(function () {

            id_ref = $(this).attr('data');
            url = "{{ route('companiesbypartner',['id_partner'=>'0']) }}";
            url = url.replace('/0', '/' + $(this).val());
            $.ajax({
                method: "GET",
                url: url
            })
                    .success(function (msg) {
                        $('#' + id_ref).html(msg);
                        refresh_pricing();
                    });
        });

        $('#select_companies').change(function () {
            refresh_pricing();
            if($('option:selected', this).attr('data')){
                $('#email_behalf').val($('option:selected', this).attr('data'));
            }
        });

        function refresh_pricing() {
            pricing_code = $('#pricing_code').val();
            if (!pricing_code){
            @if (isset($data['pricing_code']) && $data['pricing_code'])
                    @else
                    id_partner = $('.select_p').val();
            id_company = $('#select_companies').val();
            if (import_flag)
                url = "{{ route('apppricing',['partner'=>'000','company'=>'111','option'=>1]) }}";
            else
                url = "{{ route('apppricing',['partner'=>'000','company'=>'111','option'=>2]) }}";
            url = url.replace('/000/', '/' + id_partner + '/');
            url = url.replace('/111/', '/' + id_company + '/');
            if (id_partner) {

            $.ajax({
            method: "GET",
                    url: url
            })
                    .success(function (msg) {
                        $('#pricing').html(msg);
                        $('#default-pricing').html(msg);
                    });
            }
            @endif
            }
        }


        id_partner = $(".select_p option:selected").val();
        url = "{{ route('companiesbypartner',['id_partner'=>'0']) }}";
        url = url.replace('/0', '/' + id_partner);

        $.ajax({
            method: "GET",
            url: url
        })
                .success(function (msg) {
                    $('#select_companies').html(msg);
                    refresh_pricing();
                    if($('option:selected', $('#select_companies')).attr('data')){
                        $('#email_behalf').val($('option:selected', $('#select_companies')).attr('data'));
                    }
                });

    </script>

</section>