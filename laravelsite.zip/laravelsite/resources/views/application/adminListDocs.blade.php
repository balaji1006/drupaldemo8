@extends('layouts.master')
@section('title','Application')
@section('content')
<div class="normalheader ">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>


            <h2 class="font-light m-b-xs">
                Contracts
            </h2>
            <small>
                <ol class="hbreadcrumb breadcrumb">
                    <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                    <li><a href="<?php echo route('application', array('token' => $token)); ?>">Applications</a></li>
                    <li class="active">
                        <span>Contracts</span>
                    </li>

                </ol>
            </small>

        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">
        <div class="panel-heading">
            <div class="panel-tools">
                <a class="showhide"><i class="fa fa-chevron-up"></i></a>
            </div>
            <br>
        </div>
        <div class="panel-body" >
            <div class="marginb-20">
                <table class="table table-responsive table-striped table-bordered table-hover dataTable no-footer">
                    <thead>
                        <tr>
                            <th>Documents</th>
                            <th>Status</th>
                            <th>Place</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($env_documents as $Key => $docs) {
                            $dir = Config::get('onlineapp.upload_onlineapp_dir') . $Key;

                            foreach ($docs as $doc) {
                                ?>
                                <tr>
                                    <td ><?php echo $doc['name']; ?></td>
                                    <td ><?php if ($env_status[$Key] == 'completed') { ?><span class="badge alert-success">Signed</span><?php } else { ?><span class="label alert-danger pull-left">Pending to sign</span><?php } ?></td>
                                    <td >DocuSign</td>
                                    <?php
                                    $file = $dir . '/' . $doc['name'] . '.pdf';
                                    if (file_exists($file)) {
                                        ?>
                                        <td class="text-right"><a class="btndownload btn btn-xs btn-default" href="<?php echo route('downloadfileaux', array('dir' => $Key, 'file' => $doc['name'] . '.pdf')); ?>">Download</a></td>
                                        <?php
                                    } else {
                                        ?>
                                        <td class="text-right"><a class="btndownload btn btn-xs btn-default" href="<?php echo route('downloaddocds', array('uriencode' => base64_encode($doc['uri']), 'name' => $doc['name'])); ?>">Download</a></td>
                                        <?php
                                    }
                                    ?>

                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="panel-footer">
            Total {{count($env_documents)}} records
        </div>

    </div>
</div>
<script>
    $('.btndownload').click(function () {
        setTimeout(function () {
            $('#loading_layer').fadeOut();
        }, 3000);
    });
</script>
@endsection