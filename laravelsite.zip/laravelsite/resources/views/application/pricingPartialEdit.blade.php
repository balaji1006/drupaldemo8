
<table class="table table-striped">
    <thead>
        <tr>
            <th>Items</th>
            <th class="text-center">Select</th>
            <th class="text-right">Pricing</th>
        </tr>
    </thead>
    <tbody>
        @foreach($ps as $p)
        <tr>
            <td>{{ $p->description }}<br/><span class="small_text">{{ $p->toptips }}</span></td>
            <td class="text-center">
                @if($p->select==1) <input @if(Input::old('pricing_services_check_'.$p->id_p)) checked="checked" @else @if(isset($data["array_service"]['check_service'.$p->id_p])) checked="checked" @endif @endif type="checkbox" name="pricing_services_check_{{ $p->id_p }}" class="pricing_services_check" data="{{$p->service}}" value="{{$p->id_p}}"> @endif
                 @if($p->select==2) <input @if(Input::old($p['nameinput']) && Input::old($p['nameinput']) == $p->service) checked="checked" @endif type="radio" name="{{ $p->nameinput }}" class="pricing_services_radio @if(isset($data['array_service']['check_service'.$p->id_p])) radiocheck @endif " data="{{$p->service}}" value="{{$p->id_p}}"> @endif
            </td>
            <td class="text-right">{{ $p->cost }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
<script src="{{ asset('js/pricing.js') }}"></script>