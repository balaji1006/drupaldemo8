<?php

$merchant = !empty($merchant) ? $merchant : NULL;
foreach ($merchants as $m) {
    $selected = null;
    if ($m['id'] == $merchant)
        $selected = 'selected';
    echo '<option ' . $selected . '  value="' . $m['id'] . '">' . $m['name_clients'] . '</option>';
}
?>