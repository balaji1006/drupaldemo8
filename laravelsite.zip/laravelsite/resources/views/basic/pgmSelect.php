<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Page title -->
        <title><?php echo config('app.name'); ?></title>
        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->
        <!-- Vendor styles -->
        <link rel="stylesheet" href="<?php echo asset('vendor/fontawesome/css/font-awesome.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('vendor/metisMenu/dist/metisMenu.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('vendor/animate.css/animate.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('vendor/bootstrap/dist/css/bootstrap.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('vendor/toastr/build/toastr.min.css'); ?>" />
        <!-- App styles -->
        <link rel="stylesheet" href="<?php echo asset('fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('fonts/pe-icon-7-stroke/css/helper.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('css/style.css'); ?>">
        <link rel="stylesheet" href="<?php echo asset('css/custom.css'); ?>">
    </head>
    <body class="blank">
        <!--[if lt IE 7]>
        <p class="alert alert-danger">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <div class="color-line"></div>
        <div class="login-container">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center m-b-md">
                        <h3>PLEASE SELECT YOUR ENTITY</h3>
                        <small>This is the best app ever!</small>
                    </div>
                    <div class="hpanel">
                        <div class="panel-body">
                            <form action="<?php echo route('postselectpgm'); ?>" id="loginForm" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label class="control-label" for="username">Entity</label>
                                    <select class="form-control m-b" name="account">
                                        <?php
                                        foreach ($selection as $item) {
                                            $name = $item['name'];
                                            //unset($item['name']);
                                            if (isset($item['branch'])) {
                                                switch (strtoupper($item['level'])) {
                                                    case 'P':
                                                        echo "<option value='" . json_encode($item) . "'>" . $name . ' (Partner Branch)</option>';
                                                        break;
                                                    case 'G':
                                                        echo "<option value='" . json_encode($item) . "'>" . $name . ' (Group Branch)</option>';
                                                        break;
                                                    case 'M':
                                                        echo "<option value='" . json_encode($item) . "'>" . $name . ' (Merchant Branch)</option>';
                                                        break;
                                                }
                                            } else {
                                                switch (strtoupper($item['level'])) {
                                                    case 'P':
                                                        echo "<option value='" . json_encode($item) . "'>" . $name . ' (Partner)</option>';
                                                        break;
                                                    case 'G':
                                                        echo "<option value='" . json_encode($item) . "'>" . $name . ' (Group)</option>';
                                                        break;
                                                    case 'M':
                                                        echo "<option value='" . json_encode($item) . "'>" . $name . ' (Merchant)</option>';
                                                        break;
                                                }
                                            }
                                        }
                                        ?>
                                    </select>

                                </div>


                                <button class="btn btn-success btn-block">Login</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div id="loading_layer">
            <img src="{{ asset('img/loadinggif.gif') }}">
        </div>


        <!-- Vendor scripts -->
        <script src="<?php echo asset('vendor/jquery/dist/jquery.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/jquery-ui/jquery-ui.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/slimScroll/jquery.slimscroll.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/metisMenu/dist/metisMenu.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/iCheck/icheck.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/sparkline/index.js'); ?>"></script>
        <script src="<?php echo asset('vendor/toastr/build/toastr.min.js'); ?>"></script>

        <!-- App scripts -->
        <script src="<?php echo asset('js/homer.js'); ?>"></script>
        <script>
            toastr.options = {
            "debug": false,
                    "newestOnTop": false,
                    "positionClass": "toast-top-center",
                    "closeButton": true,
                    "toastClass": "animated fadeInDown",
            }

            @if ($errors - > has('login'))
                    Command: toastr["error"]("{{ $errors->first('login') }}", "Error")
                    @endif

            window.onbeforeunload = function (e) {
                $('#loading_layer').fadeIn();
            }
        </script>
    </body>
</html>