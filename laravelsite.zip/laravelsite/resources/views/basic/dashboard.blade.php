@extends('layouts.layout')

@section('content')
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="hpanel">
                <div class="panel-heading">
                    <div class="panel-tools">
                        <a class="showhide"><i class="fa fa-chevron-up"></i></a>
                    </div>
                    Dashboard information and statistics
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-3 text-center">
                            <div class="small">
                                <i class="fa fa-bolt"></i> Activity
                            </div>
                            <div>
                                <h1 class="font-extra-bold m-t-xl m-b-xs">
                                    $<?php
                                    if(isset($total))
                                        echo number_format($total, 2);
                                    else{
                                        echo number_format(0, 2);
                                    }
                                    ?>
                                </h1>
                                <small>Payment Volume</small>
                            </div>
                            <div class="small m-t-xl">
                                <i class="fa fa-clock-o"></i> Data from last year
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="text-center small">
                                <i class="fa fa-bar-chart"></i> Your last year activities in a chart
                            </div>
                            <div class="flot-chart" style="height: 160px">
                                <div class="flot-chart-content" id="flot-line-chart"></div>
                            </div>
                        </div>
                        <div class="col-md-3 text-center">
                            <div class="small">
                                <i class="fa fa-calendar"></i> Since
                                <?php
                                if(isset($records) && $records->all()){
                                    $recordsArray = $records->all();
                                    $firstDate = $recordsArray[0];
                                    $firstDate = explode('-',$firstDate['tx_date']);
                                    echo $firstDate[0];
                                }
                                ?>
                            </div>
                            <div>
                                <h1 class="font-extra-bold m-t-xl m-b-xs">
                                    <?php
                                    if(isset($count))
                                        echo $count;
                                    else{
                                        echo 0;
                                    }
                                    ?> Payments
                                </h1>
                                <small>In 12 months</small>
                            </div>
                            <div class="small m-t-xl">
                                <?php if(isset($last_date)){
                                    $last_date_time = strtotime($last_date);
                                    ?>
                                    <i class="fa fa-clock-o"></i> Last payment in <?php echo date("M d, Y",$last_date_time); ?>
                                <?php } ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-footer">
                <span class="pull-right">
                      Last update: <?php echo date("M d, Y"); ?>
                    </span>
                    &nbsp;
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4">
            <div class="hpanel">
                <div class="panel-body text-center h-200">
                    <i class="pe-7s-credit fa-4x"></i>

                    <h1 class="m-xs">$<?php if(isset($settlement)){
                            echo number_format($settlement, 2);
                        }else{
                            echo number_format(0, 2);
                        } ?></h1>

                    <h3 class="font-extra-bold no-margins text-success">
                        Expected Deposit
                    </h3>
                    <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit vestibulum.</small>
                </div>
                <div class="panel-footer">
                    Go to <a href="" class="underline">Report</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="hpanel stats">
                <div class="panel-body h-200">
                    <div class="stats-title pull-left">
                        <h4>Payors Total</h4>
                    </div>
                    <div class="stats-icon pull-right">
                        <i class="pe-7s-users fa-4x"></i>
                    </div>
                    <div class="m-t-xl">
                        <h3 class="m-b-xs"><?php
                            if(isset($payors['total']))
                                echo $payors['total'];
                            else
                                echo 0;
                            ?></h3>
                        <span class="font-bold no-margins">
                    Payors
                </span>

                        <div class="progress m-t-xs full progress-small">
                            <?php
                            $rate = 0;
                            if(isset($payors['rate'])) {
                                if($payors['rate'] >= 100)
                                {
                                    $rate = 100;
                                }
                                else{
                                    $rate =  $payors['rate'];
                                }

                            }
                            ?>

                            <div style="width: <?php echo $rate;?>%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="<?php echo $rate;?>"
                                 role="progressbar" class=" progress-bar progress-bar-success">
                                <span class="sr-only"><?php echo $rate;?>% Complete</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-6">
                                <small class="stats-label">Active</small>
                                <h4><?php if(isset($payors['active']))
                                        echo $payors['active'];
                                    else
                                        echo 0;
                                    ?></h4>
                            </div>

                            <div class="col-xs-6">
                                <small class="stats-label">Adoption Rate</small>
                                <h4><?php if(isset($payors['rate']))
                                        echo $payors['rate'];
                                    else
                                        echo 0;
                                    ?>%</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-footer">
                    Go to <a href="" class="underline">Report</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="hpanel stats">
                <div class="panel-body h-200">
                    <div class="stats-title pull-left">
                        <h4>Actives Autopayments</h4>
                    </div>
                    <div class="stats-icon pull-right">
                        <i class="pe-7s-refresh fa-3x"></i>
                    </div>
                    <div class="m-t-xl">
                        <h1 class="text-success"><?php if(isset($autopayments)){ echo $autopayments; }else{ echo 0;}?> Actives</h1>
                        <span class="font-bold no-margins">
                    Social users
                </span>
                        <br/>
                        <small>
                            Lorem Ipsum is simply dummy text of the printing and <strong>typesetting
                                industry</strong>. Lorem Ipsum has been.
                        </small>
                    </div>
                </div>
                <div class="panel-footer">
                    Go to <a href="" class="underline">Report</a>
                </div>
            </div>
        </div>

    </div>
    <div class="row">

        <div class="col-lg-3">
            <div class="hpanel">
                <div class="panel-heading">
                    <div class="panel-tools">
                        <a class="showhide"><i class="fa fa-chevron-up"></i></a>
                    </div>
                    Activity Today
                </div>
                <div class="panel-body list">

                    <div class="pull-right">
                        <span class="label label-default">12 hours</span>
                    </div>
                    <div class="panel-title">Last Activity</div>
                    <small class="fo">This is simple example</small>
                    <div class="list-item-container">
                        <?php
                        $total_ra_volume = 0;
                        if(isset($recent_activity)){
                            foreach ($recent_activity as $activity) {
                                $total_ra_volume += $activity['volume'];
                                ?>
                                <div class="list-item">
                                    <h3 class="no-margins text-success">$<?php echo number_format($activity['volume'],2);?></h3>
                                    <small><?php
                                        switch (strtolower($activity['method'])){
                                            case 'cc':
                                                echo 'Credit card ';
                                                break;
                                            case 'ec':
                                                echo 'E-check ';
                                                break;
                                            case 'cash':
                                                echo 'Cash ';
                                                break;
                                            case 'amex':
                                                echo 'American Express ';
                                                break;
                                        }
                                        ?> Volume</small>
                                    <div class="pull-right font-bold">Qty <?php echo $activity['qty']; ?> <i class="fa fa-level-up text-success"></i></div>
                                </div>
                                <?php
                            }

                        }

                        ?>



                        <div class="list-item">
                            <h3 class="no-margins font-extra-bold text-success">$<?php echo number_format($total_ra_volume, 2); ?></h3>
                            <small>Tota Volume last 12 hours</small>
                            <div class="pull-right font-bold"> </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <div class="hpanel">
                <div class="panel-heading">
                    <div class="panel-tools">
                        <a class="showhide"><i class="fa fa-chevron-up"></i></a>
                    </div>
                    Recent Payments
                </div>
                <div class="panel-body list">
                    <div class="table-responsive project-list">
                        <table class="table table-striped">
                            <thead>
                            <tr>

                                <th colspan="2">Method</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th class="pull-right">Status</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                                if(isset($recent_payments) && $recent_payments){
                                foreach ($recent_payments as $recent_payment){
                                ?>
                                    <tr>
                                        <td>
                                            <?php
                                            \App\Http\Controllers\ComponentsController::payIconImage($recent_payment['trans_card_type']);
                                            ?>
                                        </td>
                                        <td>
                                            <?php echo $recent_payment['trans_card_type']; ?><br/>
                                            <small><i class="fa fa-clock-o"></i> <?php echo date("M d, Y",strtotime( $recent_payment['trans_first_post_date']));?></small>
                                        </td>
                                        <td>
                                            <?php
                                            if($recent_payment['trans_status']==1){
                                                switch ($recent_payment['trans_type']){
                                                    case 0:
                                                        echo 'Onetime';
                                                        break;
                                                    case 1:
                                                        echo 'Autopayment';
                                                        break;
                                                    case 2:
                                                        echo 'Returned';
                                                        break;
                                                    case 5:
                                                        echo 'Refunded';
                                                        break;
                                                    case 9:
                                                        echo 'Void';
                                                        break;
                                                    default:
                                                        echo '-';

                                                }
                                            }
                                            else{
                                                echo '-';
                                            }

                                            ?>
                                        </td>
                                        <td>
                                            $<?php echo number_format($recent_payment['trans_net_amount'], 2); ?>
                                        </td>

                                        <td>
                                            <?php
                                            if($recent_payment['trans_status']==1){
                                                echo '<span class="label label-success pull-right">Approve</span>';
                                            }
                                            elseif($recent_payment['trans_status']==0){
                                                echo '<span class="label label-warning pull-right">Error</span>';
                                            }
                                            else{
                                                echo '<span class="label label-danger pull-right">Declined</span>';
                                            }
                                            ?>

                                        </td>
                                    </tr>
                                <?php
                                    }
                                }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
@stop

@section('scripts')
    <script>
        $(function () {

            /**
             * Flot charts data and options
             */

                    <?php
                    $string ='';
                    $stringMonths ='';
                    foreach ($records->all() as $record => $val) {
                        $string.='['.$record.', '.$val['net_amount'].'],';
                        $stringMonths.='['.$record.', "'.$val['tx_date'].'"],';
                    }

                    $string = rtrim($string,",");
                    $stringMonths = rtrim($stringMonths,",");
                    ?>

            var data1 = [ <?php echo $string; ?>];

            var chartUsersOptions = {
                series: {
                    splines: {
                        show: true,
                        tension: 0.4,
                        lineWidth: 1,
                        fill: 0.4
                    },
                },
                grid: {
                    tickColor: "#f0f0f0",
                    borderWidth: 1,
                    borderColor: 'f0f0f0',
                    color: '#6a6c6f'
                },
                colors: [ "#62cb31", "#efefef"],
                xaxis: { ticks:[<?php echo $stringMonths; ?>]}
            };

            $.plot($("#flot-line-chart"), [data1], chartUsersOptions);

            /**
             * Flot charts 2 data and options
             */
            var chartIncomeData = [
                {
                    label: "line",
                    data: [ [1, 10], [2, 26], [3, 16], [4, 36], [5, 32], [6, 51] ]
                }
            ];

            var chartIncomeOptions = {
                series: {
                    lines: {
                        show: true,
                        lineWidth: 0,
                        fill: true,
                        fillColor: "#64cc34"

                    }
                },
                colors: ["#62cb31"],
                grid: {
                    show: false
                },
                legend: {
                    show: false
                }
            };

            $.plot($("#flot-income-chart"), chartIncomeData, chartIncomeOptions);



        });
    </script>
@stop