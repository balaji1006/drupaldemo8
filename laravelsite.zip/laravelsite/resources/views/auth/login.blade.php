<!DOCTYPE html>
<html>
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <!-- Page title -->
        <title>{{config('app.name')}}</title>

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->

        <!-- Vendor styles -->
        <link rel="stylesheet" href="<?php echo asset('vendor/fontawesome/css/font-awesome.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('vendor/metisMenu/dist/metisMenu.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('vendor/animate.css/animate.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('vendor/bootstrap/dist/css/bootstrap.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('vendor/toastr/build/toastr.min.css'); ?>" />

        <!-- App styles -->
        <link rel="stylesheet" href="<?php echo asset('fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('fonts/pe-icon-7-stroke/css/helper.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('css/style.css'); ?>">
        <link rel="stylesheet" href="<?php echo asset('css/custom.css'); ?>">

    </head>
    <body class="blank">

        <!--[if lt IE 7]>
        <p class="alert alert-danger">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <div class="color-line"></div>


        <div class="login-container">

            <div class="row">
                <div class="col-md-12">

                    <div class="hpanel">
                        <div class="panel-body">
                            <div class="logocont" style="text-align: center;">
                                <?php if(isset($logo)){
                                $shadow = '';
                                if(substr($logo, -4)!='.svg'){
                                    $shadow = "logoshadow";
                                }
                                ?><img id="logologin" class="<?php echo $shadow; ?>" src="{{ asset($logo) }}"><?php
                                }
                                else{
                                ?><img id="logologin" src="{{ asset('img/revo.svg') }}"><?php
                                }
                                ?>

                                @if(isset($name))
                                    <h4>{{ $name }}</h4>
                                @endif
                            </div>
                            <div class="text-center m-b-md">

                                <small>Please Login to continue</small>
                            </div>
                            <form action="<?php echo route('login'); ?>" id="loginForm" method="POST">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <label class="control-label" for="username">Username</label>
                                    <input type="text" placeholder="example@gmail.com" title="Please enter your username" name="login" value="{{ old('login') }}" required autofocus id="username" class="form-control">
                                    <input type="hidden" name="level" value="{{ $level ?? null }}">
                                    <input type="hidden" name="subdomain" value="{{ $subdomain ?? null }}">
                                    <!--<span class="help-block small">Your unique username to app</span>-->
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="password">Password</label>
                                    <input type="password" title="Please enter your password" placeholder="******" required="" value="" name="password" id="password" class="form-control">
                                    <!--<span class="help-block small">Your strong password</span>-->
                                </div>

                                <button class="btn btn-success btn-block">Login</button>
                                <!--<a class="btn btn-default btn-block" href="#">Register</a>-->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!--            <div class="row">
                            <div class="col-md-12 text-center">
                                <strong>HOMER</strong> - AngularJS Responsive WebApp <br/> 2015 Copyright Company Name
                            </div>
                        </div>-->
        </div>
        <div id="loading_layer">
            &nbsp;
            <img src="{{ asset('img/loadinggif.gif') }}">
        </div>

        <!-- Vendor scripts -->
        <script src="<?php echo asset('vendor/jquery/dist/jquery.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/jquery-ui/jquery-ui.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/slimScroll/jquery.slimscroll.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/metisMenu/dist/metisMenu.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/iCheck/icheck.min.js'); ?>"></script>
        <script src="<?php echo asset('vendor/sparkline/index.js'); ?>"></script>
        <script src="<?php echo asset('vendor/toastr/build/toastr.min.js'); ?>"></script>

        <!-- App scripts -->
        <script src="<?php echo asset('js/homer.js'); ?>"></script>
        <script>


            toastr.options = {
                "debug": false,
                "newestOnTop": false,
                "positionClass": "toast-top-center",
                "closeButton": true,
                "toastClass": "animated fadeInDown",
            };

            @if (session('status'))
            toastr["error"]("Login Failed", "Error");
            @endif

            window.onbeforeunload = function (e) {
                $('#loading_layer').fadeIn();
            }
        </script>
    </body>
</html>