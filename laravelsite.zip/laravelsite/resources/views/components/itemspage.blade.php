<div class="col-md-1 col-xs-4" id="itempage">
    <?php if (isset($itemspage)) { ?>
    <select class="form-control items-per-page">
        <option value="15" <?= $itemspage == 15 ? 'selected' : NUll ?>>15</option>
        <option value="25" <?= $itemspage == 25 ? 'selected' : NUll ?>>25</option>
        <option value="50" <?= $itemspage == 50 ? 'selected' : NUll ?>>50</option>
        <option value="100" <?= $itemspage == 100 ? 'selected' : NUll ?>>100</option>
    </select>
    <?php } ?>
</div>

<script>
    $(document).ready(function () {

        $('.items-per-page').change(function () {
            val = $(this).val();
            if (document.location.href.indexOf('?') != -1) {
                var currentUrl = document.location.href.split('?');
                var arr = currentUrl[1].split('&');
                console.log(arr);
                var arr1 = [];
                for (x in arr) {
                    if (arr[x].search('itemspage') == -1) {
                        arr1.push(arr[x]);
                    }
                }
                var url = currentUrl[0] + '?&itemspage=' + val;
                for (x in arr1) {
                    url += '&' + arr1[x];
                }

            } else {
                var url = document.location.href + "?itemspage=" + val;
            }

            document.location = url;
        });
    });
</script>