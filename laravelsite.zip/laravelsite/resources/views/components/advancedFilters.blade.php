<?php if(isset($advFilter)): ?>

<button class="btn btn-default" data-toggle="modal" data-target="#advancedFilters" id="advancedFiltersBtn">Advanced filters</button>

<div id="advancedFilters" class="modal fade hmodal-success" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="color-line"></div>

            <div class="modal-body advanced-filters">
                <label>Advanced Filters</label>
                <br/>
                <div id="fil">
                
                </div>    
            </div>
            
            <div class="modal-footer">
                <div class="row">
                    <div class="col-xs-6">
                        <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
                    </div>
                    <div class="col-xs-6">
                        <button type="button" class="btn btn-primary btn-block" onclick="clicksearch()">Filter</button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<script src="{{ URL::asset('/js/base64.js') }}"></script>
<script src="{{ URL::asset('/js/jquery.searchFilter.js') }}"></script>

<script>
    var colModel=<?php echo json_encode($advFilter); ?>;

    $("#fil").searchFilter(colModel);
 $(document).ready(function () {
        $('#advadd').click(function () {
            $("#fil").searchFilter().add();
        });
        $('#advrst').click(function () {
            $("#fil").searchFilter().reset();
        });
        
        });
        
 function clicksearch(){
    var data=$("#fil").searchFilter().getData();
    var url='{{$advFilterRoute}}/'+Base64.encode(data);
    window.location.href=url;
 }
 
</script>
<?php endif; ?>
