<link rel="stylesheet" href="{{asset('vendor/toastr/build/toastr.min.css')}}" />
<script src="{{asset('vendor/toastr/build/toastr.min.js')}}"></script>
<style>
    .toast-title {
        color: #4cae4c;
    }
    .toast-message,.toast-close-button {
        color: #34495e;
    }

</style>
<script>
    toastr.options = {
    "debug": false,
            "newestOnTop": false,
            "positionClass": "toast-top-center",
            "closeButton": true,
            "toastClass": "animated fadeInDown",
    };
    @switch ($type)
            @case('success')
            toastr.success('{{$msg}}');
    @break

            @case('warning')
            toastr.warning('{{$msg}}');
    @break

            @case('error')
            toastr.error('{{$msg}}');
    @endswitch
</script>