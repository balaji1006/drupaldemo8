@yield('before-export')
<button data-toggle="dropdown" class="btn btn-success btn-outline dropdown-toggle" id="exportBtnDropDown" aria-expanded="false">Export <span class="caret"></span></button>
<ul class="dropdown-menu dropdown-menu-right">
    <li><a href="@yield('export-excel-url')" id="export-excel">Excel</a></li>
    <li><a href="@yield('export-csv-url')" id="export-csv">CSV</a></li>
    @hasSection('exportwizard-url')
    <li class="divider"></li>
    <li><a href="@yield('exportwizard-url')">Export Wizard</a></li>
    @endif
</ul>
@yield('after-export')
@push('footer-scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.fileDownload/1.4.2/jquery.fileDownload.min.js"></script>
<script>
$(function() {
    $('#export-csv,#export-excel').click(function() {
         $.fileDownload($(this).attr('href'), {
             prepareCallback: function (url) { 
                $('#exportBtnDropDown').html('<img src="<?php echo asset('img/processing.gif'); ?>" style="height: 15px"> Processing...');
                $('body').click();
             },
             successCallback: function (url) {
                 $('body').click();
                $('#exportBtnDropDown').html('Export <span class="caret"></span>');                
             },
             abortCallback: function (url) {
                 $('body').click();
                $('#exportBtnDropDown').html('Export <span class="caret"></span>');
             }
         });
        return false; //this is critical to stop the click event which will trigger a normal file download!
    });
});
</script>
@endpush