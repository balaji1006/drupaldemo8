@push('footer-scripts')
<script src="{{asset('tinymce/tinymce.min.js')}}" type="text/javascript"></script>
<script>
tinymce.init({
  selector: '.tinymce-editor',
  height: 300,
  theme: 'modern',
  menubar: false,
  plugins: [
    'advlist autolink lists link image charmap print preview anchor textcolor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table contextmenu paste code'
  ],
  toolbar: 'undo redo |  formatselect | bold italic forecolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat link table',
  content_css: [
    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    "{{asset('vendor/bootstrap/dist/css/bootstrap.min.css')}}"
  ],
  content_style: "body {padding: 1%}"
});
</script>
@endpush