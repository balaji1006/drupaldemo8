@extends('layouts.master')
@section('title','Email Template')
@section('content')
<div class="normalheader">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>

            <h2 class="font-light m-b-xs">
                Email Template
            </h2>
            <small>
                <ol class="hbreadcrumb breadcrumb">
                    <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                    <li class="active">
                        <span>Email Template</span>
                    </li>
                </ol>
            </small>
        </div>
    </div>
</div>
@include('components.tinymce')
<div class="content">
    <div class="hpanel">
        <div class="panel-body">

        <form method="post" action="<?php echo route('saveetemplates'); ?>" id="formNotification">
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" >
            <input type="hidden" name="tokendata" value="<?php echo $token; ?>" >

            <div class="row">
                <div class="col-md-9">
                    <?php if (isset($settings['SUCCESSFULEMAIL'])): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <b>Successful Payment Receipt</b>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <label>Subject:</label>
                                <input type="text" class="form-control" id="SUCCESSFULEMAIL_SUBJECT" name="SUCCESSFULEMAIL_SUBJECT" value="<?php echo $settings['SUCCESSFULEMAIL_SUBJECT']; ?>">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-12">
                                <br><textarea id="SUCCESSFULEMAIL" name="SUCCESSFULEMAIL" class="form-control tinymce-editor" style="min-height: 200px;"><?php echo $settings['SUCCESSFULEMAIL']; ?></textarea>
                            </div>
                        </div>
                        <br>
                    <?php endif; ?>
                    <?php if (isset($settings['UNSUCCESSFULEMAIL'])): ?>
                        <div class="row">
                            <div class="col-xs-12">
                                <b>Unsuccessful Payment Receipt</b>
                                <br/>
                                <label>Subject:</label>
                                <input class="form-control" type="text" id="UNSUCCESSFULEMAIL_SUBJECT" name="UNSUCCESSFULEMAIL_SUBJECT" value="<?php echo $settings['UNSUCCESSFULEMAIL_SUBJECT']; ?>">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-12">
                                <br><textarea id="UNSUCCESSFULEMAIL" name="UNSUCCESSFULEMAIL" class="form-control tinymce-editor" style="min-height: 200px;"><?php echo $settings['UNSUCCESSFULEMAIL']; ?></textarea>
                            </div>
                        </div>

                        <br/>
                    <?php endif; ?>
                    <?php if (isset($settings['RECCURRINGENDEMAIL'])): ?>
                        <div class="row">
                            <div class="col-xs-12">
                                <b>Completed Recurring Payment</b>
                                <br/>
                                <label>Subject:</label>
                                <input type="text" class="form-control" id="RECCURRINGENDEMAIL_SUBJECT" name="RECCURRINGENDEMAIL_SUBJECT" value="<?php echo $settings['RECCURRINGENDEMAIL_SUBJECT']; ?>"><br>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-12">
                                <br><textarea id="RECCURRINGENDEMAIL" name="RECCURRINGENDEMAIL" class="form-control tinymce-editor" style="min-height: 200px;"><?php echo $settings['RECCURRINGENDEMAIL']; ?></textarea>
                                <br/>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($settings['RECURRINGEXPIRESEMAIL'])): ?>
                        <div class="row">
                            <div class="col-xs-12">
                                <b>Close to expire Recurring payment</b>
                                <br/>
                                <label>Subject:</label>
                                <input class="form-control" type="text" id="RECURRINGEXPIRESEMAIL_SUBJECT" name="RECURRINGEXPIRESEMAIL_SUBJECT" value="<?php echo $settings['RECURRINGEXPIRESEMAIL_SUBJECT']; ?>"> <br>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <br><textarea id="RECURRINGEXPIRESEMAIL" name="RECURRINGEXPIRESEMAIL" class="form-control tinymce-editor" style="min-height: 200px;"><?php echo $settings['RECURRINGEXPIRESEMAIL']; ?></textarea>
                                <br/>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($settings['INSFEMAIL'])): ?>
                        <div class="row">
                            <div class="col-xs-12">
                                <b>Returned payment</b><br/>
                                <label>Subject:</label>
                                <input type="text" id="INSFEMAIL_SUBJECT" name="INSFEMAIL_SUBJECT" class="form-control" value="<?php echo $settings['INSFEMAIL_SUBJECT']; ?>"> <br>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <br><textarea id="INSFEMAIL" name="INSFEMAIL" class="form-control tinymce-editor" style="min-height: 200px;"><?php echo $settings['INSFEMAIL']; ?></textarea>
                                <br/>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-3">
                    <div class="panel panel-default" style="border: none; box-shadow: none; background-color: #F4F4F4; padding: 15px">
                    <div class="panel-body" style="font-size: 12px">

                        The following fields can be used in the email templates:<br><br>
                        <div data-toggle="tooltip" data-placement="left" title="place Merchant Logo here">[:LOGO:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="place link to create a customer ticket here">[:TICKETLINK:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print transaction date here">[:TRANS_DATE:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print transaction reference number here">[:REFNUM:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print transaction authorization code here">[:AUTHNUM:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print merchant name here">[:DBA_NAME:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's account number here">[:ACCOUNT_NUMBER:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's first name here">[:FIRSTNAME:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's last name here">[:LASTNAME:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's unit here">[:UNIT:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print settlement disclaimer here">[:DISCLAIMER:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payment details here">[:DESCRIPTION:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print group contact name here">[:CONTACTNAME:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print group name here">[:COMPANYNAME:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print autopayment next date here">[:NEXTDATE:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="place link to login page here">[:LOGINLINK:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payment net amount here">[:NETAMOUNT:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's address here">[:UADDR:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's city here">[:UCITY:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's state here">[:USTATE:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's zip here">[:UZIP:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's phone number here">[:UPHONE:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payment source here">[:SOURCE:]</div>
                        <div data-toggle="tooltip" data-placement="left" title="print payor's email here">[:UEMAIL:]</div><br>
                        <div data-toggle="tooltip" data-placement="left" title="print custom fields">[:CUSTOMFIELD:]</div><br>

                    </div>
                    </div>
                </div>
            </div>

            <div class="hr-line-dashed"></div>

            <div class="row">
                <div class="col-xs-2">
                    <button class="btn btn-primary btn-full" type="submit">Save Settings</button>
                </div>
                <div class="col-xs-8">
                    <?php if ($level != 'M'): ?>
                        <div class="checkbox checkbox-success">
                            <input type="checkbox"  class="styled" id="propagate" name="propagate"  style="cursor:pointer" >
                            <label for="propagate" style="cursor:pointer">
                                Apply these settings to all levels below this one.
                            </label>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </form>


        </div>
    </div>
</div>

@endsection
