@extends('layouts.master')
@section('title','Layout')
@section('content')
<div class="normalheader">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <h2 class="font-light m-b-xs">
                Layout
            </h2>
            <small>
                <ol class="hbreadcrumb breadcrumb">
                    <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                    <li class="active">
                        <span>Layout</span>
                    </li>
                </ol>
            </small>
        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">
        <div class="panel-body">

                        <form method="post" action="<?php echo route('savelayout');?>" id="formNotification">
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" >  
                        <input type="hidden" name="tokendata" value="<?php echo $token; ?>" >
                        <?php if(isset($settings['FAVORITES_TILES'])): ?>
                        <?php $tiles=explode('|',$settings['FAVORITES_TILES']); ?>
                    <div class="row"> 
                        <div class="col-xs-12 ">
                        <label>Admin's favorites tiles (you will need re-load the home page):</label>
                        </div>
                        <div class="col-md-4 form-group">
                            <small>Fav 1:</small> <br/><select id="favorites1" name="favorites1" class="form-control">
	        			<option value="transactions.php" <?php if (isset($tiles[0]) && $tiles[0] == 'transactions.php') echo 'selected="selected"'; ?>>Transactions</option>
	        			<option value="deposits.php" <?php if ((isset($tiles[0]) && $tiles[0] == 'deposits.php') || empty($settings['favorites_tiles'])) echo 'selected="selected"'; ?>>Deposits</option>
	        			<option value="recurring.php" <?php if (isset($tiles[0]) && $tiles[0] == 'recurring.php') echo 'selected="selected"'; ?>>Recurring</option>
	        			<option value="group.php" <?php if (isset($tiles[0]) && $tiles[0] == 'group.php') echo 'selected="selected"'; ?>>Groups</option>
	        			<option value="merchants.php" <?php if (isset($tiles[0]) && $tiles[0] == 'merchants.php') echo 'selected="selected"'; ?>>Merchants</option>
	        			<option value="admins.php" <?php if (isset($tiles[0]) && $tiles[0] == 'admins.php') echo 'selected="selected"'; ?>>Admins</option>
	        			<option value="customers.php" <?php if (isset($tiles[0]) && $tiles[0] == 'customers.php') echo 'selected="selected"'; ?>>WebUsers</option>
	        			<option value="customize.php" <?php if (isset($tiles[0]) && $tiles[0] == 'customize.php') echo 'selected="selected"'; ?>>Customize</option>
	        			<option value="tickets.php" <?php if (isset($tiles[0]) && $tiles[0] == 'tickets.php') echo 'selected="selected"'; ?>>Tickets History</option>
                                        <?php if(isset($einv) && $einv==1): ?>
	        			<option value="einvoices.php" <?php if (isset($tiles[0]) && $tiles[0] == 'einvoices.php') echo 'selected="selected"'; ?>>E-Invoices</option>
                                        <?php endif; ?>
                                       <?php if(isset($eterm) && $eterm==1): ?>
	        			<option value="eterminal.php" <?php if (isset($tiles[0]) && $tiles[0] == 'eterminal.php') echo 'selected="selected"'; ?>>E-Terminal</option>
                                        <?php endif; ?>
	        		</select>
                        </div>
                        <div class="col-md-4 form-group">
                            <small>Fav 2:</small> <br/><select id="favorites2" name="favorites2" class="form-control">
	        			<option value="transactions.php" <?php if (isset($tiles[1]) && $tiles[1] == 'transactions.php') echo 'selected="selected"'; ?>>Transactions</option>
	        			<option value="deposits.php" <?php if ((isset($tiles[1]) && $tiles[1] == 'deposits.php') ) echo 'selected="selected"'; ?>>Deposits</option>
	        			<option value="recurring.php" <?php if (isset($tiles[1]) && $tiles[1] == 'recurring.php') echo 'selected="selected"'; ?>>Recurring</option>
	        			<option value="group.php" <?php if (isset($tiles[1]) && $tiles[1] == 'group.php') echo 'selected="selected"'; ?>>Groups</option>
	        			<option value="merchants.php" <?php if (isset($tiles[1]) && $tiles[1] == 'merchants.php') echo 'selected="selected"'; ?>>Merchants</option>
	        			<option value="admins.php" <?php if (isset($tiles[1]) && $tiles[1] == 'admins.php') echo 'selected="selected"'; ?>>Admins</option>
	        			<option value="customers.php" <?php if (isset($tiles[1]) && $tiles[1] == 'customers.php') echo 'selected="selected"'; ?>>WebUsers</option>
	        			<option value="customize.php" <?php if (isset($tiles[1]) && $tiles[1] == 'customize.php') echo 'selected="selected"'; ?>>Customize</option>
	        			<option value="tickets.php" <?php if (isset($tiles[1]) && $tiles[1] == 'tickets.php') echo 'selected="selected"'; ?>>Tickets History</option>
                                        <?php if(isset($einv) && $einv==1): ?>
	        			<option value="einvoices.php" <?php if (isset($tiles[1]) && $tiles[1] == 'einvoices.php') echo 'selected="selected"'; ?>>E-Invoices</option>
                                        <?php endif; ?>
                                       <?php if(isset($eterm) && $eterm==1): ?>
	        			<option value="eterminal.php" <?php if (isset($tiles[1]) && $tiles[1] == 'eterminal.php') echo 'selected="selected"'; ?>>E-Terminal</option>
                                        <?php endif; ?>
	        		</select>
                        </div>
                        <div class="col-md-4 form-group">
                            <small>Fav 3:</small> <br/><select id="favorites3" name="favorites3" class="form-control">
	        			<option value="transactions.php" <?php if (isset($tiles[2]) && $tiles[2] == 'transactions.php') echo 'selected="selected"'; ?>>Transactions</option>
	        			<option value="deposits.php" <?php if ((isset($tiles[2]) && $tiles[2] == 'deposits.php') ) echo 'selected="selected"'; ?>>Deposits</option>
	        			<option value="recurring.php" <?php if (isset($tiles[2]) && $tiles[2] == 'recurring.php') echo 'selected="selected"'; ?>>Recurring</option>
	        			<option value="group.php" <?php if (isset($tiles[2]) && $tiles[2] == 'group.php') echo 'selected="selected"'; ?>>Groups</option>
	        			<option value="merchants.php" <?php if (isset($tiles[2]) && $tiles[2] == 'merchants.php') echo 'selected="selected"'; ?>>Merchants</option>
	        			<option value="admins.php" <?php if (isset($tiles[2]) && $tiles[2] == 'admins.php') echo 'selected="selected"'; ?>>Admins</option>
	        			<option value="customers.php" <?php if (isset($tiles[2]) && $tiles[2] == 'customers.php') echo 'selected="selected"'; ?>>WebUsers</option>
	        			<option value="customize.php" <?php if (isset($tiles[2]) && $tiles[2] == 'customize.php') echo 'selected="selected"'; ?>>Customize</option>
	        			<option value="tickets.php" <?php if (isset($tiles[2]) && $tiles[2] == 'tickets.php') echo 'selected="selected"'; ?>>Tickets History</option>
                                        <?php if(isset($einv) && $einv==1): ?>
	        			<option value="einvoices.php" <?php if (isset($tiles[2]) && $tiles[2] == 'einvoices.php') echo 'selected="selected"'; ?>>E-Invoices</option>
                                        <?php endif; ?>
                                       <?php if(isset($eterm) && $eterm==1): ?>
	        			<option value="eterminal.php" <?php if (isset($tiles[2]) && $tiles[2] == 'eterminal.php') echo 'selected="selected"'; ?>>E-Terminal</option>
                                        <?php endif; ?>
	        		</select>
                        </div>
                    </div> 

                        <?php endif; ?>





                    <div class="row">
                        <?php if(isset($settings['HIDEMERCHANTINFO'])): ?>
                         <div class="col-md-4 form-group">
                            <label> In external pages (registration, login, quickpay, etc): </label>
                             <div class="checkbox checkbox-success">
                                 <input type="checkbox"  class="styled" id="hidemerchantinfo" name="hidemerchantinfo" <?php if (isset($settings['HIDEMERCHANTINFO']) && $settings['HIDEMERCHANTINFO']== "1") echo 'checked'; ?> style="cursor:pointer" >
                                 <label for="hidemerchantinfo" style="cursor:pointer">
                                     Hide merchant information on top of page.
                                 </label>
                             </div>
                         </div>
                        <?php endif; ?>

                            <?php if(isset($settings['REPLYTCKCUST'])): ?>
                            <div class="col-md-4 form-group">
                                <label>Tickets and Help: </label>
                                <div class="checkbox checkbox-success">
                                    <input type="checkbox"  class="styled" id="REPLYTCKCUST" name="REPLYTCKCUST" <?php if (isset($settings['REPLYTCKCUST']) && $settings['REPLYTCKCUST']== "1") echo 'checked'; ?> style="cursor:pointer" >
                                    <label for="REPLYTCKCUST" style="cursor:pointer">
                                        Allow Administrators to reply user's tickets.
                                    </label>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(isset($settings['SHOWCOMPANYNAME'])): ?>
                            <div class="col-md-4 form-group">
                                <label for="default_from">
                                    Company Name:
                                </label>
                                <div class="checkbox checkbox-success">
                                    <input type="checkbox"  class="styled" id="SHOWCOMPANYNAME" name="SHOWCOMPANYNAME" <?php if (isset($settings['SHOWCOMPANYNAME']) && $settings['SHOWCOMPANYNAME']== "1") echo 'checked'; ?> style="cursor:pointer" >
                                    <label for="SHOWCOMPANYNAME" style="cursor:pointer">
                                        Show "Company Name" field in reports.
                                    </label>
                                </div>
                            </div>
                            <?php endif; ?>
                    </div>
                    <div class="row">
                        <?php if(isset($settings['DEFAULT_FROM'])): ?>
                        <div class="col-md-4 form-group">
                            <label for="default_from">
                                This is the email address that will be used in the "from:" field when replying to customer service tickets:
                            </label>
                            <input id="default_from" name="default_from" class="form-control" type="text"  value="<?php if(isset($settings['DEFAULT_FROM'])){ echo $settings['DEFAULT_FROM'];}else { echo 'customerservice@revopayments.com';} ?>">
                        </div>
                        <?php endif; ?>
                            <?php if(isset($settings['QPLOGIN'])): ?>
                            <div class="col-md-4 form-group">
                                <label for="qlogin">
                                    <br/>
                                    Default landing page:
                                </label>
                                <select id="qlogin" name="qlogin" class="form-control">
                                    <option value="0"<?php if ($settings['QPLOGIN'] == '0') echo " selected=\"selected\""; ?>>Login</option>
                                    <option value="1" <?php if ($settings['QPLOGIN'] == '1') echo " selected=\"selected\""; ?>>QuickPay</option>
                                    <option value="2"<?php if ($settings['QPLOGIN'] == '2') echo " selected=\"selected\""; ?>>Registration</option>
                                </select>
                            </div>
                            <?php endif; ?>

                            <?php if(isset($settings['USERGUIDE'])): ?>
                            <div class="col-md-4 form-group">
                                <label for="default_from">
                                    <br/>
                                    Link to User Guide:
                                </label>
                                <input id="userguide" name="userguide" class="form-control" type="text"  value="<?php if(isset($settings['USERGUIDE'])){ echo $settings['USERGUIDE'];} ?>">
                            </div>
                            <?php endif; ?>

                    </div>
                    <?php if(isset($settings['HELPDISCLAIMER'])): ?>
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <label>Help ticket Disclaimer:</label>
                            <textarea id="HELPDISCLAIMER" name="HELPDISCLAIMER" class="form-control tinymce-editor"><?php echo $settings['HELPDISCLAIMER']; ?> </textarea>
                        </div>
                    </div>
                    <?php endif; ?>



                    <?php if(isset($settings['NEWHELP'])): ?>
                    <br/>
                    <label>Help in internal pages (user logged in) max 200 characters: </label>
                    <div class="row">

                        <div class="col-md-9 form-group">
                            <textarea maxlength="200" id="NEWHELP" name="NEWHELP" class="form-control tinymce-editor" style="min-height:  270px" ><?php echo $settings['NEWHELP']; ?> </textarea>
                        </div>
                        <div class="col-md-3 form-group">
                            <div class="panel panel-default" style="border: none; box-shadow: none; background-color: #F4F4F4; padding: 15px">
                                <div class="panel-body" style="font-size: 12px">
                                    Please use the following conventions to indicate relevant information:<br><br>
                                    <b>Phone number</b><br>&nbsp;&nbsp;enclose in <b>[:T ... T:]</b> <br>
                                    &nbsp;&nbsp;Example - [:T 878-700-0000 T:]<br>
                                    &nbsp;&nbsp;Result: <span class="fa fa-phone"></span>878-700-000<br>
                                    <br><b>Email address</b><br>&nbsp;&nbsp;enclose in <b>[:M ... M:]</b> <br>
                                    &nbsp;&nbsp;Example - [:M test@domain.com M:]<br>
                                    &nbsp;&nbsp;Result: <span class="fa fa-envelope-o"></span>test@domain.com<br>
                                    <br><b>Url</b><br>&nbsp;&nbsp;enclose in <b>[:U ... U:]</b> <br>
                                    &nbsp;&nbsp;Example - [:U http://domain.com U:]<br>
                                    &nbsp;&nbsp;Result: <span class="fa fa-globe"></span> <a href="http://domain.com">http://domain.com</a><br>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?> 
                            


                    <div class="row">
                        <?php if(isset($settings['MAINTENANCEMAIL'])): ?>
                        <div class="col-md-7  form-group">
                            <label for="default_from">
                                This is the email address where the maintenance request will be sent:
                            </label>
                            <input id="maintenancemail" name="maintenancemail" class="form-control" type="text"  value="<?php if(isset($settings['MAINTENANCEMAIL'])){ echo $settings['MAINTENANCEMAIL'];} ?>">
                        </div>
                        <?php endif; ?>
                        <?php if(isset($settings['MAINTENANCE'])): ?>
                        <div class="col-md-5 form-group">
                            <label for="default_from">
                                Maintenance Request:
                            </label>
                            <div class="checkbox checkbox-success">
                                <input type="checkbox"  class="styled" id="maintenance" name="maintenance" <?php if (isset($settings['MAINTENANCE']) && $settings['MAINTENANCE']== "1") echo 'checked'; ?> style="cursor:pointer" >
                                <label for="maintenance" style="cursor:pointer">
                                    Enable Maintenance Request
                                </label>
                            </div>
                        </div>
                        <?php endif; ?>

                    </div> 




                        <?php if(isset($settings['TOPSTAB'])): ?>
                           <?php
                            #added TOPS SETTING
                                if (in_array($level, array('P', 'G'))){
                                    ?>
                                        <div class="form-group">
                                            <div class="checkbox checkbox-success">
                                                <input type="checkbox" class="styled" id="TOPSTAB" name="TOPSTAB"
                                                       style="cursor:pointer" <?php if (isset($settings['TOPSTAB']) && $settings['TOPSTAB'] == 1) echo "checked"; ?>>
                                                <label for="TOPSTAB" style="cursor:pointer">
                                                    TOPS Integration
                                                </label>
                                            </div>
                                        </div>
                           <?php }?>
                        <?php endif; ?>

                        <div class="row">
                        <div class="col-xs-12 form-group">
                            <label>Not Mandatory fields for new users in E-Terminal</label>
                            <br/>
                            <br/>
                            <div class="form-group">
                                <div class="checkbox checkbox-success checkbox-inline">
                                    <input type="checkbox" class="styled" id="account_mandatory" name="check_list[]" value="account"
                                           style="cursor:pointer" <?php if (isset($settings['NOTMANDATORYETERM']) && !empty($settings['NOTMANDATORYETERM']) && in_array('account',$settings['NOTMANDATORYETERM'])) echo "checked"; ?>>
                                    <label for="account_mandatory" style="cursor:pointer">
                                        # Account
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="checkbox checkbox-success checkbox-inline">
                                    <input type="checkbox" class="styled" id="name_mandatory" name="check_list[]" value="name"
                                           style="cursor:pointer" <?php if (isset($settings['NOTMANDATORYETERM']) && !empty($settings['NOTMANDATORYETERM']) && in_array('name',$settings['NOTMANDATORYETERM'])) echo "checked"; ?>>
                                    <label for="name_mandatory" style="cursor:pointer">
                                        Name
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="checkbox checkbox-success checkbox-inline">
                                    <input type="checkbox" class="styled" id="address_mandatory" name="check_list[]" value="address"
                                           style="cursor:pointer" <?php if (isset($settings['NOTMANDATORYETERM']) && !empty($settings['NOTMANDATORYETERM']) && in_array('address',$settings['NOTMANDATORYETERM'])) echo "checked"; ?>>
                                    <label for="address_mandatory" style="cursor:pointer">
                                        Address
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="checkbox checkbox-success checkbox-inline">
                                    <input type="checkbox" class="styled" id="phone_mandatory" name="check_list[]" value="phone"
                                           style="cursor:pointer" <?php if (isset($settings['NOTMANDATORYETERM']) && !empty($settings['NOTMANDATORYETERM']) && in_array('phone',$settings['NOTMANDATORYETERM'])) echo "checked"; ?>>
                                    <label for="phone_mandatory" style="cursor:pointer">
                                        Phone
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="checkbox checkbox-success checkbox-inline">
                                    <input type="checkbox" class="styled" id="email_mandatory" name="check_list[]" value="email"
                                           style="cursor:pointer" <?php if (isset($settings['NOTMANDATORYETERM']) && !empty($settings['NOTMANDATORYETERM']) && in_array('email',$settings['NOTMANDATORYETERM'])) echo "checked"; ?>>
                                    <label for="email_mandatory" style="cursor:pointer">
                                        Email Address
                                    </label>
                                </div>
                            </div>
                        </div>
                        </div>
                        <div class="hr-line-dashed"></div>
                        <div class="row">
                            <div class="col-xs-4 col-sm-2">
                                <button class="btn btn-primary" type="submit">Save Settings</button>
                            </div>
                            <div class="col-xs-8 col-sm-10">
                                <?php if($level!='M'): ?>
                                <div class="checkbox checkbox-success">
                                    <input type="checkbox"  class="styled" id="propagate" name="propagate" value="on"  style="cursor:pointer" >
                                    <label for="propagate" style="cursor:pointer">
                                        Apply these settings to all levels below this one.
                                    </label>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        </form>

            </div>
        </div>
    </div>    
@include('components.tinymce')
@endsection