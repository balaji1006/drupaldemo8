@extends('layouts.master')
@section('title',"Payor's Menu Tabs")
@section('content')
    <div class="normalheader">
        <div class="hpanel">
            <div class="panel-body">
                <a class="small-header-action" href="">
                    <div class="clip-header">
                        <i class="fa fa-arrow-up"></i>
                    </div>
                </a>
                <h2 class="font-light m-b-xs">
                    Payor's Menu Tabs
                </h2>
                <small>
                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                        <li class="active">
                            <span>Payor's Menu Tabs</span>
                        </li>
                    </ol>
                </small>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="hpanel">
            <div class="panel-body">

            {{ Form::open(array('route' => array('menutabsave', $token ),'method' => 'post'))}}
            <div class="row">
                <div class="col-lg-12">
                    <?php

                    $lactive='menutab';
                    //include_once __DIR__.'/../admin_components/links_accounts.php';

                    $default_tab = 0;
                    $array_tabs = ['showdashboard'=>0,'pay'=>0,'autopay'=>0,'paymethods'=>0,'payhistory'=>0,'myprofile'=>0,'helpticket'=>0,'maintenance'=>0,'listbills'=>0,'invoices'=>0,'newviewbill'=>0,'gsbbill'=>0];
                    $array_tabs_keys = array_keys($array_tabs);


                    $array_tabs_labels = [
                        'showdashboard'=>'Dashboard',
                        'pay'=>'Make a Payment',
                        'autopay'=>'Manage Autopay',
                        'paymethods'=>'Payment Methods',
                        'payhistory'=>'Payment History',
                        'myprofile'=>'User Profile',
                        'helpticket'=>'Help Ticket',
                        'maintenance'=>'Maintenance Request',
                        'listbills'=>'Statements',
                        'invoices'=>'Invoices',
                        'newviewbill'=>'SDI Bill',
                        'gsbbill' => 'GSB Bill'
                    ];
                    ?>

                </div>
            </div>


            <?php

            if(!$tabs->isEmpty()) {
            ?>

            <div class="row">
                <div class="col-sm-1 col-xs-1">

                </div>
                <div class="col-md-3 col-sm-3 col-xs-3">
                    <label>Assign</label>
                </div>
                <div class="col-md-5 col-sm-3 col-xs-3">
                    <label>Title</label>
                </div>
                <div class="col-lg-2 col-md-1 col-sm-2 col-xs-2">
                    <label>Icon</label>
                </div>
                <div class="col-lg-1 col-md-2 col-sm-3 col-xs-3 text-center">
                    <label>Priority</label>
                </div>

            </div>
            <?php
                $tabs = (array)$tabs->all();

                $cont = 1;
                foreach ($tabs as $tab) {
                    $tab = (array)$tab;

                    if (isset($array_tabs[$tab['name']])) {
                        $array_tabs[$tab['name']] = 1;
                    }
                    $number = $tab['priority']*1;
                    $dpart = $number - (int)$number;
                    if (!empty($dpart)) {
                        continue;
                    }

                    ?>


                    <div class="row form-group groupSortable">
                        <div class="col-sm-1 col-xs-2 text-center form-group">
                            <div class="checkbox checkbox-success">
                                <input type="checkbox" checked="checked" class="form-control" name="save_<?php echo $cont; ?>">
                                <label style="cursor:pointer">
                                </label>
                            </div>



                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-4 form-group">
                            <input type="text" class="form-control readonlyclear" value="<?php echo $array_tabs_labels[$tab['name']]; ?>" readonly>
                            <input type="hidden" name="name_<?php echo $cont; ?>" value="<?php echo $tab['name']; ?>">
                        </div>
                        <div class="col-md-5 col-sm-3 col-xs-6 form-group">
                            <div class="input-group">
                                <input type="text" name="title_<?php echo $cont; ?>"
                                       value="<?php echo $tab['title'] ?>" class="form-control editName"
                                       placeholder="Name" readonly>
                                <span class="input-group-btn">
                        <button class="btn btn-default editNameBtn" type="button" style="padding: 6px 20px;"><span
                                class="fa fa-edit"></span></button>
                        </span></div>
                        </div>
                        <div class="col-lg-2 col-md-1 col-sm-2 col-xs-4 form-group">
                            <div class="dropdown">
                                <a href="#" class="btnIcon btn btn-default btn-block" data-toggle="dropdown"  style="padding: 8px;"><span  class="<?php echo $tab['image']; ?>"></span> <span class="hidden-xs hidden-sm hidden-md"><?php echo substr($tab['image'], 0, 10); ?>...</span> <span class="caret"></span></a>

                                <ul class="dropdown-menu iconSelect" aria-labelledby="dropdownMenu1">
                                    <li><a href="#" value="fa fa-home"><span class="fa fa-home"></span> fa fa-home</a>
                                    </li>
                                    <li><a href="#" value="fa fa-credit-card"><span class="fa fa-credit-card"></span> fa
                                            fa-credit-card</a></li>
                                    <li><a href="#" value="fa fa-calendar"><span class="fa fa-calendar"></span> fa
                                            fa-calendar</a></li>
                                    <li><a href="#" value="fa fa-database"><span class="fa fa-database"></span> fa
                                            fa-database</a></li>
                                    <li><a href="#" value="fa fa-bar-chart"><span class="fa fa-bar-chart"></span> fa
                                            fa-bar-chart</a></li>
                                    <li><a href="#" value="fa fa-gear"><span class="fa fa-gear"></span> fa fa-gear</a>
                                    </li>
                                    <li><a href="#" value="fa fa-question-circle"><span
                                                class="fa fa-question-circle"></span> fa fa-question-circle</a></li>

                                    <li><a href="#" value="fa fa-user"><span
                                                class="fa fa-user"></span> fa fa-user</a></li>

                                    <li><a href="#" value="fa fa-file-o"><span
                                                class="fa fa-file-o"></span> fa fa-file-o</a></li>

                                    <li><a href="#" value="fa fa-wrench"><span
                                                class="fa fa-wrench"></span> fa fa-wrench</a></li>

                                    <li><a href="#" value="fa fa-money"><span
                                                class="fa fa-money"></span> fa fa-money</a></li>
                                </ul>
                            </div>
                            <input class="iconInput" type="hidden" name="icon_<?php echo $cont; ?>"
                                   value="<?php echo $tab['image'] ?>">
                        </div>
                        <div class="col-lg-1 col-md-2 col-sm-3 col-xs-6 form-group">
                            <div class="row">
                                <div class="col-xs-6">
                                    <button type="button" class="btn btn-default btn-block upBlock"
                                            style="padding: 9px;"><span class="fa fa-angle-up text-success"></span>
                                    </button>
                                </div>
                                <div class="col-xs-6">
                                    <button type="button" class="btn btn-default btn-block downBlock"
                                            style="padding: 9px;"><span class="fa fa-angle-down text-danger"></span>
                                    </button>
                                </div>
                            </div>
                            <input class="orderInput" type="hidden" name="order_<?php echo $cont; ?>"
                                   value="<?php echo $cont; ?>">
                        </div>

                    </div>
                    <?php
                    $cont++;
                    $default_tab++;
                }




                foreach ($array_tabs as $key => $tab) {
                    if ($tab == 0) {
                        $title = '';

                        ?>
                        <div class="row form-group groupSortable">
                            <div class="col-sm-1 col-xs-2 text-center form-group">
                                <div class="checkbox checkbox-success">
                                    <input type="checkbox" class="form-control" name="savenew_<?php echo $cont; ?>">
                                    <label style="cursor:pointer">
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-4 form-group">
                                <input type="text" class="form-control readonlyclear" value="<?php echo $array_tabs_labels[$key]; ?>" readonly>
                                <input type="hidden" name="namenew_<?php echo $cont; ?>" value="<?php echo $key; ?>">



                            </div>
                            <div class="col-md-5 col-sm-3 col-xs-6 form-group">
                                <div class="input-group"><input type="text" name="titlenew_<?php echo $cont; ?>"
                                                                value="<?php echo $array_tabs_labels[$key]; ?>"
                                                                class="form-control editName" placeholder="Name"
                                                                readonly>
                                    <span class="input-group-btn">
                    <button class="btn btn-default editNameBtn" type="button" style="padding: 6px 20px;"><span
                            class="fa fa-edit"></span></button>
                    </span></div>
                            </div>
                            <div class="col-lg-2 col-md-1 col-sm-2 col-xs-4 form-group">
                                <div class="dropdown">
                                    <a href="#" class="btnIcon btn btn-default btn-block" data-toggle="dropdown"
                                       style="padding: 8px;"><span class="fa fa-file-o"></span>  <span class="hidden-xs hidden-sm hidden-md">fa fa-file...</span> <span class="caret"></span></a>
                                    </button>
                                    <ul class="dropdown-menu iconSelect" aria-labelledby="dropdownMenu1">
                                        <li><a href="#" value="fa fa-home"><span class="fa fa-home"></span> fa
                                                fa-home</a></li>
                                        <li><a href="#" value="fa fa-credit-card"><span
                                                    class="fa fa-credit-card"></span> fa fa-credit-card</a></li>
                                        <li><a href="#" value="fa fa-calendar"><span class="fa fa-calendar"></span> fa
                                                fa-calendar</a></li>
                                        <li><a href="#" value="fa fa-database"><span class="fa fa-database"></span> fa
                                                fa-database</a></li>
                                        <li><a href="#" value="fa fa-bar-chart"><span class="fa fa-bar-chart"></span> fa
                                                fa-bar-chart</a></li>
                                        <li><a href="#" value="fa fa-gear"><span class="fa fa-gear"></span> fa
                                                fa-gear</a></li>
                                        <li><a href="#" value="fa fa-question-circle"><span
                                                    class="fa fa-question-circle"></span> fa fa-question-circle</a></li>
                                        <li><a href="#" value="fa fa-user"><span
                                                    class="fa fa-user"></span> fa fa-user</a></li>

                                        <li><a href="#" value="fa fa-file-o"><span
                                                    class="fa fa-file-o"></span> fa fa-file-o</a></li>

                                        <li><a href="#" value="fa fa-wrench"><span
                                                    class="fa fa-wrench"></span> fa fa-wrench</a></li>

                                        <li><a href="#" value="fa fa-money"><span
                                                    class="fa fa-money"></span> fa fa-money</a></li>
                                    </ul>
                                </div>
                                <input class="iconInput" type="hidden" name="iconnew_<?php echo $cont; ?>"
                                       value="fa fa-file-o">
                            </div>
                            <div class="col-lg-1 col-md-2 col-sm-3 col-xs-6 form-group">
                                <div class="row">
                                    <div class="col-xs-6">
                                        <button type="button" class="btn btn-default btn-block upBlock"
                                                style="padding: 9px;"><span class="fa fa-angle-up text-success"></span>
                                        </button>
                                    </div>
                                    <div class="col-xs-6">
                                        <button type="button" class="btn btn-default btn-block downBlock"
                                                style="padding: 9px;"><span class="fa fa-angle-down text-danger"></span>
                                        </button>
                                    </div>
                                </div>
                                <input class="orderInput" type="hidden" name="ordernew_<?php echo $cont; ?>"
                                       value="<?php echo $cont; ?>">
                            </div>

                        </div>
                        <?php
                        $cont++;
                        $default_tab++;
                    }

                }


            ?>

                <div class="hr-line-dashed"></div>
                <div class="form-group">

                    <button type="submit" class="btn btn-primary">Save Settings</button>
                </div>

             <?php }else{
                 ?>
                <div class="alert alert-warning">You need to have at least a merchant under this group to use this feature</div>
                <?php
            } ?>
            </form>
        </div>
    </div>
</div>


<script>
    $('.editNameBtn').click(function () {
        inputName = $(this).parent().parent().find('.editName');
        if(inputName.is('[readonly]')){
            inputName.attr("readonly", false);
        }
        else{
            inputName.attr('readonly',true);
        }

    });

    $('.iconSelect a').click(function () {
        iconA = $(this);
        iconA.parent().parent().parent().find('.btnIcon').html('<span class="'+iconA.attr('value')+'"></span> '+iconA.attr('value').substring(0, 10)+'...');
        iconA.parent().parent().parent().parent().find('.iconInput').val(iconA.attr('value'));
    });
    
    $('.groupSortable .downBlock').click(function () {
        container = $(this).parent().parent().parent().parent();
        if(container.next().hasClass('groupSortable')){

            container.find('.orderInput').val(parseInt(container.find('.orderInput').val())+1);
            container.next().find('.orderInput').val(parseInt(container.next().find('.orderInput').val())-1);

            newContainer = container.clone(true);
            container.next().after(newContainer);
            container.remove();
        }
    });
    $('.groupSortable .upBlock').click(function () {
        container = $(this).parent().parent().parent().parent();
        if(container.prev().hasClass('groupSortable')){

            container.find('.orderInput').val(parseInt(container.find('.orderInput').val())-1);
            container.prev().find('.orderInput').val(parseInt(container.prev().find('.orderInput').val())+1);

            newContainer = container.clone(true);
            container.prev().before(newContainer);
            container.remove();
        }
    });

</script>

@endsection