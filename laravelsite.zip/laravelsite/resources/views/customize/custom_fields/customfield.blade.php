@extends('layouts.master')
@section('title','Custom Fields')

@section('content')
<div class="normalheader ">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>

            <div class="pull-right">
                <a href="{{ route('addcustomfield',array('token'=>$token)) }}" class="btn btn-success pull-right margint-10"><i class="fa fa-plus"></i> New Custom field</a>
            </div>


            <h2 class="font-light m-b-xs">
                Custom Fields
            </h2>
            <small>

                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                        <li class="active">
                            <span>Custom Fields</span>
                        </li>
                    </ol>

            </small>
        </div>
    </div>
</div>

<div class="content">
    <div class="hpanel">
        <div class="panel-body">
            {!! $grid !!}
        </div>
        <div class="panel-footer">
        </div>
    </div>
</div>
@endsection
@section('footer1')
<script type="text/javascript">
function deletecustomfield(id) {

    swal({
            title: "Are you sure?",
            text: "Do you want to delete this field?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!"
        },
        function () {
            url_redirect = "<?php echo route('deletecustomfield',array('token'=>$token,'id'=>'00000000000000000000'));?>";
            url_redirect = url_redirect.replace('/00000000000000000000','/'+id);
            window.location.href = url_redirect;
        });
}
</script>
@endsection