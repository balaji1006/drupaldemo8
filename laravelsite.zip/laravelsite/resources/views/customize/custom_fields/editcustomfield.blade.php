@extends('layouts.master')
@section('title','Edit Custom Field')
@section('content')
<div class="normalheader ">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <div>
                <h2 class="font-light m-b-xs">
                    Edit Custom Field
                </h2>
                <small>
                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                        <li><a href="<?php echo route('customfieldlist', array('token' => $token)); ?>">Custom Fields</a></li>
                        <li class="active">
                            <span>Edit Custom Field</span>
                        </li>
                    </ol>
                </small>

            </div>



        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">

        <div class="panel-body">
            <div class="marginb-20">

                <form name="editcustomfield" id="editcustomfield" method="POST" action="{{route('updatecustomfield',['token'=>$token])}}" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" >
                    <input type="hidden" name="txtid" value="<?php echo $id; ?>" >

                    <div class="row">
                        <div class="col-lg-12 form-group">
                            <label>Field Description</label>
                            <?php echo Form::text('txtfd',$data->field_description, array('class' => 'form-control','placeholder'=>'Field description', 'id'=>'txtfd')); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-6 form-group">
                            <label>Field Type</label>
                            <?php
                            $type_array = array(''=>"Select",'A'=>"Alphanumeric",'N'=>"Numeric");
                            ?>
                            <?php echo Form::select('ddlfieldtype', $type_array, $data->type , array('id'=>'ddlfieldtype','class' => 'form-control'));?>

                        </div>
                        <div class="col-lg-3 col-md-6 form-group">
                            <label>Position</label>
                            <?php
                            $position_array = array(''=>"Select",'A'=>"User account section",'P'=>"Payment section");
                            ?>
                            <?php echo Form::select('ddlposition', $position_array, $data->position , array('id'=>'ddlposition','class' => 'form-control'));?>

                        </div>
                        <div class="col-lg-3 col-md-6 form-group">
                            <label>Is visible in Transaction report?</label>
                            <?php
                            $yesno_array = array(''=>"Select",0=>"No",1=>"Yes");
                            ?>
                            <?php echo Form::select('ddlvtr', $yesno_array, $data->in_txreport , array('id'=>'ddlvtr','class' => 'form-control'));?>
                        </div>
                        <div class="col-lg-3 col-md-6 form-group">
                            <label>Is visible in Settlement report?</label>
                            <?php
                            $yesno_array = array(''=>"Select",0=>"No",1=>"Yes");
                            ?>
                            <?php echo Form::select('ddlvsr', $yesno_array, $data->in_dpreport , array('id'=>'ddlvsr','class' => 'form-control'));?>
                        </div>
                    </div>



                    <div class="hr-line-dashed"></div>
                    <div class="form-group">
                        <a class="btn btn-default" href="<?php echo route('customfieldlist', array('token' => $token)); ?>">Cancel</a>
                        <button id="submitbtn" class="btn btn-primary" type="submit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@if (session('error'))
@component('components.toastr',['type' => 'error','msg' => session('error')])
@endcomponent
@endif
@endsection
@section('footers')
<script src="{{ asset('js/jquery.validate.min.js') }}"></script>
<script type="text/javascript">
$(document).ready(function () {
    $("#editcustomfield").validate({
        ignore: '*:not([name])',
        rules: {
            txtfd: {required: true, maxlength:250},
            ddlfieldtype: {required: true,  maxlength:1},
            ddlposition: {required: true ,  maxlength:1},
            ddlvtr: {required: true,  maxlength:4},
            ddlvsr: {required: true,  maxlength:4},
        },
        errorPlacement: function(error, element) {
            error.insertBefore(element);

        },
        errorElement: "span",
    });
});



</script>
@endsection


