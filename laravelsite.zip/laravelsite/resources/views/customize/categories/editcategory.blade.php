<?php $active_submenu = 'categorieslist'; ?>
@extends('layouts.master')
@section('title','Edit Category')
@section('content')
@php
$category = (array) $category;
@endphp
<div class="normalheader ">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <div>
                <h2 class="font-light m-b-xs">
                    Edit Category
                </h2>
                <small>
                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                        <li><a href="<?php echo route('categorieslist', array('token' => $token)); ?>">Payment Categories</a></li>
                        <li class="active">
                            <span>Add Payment Categories</span>
                        </li>
                    </ol>
                </small>
            </div>



        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">

        <div class="panel-body">
            <div class="marginb-20">

                <form name="editcategory" id="editcategory" method="POST" action="{{route('updatecategory')}}" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" >
                    <input type="hidden" name="token" value="<?php echo $token; ?>" >
                    <input type="hidden" name="id" value="<?php echo $category['payment_type_id']; ?>" >
                    <div class="row">
                        <div class="col-md-4 form-group">
                            <label>Description</label>
                            <?php echo Form::text('txtname',old('txtname', $category['payment_type_name']), array('class' => 'form-control','placeholder'=>'Category Description', 'id'=>'txtname', 'required'=>'required')); ?>
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Charge Code</label>
                            <?php echo Form::text('txtcode',old('txtcode', $category['payment_type_code']), array('class' => 'form-control','placeholder'=>'Charge Code', 'id'=>'txtcode')); ?>
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Amount</label>
                            <?php echo Form::text('txtamount',old('txtamount', $category['amount']), array('class' => 'form-control','placeholder'=>'Amount', 'id'=>'txtamount')); ?>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-4 form-group">
                            <label>Impact the Balance?</label>
                            <?php
                            $yes_no_array = array(0=>"No",1=>"Yes");
                            ?>
                            <?php echo Form::select('ddlbalance', $yes_no_array, old('ddlbalance', $category['is_balance']) , array('id'=>'ddlbalance','class' => 'form-control'));?>

                        </div>
                        <div class="col-md-4 form-group">
                            <label>Show quantities?</label>
                            <?php echo Form::select('ddlqty', $yes_no_array, old('ddlqty', $category['qty']) , array('id'=>'ddlqty','class' => 'form-control'));?>
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Quantity Limit</label>
                            <?php echo Form::text('txtlimit',$category['qtymax'], array('class' => 'form-control','placeholder'=>'Quantity Limit', 'id'=>'txtlimit', 'value'=>'1')); ?>
                        </div>
                    </div>

                    <div class="hr-line-dashed"></div>
                    <div class="form-group">
                        <a class="btn btn-default" href="<?php echo route('categorieslist', array('token'=>$token));?>">Cancel</a>
                        <button id="submitbtn" class="btn btn-primary" type="submit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
@section('footers')
    <script src="{{ asset('js/jquery.validate.min.js') }}"></script>
    <script type="text/javascript">

        jQuery.validator.addMethod("money", function(value, element) {
            return this.optional(element) || /^\d*(\.\d{0,2})?$/.test(value);
        }, "This field has errors.");
        jQuery.validator.addMethod('integerPositive',
                function (value) {
                    if(value==''){
                        return true;
                    }
                    if(value.indexOf('.') >= 0){
                        return false;
                    }
                    if(Number(value) > 0 && Math.floor(value) == value && $.isNumeric(value)){
                        return true;
                    }
                    return false;
                }, 'Enter a positive number.');
        
        $('#ddlqty').change(function () {
            if($(this).val() == 0){
                $('#txtlimit').val(0);
                $('#txtlimit').attr('disabled', 'disabled');
            }else{
                $('#txtlimit').removeAttr('disabled');
            }
        });

        $(document).ready(function () {

            $("#editcategory").validate({
                rules: {
                    txtamount: {money: true},
                    txtlimit: {integerPositive: true, required: true, min: 2},
                },
                errorPlacement: function(error, element) {
                    error.insertBefore(element);

                },
                errorElement: "span",
            });


            // validate if show quantity is "NO" then quantity limit has to be 0
            if($('#ddlqty').val() == 0){
                $('#txtlimit').val(0);
                $('#txtlimit').attr('disabled', 'disabled');
            } else {
                $('#txtlimit').removeAttr('disabled');
            }
            
        });



    </script>
@endsection



