@extends('layouts.master')
@section('title','Categories')
@section('export-excel-url',route('export', array('sqlEncrypted' => $sqlEncrypted, 'type' => 'excel', 'sheetname' => 'Categories')))
@section('export-csv-url',route('export', array('sqlEncrypted' => $sqlEncrypted, 'type' => 'csv', 'sheetname' => 'Categories')))
@section('content')

<div class="normalheader ">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <div class="pull-right">
                <a href="{{route('addcategory',['token'=>$token])}}" class="btn btn-success margint-10"><i class="fa fa-plus"></i>&nbsp;Add Payment Category</a>
            </div>
            <div>
                <h2 class="font-light m-b-xs">
                    Payment Categories
                </h2>
                <small>
                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                        <li class="active">
                            <span>Payment Categories</span>
                        </li>
                    </ol>
                </small>

            </div>



        </div>
    </div>
</div>

<div class="content">
    <div class="hpanel">

        <div class="panel-body">
            <div class="marginb-20">
                @include('components.filtersAndExport')
            </div>
            {!! $grid !!}
        </div>
        <div class="panel-footer">
        </div>
    </div>
</div>
<div id="groupDetailsModal" class="modal fade" role="dialog">
    <div class="modal-dialog" style="width: 500px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Vendor Details</h4>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

@endsection
@section('footer1')
<script type="text/javascript">

function deletecategory(id) {
    swal({
                title: "Are you sure?",
                text: "Do you want to delete this Payment Category?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!"
            },
            function () {
                url_redirect = "<?php echo route('deletecategory',array('token'=>$token,'id'=>'00000000000000000000'));?>";
                url_redirect = url_redirect.replace('/00000000000000000000','/'+id);
                window.location.href = url_redirect;
            });
}

</script>
@endsection


