@extends('layouts.master')
@section('title','General')
@section('content')
@include('components.tinymce')
<div class="normalheader">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <h2 class="font-light m-b-xs">
                General
            </h2>
            <small>
                <ol class="hbreadcrumb breadcrumb">
                    <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                    <li class="active">
                        <span>General</span>
                    </li>
                </ol>
            </small>
        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">
        <div class="panel-body">

                        <form method="post" action="<?php echo route('savegeneral');?>" id="formNotification">
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" >  
                        <input type="hidden" name="tokendata" value="<?php echo $token; ?>" >

                        <div class="row">
                            <?php if(isset($settings['MANAGER_APPROVAL_NOT_REQUIRED'])): ?>
                            <div class="col-md-3 form-group">
                                <label> User Registration: </label>
                                <div class="checkbox checkbox-success">
                                    <input type="checkbox"  class="styled" id="manager_approval_not_required" name="manager_approval_not_required" <?php if ($settings['MANAGER_APPROVAL_NOT_REQUIRED']== "1") echo 'checked'; ?> style="cursor:pointer" onclick="verifynoreg();" />
                                    <label for="manager_approval_not_required" style="cursor:pointer">
                                        Manager approval is not required on user self registration.
                                    </label>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(isset($settings['NOTREG'])): ?>
                            <label> &nbsp;</label><br/>
                            <div class="col-md-3 form-group">
                                <div class="checkbox checkbox-success">
                                    <input type="checkbox"  class="styled" id="notreg" name="notreg" <?php if ($settings['NOTREG']== "1") echo 'checked'; ?> style="cursor:pointer" onclick="verifynoreg();">
                                    <label for="notreg" style="cursor:pointer">
                                        Do not allow self registration.
                                    </label>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if(isset($settings['REGREG'])): ?>
                            <label> &nbsp;</label><br/>
                            <div class="col-md-3 form-group">
                            <div class="checkbox checkbox-success">
                                <input type="checkbox"  class="styled" id="regreg" name="regreg" <?php if ($settings['REGREG']== "1") echo 'checked'; ?> style="cursor:pointer" >
                                <label for="regreg" style="cursor:pointer">
                                    Allow re-registration.
                                </label>
                            </div>
                            </div>
                            <?php endif; ?>
                        </div>


                        <?php if(isset($settings['PAYMENT_NUMBERS'])): ?>
                        <div class="form-group">
                        <label>User Account # and Registration Preferences:</label>
                        <div class="checkbox checkbox-success">
                            <input type="checkbox"  class="styled" id="payment_numbers" name="payment_numbers" <?php if ($settings['PAYMENT_NUMBERS']== "1") echo 'checked'; ?> style="cursor:pointer" onclick="verifyacc();">
                                    <label for="payment_numbers" style="cursor:pointer">
                                        Require Account # registration process?
                                    </label>
                        </div>
                        </div>
                            <br/>

                            <?php if(isset($settings['PAYMENT_NUMBER_LOGON_WELCOME'])): ?>
                            <div class="form-group">

                                <label for="edit_def_first">
                                    Edit default 'Registration' Welcome text (max 200 characters):
                                </label>
                                <textarea maxlength="200" id="payment_number_logon_welcome" name="payment_number_logon_welcome" class="form-control tinymce-editor" style="min-height:  270px" ><?php if(isset($settings['PAYMENT_NUMBER_LOGON_WELCOME'])) echo $settings['PAYMENT_NUMBER_LOGON_WELCOME']; ?> </textarea>
                                <br/>
                            </div>
                            <?php endif; ?>
                            <div class="row">

                                    <?php if(isset($settings['PAYMENT_NUMBER_REG_WELCOME'])): ?>
                                    <div class="col-md-4 form-group">
                                        <label for="payment_number_reg_welcome">
                                            Edit default Account number instructions text (Registration):
                                        </label>
                                        <input id="payment_number_reg_welcome" name="payment_number_reg_welcome" class="form-control"  type="text"  value="<?php if(isset($settings['PAYMENT_NUMBER_REG_WELCOME'])) echo $settings['PAYMENT_NUMBER_REG_WELCOME']; ?>">
                                    </div>
                                    <?php endif; ?>


                                    <?php if(isset($settings['PAYMENT_NUMBER_QP_WELCOME'])): ?>
                                        <div class="col-md-4 form-group">
                                            <label for="payment_number_qp_welcome" style="cursor:pointer">
                                                Edit default Account number instructions text (QuickPay):
                                            </label>
                                            <input id="payment_number_qp_welcome" name="payment_number_qp_welcome" class="form-control"  type="text"  value="<?php if(isset($settings['PAYMENT_NUMBER_QP_WELCOME'])) echo $settings['PAYMENT_NUMBER_QP_WELCOME']; ?>">
                                        </div>
                                    <?php endif; ?>

                                    <?php if(isset($settings['PAYMENT_NUMBER_REG_NUMBER'])): ?>
                                        <div class="col-md-4 form-group">
                                            <label for="payment_number_qp_welcome" style="cursor:pointer">
                                                Edit default "Account #" text
                                            </label>
                                            <input id="payment_number_reg_number" name="payment_number_reg_number" class="form-control" type="text"  value="<?php if(isset($settings['PAYMENT_NUMBER_REG_NUMBER'])) echo $settings['PAYMENT_NUMBER_REG_NUMBER']; ?>">
                                        </div>
                                     <?php endif; ?>

                            </div>

                        <br/>
                    <?php endif; ?>
                    <?php if(isset($settings['PAYNOW'])): ?>    
                        <div class="form-group">
                        <label>Quickpay:</label>
                        <div class="checkbox checkbox-success">
                            <input type="checkbox"  class="styled" id="paynow" name="paynow" <?php if (isset($settings['PAYNOW']) &&  $settings['PAYNOW']== "1") echo 'checked'; ?> style="cursor:pointer">
                            <label for="paynow" style="cursor:pointer">
                                Enable Quick Pay Option?
                            </label>
                        </div>
                        </div>


                    <div class="row">

                    <?php if(isset($settings['ACCSETTING'])): ?>
                        <div class="col-md-12">
                        <label>Behavior for Account # field:</label>
                        <div class="form-group">
                        <div class="radio radio-success">
                            <input type="radio"  class="radio" id="ACCHIDE" name="accsetting" value="1" style="cursor:pointer" <?php if(isset($settings['ACCSETTING']) && $settings['ACCSETTING']==1)echo "checked";  ?> onclick="verifyacc()">
                                    <label for="ACCHIDE" style="cursor:pointer">
                                        Hide Account # field in QuickPay
                                    </label>
                        </div>
                        </div>
                            <div class="row">
                                <div class="col-xs-4">
                        <div class="form-group">
                        <div class="radio radio-success">
                            <input type="radio"  class="radio" id="NEWUSER" name="accsetting" value="2" style="cursor:pointer" <?php if(isset($settings['ACCSETTING']) && $settings['ACCSETTING']==2)echo "checked";  ?> onclick="verifyacc()">
                                    <label for="NEWUSER" style="cursor:pointer">
                                        A matching Account # is not required but the field cannot be empty
                                    </label>
                        </div>
                        </div>
                                </div>
                                <div class="col-xs-7">
                            <div class="form-group">
                                <div class="checkbox checkbox-success">
                                    <input type="checkbox"  class="styled" id="captcha2" name="notcaptcha2" <?php if (isset($settings['NOTCAPTCHA2']) &&  $settings['NOTCAPTCHA2']) echo 'checked'; ?> style="cursor:pointer">
                                    <label for="captcha2" style="cursor:pointer">
                                        Hide Captcha
                                    </label>
                                </div>
                            </div>
                                </div>
                            </div>
                        <div class="form-group">
                        <div class="radio radio-success">
                            <input type="radio"  class="radio" id="NONEWUSER" name="accsetting" value="3" style="cursor:pointer" <?php if(isset($settings['ACCSETTING']) && $settings['ACCSETTING']==3)echo "checked";  ?> onclick="verifyacc()">
                                    <label for="NONEWUSER" style="cursor:pointer">
                                        A matching Account # is required to use QuickPay
                                    </label>
                        </div>
                        </div>
                            <div class="row">
                                <div class="col-xs-4">
                        <div class="form-group">
                        <div class="radio radio-success">
                            <input type="radio"  class="radio" id="NOTACCQP" name="accsetting" value="4" style="cursor:pointer" <?php if(isset($settings['ACCSETTING']) && $settings['ACCSETTING']==4)echo "checked";  ?> onclick="verifyacc()">
                                    <label for="NOTACCQP" style="cursor:pointer">
                                        Do not require Account # in QuickPay (field can be empty)
                                    </label>
                        </div>
                        </div>
                                </div>

                            <div class="col-xs-7">
                                <div class="form-group">
                                    <div class="checkbox checkbox-success">
                                    <input type="checkbox"  class="styled" id="captcha4" name="notcaptcha4" <?php if (isset($settings['NOTCAPTCHA4']) &&  $settings['NOTCAPTCHA4']) echo 'checked'; ?> style="cursor:pointer">
                                    <label for="captcha4" style="cursor:pointer">
                                        Hide Captcha
                                    </label>
                                </div>
                                </div>
                            </div>
                        </div>

                        </div>
                    <?php endif; ?>

                    </div>
                            <div class="row">
                    <?php if(isset($settings['INVSETTING'])): ?>
                        <div class="col-md-4">
                        <label>Behavior for Invoice # field:</label>
                        <div class="form-group">
                        <div class="radio radio-success">
                            <input type="radio"  class="radio" id="ACCHIDE1" name="invsetting" value="1" style="cursor:pointer" <?php if(isset($settings['INVSETTING']) && $settings['INVSETTING']==1)echo "checked";  ?>>
                                    <label for="ACCHIDE1" style="cursor:pointer">
                                        Hide Invoice # field in QuickPay
                                    </label>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="radio radio-success">
                            <input type="radio"  class="radio" id="NEWUSER1" name="invsetting" value="2" style="cursor:pointer" <?php if(isset($settings['INVSETTING']) && $settings['INVSETTING']==2)echo "checked";  ?>>
                                    <label for="NEWUSER1" style="cursor:pointer">
                                        A matching Invoice # is not required but the field cannot be empty
                                    </label>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="radio radio-success">
                            <input type="radio"  class="radio" id="NONEWUSER1" name="invsetting" value="3" style="cursor:pointer" <?php if(isset($settings['INVSETTING']) && $settings['INVSETTING']==3)echo "checked";  ?>>
                                    <label for="NONEWUSER1" style="cursor:pointer">
                                        Only allow users with a matching Invoice # to use QuickPay
                                    </label>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="radio radio-success">
                            <input type="radio"  class="radio" id="NOTACCQP1" name="invsetting" value="4" style="cursor:pointer" <?php if(isset($settings['INVSETTING']) && $settings['INVSETTING']==4)echo "checked";  ?>>
                                    <label for="NOTACCQP1" style="cursor:pointer">
                                        Do not require Invoice # in QuickPay (field can be empty)
                                    </label>
                        </div>
                        </div>
                        </div>
                    <?php endif; ?>
                    </div>

                    <?php endif; ?>    
                    <?php if(isset($settings['EINVOICE']) ): ?>
                            <br/>
                            <label>E-Invoice:</label>
                            <div class="form-group hidden">
                               <div class="checkbox checkbox-success">
                                <input type="checkbox"  class="styled" id="einvoice" name="einvoice" style="cursor:pointer" <?php if(isset($settings['EINVOICE']))echo "checked";  ?>>
                                    <label for="einvoice" style="cursor:pointer">
                                        Enable E-Invoicing
                                    </label>
                                </div>
                            </div>
                        <div class="form-group">
                            <div class="checkbox checkbox-success">
                            <input type="checkbox"  class="styled" id="INVOICEDEFAULTQUICKPAY" name="INVOICEDEFAULTQUICKPAY" style="cursor:pointer" <?php if(isset($settings['INVOICEDEFAULTQUICKPAY']) && $settings['INVOICEDEFAULTQUICKPAY']==1)echo "checked";  ?>>
                                    <label for="INVOICEDEFAULTQUICKPAY">
                                        Enable QuickPay as default method for payor to pay an invoice without Payor Account # Registration & Authentication?
                                    </label>
                        </div>
                        </div>
                        <div class="form-group">
                            <div class="checkbox checkbox-success">
                            <input type="checkbox"  class="styled" id="SEND_REMINDERS" name="SEND_REMINDERS" style="cursor:pointer" <?php if(isset($settings['SEND_REMINDERS']) && $settings['SEND_REMINDERS']==1)echo "checked";  ?>>
                                    <label for="SEND_REMINDERS">
                                        Enable Invoice Reminders?
                                    </label>
                        </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3 form-group">
                            <label>Frequency Before Due Date</label>

                                <select name="freq_before_due" id="freq_before_due" class="form-control">
	                		<option value="none" <?php if (isset($settings['FREQ_BEFORE_DUE']) && $settings['FREQ_BEFORE_DUE'] == "none" ) echo ' selected="selected"; '; ?>>None</option>
                                        <option value="weekly" <?php if (isset($settings['FREQ_BEFORE_DUE']) && $settings['FREQ_BEFORE_DUE'] == "weekly" ) echo ' selected="selected"; '; ?>>Weekly</option>
                                        <option value="2weeks" <?php if (isset($settings['FREQ_BEFORE_DUE']) && $settings['FREQ_BEFORE_DUE'] == "2weeks" ) echo ' selected="selected"; '; ?>>Bi-Weekly</option>
                                        <option value="3days" <?php if (isset($settings['FREQ_BEFORE_DUE']) && $settings['FREQ_BEFORE_DUE'] == "3days" ) echo ' selected="selected"; '; ?>>3 Days Prior to Due Date</option>
                                        <option value="ondueday" <?php if (isset($settings['FREQ_BEFORE_DUE']) && $settings['FREQ_BEFORE_DUE'] == "ondueday" ) echo ' selected="selected"; '; ?>>On Due Date</option>
	        		        </select>

                        </div>
                            <div class="col-md-3 form-group">
                            <label>Frequency After Due Date</label>

                                <select name="freq_after_due" id="freq_after_due" class="form-control">
	                		<option value="none" <?php if (isset($settings['FREQ_AFTER_DUE']) && $settings['FREQ_AFTER_DUE'] == "none" ) echo ' selected="selected"; '; ?>>None</option>
                                        <option value="daily" <?php if (isset($settings['FREQ_AFTER_DUE']) && $settings['FREQ_AFTER_DUE'] == "daily" ) echo ' selected="selected"; '; ?>>Daily</option>
                                        <option value="3days" <?php if (isset($settings['FREQ_AFTER_DUE']) && $settings['FREQ_AFTER_DUE'] == "3days" ) echo ' selected="selected"; '; ?>>3 Days After Due Date</option>
                                        <option value="weekly" <?php if (isset($settings['FREQ_AFTER_DUE']) && $settings['FREQ_AFTER_DUE'] == "weekly" ) echo ' selected="selected"; '; ?>>Weekly</option>
                                        <option value="2weeks" <?php if (isset($settings['FREQ_AFTER_DUE']) && $settings['FREQ_AFTER_DUE'] == "2weeks" ) echo ' selected="selected"; '; ?>>Bi-Weekly</option>
                                        <option value="monthly" <?php if (isset($settings['FREQ_AFTER_DUE']) && $settings['FREQ_AFTER_DUE'] == "monthly" ) echo ' selected="selected"; '; ?>>Monthly</option>
	        		</select>

                        </div>



                        <?php if(!isset($settings['DAYS_AFTER_DUE_VALUE'])){$settings['DAYS_AFTER_DUE_VALUE']=0;} ?>
                        <div class="col-md-3 form-group">
                            <label>Times After Due Date</label>
                            <input class="form-control" id="days_after_due_check" name="days_after_due_value" type="text" value="<?php if($settings['DAYS_AFTER_DUE_VALUE']){echo $settings['DAYS_AFTER_DUE_VALUE'];}else {echo "0";} ?>">

                        </div>
                        <?php if(!isset($settings['INVOICETAXES'])){$settings['INVOICETAXES']=0;} ?>
                        <div class="col-md-3 form-group">
                            <label>Default Invoice Tax %:</label>
                                <select id="INVOICETAXES" name="INVOICETAXES" class="form-control" >
                                    <?php for($i=0;$i<=90;$i++){echo '<option value="'.$i.'"';if($settings['INVOICETAXES']==$i)echo ' selected';echo '>'.$i.'</option>';} ?>
                                </select>
                        </div>
                        <?php endif; ?>

                        </div>

                        <div class="hr-line-dashed"></div>
                        <div class="row">
                            <div class="col-md-2 col-xs-5">
                                <button class="btn btn-primary btn-full" type="submit">Save Settings</button>
                            </div>
                            <div class="col-md-10 col-xs-7">
                                <?php if($level!='M'): ?>
                                <div class="checkbox checkbox-success">
                                    <input type="checkbox"  class="styled" value="on" id="propagate" name="propagate"  style="cursor:pointer" >
                                    <label for="propagate" style="cursor:pointer">
                                        Apply these settings to all levels below this one.
                                    </label>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        </form>

        </div>
    </div>
</div>
    <script>
        function verifyacc(){
            verifynoreg();
            if($("#payment_numbers").is(":checked")){
                $("#NONEWUSER").prop("checked",true);
            }
        }
        
        function verifynoreg(){
            if($("#notreg").is(":checked")){
                $("#payment_numbers").prop("checked",false);
                $("#manager_approval_not_required").prop("checked",false);
            }
        }
        
        $(document).ready(function(){
            verifyacc();
        });
    </script>

@endsection