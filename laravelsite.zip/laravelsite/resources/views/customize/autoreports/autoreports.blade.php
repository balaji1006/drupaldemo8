@extends('layouts.master')
@section('title','Automated Report')
@section('export-excel-url',route('export',['type'=>'excel','sheetname'=>'AutomatedReport','sqlEncrypted'=>$sqlEncrypted,'token'=>$token]))
@section('export-csv-url',route('export',['type'=>'csv','sheetname'=>'AutomatedReport','sqlEncrypted'=>$sqlEncrypted,'token'=>$token]))
@section('content')
<div class="normalheader">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <div class="pull-right">
                <a class="btn btn-success margint-10" href="{{route('autoreportnew', array('token' => $token))}}">
                    <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> New Report
                </a>
            </div>
            <h2 class="font-light m-b-xs">
                Automated Report
            </h2>
            <small>
                <ol class="hbreadcrumb breadcrumb">
                    <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                    <li class="active">
                        <span>Automated Report</span>
                    </li>
                </ol>
            </small>
        </div>

    </div>
</div>
<div class="content">
    <div class="hpanel">
        <div class="panel-body">

            <div class="panel panel-default" style="border: none; box-shadow: none; background-color: #F4F4F4; padding: 15px">
                <div class="panel-body" style="font-size: 12px">
                    <h4>Please Note</h4>
                    <span>The transaction report is in MST, some transactions in your reports may have their time stamps changed to reflect a different time zone.</span><br><br>
                </div>
            </div>
            <br/>


            <div class="row marginb-20">
                @include('components.itemspage')
                <div class="col-md-9 col-xs-4 text-center rapyd-filters" id="filtersAndExportDiv">
                    {!! $filter !!}
                    @include('components.advancedFilters')
                </div>
            </div>

            {!! $grid !!}
        </div>
        <div class="panel-footer">
        </div>
    </div>
</div>



<div id="download_modal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Download Report</h4>
            </div>
            <div id="download_body" class="modal-body">
                aaaaaa
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    function _delete(token, id) {
        swal({
                    title: "Are you sure?",
                    text: "Confirm that you want to delete the automated report!",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Yes, cancel it!"
                },
                function () {
                    route = "<?php echo route('autoreportsdelete', array('token' => $token, 'id' => '000000000000000')); ?>"
                    route = route.replace('/000000000000000', '/' + id);
                    window.location.href = route;
                });
    }

    function _edit(token) {

        route = "<?php echo route('autoreportsedit', array('id' => 0, 'token' => $token)); ?>"
        route = route.replace('/0', '/' + token);
        window.location = route;
    }

    function _download(token) {

        route = "<?php echo route('autoreportsdownload', array('token' => $token)); ?>"
        route = route.replace('/0', '/' + token);
        $.ajax({
            url: route,
        }).done(function (response) {
            $('#download_body').html(response);
            $('#download_modal').modal('show');
        });
    }

    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
        $('#advancedFiltersBtn').hide();
        $('#filtersAndExportDiv').removeClass('col-md-9').addClass('col-md-8');
        $('#exportDropdownDiv').removeClass('col-md-2').addClass('col-md-3');
    });
</script>

@endsection