<?php $active_submenu = 'autoreport'; ?>
@extends('layouts.master')
@section('title','Automated Report')
@section('content')
<div class="normalheader">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <h2 class="font-light m-b-xs">
                New Automated Report
            </h2>
            <small>
                <ol class="hbreadcrumb breadcrumb">
                    <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                    <li><a href="<?php echo route('autoreport', array('token' => $token)); ?>">Automated Report</a></li>
                    <li class="active">
                        <span>Automated Report</span>
                    </li>
                </ol>
            </small>
        </div>
    </div>
</div>
<div class="content">
    <div class="hpanel">
        <div class="panel-body">
            <?php echo Form::open(['route' => ['autoreportnewstore', $token], 'method' => 'POST', 'id' => 'form']); ?>
            <input name="token" type="hidden" value="<?php echo $token; ?>">
            <div class="col-xs-12">
                @include('components.validationError')
                <br/>
                <div class="row form-group">
                    <div class="col-sm-3">
                        <label>Type</label>
                        <?php
                        $reportslist = array(
                            '' => 'Select',
                            '1' => 'Transaction (TOPS)',
                            '2' => 'Transaction (CSV)',
                            '3' => 'Deposits (TOPS)',
                            '4' => 'Deposits (CSV)',
                            '5' => 'Deposits Batch (CSV)',
                            '6' => 'Autopayments (CSV)',
                            '7' => 'Autopayment (Summary) (CSV)',
                            '8' => 'Transaction (Summary) (CSV)',
                            '9' => 'Returned (CSV)',
                            '10' => 'Transactions (CALIBER)',
                            '11' => 'Transactions (Regular Lockbox file)',
                            '12' => 'Deposits (Regular Lockbox file)',
                            '13' => 'Transactions (JENARK)',
                            '14' => 'Deposit (JENARK)',
                            '15' => 'Transactions (JENARK EC CC)',
                        );

                        if ($level == 'M') {
                            foreach ($reports as $rep) {
                                unset($reportslist[$rep->type]);
                            }
                        }

                        if (isset($settings['EXAUTO'])) {
                            if ($settings['EXAUTO'] != '') {
                                $exauto = explode('|', $settings['EXAUTO']);
                                foreach ($exauto as $xxidx) {
                                    unset($reportslist[$xxidx]);
                                }
                            }
                        }
                        echo Form::select('type', $reportslist, '', array('class' => 'form-control', 'required' => true, 'id' => 'typereport'));
                        ?>
                    </div>
                    <div class="col-sm-3">
                        <label>Frequency</label>
                        <?php
                        echo Form::select('frequency', array(
                            '' => 'Select',
                            'days' => 'Daily',
                            'weeks' => 'Weekly (Friday)',
                            'months' => 'Monthly (end of month)',
                                ), null, array('class' => 'form-control', 'required' => true));
                        ?>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-6">
                                <label>Time</label>
                                <?php
                                echo Form::select('time', array(
                                    '' => 'Select',
                                    '1000' => '10:00am',
                                    '1100' => '11:00am',
                                    '1200' => '12:00pm',
                                    '1300' => '1:00pm',
                                    '1400' => '2:00pm',
                                    '1500' => '3:00pm',
                                    '1600' => '4:00pm',
                                    '1700' => '5:00pm',
                                    '1800' => '6:00pm',
                                    '1900' => '7:00pm',
                                    '2000' => '8:00pm',
                                    '2100' => '9:00pm',
                                    '2200' => '10:00pm',
                                    '2300' => '11:00pm',
                                    '2400' => 'Mid night',
                                        ), null, array('class' => 'form-control', 'required' => true));
                                ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Time Zone</label>
                                <?php
                                echo Form::select('timezone', array(
                                    '' => 'Select',
                                    '0' => 'EST',
                                    '1' => 'CST',
                                    '2' => 'MST',
                                    '3' => 'PST',
                                        ), null, array('class' => 'form-control', 'required' => true));
                                ?>
                            </div>
                        </div>

                    </div>

                    <div style="display: none" id="splitpmcont" class="col-sm-3">
                        <label>
                            <br/>
                            <br/>
                            <input id="splitpm" name="splitpm" type="checkbox">
                            Split per Payment Methods</label>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-6">
                        <label>Email</label>
                        <?php echo Form::text('email', null, array('class' => 'form-control', 'required' => true)); ?>
                    </div>
                    <div class="col-sm-6">
                        <div class="">
                            <label>Use this field to identify the Merchant</label>
                            <br/>
                            <ul class="list-inline" style="margin: 10px 0 0 0;">
                                <li>
                                    <div class="radio radio-success">
                                        <?php echo Form::radio('identify_merchant', '0', true); ?>
                                        <label class="small"> RevoPay ID</label>
                                    </div>
                                </li>
                                <li>
                                    <div class="radio radio-success">
                                        <?php echo Form::radio('identify_merchant', '1'); ?>
                                    <label class="small"> Lockbox ID</label>
                                    </div>
                                </li>
                                <li>
                                    <div class="radio radio-success">
                                        <?php echo Form::radio('identify_merchant', '2'); ?>
                                        <label class="small">Misc ID</label>
                                    </div>
                                </li>
                                <li>
                                    <div class="radio radio-success">
                                        <?php echo Form::radio('identify_merchant', '3'); ?>
                                        <label class="small">Bank ID</label>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php if ($level != 'M') { ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <label>Scope</label>
                            <div class="alert alert-info" role="alert">
                                <?php
                                if ($level == 'P') {
                                    echo 'By default, all companies / groups listed below are included in the report.';
                                } else {
                                    echo 'By default, all companies / merchants listed below are included in the report.';
                                }
                                ?>
                                <a style="cursor: pointer; font-weight: bold" data-toggle="collapse" data-target="#collapse">Click here to expand the list</a>
                            </div>


                            <?php
                            $rows = ceil(count($scopes) / 3);
                            ?>
                            <div id="collapse" class="panel panel-default collapse" style="border: none; box-shadow: none!important; background-color: #F4F4F4; padding: 15px">
                                <div class="panel-body" style="font-size: 12px">
                                    <div class="row">
                                        <?php
                                        $count = 1;
                                        for ($a = 1; $a <= $rows; $a++) {
                                            for ($b = $count; $b <= count($scopes); $b++) {
                                                ?>
                                                <div class="col-sm-4">
                                                    <div><label>
                                                            <?php
                                                            $checked = '';
                                                            if (Input::old('checkbox_' . $scopes[$count - 1]->id)) {
                                                                $checked = 'checked = "checked"';
                                                            }

                                                            switch ($level) {
                                                                case 'P':
                                                                    echo '<input type="checkbox" ' . $checked . ' name="checkbox_' . $scopes[$count - 1]->id . '" value="' . $scopes[$count - 1]->id . '"> ' . $scopes[$count - 1]->company_name;
                                                                    break;
                                                                case 'G':
                                                                    echo '<input type="checkbox" ' . $checked . ' name="checkbox_' . $scopes[$count - 1]->id . '" value="' . $scopes[$count - 1]->id . '"> ' . $scopes[$count - 1]->name_clients;
                                                                    break;
                                                                case 'M':

                                                                    break;
                                                            }
                                                            ?>
                                                        </label></div>
                                                </div>
                                                <?php
                                                $count++;
                                                if ($b % 3 == 0) {
                                                    break;
                                                }
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <div class="hr-line-dashed"></div>
                <div class="form-group">
                    <a class="btn btn-default" href="<?php echo route('autoreport', array('token'=>$token));?>">Cancel</a>
                    <button id="submitbtn" class="btn btn-primary" type="submit">Create New Report</button>
                </div>
            </div>
            </form>
        </div>

    </div>
</div>

<?php
$popuphdr = 'Alert!';
$popupcontent = 'Our system has detected that this type of report has been selected by multiple administrative users, which could cause reporting errors. Please review the property selections for each report to confirm that the same property has been selected by multiple users.';
?>
@include('popup.popupsuccess')
<script src="{{ asset('js/jquery.validate.min.js') }}"></script>
<script>
    jQuery.validator.addMethod("multipleEmailValidFn", function(value, element) {
                            return this.optional(element) || /^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;](([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+)*$/.test(value);
                        }, "This field has errors.");
    $("#form").validate({
        //debug: true,
        ignore: '*:not([name])',
        rules: {
          email: {required:true, multipleEmailValidFn:true}  
        },
        errorPlacement: function(error, element) {
           error.insertBefore(element);
        },
        errorElement: "span"
    });
    var preselected = Array();
<?php
foreach ($reports as $rep) {
    echo 'preselected.push(' . $rep->type . ');';
}
?>
    $('#typereport').change(function () {
        val = $(this).val();
        if (val == 2 || val == 10 || val == 13 || val == 14 || val == 15) {
            $('#splitpm').removeAttr('disabled');
            $('#splitpmcont').show();
        } else {
            $('#splitpmcont').hide();
            $('#splitpm').attr('disabled', 'disabled');
        }
<?php if ($level != 'M' && count($reports) > 0): ?>
            if ($.inArray(parseInt(val), preselected) > -1) {
                $('#myModal_success').modal();
            }
<?php endif; ?>
    });
</script>
@endsection