<div class="row">
    <div class="col-md-5 form-group">
        <label>Title or Name</label>
        <input type="text" name="partner_title" class="form-control" placeholder="Input the Title for this vertical" value="<?php if (isset($partner_title)) {
            echo $partner_title;
        } ?>" >
    </div>
</div>

<div class="row">
    <div class="col-md-5 form-group">
        <label>Identifier (ID)</label>
        <input type="text" name="partner_composite_id" class="form-control" placeholder="Input the identifier for this vertical" value="<?php if (isset($partner_composite_id)) {
            echo $partner_composite_id;
        } ?>" >
    </div>
    </div>

<div class="row">
    <div class="col-md-5 form-group">
        <label>Vertical Layout to apply</label>
        <select name="layout_id" class="form-control">
            <option value="1" <?php if (isset($layout_id) && $layout_id == 1) {
                echo 'selected';
            } ?>>Property</option>
            <option value="2" <?php if (isset($layout_id) && $layout_id == 2) {
                echo 'selected';
            } ?>>Academic</option>
            <option value="6" <?php if (isset($layout_id) && $layout_id == 6) {
                echo 'selected';
            } ?>>B2B</option>
            <option value="13" <?php if (isset($layout_id) && $layout_id == 13) {
                echo 'selected';
            } ?>>Non-Profit</option>
            <option value="14" <?php if (isset($layout_id) && $layout_id == 14) {
                echo 'selected';
            } ?>>Utility</option>
            <option value="15" <?php if (isset($layout_id) && $layout_id == 15) {
                echo 'selected';
            } ?>>B2C</option>
        </select>
    </div>

</div>

<div class="row">
    <div class="col-md-2 form-group">
        <label>Upload Logo</label>
        <input type="file" name="logo" id="file" onchange="return fileValidation()">
    </div>
    <div class="col-md-2" id="imagePreview">
        <label>&nbsp;</label><br/>
        <?php if (isset($logo) && $logo != "") {
            echo '<img style="max-width: 100px;" src="'.asset($logo).'"/>';
        } ?>
    </div>
</div>

<script type="text/javascript" src="<?php echo asset('js/jquery.form.js'); ?>"></script>
<script src="<?php echo asset('js/appvalidation.js'); ?>"></script>
<script src="<?php echo asset('js/appvalidate.js'); ?>"></script>

<script src="<?php echo asset('js/jquery.validate.min.js'); ?>"></script>
<script>

    $("#formNotification").validate({
        ignore: '*:not([name])',
        rules: {
            partner_title: {required: true},
        }
    });

    function fileValidation(){
        var fileInput = document.getElementById('file');
        var filePath = fileInput.value;
        var allowedExtensions = /(.jpg|.jpeg|.png|.gif)$/i;
        if(!allowedExtensions.exec(filePath)){
            swal({
                title: "Error",
                text: "Please upload file having extensions .jpeg/.jpg/.png/.gif only.",
                type: "error"
            });
            fileInput.value = '';
            return false;
        }else{
            //Image preview
            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').innerHTML = '<img src="'+e.target.result+'"/>';
                };
                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    }

</script>