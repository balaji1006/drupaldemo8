<div class="row">
    <div class="col-md-6 form-group">
        <label>Title or Name</label>
        <input type="text" name="name_clients" class="form-control" placeholder="Input the Title for this merchant" value="<?php
        if (isset($name_clients)) {
            echo $name_clients;
        }
        ?>" >
    </div>
    <div class="col-md-6 form-group">
        <label>Identifier (ID)</label>
        <input type="text" name="compositeID_clients" class="form-control" placeholder="Input the identifier for this merchant" value="<?php
        if (isset($compositeID_clients)) {
            echo $compositeID_clients;
        }
        ?>">
    </div>
</div>
<div class="row">
    <div class="col-xs-12 hidden form-group">
        <label>Base Layout to apply</label>
        <select name="playout_id" class="form-control">
            <option value="0" <?php
            if (isset($playout_id) && $playout_id == 0) {
                echo 'selected';
            }
            ?>>Inherit</option>
            <option value="1" <?php
            if (isset($playout_id) && $playout_id == 1) {
                echo 'selected';
            }
            ?>>Property</option>
            <option value="2" <?php
            if (isset($playout_id) && $playout_id == 2) {
                echo 'selected';
            }
            ?>>Academic</option>
            <option value="6" <?php
            if (isset($playout_id) && $playout_id == 6) {
                echo 'selected';
            }
            ?>>B2B</option>
            <option value="13" <?php
            if (isset($playout_id) && $playout_id == 13) {
                echo 'selected';
            }
            ?>>Non-Profit</option>
            <option value="14" <?php
            if (isset($playout_id) && $playout_id == 14) {
                echo 'selected';
            }
            ?>>Utility</option>
            <option value="15" <?php
            if (isset($playout_id) && $playout_id == 15) {
                echo 'selected';
            }
            ?>>B2C</option>
        </select>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
<div class="panel panel-default" style="border: none; box-shadow: none; background-color: #F4F4F4; padding: 15px">
    <div class="panel-body" style="font-size: 12px">
        <h4>Additional Identifiers</h4>
        <span>The parameters below can be inserted in your automated reports.</span><br><br>
        <div class="row">
        <div class="col-md-6 form-group">
            <label>LockBox ID</label>
            <input type="text" class="form-control" name="lockbox_id" placeholder="Lockbox ID" value="<?php
            if (isset($lockbox_id)) {
                echo $lockbox_id;
            }
            ?>" >
        </div>
        <div class="col-md-6  form-group">
            <label>Bank ID</label>
            <input type="text" class="form-control" name="bank_id" placeholder="Bank ID" value="<?php
            if (isset($bank_id)) {
                echo $bank_id;
            }
            ?>" >
        </div>
        <div class="col-md-12  form-group">
            <label>Misc.</label>
            <input type="text" class="form-control" name="misc_field" placeholder="Miscellaneous" value="<?php
            if (isset($misc_field)) {
                echo $misc_field;
            }
            ?>" >
        </div>
        </div>
    </div>
    </div>
</div>
</div>

<div class="row">
    <div class="col-md-4 form-group">
        <label>Contact Name</label>
        <input type="text" class="form-control" name="contact_name_clients" placeholder="Contact Name" value="<?php
        if (isset($contact_name_clients)) {
            echo $contact_name_clients;
        }
        ?>" >
    </div>
    <div class="col-md-4 form-group">
        <label>Contact Email</label>
        <input type="text" class="form-control" name="email_address_clients" placeholder="Contact Email" value="<?php
        if (isset($email_address_clients)) {
            echo $email_address_clients;
        }
        ?>" >
    </div>
    <div class="col-md-4 form-group">
        <label>Accounting Email(s)</label>
        <input type="text" class="form-control" name="accounting_email_address_clients" placeholder="Accounting Email(s)" value="<?php
        if (isset($accounting_email_address_clients)) {
            echo $accounting_email_address_clients;
        }
        ?>" >
    </div>
</div>


<div class="row">
    <div class="col-md-4 form-group">
        <label>Address</label>
        <input type="text" class="form-control" name="address_clients" placeholder="address" value="<?php
        if (isset($address_clients)) {
            echo $address_clients;
        }
        ?>" >
    </div>
    <div class="col-md-2 form-group">
        <label>City</label>
        <input type="text" class="form-control" name="city_clients" placeholder="city" value="<?php
        if (isset($city_clients)) {
            echo $city_clients;
        }
        ?>" >
    </div>
    <div class="col-md-2 form-group">
        <label>State</label>
        <select class="form-control"  id="xstate" name="state_clients">
            <option value="">State</option>
            <option value="AL" <?php
            if (isset($state_clients) && $state_clients == 'AL') {
                echo 'selected';
            }
            ?>>AL</option>
            <option value="AK" <?php
            if (isset($state_clients) && $state_clients == 'AK') {
                echo 'selected';
            }
            ?>>AK</option>
            <option value="AZ" <?php
            if (isset($state_clients) && $state_clients == 'AZ') {
                echo 'selected';
            }
            ?>>AZ</option>
            <option value="AR" <?php
            if (isset($state_clients) && $state_clients == 'AR') {
                echo 'selected';
            }
            ?>>AR</option>
            <option value="CA" <?php
            if (isset($state_clients) && $state_clients == 'CA') {
                echo 'selected';
            }
            ?>>CA</option>
            <option value="CO" <?php
            if (isset($state_clients) && $state_clients == 'CO') {
                echo 'selected';
            }
            ?>>CO</option>
            <option value="CT" <?php
            if (isset($state_clients) && $state_clients == 'CT') {
                echo 'selected';
            }
            ?>>CT</option>
            <option value="DE" <?php
            if (isset($state_clients) && $state_clients == 'DE') {
                echo 'selected';
            }
            ?>>DE</option>
            <option value="DC" <?php
            if (isset($state_clients) && $state_clients == 'DC') {
                echo 'selected';
            }
            ?>>DC</option>
            <option value="FL" <?php
            if (isset($state_clients) && $state_clients == 'FL') {
                echo 'selected';
            }
            ?>>FL</option>
            <option value="GA" <?php
            if (isset($state_clients) && $state_clients == 'GA') {
                echo 'selected';
            }
            ?>>GA</option>
            <option value="HI" <?php
            if (isset($state_clients) && $state_clients == 'HI') {
                echo 'selected';
            }
            ?>>HI</option>
            <option value="ID" <?php
            if (isset($state_clients) && $state_clients == 'ID') {
                echo 'selected';
            }
            ?>>ID</option>
            <option value="IL" <?php
            if (isset($state_clients) && $state_clients == 'IL') {
                echo 'selected';
            }
            ?>>IL</option>
            <option value="IN" <?php
            if (isset($state_clients) && $state_clients == 'IN') {
                echo 'selected';
            }
            ?>>IN</option>
            <option value="IA" <?php
            if (isset($state_clients) && $state_clients == 'IA') {
                echo 'selected';
            }
            ?>>IA</option>
            <option value="KS" <?php
            if (isset($state_clients) && $state_clients == 'KS') {
                echo 'selected';
            }
            ?>>KS</option>
            <option value="KY" <?php
            if (isset($state_clients) && $state_clients == 'KY') {
                echo 'selected';
            }
            ?>>KY</option>
            <option value="LA" <?php
            if (isset($state_clients) && $state_clients == 'LA') {
                echo 'selected';
            }
            ?>>LA</option>
            <option value="MA" <?php
            if (isset($state_clients) && $state_clients == 'MA') {
                echo 'selected';
            }
            ?>>MA</option>
            <option value="ME" <?php
            if (isset($state_clients) && $state_clients == 'ME') {
                echo 'selected';
            }
            ?>>ME</option>
            <option value="MD" <?php
            if (isset($state_clients) && $state_clients == 'MD') {
                echo 'selected';
            }
            ?>>MD</option>
            <option value="MI" <?php
            if (isset($state_clients) && $state_clients == 'MI') {
                echo 'selected';
            }
            ?>>MI</option>
            <option value="MN" <?php
            if (isset($state_clients) && $state_clients == 'MN') {
                echo 'selected';
            }
            ?>>MN</option>
            <option value="MS" <?php
            if (isset($state_clients) && $state_clients == 'MS') {
                echo 'selected';
            }
            ?>>MS</option>
            <option value="MO" <?php
            if (isset($state_clients) && $state_clients == 'MO') {
                echo 'selected';
            }
            ?>>MO</option>
            <option value="MT" <?php
            if (isset($state_clients) && $state_clients == 'MT') {
                echo 'selected';
            }
            ?>>MT</option>
            <option value="NE" <?php
            if (isset($state_clients) && $state_clients == 'NE') {
                echo 'selected';
            }
            ?>>NE</option>
            <option value="NV" <?php
            if (isset($state_clients) && $state_clients == 'NV') {
                echo 'selected';
            }
            ?>>NV</option>
            <option value="NH" <?php
            if (isset($state_clients) && $state_clients == 'NH') {
                echo 'selected';
            }
            ?>>NH</option>
            <option value="NJ" <?php
            if (isset($state_clients) && $state_clients == 'NJ') {
                echo 'selected';
            }
            ?>>NJ</option>
            <option value="NM" <?php
            if (isset($state_clients) && $state_clients == 'NM') {
                echo 'selected';
            }
            ?>>NM</option>
            <option value="NY" <?php
            if (isset($state_clients) && $state_clients == 'NY') {
                echo 'selected';
            }
            ?>>NY</option>
            <option value="NC" <?php
            if (isset($state_clients) && $state_clients == 'NC') {
                echo 'selected';
            }
            ?>>NC</option>
            <option value="ND" <?php
            if (isset($state_clients) && $state_clients == 'ND') {
                echo 'selected';
            }
            ?>>ND</option>
            <option value="OH" <?php
            if (isset($state_clients) && $state_clients == 'OH') {
                echo 'selected';
            }
            ?>>OH</option>
            <option value="OK" <?php
            if (isset($state_clients) && $state_clients == 'OK') {
                echo 'selected';
            }
            ?>>OK</option>
            <option value="OR" <?php
            if (isset($state_clients) && $state_clients == 'OR') {
                echo 'selected';
            }
            ?>>OR</option>
            <option value="PA" <?php
            if (isset($state_clients) && $state_clients == 'PA') {
                echo 'selected';
            }
            ?>>PA</option>
            <option value="RI" <?php
            if (isset($state_clients) && $state_clients == 'RI') {
                echo 'selected';
            }
            ?>>RI</option>
            <option value="SC" <?php
            if (isset($state_clients) && $state_clients == 'SC') {
                echo 'selected';
            }
            ?>>SC</option>
            <option value="SD" <?php
            if (isset($state_clients) && $state_clients == 'SD') {
                echo 'selected';
            }
            ?>>SD</option>
            <option value="TN" <?php
            if (isset($state_clients) && $state_clients == 'TN') {
                echo 'selected';
            }
            ?>>TN</option>
            <option value="TX" <?php
            if (isset($state_clients) && $state_clients == 'TX') {
                echo 'selected';
            }
            ?>>TX</option>
            <option value="UT" <?php
            if (isset($state_clients) && $state_clients == 'UT') {
                echo 'selected';
            }
            ?>>UT</option>
            <option value="VT" <?php
            if (isset($state_clients) && $state_clients == 'VT') {
                echo 'selected';
            }
            ?>>VT</option>
            <option value="VA" <?php
            if (isset($state_clients) && $state_clients == 'VA') {
                echo 'selected';
            }
            ?>>VA</option>
            <option value="WA" <?php
            if (isset($state_clients) && $state_clients == 'WA') {
                echo 'selected';
            }
            ?>>WA</option>
            <option value="WV" <?php
            if (isset($state_clients) && $state_clients == 'WV') {
                echo 'selected';
            }
            ?>>WV</option>
            <option value="WI" <?php
            if (isset($state_clients) && $state_clients == 'WI') {
                echo 'selected';
            }
            ?>>WI</option>
            <option value="WY" <?php
            if (isset($state_clients) && $state_clients == 'WY') {
                echo 'selected';
            }
            ?>>WY</option>
            <option value="PR" <?php
            if (isset($state_clients) && $state_clients == 'PR') {
                echo 'selected';
            }
            ?>>PR</option>
        </select>
    </div>
    <div class="col-md-2 form-group">
        <label>Zip</label>
        <input type="text" class="form-control" name="zip_clients" placeholder="zip" value="<?php
        if (isset($zip_clients)) {
            echo $zip_clients;
        }
        ?>" >
    </div>
    <div class="col-md-2 form-group">
        <label>Phone</label>
        <input type="text" class="form-control" name="phone_clients" placeholder="Phone Number" value="<?php
        if (isset($phone_clients)) {
            echo $phone_clients;
        }
        ?>" >
    </div>
</div>


<div class="row">
    <div class="col-md-2 form-group">
        <label>Upload Logo</label>
        <input type="file" name="logo" id="file" onchange="return fileValidation()">
    </div>
    <div class="col-md-2" id="imagePreview">
        <label>&nbsp;</label><br/>
        <?php if (isset($logo) && $logo != "") {
            echo '<img style="max-width: 100px;" src="'.asset($logo).'"/>';
        } ?>
    </div>
</div>

<script type="text/javascript" src="<?php echo asset('js/jquery.form.js'); ?>"></script>
<script src="<?php echo asset('js/appvalidation.js'); ?>"></script>
<script src="<?php echo asset('js/appvalidate.js'); ?>"></script>

<script src="<?php echo asset('js/jquery.validate.min.js'); ?>"></script>
<script>

    $("#formNotification").validate({
        ignore: '*:not([name])',
        rules: {
            name_clients: {required: true},
            email_address_clients: {email: true},
            accounting_email_address_clients: {email: true},
            zip_clients: {
                number:true,
                maxlength: 5,
                minlength: 5
            },
            phone_clients:{
                number:true,
            },

        }
    });

    function fileValidation(){
        var fileInput = document.getElementById('file');
        var filePath = fileInput.value;
        var allowedExtensions = /(.jpg|.jpeg|.png|.gif)$/i;
        if(!allowedExtensions.exec(filePath)){
            swal({
                title: "Error",
                text: "Please upload file having extensions .jpeg/.jpg/.png/.gif only.",
                type: "error"
            });
            fileInput.value = '';
            return false;
        }else{
            //Image preview
            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').innerHTML = '<img src="'+e.target.result+'"/>';
                };
                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    }

</script>