<div class="row">
    <div class="col-md-4 form-group">
        <label>Title or Name</label>
        <input type="text" name="company_name" class="form-control" placeholder="Input the Title for this group" value="<?php
        if (isset($company_name)) {
            echo $company_name;
        }
        ?>" >
    </div>
    <div class="col-md-4 form-group">
        <label>Identifier (ID)</label>
        <input type="text" name="compositeID_companies" class="form-control" placeholder="Input the identifier for this group" value="<?php
        if (isset($compositeID_companies)) {
            echo $compositeID_companies;
        }
        ?>" >
    </div>
</div>


<div class="row hidden">
    <div class="col-md-4 form-group">
        <label>Base Layout to apply</label>
        <select name="clayout_id" class="form-control">
            <option value="0" <?php
            if (isset($clayout_id) && $clayout_id == 0) {
                echo 'selected';
            }
            ?>>Inherit</option>
            <option value="1" <?php
            if (isset($clayout_id) && $clayout_id == 1) {
                echo 'selected';
            }
            ?>>Property</option>
            <option value="2" <?php
            if (isset($clayout_id) && $clayout_id == 2) {
                echo 'selected';
            }
            ?>>Academic</option>
            <option value="6" <?php
            if (isset($clayout_id) && $clayout_id == 6) {
                echo 'selected';
            }
            ?>>B2B</option>
            <option value="13" <?php
            if (isset($clayout_id) && $clayout_id == 13) {
                echo 'selected';
            }
            ?>>Non-Profit</option>
            <option value="14" <?php
            if (isset($clayout_id) && $clayout_id == 14) {
                echo 'selected';
            }
            ?>>Utility</option>
            <option value="15" <?php
            if (isset($clayout_id) && $clayout_id == 15) {
                echo 'selected';
            }
            ?>>B2C</option>
        </select>
    </div>
</div>
<div class="row">
    <div class="col-md-3 form-group">
        <label>Contact Name</label>
        <input type="text" class="form-control" name="contact_name" placeholder="Contact Name" value="<?php
        if (isset($contact_name)) {
            echo $contact_name;
        }
        ?>" >
    </div>
    <div class="col-md-3 form-group">
        <label>Contact Email</label>
        <input type="text" class="form-control" name="contact_email" placeholder="Contact Email" value="<?php
        if (isset($contact_email)) {
            echo $contact_email;
        }
        ?>" >
    </div>
    <div class="col-md-2 form-group">
        <label>Phone</label>
        <input type="text" class="form-control" name="phone_number" placeholder="Phone Number" value="<?php
        if (isset($phone_number)) {
            echo $phone_number;
        }
        ?>" >
    </div>
</div>


<div class="row">
    <div class="col-md-2 form-group">
        <label>Address</label>
        <input type="text" class="form-control" name="address" placeholder="address" value="<?php
        if (isset($address)) {
            echo $address;
        }
        ?>" >
    </div>
    <div class="col-md-2 form-group">
        <label>City</label>
        <input type="text" class="form-control" name="city" placeholder="city" value="<?php
        if (isset($city)) {
            echo $city;
        }
        ?>" >
    </div>
    <div class="col-md-2 form-group">
        <label>State</label>
        <select class="form-control"  id="xstate" name="state">
            <option value="">State</option>
            <option value="AL" <?php
            if (isset($state) && $state == 'AL') {
                echo 'selected';
            }
            ?>>AL</option>
            <option value="AK" <?php
            if (isset($state) && $state == 'AK') {
                echo 'selected';
            }
            ?>>AK</option>
            <option value="AZ" <?php
            if (isset($state) && $state == 'AZ') {
                echo 'selected';
            }
            ?>>AZ</option>
            <option value="AR" <?php
            if (isset($state) && $state == 'AR') {
                echo 'selected';
            }
            ?>>AR</option>
            <option value="CA" <?php
            if (isset($state) && $state == 'CA') {
                echo 'selected';
            }
            ?>>CA</option>
            <option value="CO" <?php
            if (isset($state) && $state == 'CO') {
                echo 'selected';
            }
            ?>>CO</option>
            <option value="CT" <?php
            if (isset($state) && $state == 'CT') {
                echo 'selected';
            }
            ?>>CT</option>
            <option value="DE" <?php
            if (isset($state) && $state == 'DE') {
                echo 'selected';
            }
            ?>>DE</option>
            <option value="DC" <?php
            if (isset($state) && $state == 'DC') {
                echo 'selected';
            }
            ?>>DC</option>
            <option value="FL" <?php
            if (isset($state) && $state == 'FL') {
                echo 'selected';
            }
            ?>>FL</option>
            <option value="GA" <?php
            if (isset($state) && $state == 'GA') {
                echo 'selected';
            }
            ?>>GA</option>
            <option value="HI" <?php
            if (isset($state) && $state == 'HI') {
                echo 'selected';
            }
            ?>>HI</option>
            <option value="ID" <?php
            if (isset($state) && $state == 'ID') {
                echo 'selected';
            }
            ?>>ID</option>
            <option value="IL" <?php
            if (isset($state) && $state == 'IL') {
                echo 'selected';
            }
            ?>>IL</option>
            <option value="IN" <?php
            if (isset($state) && $state == 'IN') {
                echo 'selected';
            }
            ?>>IN</option>
            <option value="IA" <?php
            if (isset($state) && $state == 'IA') {
                echo 'selected';
            }
            ?>>IA</option>
            <option value="KS" <?php
            if (isset($state) && $state == 'KS') {
                echo 'selected';
            }
            ?>>KS</option>
            <option value="KY" <?php
            if (isset($state) && $state == 'KY') {
                echo 'selected';
            }
            ?>>KY</option>
            <option value="LA" <?php
            if (isset($state) && $state == 'LA') {
                echo 'selected';
            }
            ?>>LA</option>
            <option value="MA" <?php
            if (isset($state) && $state == 'MA') {
                echo 'selected';
            }
            ?>>MA</option>
            <option value="ME" <?php
            if (isset($state) && $state == 'ME') {
                echo 'selected';
            }
            ?>>ME</option>
            <option value="MD" <?php
            if (isset($state) && $state == 'MD') {
                echo 'selected';
            }
            ?>>MD</option>
            <option value="MI" <?php
            if (isset($state) && $state == 'MI') {
                echo 'selected';
            }
            ?>>MI</option>
            <option value="MN" <?php
            if (isset($state) && $state == 'MN') {
                echo 'selected';
            }
            ?>>MN</option>
            <option value="MS" <?php
            if (isset($state) && $state == 'MS') {
                echo 'selected';
            }
            ?>>MS</option>
            <option value="MO" <?php
            if (isset($state) && $state == 'MO') {
                echo 'selected';
            }
            ?>>MO</option>
            <option value="MT" <?php
            if (isset($state) && $state == 'MT') {
                echo 'selected';
            }
            ?>>MT</option>
            <option value="NE" <?php
            if (isset($state) && $state == 'NE') {
                echo 'selected';
            }
            ?>>NE</option>
            <option value="NV" <?php
            if (isset($state) && $state == 'NV') {
                echo 'selected';
            }
            ?>>NV</option>
            <option value="NH" <?php
            if (isset($state) && $state == 'NH') {
                echo 'selected';
            }
            ?>>NH</option>
            <option value="NJ" <?php
            if (isset($state) && $state == 'NJ') {
                echo 'selected';
            }
            ?>>NJ</option>
            <option value="NM" <?php
            if (isset($state) && $state == 'NM') {
                echo 'selected';
            }
            ?>>NM</option>
            <option value="NY" <?php
            if (isset($state) && $state == 'NY') {
                echo 'selected';
            }
            ?>>NY</option>
            <option value="NC" <?php
            if (isset($state) && $state == 'NC') {
                echo 'selected';
            }
            ?>>NC</option>
            <option value="ND" <?php
            if (isset($state) && $state == 'ND') {
                echo 'selected';
            }
            ?>>ND</option>
            <option value="OH" <?php
            if (isset($state) && $state == 'OH') {
                echo 'selected';
            }
            ?>>OH</option>
            <option value="OK" <?php
            if (isset($state) && $state == 'OK') {
                echo 'selected';
            }
            ?>>OK</option>
            <option value="OR" <?php
            if (isset($state) && $state == 'OR') {
                echo 'selected';
            }
            ?>>OR</option>
            <option value="PA" <?php
            if (isset($state) && $state == 'PA') {
                echo 'selected';
            }
            ?>>PA</option>
            <option value="RI" <?php
            if (isset($state) && $state == 'RI') {
                echo 'selected';
            }
            ?>>RI</option>
            <option value="SC" <?php
            if (isset($state) && $state == 'SC') {
                echo 'selected';
            }
            ?>>SC</option>
            <option value="SD" <?php
            if (isset($state) && $state == 'SD') {
                echo 'selected';
            }
            ?>>SD</option>
            <option value="TN" <?php
            if (isset($state) && $state == 'TN') {
                echo 'selected';
            }
            ?>>TN</option>
            <option value="TX" <?php
            if (isset($state) && $state == 'TX') {
                echo 'selected';
            }
            ?>>TX</option>
            <option value="UT" <?php
            if (isset($state) && $state == 'UT') {
                echo 'selected';
            }
            ?>>UT</option>
            <option value="VT" <?php
            if (isset($state) && $state == 'VT') {
                echo 'selected';
            }
            ?>>VT</option>
            <option value="VA" <?php
            if (isset($state) && $state == 'VA') {
                echo 'selected';
            }
            ?>>VA</option>
            <option value="WA" <?php
            if (isset($state) && $state == 'WA') {
                echo 'selected';
            }
            ?>>WA</option>
            <option value="WV" <?php
            if (isset($state) && $state == 'WV') {
                echo 'selected';
            }
            ?>>WV</option>
            <option value="WI" <?php
            if (isset($state) && $state == 'WI') {
                echo 'selected';
            }
            ?>>WI</option>
            <option value="WY" <?php
            if (isset($state) && $state == 'WY') {
                echo 'selected';
            }
            ?>>WY</option>
            <option value="PR" <?php
            if (isset($state) && $state == 'PR') {
                echo 'selected';
            }
            ?>>PR</option>
        </select>
    </div>
    <div class="col-md-2 form-group">
        <label>Zip</label>
        <input type="text" class="form-control" name="zip" placeholder="zip" value="<?php
        if (isset($zip)) {
            echo $zip;
        }
        ?>" >
    </div>
</div>

<div class="row">
    <div class="col-md-2 form-group">
        <label>Upload Logo</label>
        <input type="file" name="logo" id="file" onchange="return fileValidation()">
    </div>
    <div class="col-md-2" id="imagePreview">
        <label>&nbsp;</label><br/>
        <?php if (isset($logo) && $logo != "") {
            echo '<img style="max-width: 100px;" src="'.asset($logo).'"/>';
        } ?>
    </div>
</div>

<script type="text/javascript" src="<?php echo asset('js/jquery.form.js'); ?>"></script>
<script src="<?php echo asset('js/appvalidation.js'); ?>"></script>
<script src="<?php echo asset('js/appvalidate.js'); ?>"></script>

<script src="<?php echo asset('js/jquery.validate.min.js'); ?>"></script>
<script>

    $("#formNotification").validate({
        ignore: '*:not([name])',
        rules: {
            company_name: {required: true},
            zip: {
                number:true,
                maxlength: 5,
                minlength: 5
            },
            contact_email: {
                email:true,
            },
            phone_number:{
                number:true,
            },

        }
    });

    function fileValidation(){
        var fileInput = document.getElementById('file');
        var filePath = fileInput.value;
        var allowedExtensions = /(.jpg|.jpeg|.png|.gif)$/i;
        if(!allowedExtensions.exec(filePath)){
            swal({
                title: "Error",
                text: "Please upload file having extensions .jpeg/.jpg/.png/.gif only.",
                type: "error"
            });
            fileInput.value = '';
            return false;
        }else{
            //Image preview
            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').innerHTML = '<img src="'+e.target.result+'"/>';
                };
                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    }

</script>