@extends('layouts.master')
@section('title','My Info')
@section('content')
<div class="normalheader">
    <div class="hpanel">
        <div class="panel-body">
            <a class="small-header-action" href="">
                <div class="clip-header">
                    <i class="fa fa-arrow-up"></i>
                </div>
            </a>
            <?php if(isset($clickroute) && $clickroute){ ?>
            <div class="pull-right">
                <a href="<?php echo $clickroute; ?>" class="btn btn-success margint-10" target="_blank"><i class="fa fa-external-link"></i> Go to the default landing page</a>
            </div>
            <?php } ?>
            <h2 class="font-light m-b-xs">
                My Info
            </h2>
            <small>
                <ol class="hbreadcrumb breadcrumb">
                    <li><a href="<?php echo route('dashboard', array('token' => $token)); ?>">Dashboard</a></li>
                    <li class="active">
                        <span>My Info</span>
                    </li>
                </ol>
            </small>
        </div>
    </div>
</div>
<div class="content">
<div class="hpanel">
    <div class="panel-body">
        <form method="post" action="<?php echo route('savemyinfo'); ?>" id="formNotification" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" >
            <input type="hidden" name="token" value="{{$token}}" >
            <!--<h1 class="header">My info</h1>-->
            @if($level == 'P')
            @include('customize.myinfo.partner_info')
            @elseif ($level == 'G')
            @include('customize.myinfo.company_info')
            @elseif ($level == 'M')
            @include('customize.myinfo.property_info')
            @endif

            <div class="hr-line-dashed"></div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit">Save Settings</button>
            </div>

        </form>
    </div>
</div>
</div>

@isset($msgCode)

@php
$popuphdr = "Success!";
$popupcontent = "";
@endphp
@include('popup.popupsuccess')
@isset($global_messages[$msgCode]))
@php $popupcontent = $global_messages[$msgCode]; @endphp
@include('components.messages')
@endisset

@isset($msgCode)
<script>
    $('#myModal_success').modal();
</script>
@endisset

@endisset


@endsection